#!/usr/bin/env bash
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="/u01/pg-audit-collector"
SERVICE="/etc/systemd/system/pg-audit-collector.service"

echo "======================================================="
echo " PostgreSQL Audit Collector - One Click Installer"
echo "======================================================="
echo

if [[ "$(id -u)" -ne 0 ]]; then
  echo "ERROR: run this installer as root:"
  echo "  sudo bash install.sh"
  exit 1
fi

echo "[1/8] Installing runtime packages..."
dnf install -y python3 python3-psycopg2

echo "[2/8] Creating /u01 structure..."
install -d -m 0750 -o postgres -g postgres "$DEST"
install -d -m 0750 -o postgres -g postgres "$DEST/state"

echo "[3/8] Installing collector files..."
install -m 0750 -o postgres -g postgres "$SRC/audit_collector.py" "$DEST/audit_collector.py"
install -m 0750 -o postgres -g postgres "$SRC/sync_all_tables.sh" "$DEST/sync_all_tables.sh"

if [[ ! -f "$DEST/collector.env" ]]; then
  install -m 0640 -o postgres -g postgres "$SRC/collector.env" "$DEST/collector.env"
  echo "  Created $DEST/collector.env"
else
  echo "  Existing $DEST/collector.env preserved"
fi

echo "[4/8] Installing ONLY the service file under /etc..."
install -m 0644 "$SRC/pg-audit-collector.service" "$SERVICE"

echo "[5/8] Checking PostgreSQL JSON logging..."
PGDATA_VALUE="$(grep '^PGDATA=' "$DEST/collector.env" | cut -d= -f2-)"
if [[ -z "$PGDATA_VALUE" ]]; then
  echo "ERROR: PGDATA is empty in $DEST/collector.env"
  exit 1
fi

if [[ ! -f "$PGDATA_VALUE/current_logfiles" ]]; then
  echo "WARNING: $PGDATA_VALUE/current_logfiles was not found."
  echo "         Check PGDATA or enable logging_collector/jsonlog."
else
  echo "  current_logfiles found:"
  cat "$PGDATA_VALUE/current_logfiles" || true
fi

echo "[6/8] Testing the SAME local DB connection used by collector..."
PORT="$(grep '^AUDIT_PORT=' "$DEST/collector.env" | cut -d= -f2-)"
ADB="$(grep '^AUDIT_DB=' "$DEST/collector.env" | cut -d= -f2-)"
AUSER="$(grep '^AUDIT_USER=' "$DEST/collector.env" | cut -d= -f2-)"

if sudo -u postgres psql -p "$PORT" -U "$AUSER" -d "$ADB" -Atqc "SELECT 1" >/dev/null; then
  echo "  OK: psql -p $PORT -U $AUSER -d $ADB"
else
  echo
  echo "ERROR: local audit repository connection failed."
  echo "Test this manually:"
  echo "  sudo -u postgres psql -p $PORT -U $AUSER -d $ADB"
  exit 1
fi

echo "[7/8] Checking required repository tables..."
MISSING="$(sudo -u postgres psql -p "$PORT" -U "$AUSER" -d "$ADB" -Atqc "
SELECT string_agg(x, ',')
FROM (
  VALUES
    (CASE WHEN to_regclass('public.audit_targets') IS NULL THEN 'audit_targets' END),
    (CASE WHEN to_regclass('public.audit_history') IS NULL THEN 'audit_history' END)
) v(x)
WHERE x IS NOT NULL;
")"

if [[ -n "${MISSING:-}" ]]; then
  echo "ERROR: required table(s) missing in $ADB: $MISSING"
  echo "You said the DB was already prepared, so installer will NOT recreate it."
  exit 1
fi
echo "  Repository tables OK."

echo "[8/8] Reloading systemd and starting service..."
systemctl daemon-reload
systemctl reset-failed pg-audit-collector 2>/dev/null || true
systemctl enable pg-audit-collector >/dev/null
systemctl restart pg-audit-collector

sleep 2

echo
systemctl --no-pager --full status pg-audit-collector || true

echo
echo "======================================================="
echo " Installation completed."
echo "======================================================="
echo
echo "Project      : $DEST"
echo "Environment  : $DEST/collector.env"
echo "Service only : $SERVICE"
echo
echo "Useful commands:"
echo "  systemctl status pg-audit-collector"
echo "  journalctl -u pg-audit-collector -f"
echo "  sudo -u postgres $DEST/sync_all_tables.sh"
echo
