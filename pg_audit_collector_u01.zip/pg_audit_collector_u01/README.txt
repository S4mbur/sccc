POSTGRESQL AUDIT COLLECTOR - /u01 VERSION
=========================================

FINAL LAYOUT

/u01/pg-audit-collector/
    audit_collector.py
    collector.env
    sync_all_tables.sh
    state/
        state.json

/etc/systemd/system/
    pg-audit-collector.service

Nothing else is installed under /etc.

DEFAULT SETTINGS

PGDATA=/data/postgres/data
PORT=5420
AUDIT_DB=auditdb
AUDIT_USER=audit_writer

DATABASE CONNECTION

The collector does NOT specify a host.

It connects exactly like:

    psql -p 5420 -U audit_writer -d auditdb

That means libpq uses the local Unix-domain socket using its normal/default
socket lookup behavior. No PGDATA path is used as a socket directory.

ONE CLICK INSTALL

    unzip pg_audit_collector_u01.zip
    cd pg_audit_collector_u01
    sudo bash install.sh

The installer:
- installs python3 + python3-psycopg2 from enabled RHEL repositories
- creates /u01/pg-audit-collector
- copies script/env/state paths there
- puts only pg-audit-collector.service under /etc/systemd/system
- validates PGDATA/current_logfiles
- validates:
      psql -p 5420 -U audit_writer -d auditdb
- verifies audit_targets + audit_history already exist
- enables and starts the service

ADD ALL EXISTING USER TABLES

    sudo -u postgres /u01/pg-audit-collector/sync_all_tables.sh

The target repository remains intentionally simple:

    audit_targets(table_name, enabled)

No database/schema is used in whitelist matching.

CHECK SERVICE

    systemctl status pg-audit-collector

FOLLOW LOG

    journalctl -u pg-audit-collector -f

TEST REPOSITORY

    psql -p 5420 -U audit_writer -d auditdb

    SELECT event_time,
           database_name,
           db_user,
           client_ip,
           application_name,
           command_type,
           table_name,
           statement
    FROM audit_history
    ORDER BY id DESC
    LIMIT 20;
