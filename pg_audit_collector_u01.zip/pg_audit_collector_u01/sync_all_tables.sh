#!/usr/bin/env bash
set -euo pipefail

BASE="/u01/pg-audit-collector"
ENV_FILE="$BASE/collector.env"

set -a
source "$ENV_FILE"
set +a

PORT="${AUDIT_PORT:-5420}"
AUDIT_DB="${AUDIT_DB:-auditdb}"

DATABASES="${DATABASES:-}"

if [[ -z "$DATABASES" ]]; then
  DATABASES="$(psql -p "$PORT" -d postgres -Atqc "
    SELECT datname
    FROM pg_database
    WHERE datallowconn
      AND NOT datistemplate
      AND datname <> '$AUDIT_DB'
    ORDER BY 1;
  ")"
fi

tmp="$(mktemp)"
trap 'rm -f "$tmp"' EXIT

for db in $DATABASES; do
  echo "Scanning database: $db" >&2
  psql -p "$PORT" -d "$db" -Atqc "
    SELECT DISTINCT c.relname
    FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE c.relkind IN ('r','p')
      AND n.nspname NOT IN ('pg_catalog','information_schema')
      AND n.nspname NOT LIKE 'pg_toast%'
    ORDER BY 1;
  " >> "$tmp"
done

sort -u "$tmp" -o "$tmp"

psql -p "$PORT" -U "$AUDIT_USER" -d "$AUDIT_DB" <<SQL
CREATE TEMP TABLE _audit_sync_names(table_name text);
\copy _audit_sync_names(table_name) FROM '$tmp'

INSERT INTO audit_targets(table_name, enabled)
SELECT table_name, true
FROM _audit_sync_names
WHERE table_name IS NOT NULL
  AND btrim(table_name) <> ''
ON CONFLICT (table_name)
DO UPDATE SET enabled = true;
SQL

echo
echo "Enabled target count:"
psql -p "$PORT" -U "$AUDIT_USER" -d "$AUDIT_DB" -c \
  "SELECT count(*) AS enabled_target_count FROM audit_targets WHERE enabled;"
