#!/usr/bin/env python3
"""
pgAudit text log -> PostgreSQL table collector

- Harici Python paketi kullanmaz.
- PGDATA/current_logfiles üzerinden aktif PostgreSQL logunu bulur.
- Log rotation / günlük filename değişimini otomatik takip eder.
- Sadece "AUDIT:" kayıtlarını işler.
- pgAudit'in statement_id/substatement_id/parameter gibi Bilgi Güvenliği
  açısından gereksiz alanlarını hedef tabloya yazmaz.
- Multi-line SQL kayıtlarını birleştirmeye çalışır.
"""

import csv
import ipaddress
import os
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONFIG_FILE = HERE / "config.env"

# Kullanıcının ekrandaki log_prefix formatı için.
# Örnek:
# 2026-10-02 09:52:08.059 +03 [1067593] session=... user=postgres
# db=postgres app=DBeaver ... client=10.120.6.244(56972) LOG: AUDIT: ...
RE_TS = re.compile(
    r"^(?P<ts>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d+)?\s+[+-]\d{2}(?::?\d{2})?)"
)
RE_USER = re.compile(r"(?:^|\s)user=(?P<v>\S+)")
RE_DB = re.compile(r"(?:^|\s)db=(?P<v>\S+)")
RE_APP = re.compile(r"(?:^|\s)app=(?P<v>.*?)(?=\s+client=)")
RE_CLIENT = re.compile(r"(?:^|\s)client=(?P<v>\S+)")
RE_NEW_RECORD = re.compile(r"^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}")

AUDIT_FIELD_COUNT_MIN = 8


def load_env(path):
    cfg = {}
    with open(path, "r", encoding="utf-8") as f:
        for raw in f:
            s = raw.strip()
            if not s or s.startswith("#") or "=" not in s:
                continue
            k, v = s.split("=", 1)
            cfg[k.strip()] = v.strip()
    return cfg


CFG = load_env(CONFIG_FILE)
PGDATA = Path(CFG["PGDATA"])
PGPORT = CFG.get("PGPORT", "5432")
PGDATABASE = CFG.get("PGDATABASE", "postgres")
PGUSER = CFG.get("PGUSER", "")
PGHOST = CFG.get("PGHOST", "")
TARGET_SCHEMA = CFG.get("TARGET_SCHEMA", "security_audit")
TARGET_TABLE = CFG.get("TARGET_TABLE", "pgaudit_events")
COLLECTOR_APP_NAME = CFG.get("COLLECTOR_APP_NAME", "pgaudit_collector")
LOG_CHECK_SECONDS = float(CFG.get("LOG_CHECK_SECONDS", "2"))

RUNTIME = HERE / "runtime"
RUNTIME.mkdir(exist_ok=True)
ERROR_LOG = RUNTIME / "collector_error.log"


def elog(msg):
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"{stamp} {msg}\n"
    with open(ERROR_LOG, "a", encoding="utf-8") as f:
        f.write(line)
    print(line, end="", file=sys.stderr, flush=True)


def psql_base():
    cmd = ["psql", "-X", "-q", "-v", "ON_ERROR_STOP=1",
           "-p", PGPORT, "-d", PGDATABASE]
    if PGUSER:
        cmd += ["-U", PGUSER]
    if PGHOST:
        cmd += ["-h", PGHOST]
    return cmd


def sql_literal(value):
    if value is None:
        return "NULL"
    # PostgreSQL standard_conforming_strings=on varsayımı altında güvenli literal.
    # NUL karakteri PostgreSQL text içinde kullanılamaz.
    value = value.replace("\x00", "")
    return "'" + value.replace("'", "''") + "'"


def ident(name):
    # Config'ten gelen identifier için basit ve güvenli whitelist.
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        raise ValueError(f"Geçersiz SQL identifier: {name!r}")
    return '"' + name + '"'


def normalize_client(raw):
    if not raw or raw in ("[local]", "local"):
        return None

    # IPv4: 10.1.2.3(54321)
    m = re.match(r"^(?P<ip>\d{1,3}(?:\.\d{1,3}){3})(?:\(\d+\))?$", raw)
    if m:
        ip = m.group("ip")
        try:
            return str(ipaddress.ip_address(ip))
        except ValueError:
            return None

    # IPv6 log formatları için port parantezini ayır.
    candidate = raw
    if raw.endswith(")") and "(" in raw:
        candidate = raw.rsplit("(", 1)[0]
    candidate = candidate.strip("[]")
    try:
        return str(ipaddress.ip_address(candidate))
    except ValueError:
        return None


def parse_audit_record(record):
    if "AUDIT:" not in record:
        return None

    # Collector'ın kendi psql session'ından kaynaklı logları işlemeyelim.
    app_m = RE_APP.search(record)
    app = app_m.group("v").strip() if app_m else None
    if app == COLLECTOR_APP_NAME:
        return None

    ts_m = RE_TS.search(record)
    user_m = RE_USER.search(record)
    db_m = RE_DB.search(record)
    client_m = RE_CLIENT.search(record)

    audit_text = record.split("AUDIT:", 1)[1].strip()

    # pgAudit payload CSV-benzeri comma-separated yapıdadır.
    try:
        fields = next(csv.reader([audit_text], strict=False))
    except Exception as exc:
        raise ValueError(f"pgAudit CSV parse edilemedi: {exc}") from exc

    if len(fields) < AUDIT_FIELD_COUNT_MIN:
        raise ValueError(
            f"Beklenenden az pgAudit alanı var ({len(fields)}): {audit_text[:300]}"
        )

    # pgAudit:
    # 0 audit_type
    # 1 statement_id            -> tutulmuyor
    # 2 substatement_id         -> tutulmuyor
    # 3 class
    # 4 command
    # 5 object_type
    # 6 object_name
    # 7 statement
    # 8 parameter               -> tutulmuyor
    return {
        "event_time": ts_m.group("ts") if ts_m else None,
        "db_user": user_m.group("v") if user_m else None,
        "database_name": db_m.group("v") if db_m else None,
        "application_name": app,
        "client_ip": normalize_client(client_m.group("v")) if client_m else None,
        "audit_type": fields[0].strip() or None,
        "audit_class": fields[3].strip() or None,
        "command": fields[4].strip() or None,
        "object_type": fields[5].strip() or None,
        "object_name": fields[6].strip() or None,
        "sql_text": fields[7] if len(fields) > 7 else None,
    }


def insert_event(ev):
    if not ev["event_time"]:
        raise ValueError("event_time parse edilemedi; log_line_prefix kontrol edilmeli")

    table = f"{ident(TARGET_SCHEMA)}.{ident(TARGET_TABLE)}"

    sql = f"""
SET application_name = {sql_literal(COLLECTOR_APP_NAME)};
INSERT INTO {table}
(
    event_time, db_user, database_name, application_name, client_ip,
    audit_type, audit_class, command, object_type, object_name, sql_text
)
VALUES
(
    {sql_literal(ev['event_time'])}::timestamptz,
    {sql_literal(ev['db_user'])},
    {sql_literal(ev['database_name'])},
    {sql_literal(ev['application_name'])},
    {sql_literal(ev['client_ip'])}::inet,
    {sql_literal(ev['audit_type'])},
    {sql_literal(ev['audit_class'])},
    {sql_literal(ev['command'])},
    {sql_literal(ev['object_type'])},
    {sql_literal(ev['object_name'])},
    {sql_literal(ev['sql_text'])}
);
"""
    proc = subprocess.run(
        psql_base(),
        input=sql,
        text=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip())


def current_log_file():
    """
    PGDATA/current_logfiles dosyasından stderr logunu bulur.
    logging_collector=on olduğunda PostgreSQL bunu güncel tutar.
    """
    f = PGDATA / "current_logfiles"
    if not f.exists():
        raise FileNotFoundError(
            f"{f} bulunamadı. logging_collector=on olmalı veya PGDATA yanlış."
        )

    choices = []
    for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
        parts = line.strip().split(None, 1)
        if len(parts) != 2:
            continue
        dest, relpath = parts
        path = Path(relpath)
        if not path.is_absolute():
            path = PGDATA / path
        choices.append((dest, path))

    for dest, path in choices:
        if dest == "stderr" and path.exists():
            return path

    # stderr yoksa bulunan ilk text logu kullan.
    for _, path in choices:
        if path.exists() and path.suffix.lower() != ".csv":
            return path

    raise FileNotFoundError("current_logfiles içinde okunabilir text log bulunamadı.")


def process_record(record):
    if "AUDIT:" not in record:
        return
    try:
        ev = parse_audit_record(record)
        if ev:
            insert_event(ev)
    except Exception as exc:
        # Raw SQL'i ayrı error loguna basmayalım; sadece hata özeti.
        elog(f"PARSE/INSERT ERROR: {exc}")


def follow_logs():
    active_path = None
    fh = None
    buffer = None
    last_check = 0.0

    while True:
        now = time.time()

        if fh is None or (now - last_check) >= LOG_CHECK_SECONDS:
            last_check = now
            try:
                new_path = current_log_file()
                if new_path != active_path:
                    if buffer:
                        process_record(buffer)
                        buffer = None
                    if fh:
                        fh.close()

                    active_path = new_path
                    fh = open(active_path, "r", encoding="utf-8", errors="replace")
                    # İlk açılışta eski logları tekrar yükleme.
                    fh.seek(0, os.SEEK_END)
                    print(f"Following: {active_path}", flush=True)
            except Exception as exc:
                elog(f"LOG ERROR: {exc}")
                time.sleep(LOG_CHECK_SECONDS)
                continue

        line = fh.readline()

        if not line:
            # Dosya truncate/rotate olmuş olabilir.
            try:
                if active_path and active_path.exists() and fh.tell() > active_path.stat().st_size:
                    fh.seek(0, os.SEEK_SET)
            except Exception:
                pass

            # Tek kayıt geldi ama arkasından başka log gelmediyse gecikmesin.
            if buffer and "AUDIT:" in buffer:
                process_record(buffer)
                buffer = None

            time.sleep(0.20)
            continue

        line = line.rstrip("\n")

        if RE_NEW_RECORD.match(line):
            if buffer:
                process_record(buffer)
            buffer = line
        else:
            # PostgreSQL multi-line statement continuation.
            if buffer is not None:
                buffer += "\n" + line


def self_test():
    print("Config:", CONFIG_FILE)
    print("PGDATA:", PGDATA)
    print("Current log:", current_log_file())

    cmd = psql_base() + [
        "-Atc",
        "select current_database() || '|' || current_user || '|' || version();"
    ]
    env = os.environ.copy()
    env["PGAPPNAME"] = COLLECTOR_APP_NAME
    p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    if p.returncode != 0:
        raise RuntimeError("psql bağlantısı başarısız: " + p.stderr.strip())
    print("DB:", p.stdout.strip())
    print("TEST OK")


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        self_test()
        return

    print("pgAudit collector started", flush=True)
    print(f"Target: {TARGET_SCHEMA}.{TARGET_TABLE}", flush=True)
    follow_logs()


if __name__ == "__main__":
    main()
