#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
PIDFILE="$DIR/runtime/collector.pid"

if [[ ! -f "$PIDFILE" ]]; then
  echo "Collector çalışmıyor."
  exit 0
fi

PID="$(cat "$PIDFILE" 2>/dev/null || true)"
if [[ -n "$PID" ]] && kill -0 "$PID" 2>/dev/null; then
  kill "$PID"
  for _ in {1..20}; do
    kill -0 "$PID" 2>/dev/null || break
    sleep 0.25
  done
fi

rm -f "$PIDFILE"
echo "Collector durduruldu."
