#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

if [[ ! -f config.env ]]; then
  echo "config.env bulunamadı."
  exit 1
fi

# shellcheck disable=SC1091
source "$DIR/config.env"

mkdir -p "$DIR/runtime"

if ! command -v python3 >/dev/null 2>&1; then
  echo "HATA: python3 bulunamadı."
  exit 1
fi

if ! command -v psql >/dev/null 2>&1; then
  echo "HATA: psql bulunamadı veya PATH içinde değil."
  exit 1
fi

if [[ -z "${PGDATA:-}" || ! -d "$PGDATA" ]]; then
  echo "HATA: config.env içindeki PGDATA yanlış: ${PGDATA:-<bos>}"
  exit 1
fi

PSQL=(psql -X -q -v ON_ERROR_STOP=1 -p "$PGPORT" -d "$PGDATABASE")
[[ -n "${PGUSER:-}" ]] && PSQL+=(-U "$PGUSER")
[[ -n "${PGHOST:-}" ]] && PSQL+=(-h "$PGHOST")

echo "[1/4] PostgreSQL bağlantısı test ediliyor..."
PGAPPNAME="${COLLECTOR_APP_NAME}" "${PSQL[@]}" -Atc "select current_database(), current_user;" >/dev/null

echo "[2/4] Hedef tablo oluşturuluyor..."
PGAPPNAME="${COLLECTOR_APP_NAME}" "${PSQL[@]}" \
  -v target_schema="$TARGET_SCHEMA" \
  -v target_table="$TARGET_TABLE" \
  -f "$DIR/schema.sql"

echo "[3/4] Collector self-test..."
python3 "$DIR/pgaudit_collector.py" --test

echo "[4/4] Collector başlatılıyor..."
"$DIR/start.sh"

echo
echo "Kurulum tamamlandı."
echo "Status : $DIR/status.sh"
echo "Log    : $DIR/runtime/collector.out"
echo "Table  : $TARGET_SCHEMA.$TARGET_TABLE"
