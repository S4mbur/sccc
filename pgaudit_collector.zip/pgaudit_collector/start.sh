#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
PIDFILE="$DIR/runtime/collector.pid"
OUT="$DIR/runtime/collector.out"

mkdir -p "$DIR/runtime"

if [[ -f "$PIDFILE" ]]; then
  PID="$(cat "$PIDFILE" 2>/dev/null || true)"
  if [[ -n "$PID" ]] && kill -0 "$PID" 2>/dev/null; then
    echo "Collector zaten çalışıyor. PID=$PID"
    exit 0
  fi
  rm -f "$PIDFILE"
fi

nohup python3 "$DIR/pgaudit_collector.py" >>"$OUT" 2>&1 &
PID=$!
echo "$PID" > "$PIDFILE"

sleep 1
if kill -0 "$PID" 2>/dev/null; then
  echo "Collector başladı. PID=$PID"
else
  echo "Collector başlatılamadı. Log:"
  tail -50 "$OUT" || true
  exit 1
fi
