#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
"$DIR/stop.sh" || true
echo "Collector durduruldu. Database tablosu otomatik silinmedi."
