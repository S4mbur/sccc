pgAudit -> PostgreSQL Table Collector
====================================

AMAÇ
----
PostgreSQL text logundaki yalnızca "AUDIT:" kayıtlarını okuyup,
Bilgi Güvenliği için sade bir tabloya yazar.

Hedef kolonlar:
- event_time
- db_user
- database_name
- application_name
- client_ip
- audit_type
- audit_class
- command
- object_type
- object_name
- sql_text
- collected_at

Bilinçli olarak tutulmayan pgAudit alanları:
- statement_id
- substatement_id
- parameter

KURULUM
-------
1) Zip'i /u01 altına açın.

   cd /u01
   unzip pgaudit_collector.zip
   cd pgaudit_collector

2) Sadece config.env dosyasını düzenleyin.

   vi config.env

En az:
   PGDATA=/u01/postgresql/18/data
   PGPORT=5420
   PGDATABASE=postgres

Local/trust/peer kullanıyorsanız PGUSER ve PGHOST boş kalabilir.

3) Tek komut:

   ./install.sh

Bu komut:
- psql bağlantısını test eder
- security_audit.pgaudit_events tablosunu oluşturur
- aktif logu PGDATA/current_logfiles üzerinden bulur
- collector'ı nohup ile başlatır

SERVİS YOKTUR.
systemd kurulmaz.

YÖNETİM
-------
Başlat:
   ./start.sh

Durdur:
   ./stop.sh

Durum:
   ./status.sh

Collector çıktısı:
   tail -f runtime/collector.out

Hata logu:
   tail -f runtime/collector_error.log

DB KONTROL
----------
psql -p 5420 -d postgres

SELECT *
FROM security_audit.pgaudit_events
ORDER BY event_time DESC
LIMIT 50;

ÖNEMLİ
------
1) PostgreSQL'de logging_collector=on olmalıdır.
2) PGDATA/current_logfiles mevcut olmalıdır.
3) PostgreSQL OS kullanıcısının log dosyasını okuyabilmesi gerekir.
4) security_audit schema'sını pgAudit object-audit rolüne GRANT ETMEYİN.
   Aksi halde collector'ın kendi INSERT'leri de audit olabilir.
5) Collector psql bağlantılarında application_name=pgaudit_collector kullanır
   ve bu application_name'i ayrıca ignore eder.
6) İlk çalıştırmada mevcut eski loglar import edilmez; collector logun sonundan
   başlayarak yeni AUDIT kayıtlarını işler.
7) PostgreSQL log rotate edip filename değiştirdiğinde current_logfiles takip
   edildiği için yeni aktif loga otomatik geçer.

NOT
---
Parser şu log_prefix alanlarını bekler:
- timestamp
- user=
- db=
- app=
- client=

Örnek:
2026-10-02 09:52:08.059 +03 [1067593] session=... user=postgres db=postgres app=DBeaver 25.3.4 - SQLEditor client=10.120.6.244(56972) LOG: AUDIT: ...

Sizde log_prefix farklıysa pgaudit_collector.py içindeki regexler uyarlanabilir.
