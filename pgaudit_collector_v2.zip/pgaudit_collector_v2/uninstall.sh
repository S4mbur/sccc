#!/usr/bin/env bash
set -euo pipefail
if [[ "$(id -u)" -ne 0 ]]; then
  echo "root ile çalıştırın"
  exit 1
fi
systemctl disable --now pgaudit-collector.service 2>/dev/null || true
rm -f /etc/systemd/system/pgaudit-collector.service
systemctl daemon-reload
echo "Service kaldırıldı. DB tablosu silinmedi."
