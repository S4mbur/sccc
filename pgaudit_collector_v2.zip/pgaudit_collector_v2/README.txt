pgAudit Collector v2
====================

1) /u01 altına aç:
   cd /u01
   unzip pgaudit_collector_v2.zip
   cd pgaudit_collector_v2

2) config.env düzenle:
   vi config.env

Örnek:
   PGDATA=/u01/postgresql/18/data
   PGPORT=5420
   PGDATABASE=postgres
   PGUSER=postgres
   SERVICE_USER=postgres
   SERVICE_GROUP=postgres

3) Kur:
   sudo ./install.sh

4) Kontrol:
   systemctl status pgaudit-collector
   journalctl -u pgaudit-collector -f

5) Test sorgusu çalıştır ve tabloyu kontrol et:
   psql -p 5420 -d postgres

   SELECT *
   FROM security_audit.pgaudit_events
   ORDER BY id DESC
   LIMIT 20;

Sorun varsa:
   sudo ./diagnose.sh

Önemli:
- logging_collector=on olmalı.
- SERVICE_USER PostgreSQL logunu okuyabilmeli.
- security_audit schema'sını pgAudit OBJECT audit rolüne dahil etmeyin.
- Session audit açıksa collector kendi application_name'i olan
  pgaudit_collector kayıtlarını parser tarafında ignore eder.
- Collector ilk açılışta eski logları yüklemez; yeni oluşan AUDIT satırlarından başlar.
