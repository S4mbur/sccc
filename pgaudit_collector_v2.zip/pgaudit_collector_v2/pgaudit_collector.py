#!/usr/bin/env python3
import csv
import ipaddress
import os
import re
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONFIG_FILE = HERE / "config.env"

RE_TS = re.compile(
    r"^(?P<ts>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d+)?\s+[+-]\d{2}(?::?\d{2})?)"
)
RE_USER = re.compile(r"(?:^|\s)user=(?P<v>\S+)")
RE_DB = re.compile(r"(?:^|\s)db=(?P<v>\S+)")
RE_APP = re.compile(r"(?:^|\s)app=(?P<v>.*?)(?=\s+client=)")
RE_CLIENT = re.compile(r"(?:^|\s)client=(?P<v>\S+)")
RE_RECORD_START = re.compile(r"^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}")

def load_env(path):
    cfg = {}
    with open(path, encoding="utf-8") as f:
        for raw in f:
            s = raw.strip()
            if not s or s.startswith("#") or "=" not in s:
                continue
            k, v = s.split("=", 1)
            cfg[k.strip()] = v.strip()
    return cfg

CFG = load_env(CONFIG_FILE)
PGDATA = Path(CFG["PGDATA"])
PGPORT = CFG.get("PGPORT", "5432")
PGDATABASE = CFG.get("PGDATABASE", "postgres")
PGUSER = CFG.get("PGUSER", "")
PGHOST = CFG.get("PGHOST", "")
TARGET_SCHEMA = CFG.get("TARGET_SCHEMA", "security_audit")
TARGET_TABLE = CFG.get("TARGET_TABLE", "pgaudit_events")
COLLECTOR_APP_NAME = CFG.get("COLLECTOR_APP_NAME", "pgaudit_collector")
LOG_CHECK_SECONDS = float(CFG.get("LOG_CHECK_SECONDS", "2"))

RUNTIME = HERE / "runtime"
RUNTIME.mkdir(exist_ok=True)
ERROR_LOG = RUNTIME / "collector_error.log"

def log(msg):
    print(time.strftime("%Y-%m-%d %H:%M:%S"), msg, flush=True)

def elog(msg):
    line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}"
    print(line, file=sys.stderr, flush=True)
    try:
        with open(ERROR_LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

def psql_cmd():
    cmd = ["psql", "-X", "-q", "-v", "ON_ERROR_STOP=1", "-p", PGPORT, "-d", PGDATABASE]
    if PGUSER:
        cmd += ["-U", PGUSER]
    if PGHOST:
        cmd += ["-h", PGHOST]
    return cmd

def psql_env():
    env = os.environ.copy()
    env["PGAPPNAME"] = COLLECTOR_APP_NAME
    return env

def ident(v):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", v):
        raise ValueError(f"Geçersiz identifier: {v}")
    return '"' + v + '"'

def lit(v):
    if v is None:
        return "NULL"
    return "'" + str(v).replace("\x00", "").replace("'", "''") + "'"

def normalize_client(raw):
    if not raw or raw in ("[local]", "local"):
        return None
    s = raw
    # IPv4/IPv6 sonunda "(port)" varsa çıkar
    if s.endswith(")") and "(" in s:
        s = s.rsplit("(", 1)[0]
    s = s.strip("[]")
    try:
        return str(ipaddress.ip_address(s))
    except ValueError:
        return None

def current_log_file():
    # En güvenli/ucuz yöntem: PGDATA/current_logfiles
    cl = PGDATA / "current_logfiles"
    if cl.exists():
        entries = []
        for line in cl.read_text(encoding="utf-8", errors="replace").splitlines():
            parts = line.strip().split(None, 1)
            if len(parts) != 2:
                continue
            dest, path = parts
            p = Path(path)
            if not p.is_absolute():
                p = PGDATA / p
            entries.append((dest, p))
        # Önce stderr text log
        for dest, p in entries:
            if dest == "stderr" and p.exists():
                return p
        # Sonra jsonlog dışında ilk mevcut text log
        for dest, p in entries:
            if p.exists() and dest not in ("csvlog", "jsonlog"):
                return p

    # Fallback: pg_current_logfile()
    proc = subprocess.run(
        psql_cmd() + ["-Atc", "select pg_current_logfile();"],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=psql_env()
    )
    if proc.returncode != 0:
        raise RuntimeError("Aktif log bulunamadı: " + proc.stderr.strip())
    s = proc.stdout.strip()
    if not s:
        raise RuntimeError("pg_current_logfile() boş döndü; logging_collector=on kontrol edin.")
    p = Path(s)
    if not p.is_absolute():
        p = PGDATA / p
    if not p.exists():
        raise FileNotFoundError(str(p))
    return p

def parse_record(record):
    if "AUDIT:" not in record:
        return None

    appm = RE_APP.search(record)
    app = appm.group("v").strip() if appm else None
    if app == COLLECTOR_APP_NAME:
        return None

    tsm = RE_TS.search(record)
    um = RE_USER.search(record)
    dm = RE_DB.search(record)
    cm = RE_CLIENT.search(record)

    if not tsm:
        raise ValueError("timestamp parse edilemedi")

    payload = record.split("AUDIT:", 1)[1].strip()

    # pgAudit alanları comma-separated. SQL virgül içerirse pgAudit bunu quote eder.
    fields = next(csv.reader([payload], strict=False))
    if len(fields) < 8:
        raise ValueError(f"pgAudit alan sayısı yetersiz: {len(fields)}")

    return {
        "event_time": tsm.group("ts"),
        "db_user": um.group("v") if um else None,
        "database_name": dm.group("v") if dm else None,
        "application_name": app,
        "client_ip": normalize_client(cm.group("v")) if cm else None,
        "audit_type": fields[0].strip() or None,
        "audit_class": fields[3].strip() or None,
        "command": fields[4].strip() or None,
        "object_type": fields[5].strip() or None,
        "object_name": fields[6].strip() or None,
        "sql_text": fields[7] if len(fields) > 7 else None,
    }

def insert_event(e):
    table = f"{ident(TARGET_SCHEMA)}.{ident(TARGET_TABLE)}"
    sql = f"""
INSERT INTO {table}
(event_time,db_user,database_name,application_name,client_ip,
 audit_type,audit_class,command,object_type,object_name,sql_text)
VALUES
({lit(e['event_time'])}::timestamptz,
 {lit(e['db_user'])},
 {lit(e['database_name'])},
 {lit(e['application_name'])},
 {lit(e['client_ip'])}::inet,
 {lit(e['audit_type'])},
 {lit(e['audit_class'])},
 {lit(e['command'])},
 {lit(e['object_type'])},
 {lit(e['object_name'])},
 {lit(e['sql_text'])});
"""
    proc = subprocess.run(
        psql_cmd(), input=sql, text=True,
        stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, env=psql_env()
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip())

def handle(record):
    if "AUDIT:" not in record:
        return
    try:
        e = parse_record(record)
        if e:
            insert_event(e)
            log(f"INSERT OK user={e['db_user']} db={e['database_name']} command={e['command']} object={e['object_name']}")
    except Exception as exc:
        # Ham SQL'i error loga bilerek yazmıyoruz.
        elog(f"EVENT ERROR: {exc}")

def follow():
    active = None
    fh = None
    buf = None
    last_check = 0.0

    while True:
        now = time.time()
        if fh is None or now - last_check >= LOG_CHECK_SECONDS:
            last_check = now
            try:
                p = current_log_file()
                if p != active:
                    if buf:
                        handle(buf)
                        buf = None
                    if fh:
                        fh.close()
                    active = p
                    fh = open(active, "r", encoding="utf-8", errors="replace")
                    fh.seek(0, os.SEEK_END)
                    log(f"FOLLOW {active}")
            except Exception as exc:
                elog(f"LOG ERROR: {exc}")
                time.sleep(LOG_CHECK_SECONDS)
                continue

        line = fh.readline()
        if not line:
            # EOF'ta bekleyen tek AUDIT kaydını hemen işle
            if buf and "AUDIT:" in buf:
                handle(buf)
                buf = None
            # truncate olmuşsa başa dön
            try:
                if active and active.exists() and fh.tell() > active.stat().st_size:
                    fh.seek(0)
            except Exception:
                pass
            time.sleep(0.2)
            continue

        line = line.rstrip("\n")
        if RE_RECORD_START.match(line):
            if buf:
                handle(buf)
            buf = line
        else:
            if buf is not None:
                buf += "\n" + line

def self_test():
    print("PGDATA =", PGDATA)
    print("LOG    =", current_log_file())
    p = subprocess.run(
        psql_cmd() + ["-Atc", "select current_database()||'|'||current_user;"],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=psql_env()
    )
    if p.returncode != 0:
        raise RuntimeError(p.stderr.strip())
    print("DB     =", p.stdout.strip())
    print("TEST OK")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        self_test()
    else:
        log("pgAudit collector starting")
        follow()
