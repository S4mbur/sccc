#!/usr/bin/env bash
set -u
DIR="$(cd "$(dirname "$0")" && pwd)"
source "$DIR/config.env"

echo "=== SERVICE ==="
systemctl --no-pager --full status pgaudit-collector.service 2>&1 | tail -30
echo

echo "=== JOURNAL ==="
journalctl -u pgaudit-collector.service -n 30 --no-pager 2>&1
echo

echo "=== CURRENT LOGFILES ==="
cat "$PGDATA/current_logfiles" 2>&1 || true
echo

echo "=== AUDIT SAMPLE ==="
LOG_REL="$(awk '$1=="stderr"{print $2; exit}' "$PGDATA/current_logfiles" 2>/dev/null)"
if [[ -n "${LOG_REL:-}" ]]; then
  if [[ "$LOG_REL" = /* ]]; then LOG="$LOG_REL"; else LOG="$PGDATA/$LOG_REL"; fi
  echo "Log=$LOG"
  grep "AUDIT:" "$LOG" 2>/dev/null | tail -3 || true
else
  echo "stderr log bulunamadı."
fi
echo

echo "=== COLLECTOR ERROR ==="
tail -30 "$DIR/runtime/collector_error.log" 2>/dev/null || true
