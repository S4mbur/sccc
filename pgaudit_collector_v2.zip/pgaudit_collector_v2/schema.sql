CREATE SCHEMA IF NOT EXISTS :"target_schema";

CREATE TABLE IF NOT EXISTS :"target_schema".:"target_table"
(
    id                bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    event_time        timestamptz NOT NULL,
    db_user           text,
    database_name     text,
    application_name  text,
    client_ip         inet,
    audit_type        text NOT NULL,
    audit_class       text NOT NULL,
    command           text NOT NULL,
    object_type       text,
    object_name       text,
    sql_text          text,
    collected_at      timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE INDEX IF NOT EXISTS pgaudit_events_event_time_idx
    ON :"target_schema".:"target_table" (event_time DESC);

CREATE INDEX IF NOT EXISTS pgaudit_events_user_time_idx
    ON :"target_schema".:"target_table" (db_user, event_time DESC);

CREATE INDEX IF NOT EXISTS pgaudit_events_object_time_idx
    ON :"target_schema".:"target_table" (object_name, event_time DESC);
