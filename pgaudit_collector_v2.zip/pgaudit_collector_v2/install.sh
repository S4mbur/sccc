#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
source "$DIR/config.env"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "HATA: systemd kurulumu için root ile çalıştırın: sudo ./install.sh"
  exit 1
fi

command -v python3 >/dev/null || { echo "HATA: python3 yok"; exit 1; }
command -v psql >/dev/null || { echo "HATA: psql PATH içinde yok"; exit 1; }
id "$SERVICE_USER" >/dev/null 2>&1 || { echo "HATA: SERVICE_USER yok: $SERVICE_USER"; exit 1; }

mkdir -p "$DIR/runtime"
chown -R "$SERVICE_USER:$SERVICE_GROUP" "$DIR/runtime"
chmod 750 "$DIR/runtime"
chmod 755 "$DIR/pgaudit_collector.py"

run_as_service_user() {
  runuser -u "$SERVICE_USER" -- env PGAPPNAME="$COLLECTOR_APP_NAME" "$@"
}

PSQL=(psql -X -q -v ON_ERROR_STOP=1 -p "$PGPORT" -d "$PGDATABASE")
[[ -n "${PGUSER:-}" ]] && PSQL+=(-U "$PGUSER")
[[ -n "${PGHOST:-}" ]] && PSQL+=(-h "$PGHOST")

echo "[1/5] DB bağlantısı..."
run_as_service_user "${PSQL[@]}" -Atc "select current_database(),current_user;" >/dev/null

echo "[2/5] Hedef tablo..."
run_as_service_user "${PSQL[@]}" \
  -v target_schema="$TARGET_SCHEMA" \
  -v target_table="$TARGET_TABLE" \
  -f "$DIR/schema.sql"

echo "[3/5] Collector test..."
run_as_service_user python3 "$DIR/pgaudit_collector.py" --test

echo "[4/5] systemd unit..."
cat > /etc/systemd/system/pgaudit-collector.service <<EOF
[Unit]
Description=pgAudit PostgreSQL Table Collector
After=network.target
Wants=network.target

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_GROUP
WorkingDirectory=$DIR
ExecStart=/usr/bin/python3 $DIR/pgaudit_collector.py
Restart=always
RestartSec=3
StandardOutput=append:$DIR/runtime/collector.out
StandardError=append:$DIR/runtime/collector_error.log

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload

echo "[5/5] Service enable/start..."
systemctl enable --now pgaudit-collector.service

sleep 1
systemctl --no-pager --full status pgaudit-collector.service || true

echo
echo "Tamamlandı."
echo "Log: journalctl -u pgaudit-collector -f"
echo "Tablo: $TARGET_SCHEMA.$TARGET_TABLE"
