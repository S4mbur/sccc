# Environment
Target: Oracle Database 19c RU 19.32.
Current source database RU: NOT PROVIDED.
Source: DBA_SOURCE snapshot, keyed by OWNER, NAME, TYPE and ordered by LINE.
Runtime: RHEL; Python orchestrates static source review through an internal model.
No execution evidence is available. SQL embedded in application code, view DDL,
synonym definitions and external dynamic SQL templates are NOT collected by
DBA_SOURCE. A package specification is included when present in the snapshot.
Other object dependencies are not automatically fetched. Interpret missing
metadata conservatively; request it in limitations when material.

# User-maintained additions
Add schema-specific rules and business meanings here, with dated provenance.
Do not put passwords, API tokens, or production row data in context files.
