# Oracle 19.32 regression evidence
No specific Oracle SR, bug number, release note, before/after erroring SQL or
confirmed regression signature has been supplied. Do not invent one.

To specialize the review, add sanitized information below:
- Prior working RU and target RU
- Oracle SR / bug reference and exact relevant description
- Minimal failing source and complete error text
- Known constraints (DB link, query transformation, function, grouping pattern)
- What is observed vs suspected; relevant schema metadata

Source inspection may identify a pattern candidate, not prove the RU introduced it.
