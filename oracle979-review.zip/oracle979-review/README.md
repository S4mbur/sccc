# Oracle 19.32 / ORA-00979 kaynak inceleme sistemi

DBA_SOURCE satırlarını obje bazında birleştirir; internal chat modeline her obje
bütünüyle gönderilir. İki bağımsız çağrı yapılır. İncelenen kod Oracle üzerinde
çalıştırılmaz, parse/compile edilmez. Oracle bağlantısı yalnızca isteğe bağlı
`extract` komutunda, SYS.DBA_SOURCE için tek SELECT ile kullanılır. `run` hiçbir
Oracle bağlantısı açmaz. Modelin ürettiği SQL hiçbir şekilde uygulanmaz.

## Yapı ve sınırlar

- Python 3.9+ / RHEL. İnceleme, JSONL/CSV import, SQLite ve raporlama standard
  library ile çalışır. Yalnızca canlı kaynak çekimi `oracledb` gerektirir.
- Yerel SQLite: kaynak snapshot'ı, sürümlü işler, çağrı sonuçları, ilerleme.
- OpenAI-uyumlu chat completions: görseldeki `takasai-coder` model adı ve endpoint
  örnek config'e işlendi. Endpoint'i kendi ortamında doğrula. Görseldeki anahtar
  kopyalanmadı. Embedding ve rerank bu tam-kaynak incelemesinde kullanılmaz.
- Tek worker, obje başına iki çağrı. 2.000 obje için normal koşulda 4.000 çağrı.
  Aynı modelin iki turu bağımsız kanıt veya doğruluk garantisi değildir.
- Her istekte yeni mesaj listesi: başka objelerin sohbet geçmişi taşınmaz.
- PACKAGE BODY / TYPE BODY için snapshot'ta bulunan aynı isimli spec eklenir.
  Diğer bağımlılıklar otomatik toplanmaz; ilgili bilgiler context'e eklenebilir.
- Kimlik OWNER+NAME+TYPE: package spec ve body ayrı objelerdir.
- DBA_SOURCE bir tüm-veritabanı SQL envanteri değildir. View DDL, uygulama SQL'i,
  harici şablonlar ve runtime'da oluşan tüm SQL'ler bu kapsamda değildir.
- Büyük objeler otomatik parçalanmaz. Tam obje+spec+context bütçeyi aşarsa
  `blocked / CONTEXT_BUDGET_EXCEEDED_FULL_OBJECT_NOT_SENT` olur. Sessiz kesme yok.
  Bu başlangıç sürümünde semantik PL/SQL parçalama uygulanmamıştır.
- Wrapped kod ve desteklenmeyen türler incelenmiş sayılmaz.
- Her rapor mevcut import snapshot'ındaki bütün objeleri içerir: pending, failed,
  blocked ve tamamlananlar. Önceki snapshot'ın çıkarılmış objeleri güncel rapora
  karışmaz; geçmiş SQLite'da kalır. Her import TAM yeni kapsamı temsil eder.
- Kaynak, spec, prompt, context, model revision veya config değişirse iş anahtarı
  değişir. Model sunucuda aynı adla güncellenirse model_revision'ı sen artırmalısın.

## 19.32'ye özel önemli ayrım

Genel GROUP BY kural incelemesi, 19.32'de ortaya çıkan belirli optimizer/RU
regresyonunu bulmakla aynı şey değildir. Bu pakete henüz somut bir Oracle bug/SR
veya önce/sonra bozulma örneği verilmedi. Çıktı `regression_19_32_confirmed=false`
ve `oracle_validated=false` taşır. Modelin risk raporu “19.32'de kesin bozulur”
anlamına gelmez. Bilinen örneği ve Oracle açıklamasını
`context/known_regressions.md` içine eklemek incelemeyi hedefler; kanıtlamaz.

## Kurulum

Proje klasöründe, örneğin RHEL'deki mevcut Python 3.11 ile:

```bash
python3.11 -m venv .venv
source .venv/bin/activate
cp config.example.json config.json
chmod 600 config.json
python -m unittest discover -s tests -v
```

Sistemdeki Python komutu farklıysa ilk komutu uyarlayın. Canlı Oracle çekimi için:

```bash
python -m pip install -r requirements-oracle.txt
```

İnternete kapalı ortamda hedef RHEL mimarisi ve Python sürümüyle uyumlu bağlı bir
makinede wheel dosyalarını hazırlayın, wheelhouse klasörünü içeri taşıyın:

```bash
python -m pip download -r requirements-oracle.txt -d wheelhouse
python -m pip install --no-index --find-links wheelhouse -r requirements-oracle.txt
```

`oracledb==4.0.2` sabitlenmiştir; transitive bağımlılıklar çözülür. Kurum içi
tekrarlanabilir kurulum için onaylı wheelhouse'u ve `pip freeze` çıktısını saklayın.
Bu teslimata wheel dosyaları dahil değildir. Varsayılan Thin moddur. Ortamınızın
Oracle network ayarları Thin ile uyumlu değilse kurumda kurulu Oracle Client ile
`oracle_client_dir` ayarlanabilir; bunu kendi sunucunuzda doğrulayın.

## Ayarlar ve sırlar

`config.json` içindeki model URL'sini, model adını ve bütçeleri kontrol edin.
Sırlar yalnızca ortam değişkenlerinden okunur. İnteraktif shell örneği:

```bash
read -rsp 'Chat API key: ' REMOTE_CHAT_API_KEY
export REMOTE_CHAT_API_KEY
```

TLS doğrulaması açıktır; kurum CA dosyası gerekiyorsa `ca_bundle` alanına PEM
zincirinin yolunu yazın. TLS doğrulamasını kapatan seçenek yoktur. HTTP redirect
ve environment proxy kullanılmaz. Gateway'e bu RHEL sunucusundan doğrudan erişim
olmalıdır. İstek/response içindeki kaynak kod yalnızca yapılandırdığınız endpoint'e
gider; endpoint değiştirmek veri hedefini değiştirir.

`max_request_bytes=60000` tüm kaynak, context ve prompt için muhafazakâr bir UTF-8
byte bütçesidir; TOKEN sayısı veya model context limiti değildir. `max_output_tokens`
çıktı bütçesidir. Gerçek model context/input/output limitlerini API ekibinden öğrenip
bu değerleri uyarlayın. Kaynak/spec hiçbir zaman sığdırmak için kesilmez. Gateway
context hatası döndürürse config'i düzeltip tekrar çalıştırın. `json_mode` sadece
sunucu destekliyorsa açılmalı; varsayılan false. Model temperature parametresini
kabul etmiyorsa `null` yapın. Reasoning modeli token bütçesinin bir kısmını içeride
kullanabilir; kesik çıktı başarılı sayılmaz. Sadece final JSON content işlenir.

## Kaynak alma: iki alternatif

A. Oracle'dan yalnızca DBA_SOURCE okuyarak snapshot oluşturma:

```bash
export ORACLE_USER='SOURCE_READER'
export ORACLE_DSN='dbhost:1521/service'
read -rsp 'Oracle password: ' ORACLE_PASSWORD
export ORACLE_PASSWORD
python review.py extract --owners APP1 APP2 --out data/source.jsonl
python review.py import data/source.jsonl
```

Hesabın SYS.DBA_SOURCE okuma yetkisi olmalıdır; SYSDBA kullanılmaz. Şema isimleri
bind değişkenleridir ve dictionary'deki büyük/küçük harfleriyle verilmelidir.
Bağlanılan servis/PDB ve edition'ın doğru olması operatör sorumluluğundadır.
Tek SELECT'in tamamlanmasından sonra dosya atomik değiştirilir. Çekim sırasında
sık DDL yapılan bir kapsamı ayrıca sabit bir bakım anında alın.

B. Hazır export'u import etme (Oracle sürücüsü gerekmez):

```bash
python review.py import /path/to/dba_source.csv
```

Gerekli kolonlar: OWNER, NAME, TYPE, LINE, TEXT. UTF-8 JSONL önerilir. CSV'de
TEXT içindeki virgül/tırnak/yeni satırlar CSV standardına göre quote edilmelidir;
satır başına düz `split(',')` formatı değildir. SQL çıktısındaki sayfa başlıkları,
spool mesajları veya satır kesilmeleri kabul edilmez. LINE 1'den başlayıp kesintisiz
olmalı, duplicate bulunmamalıdır. TEXT içinde orijinal satır sonlarını koruyun.
Import satırları LINE'a göre sıralar; malformed veya boş import eski kapsamı silmez.
`examples/source.jsonl` yalnızca uygulama akışını denemek içindir.

## İnceleme ve devam

```bash
python review.py plan
python review.py run --limit 5
python review.py report --out reports/pilot
```

İlk 5 gerçek objenin özetlerini, SQL bloklarını, kod alıntılarını ve sonuçlarını
manuel inceleyin. Bu pilot model kalitesini değerlendirmek içindir; altyapı testleri
modelin Oracle bilgisine puan vermez. Ardından tüm kalan objeler:

```bash
python review.py run
python review.py report --out reports/full
```

`--limit` obje sayısıdır; 0 bütün bekleyenlerdir. Ctrl+C / process sonlanması sonrası
aynı run kaldığı yerden devam eder. Başarılı ilk tur kaydedilmişse tekrar kullanılabilir.
İki bağımsız tur arasında önceki turun cevabı modele gönderilmez.

```bash
python review.py run --retry-failed
```

API 408/429/5xx ve bağlantı timeout hatalarında sınırlı backoff vardır. Kalıcı HTTP
ayar/auth hatasında veya retry tükenmesinde tüm kuyruğu boşa tüketmemek için durur.
JSON/şema/alıntı hatası ilgili objeyi failed yapar. Gizlice no_finding'e çevrilmez.
Uygunsuz yanıtlar için otomatik “JSON tamir modeli” çağrısı yoktur. `--retry-failed`
bilinçli yeniden denemedir. Parametre değişiklikleri yeni profil oluşturur.
SQLite yanındaki Linux flock aynı state için iki eşzamanlı worker'ı engeller.
State ve kaynakları yerel diskte tutun; paylaşımlı NFS iş kuyruğu tasarlanmamıştır.

## Çıktıları okuma

- `report.json`: iki turun tam sonucu, özetler, sorgu blokları, context kısıtları,
  source hash, profil ve durum. Esas ayrıntılı rapor budur.
- `report.csv`: Excel'de açılabilen UTF-8 BOM'lu düz rapor. Her tur/bulgu ayrı satır;
  aynı bulgunun iki turda görünmesi kasıtlıdır. Formül başlatabilecek hücreler kaçırılır.
- `risk_review_required`: en az bir turda risk; manuel inceleme gerekir.
- `insufficient_context`: kaynak/context yeterli değil.
- `no_finding_model_only`: iki turda bulgu yok; uyumluluk garantisi değildir.
- `review_disagreement=true`: durum veya bulgu yerleri/alıntıları uyuşmuyor.
  Bu mekanik karşılaştırma semantik eşdeğerlik değerlendirmesi değildir.
- `pending/failed/blocked`: inceleme tamamlanmadı. Rapor kapsamından düşürülmez.

Alıntı kontrolü yalnızca gösterilen metnin kaynakta o satırlarda bulunduğunu
kanıtlar; modelin SQL yorumunun doğruluğunu veya bütün sorguları bulduğunu kanıtlamaz.
İkinci tur yanlış negatifleri ortadan kaldırmaz. Model confidence alanı kalibre
edilmiş bir yüzde değildir. Hatalar ve doğru örneklerden oluşan kurum içi bir
etiketli setle prompt değişikliklerini değerlendirin.

## Context düzenleme

`prompts/system.md`: analiz sınırları, GROUP BY denetimi, false-positive önleme.
`prompts/output.md`: doğrulanan JSON sözleşmesi.
`prompts/review.md` ve `audit.md`: iki bağımsız geçişin odakları.
`context/environment.md`: kaynak sürümü, şema sözlüğü, bağımlılık/iş bilgisi.
`context/known_regressions.md`: 19.32 için doğrulanmış SR/bug/örnek bilgileri.
Yeni context `.md` dosyalarını context dizinine koyabilirsiniz; tüm objelere
verilir ve bütçeye dahil edilir. Objeye özel büyük bağımlılık paketleri için bu
sürüm otomatik retrieval uygulamaz. İçine tüm 2.000 objeyi koymayın.

## Teslimat doğrulaması

Yerel unit/integration testleri mock API ve mock Oracle bağlantısı kullanır.
Gerçek internal endpoint'e veya Oracle'a bağlanılmadı. RHEL üzerinde gerçek
TLS/auth/driver uyumu ve model kalitesi henüz doğrulanmadı. Testleri çalıştırma:

```bash
python -m unittest discover -s tests -v
```

Yerel data dizini kaynak kod içerir. Program yeni dosyalar için umask 077 uygular.
Konfigürasyon dosyasına anahtar yazmayın. State yedeklemesini süreç durmuşken alın
(WAL dosyaları varken yalnızca ana .sqlite dosyasını kopyalamayın).

## Teknik başvuru

- https://docs.oracle.com/en/database/oracle/oracle-database/19/refrn/DBA_SOURCE.html
- https://docs.oracle.com/en/database/oracle/oracle-database/19/sqlrf/SELECT.html
- https://docs.oracle.com/en/error-help/db/ora-00979/
- https://python-oracledb.readthedocs.io/en/latest/user_guide/installation.html
