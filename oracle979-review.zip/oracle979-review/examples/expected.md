# Model kalite pilotu — insan etiketleri

Bu örnekler Oracle üzerinde çalıştırılmamıştır. EMP.DEPTNO ve EMP.ENAME kolonları varsayılmıştır.
- P_RISK: SELECT listesinde gruplama dışındaki ENAME nedeniyle ORA-00979 adayı.
- P_GROUPED: sunulan SQL için gruplama bulgusu beklenmez.
- P_DYNAMIC: p_sql içeriği bilinmediğinden insufficient_context beklenir.

Bu üç örnek yalnızca başlangıç smoke setidir, doğruluk benchmark'ı değildir.
19.32'ye özgü regresyon örneği içermez. Gerçek doğru/hatalı kurum objeleriyle genişletin.
