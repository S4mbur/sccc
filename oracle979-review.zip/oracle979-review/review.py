#!/usr/bin/env python3
"""Offline source review; only extract opens Oracle, only SELECT DBA_SOURCE."""
import argparse
import contextlib
import csv
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import random
import re
import sqlite3
import ssl
import sys
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent
VERSION = '1.0.0'
TYPES = {'PACKAGE','PACKAGE BODY','PROCEDURE','FUNCTION','TRIGGER','TYPE','TYPE BODY'}

def js(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True)

def digest(value):
    return hashlib.sha256(js(value).encode()).hexdigest()

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def atomic(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(content, encoding='utf-8')
    os.replace(temp, path)

def read_config(path):
    c = json.loads(Path(path).read_text(encoding='utf-8'))
    for key in ('max_request_bytes','max_output_tokens','timeout_seconds','http_attempts'):
        if type(c[key]) is not int or c[key] <= 0:
            raise ValueError('Invalid configuration: ' + key)
    if not c['chat_url'].startswith('https://'):
        raise ValueError('chat_url must use HTTPS')
    return c

@contextlib.contextmanager
def database(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(str(path) + '.lock', 'a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('Another command is using this state database')
        db = sqlite3.connect(path)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA journal_mode=WAL')
        db.executescript('''
        CREATE TABLE IF NOT EXISTS objects (
          id TEXT PRIMARY KEY, owner TEXT, name TEXT, type TEXT, source TEXT,
          source_hash TEXT, active INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS jobs (
          key TEXT PRIMARY KEY, object_id TEXT, profile TEXT, status TEXT,
          payload TEXT, result TEXT, error TEXT, updated TEXT);
        CREATE TABLE IF NOT EXISTS calls (
          id INTEGER PRIMARY KEY, job_key TEXT, stage TEXT, request_hash TEXT,
          response TEXT, created TEXT);
        CREATE TABLE IF NOT EXISTS imports (
          id INTEGER PRIMARY KEY, imported_at TEXT, source_file TEXT, count INTEGER);
        ''')
        try:
            yield db
        finally:
            db.close()

def load_rows(path):
    with open(path, encoding='utf-8-sig', newline='') as stream:
        rows = csv.DictReader(stream) if str(path).lower().endswith('.csv') else (json.loads(s) for s in stream if s.strip())
        groups = {}
        for row in rows:
            row = {k.upper():v for k,v in row.items()}
            owner, name, kind = (row[k] for k in ('OWNER','NAME','TYPE'))
            if not all(isinstance(x,str) and x for x in (owner,name,kind)):
                raise ValueError('Empty object identity')
            number = int(row['LINE'])
            if number < 1:
                raise ValueError('Invalid source line')
            text = row['TEXT'] if row['TEXT'] is not None else ''
            if not isinstance(text,str):
                raise ValueError('Source TEXT must be a string')
            key = js([owner,name,kind])
            lines = groups.setdefault(key,{})
            if number in lines:
                raise ValueError('Duplicate source line: ' + key)
            lines[number] = text
    objects = []
    for key, lines in sorted(groups.items()):
        if sorted(lines) != list(range(1,max(lines)+1)):
            raise ValueError('Missing source lines: ' + key)
        owner,name,kind = json.loads(key)
        source = [{'line':n,'text':lines[n]} for n in sorted(lines)]
        objects.append((key,owner,name,kind,js(source),digest(source)))
    if not objects:
        raise ValueError('No source rows; refusing to replace inventory')
    return objects

def ingest(db, path):
    objects = load_rows(path)  # validate entire snapshot before changing inventory
    with db:
        db.execute('UPDATE objects SET active=0')
        db.executemany('''INSERT INTO objects VALUES (?,?,?,?,?,?,1)
          ON CONFLICT(id) DO UPDATE SET source=excluded.source,
          source_hash=excluded.source_hash, active=1''',objects)
        db.execute('INSERT INTO imports(imported_at,source_file,count) VALUES (?,?,?)',(now(),str(path),len(objects)))
    return len(objects)

def extract(c, owners, output):
    import oracledb
    if not owners:
        raise ValueError('Explicit schema owners are required')
    if c.get('oracle_client_dir'):
        oracledb.init_oracle_client(lib_dir=c['oracle_client_dir'])
    binds = {f'o{i}':v for i,v in enumerate(owners)}
    placeholders = ','.join(':'+k for k in binds)
    sql = ('SELECT owner, name, type, line, text FROM SYS.DBA_SOURCE '
           f'WHERE owner IN ({placeholders}) ORDER BY owner, name, type, line')
    # No user SQL, DDL, DBMS_SQL, object execution, or compilation is exposed.
    path = Path(output)
    path.parent.mkdir(parents=True,exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    try:
        with oracledb.connect(user=os.environ['ORACLE_USER'],password=os.environ['ORACLE_PASSWORD'],dsn=os.environ['ORACLE_DSN']) as conn:
            conn.call_timeout = c.get('oracle_call_timeout_ms',120000)
            with conn.cursor() as cur, temp.open('w',encoding='utf-8') as stream:
                cur.arraysize = 1000
                cur.execute(sql,binds)
                for row in cur:
                    stream.write(js(dict(zip(('OWNER','NAME','TYPE','LINE','TEXT'),row)))+'\n')
        load_rows(temp)
        os.replace(temp,path)
    finally:
        if temp.exists():
            temp.unlink()

def resources():
    return {str(p.relative_to(ROOT)):p.read_text(encoding='utf-8') for folder in ('prompts','context') for p in sorted((ROOT/folder).rglob('*.md'))}

def plan(db,c):
    docs = resources()
    # Credentials excluded; endpoint/model revision/settings/context all invalidate cache.
    profile = digest({'version':VERSION,'config':c,'docs':docs})
    objects = list(db.execute('SELECT * FROM objects WHERE active=1 ORDER BY id'))
    by_id = {o['id']:o for o in objects}
    keys = []
    for o in objects:
        source = json.loads(o['source'])
        attached = []
        if o['type'] in ('PACKAGE BODY','TYPE BODY'):
            spec = by_id.get(js([o['owner'],o['name'],o['type'].replace(' BODY','')]))
            if spec:
                attached.append({'identity':json.loads(spec['id']),'source':json.loads(spec['source'])})
        payload = {'identity':json.loads(o['id']),'target_version':'19.32',
                   'source':source,'related_specs':attached,
                   'dependency_scope':'Only supplied specs and context; no automatic dependency closure'}
        key = digest({'profile':profile,'payload':payload})
        keys.append(key)
        blocked = ''
        if o['type'] not in TYPES:
            blocked = 'UNSUPPORTED_OBJECT_TYPE'
        elif re.search(r'\bwrapped\b',''.join(x['text'] for x in source[:12]),re.I):
            blocked = 'WRAPPED_SOURCE_REQUIRES_PLAINTEXT'
        # Conservative byte budget is explicit, NOT a tokenizer or advertised context size.
        elif request_size(docs,payload) > c['max_request_bytes']:
            blocked = 'CONTEXT_BUDGET_EXCEEDED_FULL_OBJECT_NOT_SENT'
        with db:
            db.execute('INSERT OR IGNORE INTO jobs VALUES (?,?,?,?,?,?,?,?)',
                       (key,o['id'],profile,'blocked' if blocked else 'pending',js(payload),None,blocked,now()))
    return profile,keys,docs

def request_size(docs,payload):
    return len(js(docs).encode()) + len(js(payload).encode()) + 4096

def validate(result,payload):
    if not isinstance(result,dict):
        raise ValueError('Expected JSON object')
    required = {'identity','status','summary','coverage','query_blocks','limitations','findings','version_assessment'}
    if set(result) != required:
        raise ValueError('Unexpected or missing response fields')
    if result['identity'] != payload['identity']:
        raise ValueError('Wrong object identity')
    if result['status'] not in ('risk','no_finding','insufficient_context'):
        raise ValueError('Invalid status')
    if result['version_assessment'] != 'not_established':
        raise ValueError('Static review cannot establish a 19.32 regression')
    if result['coverage'] not in ('full_source_reviewed','partial'):
        raise ValueError('Invalid coverage')
    if not isinstance(result['summary'],str) or not result['summary'].strip():
        raise ValueError('Missing summary')
    if not isinstance(result['limitations'],list) or not all(isinstance(x,str) for x in result['limitations']):
        raise ValueError('Invalid limitations')
    if result['coverage']=='partial' and result['status']=='no_finding':
        raise ValueError('Partial source cannot be no_finding')
    if result['status']=='insufficient_context' and not result['limitations']:
        raise ValueError('Missing context explanation')
    source = {r['line']:r['text'] for r in payload['source']}
    def span(item):
        start,end = item.get('line_start'),item.get('line_end')
        if type(start) is not int or type(end) is not int or start>end or start not in source or end not in source:
            raise ValueError('Invalid evidence range')
        return ''.join(source[n] for n in range(start,end+1))
    if not isinstance(result['query_blocks'],list):
        raise ValueError('Invalid block inventory')
    for q in result['query_blocks']:
        if not isinstance(q,dict) or set(q)!={'line_start','line_end','kind','assessment'}:
            raise ValueError('Invalid query block')
        span(q)
        if q['kind'] not in ('static_sql','dynamic_sql','unresolved_dynamic_sql') or not isinstance(q['assessment'],str):
            raise ValueError('Invalid query block description')
    if any(q['kind']=='unresolved_dynamic_sql' for q in result['query_blocks']) and result['status']=='no_finding':
        raise ValueError('Unresolved dynamic SQL cannot be no_finding')
    if not isinstance(result['findings'],list):
        raise ValueError('Invalid findings')
    if result['status']=='risk' and not result['findings']:
        raise ValueError('Risk must include evidence')
    if result['status']=='no_finding' and result['findings']:
        raise ValueError('Inconsistent result')
    for f in result['findings']:
        if not isinstance(f,dict) or set(f)!={'line_start','line_end','evidence','reason','confidence','suggestion','semantic_impact'}:
            raise ValueError('Invalid finding fields')
        actual = span(f)
        for key in ('evidence','reason','suggestion','semantic_impact'):
            if not isinstance(f[key],str) or not f[key].strip():
                raise ValueError('Empty finding field')
        if f['evidence'] not in actual:
            raise ValueError('Evidence is not an exact source substring')
        if f['confidence'] not in ('low','medium','high'):
            raise ValueError('Invalid confidence')
    return result

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        return None

class FatalAPI(RuntimeError):
    pass

def chat(c,messages):
    key = os.environ.get('REMOTE_CHAT_API_KEY','')
    if not key:
        raise FatalAPI('REMOTE_CHAT_API_KEY missing')
    body = {'model':c['model'],'messages':messages,'stream':False,'max_tokens':c['max_output_tokens']}
    if c.get('temperature') is not None:
        body['temperature']=c['temperature']
    if c.get('json_mode',False):
        body['response_format']={'type':'json_object'}
    data = js(body).encode()
    ctx = ssl.create_default_context(cafile=c.get('ca_bundle') or None)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPSHandler(context=ctx),NoRedirect())
    for attempt in range(c['http_attempts']):
        delay = min(2**attempt + random.random(),20)
        try:
            request = urllib.request.Request(c['chat_url'],data=data,headers={'Content-Type':'application/json','Authorization':'Bearer '+key})
            with opener.open(request,timeout=c['timeout_seconds']) as response:
                raw = response.read(8*1024*1024+1)
            if len(raw)>8*1024*1024:
                raise ValueError('Oversized API response')
            obj = json.loads(raw)
            choice = obj['choices'][0]
            if choice.get('finish_reason') != 'stop':
                raise ValueError('API response not complete: finish_reason is not stop')
            content = choice['message']['content']
            if not isinstance(content,str):
                raise ValueError('Missing final content')
            # Reasoning-only responses are never substituted for final structured output.
            parsed = json.loads(content)
            return parsed,{'content':content,'model':obj.get('model'), 'usage':obj.get('usage'),
                           'id':obj.get('id'),'finish_reason':choice['finish_reason']}
        except urllib.error.HTTPError as exc:
            if exc.code not in (408,429,500,502,503,504):
                raise FatalAPI('HTTP '+str(exc.code)+'; check endpoint, credentials and request settings') from None
            retry = exc.headers.get('Retry-After','')
            if retry.isdigit():
                delay = min(int(retry),60)
            error = 'HTTP '+str(exc.code)
        except (urllib.error.URLError,TimeoutError,OSError):
            error = 'API transport/TLS/timeout failure'
        if attempt+1<c['http_attempts']:
            time.sleep(delay)
    raise RuntimeError(error + '; retry budget exhausted')

def messages(docs,payload,stage):
    system = docs['prompts/system.md']+'\n'+docs['prompts/output.md']
    system += '\n'+docs['prompts/'+stage+'.md']
    context = {k:v for k,v in docs.items() if k.startswith('context/')}
    return [{'role':'system','content':system},
            {'role':'user','content':js({'task':'Review the full object for ORA-00979 risks for target 19.32. Return JSON only.',
                                       'reference_context':context,'untrusted_source_data':payload})}]

def combine(first,second):
    # Report union by keeping BOTH complete results. Different findings never disappear.
    signature = lambda r: sorted((x['line_start'],x['line_end'],x['evidence']) for x in r['findings'])
    disagree = first['status']!=second['status'] or signature(first)!=signature(second)
    if first['status']=='risk' or second['status']=='risk':
        status='risk_review_required'
    elif first['status']=='insufficient_context' or second['status']=='insufficient_context':
        status='insufficient_context'
    else:
        status='no_finding_model_only'
    return {'status':status,'manual_review_required':status!='no_finding_model_only' or disagree,
            'review_disagreement':disagree,'oracle_validated':False,'regression_19_32_confirmed':False,
            'reviews':[first,second]}

def run(db,c,limit,retry_failed):
    profile,keys,docs=plan(db,c)
    with db:
        db.execute("UPDATE jobs SET status='pending' WHERE status='running'")
        if retry_failed:
            db.execute("UPDATE jobs SET status='pending',error='' WHERE profile=? AND status='failed'",(profile,))
    done=0
    for key in keys:
        row=db.execute('SELECT * FROM jobs WHERE key=?',(key,)).fetchone()
        if row['status']!='pending':
            continue
        if limit and done>=limit:
            break
        with db:
            db.execute("UPDATE jobs SET status='running',updated=? WHERE key=?",(now(),key))
        payload=json.loads(row['payload'])
        invalid_call_id=None
        try:
            reviews=[]
            for stage in ('review','audit'):
                msgs=messages(docs,payload,stage)
                req_hash=digest({'config':c,'messages':msgs})
                cached=db.execute('SELECT response FROM calls WHERE job_key=? AND stage=? AND request_hash=? ORDER BY id DESC LIMIT 1',(key,stage,req_hash)).fetchone()
                if cached:
                    result=validate(json.loads(cached['response'])['parsed'],payload)
                else:
                    result,meta=chat(c,msgs)
                    # Store the received final response even if schema validation then fails.
                    with db:
                        db.execute('INSERT INTO calls(job_key,stage,request_hash,response,created) VALUES (?,?,?,?,?)',
                                   (key,stage,req_hash,js({'parsed':result,'meta':meta}),now()))
                    invalid_call_id=db.execute('SELECT MAX(id) FROM calls WHERE job_key=?',(key,)).fetchone()[0]
                    result=validate(result,payload)
                    invalid_call_id=None
                reviews.append(result)
            combined=combine(*reviews)
            with db:
                db.execute("UPDATE jobs SET status='done',result=?,error='',updated=? WHERE key=?",(js(combined),now(),key))
            print(js({'object':payload['identity'],'status':combined['status']}),flush=True)
        except Exception as exc:
            # Never persist raw HTTP bodies, passwords, source snippets from exceptions, or headers.
            safe = str(exc) if isinstance(exc,(ValueError,FatalAPI,RuntimeError)) else type(exc).__name__
            with db:
                db.execute("UPDATE jobs SET status='failed',error=?,updated=? WHERE key=?",(safe,now(),key))
                # Invalid schema cache must not poison explicit retries.
                if invalid_call_id is not None:
                    db.execute('DELETE FROM calls WHERE id=?',(invalid_call_id,))
            print(js({'object':payload['identity'],'status':'failed','error':safe}),flush=True)
            if isinstance(exc,FatalAPI) or 'retry budget exhausted' in safe:
                raise RuntimeError('Run paused on API failure; resolve settings/network and use --retry-failed') from None
        done+=1
    return profile,keys

def report(db,c,dest):
    profile,keys,_=plan(db,c)
    records=[]
    for key in keys:
        r=dict(db.execute('SELECT * FROM jobs WHERE key=?',(key,)).fetchone())
        p=json.loads(r.pop('payload'))
        r['identity']=p['identity']
        r['source_hash']=digest(p['source'])
        r['result']=json.loads(r['result']) if r['result'] else None
        records.append(r)
    dest=Path(dest)
    dest.mkdir(parents=True,exist_ok=True)
    atomic(dest/'report.json',js({'created_at':now(),'profile':profile,'objects':records}))
    with (dest/'report.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.writer(stream)
        writer.writerow(['owner','name','type','job_status','assessment','manual_review','disagreement','review_pass','line_start','line_end','evidence','reason','suggestion','semantic_impact','limitations','error','job_key'])
        def safe(v):
            s=str(v)
            return "'"+s if s.lstrip().startswith(('=','+','-','@')) or s.startswith(('\t','\r','\n')) else s
        for r in records:
            result=r['result'] or {}
            reviews=result.get('reviews',[])
            rows=[]
            for idx,rev in enumerate(reviews,1):
                for finding in rev['findings'] or [{}]:
                    rows.append([idx,*[finding.get(k,'') for k in ('line_start','line_end','evidence','reason','suggestion','semantic_impact')],'; '.join(rev['limitations'])])
            for values in rows or [['']*9]:
                writer.writerow([safe(x) for x in [*r['identity'],r['status'],result.get('status',''),result.get('manual_review_required',''),result.get('review_disagreement',''),*values,r['error'],r['key']]])
    counts={}
    for r in records:
        label=(r['result'] or {}).get('status',r['status'])
        counts[label]=counts.get(label,0)+1
    print(js({'objects':len(records),'counts':counts,'directory':str(dest)}))

def main():
    os.umask(0o077)
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',default='config.json')
    parser.add_argument('--state',default='data/state.sqlite')
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('extract'); p.add_argument('--owners',nargs='+',required=True); p.add_argument('--out',default='data/source.jsonl')
    p=sub.add_parser('import'); p.add_argument('file')
    p=sub.add_parser('plan')
    p=sub.add_parser('run'); p.add_argument('--limit',type=int,default=0); p.add_argument('--retry-failed',action='store_true')
    p=sub.add_parser('report'); p.add_argument('--out',default='reports')
    args=parser.parse_args()
    c=read_config(args.config)
    if args.command=='extract':
        extract(c,args.owners,args.out)
        print('Source snapshot written: '+args.out)
        return
    with database(args.state) as db:
        if args.command=='import':
            print('Imported objects: '+str(ingest(db,args.file)))
        elif args.command=='plan':
            profile,keys,_=plan(db,c)
            counts={}
            for key in keys:
                row=db.execute('SELECT status,error FROM jobs WHERE key=?',(key,)).fetchone()
                label=row['status']+(':'+row['error'] if row['error'] else '')
                counts[label]=counts.get(label,0)+1
            print(js({'profile':profile,'objects':len(keys),'counts':counts}))
        elif args.command=='run':
            if args.limit<0:
                raise ValueError('--limit must be >= 0')
            run(db,c,args.limit,args.retry_failed)
        elif args.command=='report':
            report(db,c,args.out)

if __name__=='__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('Interrupted; rerun to resume.',file=sys.stderr)
        sys.exit(130)
    except Exception as exc:
        # Driver errors may contain environment details. Avoid dumping tracebacks by default.
        print('ERROR: '+(str(exc) if isinstance(exc,(ValueError,RuntimeError)) else type(exc).__name__),file=sys.stderr)
        sys.exit(1)
