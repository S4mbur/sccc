# Strict output contract
Return a single JSON object only, with exactly these fields. No markdown fences,
preface, trailing text or tool calls. All required arrays must exist.
{
  "identity": ["EXACT_OWNER", "EXACT_NAME", "EXACT_TYPE"],
  "status": "risk|no_finding|insufficient_context",
  "summary": "Concise object purpose and assessment in Turkish",
  "coverage": "full_source_reviewed|partial",
  "query_blocks": [
    {"line_start": 1, "line_end": 5, "kind": "static_sql|dynamic_sql|unresolved_dynamic_sql", "assessment": "Concise assessment"}
  ],
  "limitations": ["Specific missing context, if any"],
  "findings": [
    {"line_start": 1, "line_end": 5, "evidence": "exact source substring",
     "reason": "Affected expression, grouping scope and reason",
     "confidence": "low|medium|high",
     "suggestion": "Conditional correction or concrete review action",
     "semantic_impact": "Effect on grouping/business meaning, or unknown intent"}
  ],
  "version_assessment": "not_established"
}
The strings containing | illustrate alternatives: emit exactly ONE enum value.
line_start/line_end are inclusive integer DBA_SOURCE line numbers of primary source.
Use empty arrays when no entries apply. risk requires findings. no_finding forbids
findings and requires full_source_reviewed. insufficient_context requires limitations.
