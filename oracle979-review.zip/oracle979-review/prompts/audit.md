# Independent second pass
Independently review the same complete object. You have NOT been given the first
review's conclusions. Look both for overlooked grouping problems and plausible
false positives. Follow the identical output contract. Do not fabricate agreement
with another reviewer. Two calls to the same model can share blind spots.
