# First pass
Perform an independent full-object review following all system rules. Pay special
attention to nested scopes and dynamic SQL assembly. Do not keyword-filter away
code without a literal GROUP BY: generated SQL may assemble it in fragments.
