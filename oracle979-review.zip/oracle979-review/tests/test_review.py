import copy
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import review as r


def source():
    return {'identity':['APP','P','PROCEDURE'],'source':[
        {'line':1,'text':'procedure p is\n'},
        {'line':2,'text':'select deptno, ename, count(*) from emp group by deptno;\n'}]}

def answer(payload=None):
    p=payload or source()
    return {'identity':p['identity'],'status':'risk','summary':'Gruplama riski',
            'coverage':'full_source_reviewed','query_blocks':[{'line_start':2,'line_end':2,'kind':'static_sql','assessment':'ename gruplama dışında'}],
            'limitations':[], 'findings':[{'line_start':2,'line_end':2,'evidence':'ename','reason':'Gruplama dışı ifade',
            'confidence':'high','suggestion':'İş anlamına göre düzeltin','semantic_impact':'Grup sayısı değişebilir'}],
            'version_assessment':'not_established'}

class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.path=Path(self.tmp.name)
        self.c=json.loads((r.ROOT/'config.example.json').read_text())
        self.file=self.path/'source.jsonl'
        p=source()
        self.rows=[dict(zip(('OWNER','NAME','TYPE'),p['identity']),LINE=x['line'],TEXT=x['text']) for x in p['source']]
        self.write(self.rows)
    def tearDown(self):
        self.tmp.cleanup()
    def write(self,rows):
        self.file.write_text('\n'.join(json.dumps(x) for x in rows),encoding='utf-8')
    def test_exact_evidence(self):
        r.validate(answer(),source())
        a=answer();a['findings'][0]['evidence']='invented'
        with self.assertRaises(ValueError):r.validate(a,source())
    def test_wrong_identity_and_regression(self):
        for field,val in [('identity',['A','B','C']),('version_assessment','confirmed')]:
            a=answer();a[field]=val
            with self.assertRaises(ValueError):r.validate(a,source())
    def test_partial_and_dynamic_not_clean(self):
        a=answer();a['status']='no_finding';a['findings']=[];a['coverage']='partial'
        with self.assertRaises(ValueError):r.validate(a,source())
        a['coverage']='full_source_reviewed';a['query_blocks'][0]['kind']='unresolved_dynamic_sql'
        with self.assertRaises(ValueError):r.validate(a,source())
    def test_snapshot_validation(self):
        for rows in ([self.rows[0],self.rows[0]],[dict(self.rows[0],LINE=2)]):
            self.write(rows)
            with self.assertRaises(ValueError):r.load_rows(self.file)
    def test_failed_import_keeps_inventory(self):
        with r.database(self.path/'db') as db:
            r.ingest(db,self.file)
            self.write([])
            with self.assertRaises(ValueError):r.ingest(db,self.file)
            self.assertEqual(db.execute('select count(*) from objects where active=1').fetchone()[0],1)
    def test_plan_cache_and_context_limit(self):
        with r.database(self.path/'db') as db:
            r.ingest(db,self.file)
            a,keys,_=r.plan(db,self.c)
            self.assertEqual(keys,r.plan(db,self.c)[1])
            c=dict(self.c,max_request_bytes=100)
            b,other,_=r.plan(db,c)
            self.assertNotEqual(a,b)
            self.assertEqual(db.execute('select status from jobs where key=?',(other[0],)).fetchone()[0],'blocked')
    def test_spec_changes_invalidate_body(self):
        rows=[dict(x,TYPE='PACKAGE BODY') for x in self.rows]+[dict(self.rows[0],TYPE='PACKAGE',TEXT='package p as\n')]
        self.write(rows)
        with r.database(self.path/'db') as db:
            r.ingest(db,self.file);old=set(r.plan(db,self.c)[1])
            rows[-1]['TEXT']='package p authid current_user as\n';self.write(rows)
            r.ingest(db,self.file);new=set(r.plan(db,self.c)[1])
            self.assertFalse(old & new)
    def test_two_pass_resume_and_report(self):
        with r.database(self.path/'db') as db:
            r.ingest(db,self.file)
            with patch.object(r,'chat',return_value=(answer(),{'model':'mock'})) as mock,patch('sys.stdout',new=io.StringIO()):
                r.run(db,self.c,0,False)
                r.run(db,self.c,0,False)
                self.assertEqual(mock.call_count,2)
                r.report(db,self.c,self.path/'reports')
            report=json.loads((self.path/'reports/report.json').read_text())
            self.assertFalse(report['objects'][0]['result']['oracle_validated'])
            import csv
            with open(self.path/'reports/report.csv',encoding='utf-8-sig') as f:
                rows=list(csv.reader(f))
            self.assertTrue(all(len(x)==len(rows[0]) for x in rows))
    def test_crash_recovery_and_failed_retry(self):
        with r.database(self.path/'db') as db:
            r.ingest(db,self.file);_,keys,_=r.plan(db,self.c)
            db.execute("update jobs set status='running'");db.commit()
            with patch.object(r,'chat',side_effect=ValueError('bad JSON')),patch('sys.stdout',new=io.StringIO()):
                r.run(db,self.c,0,False)
            self.assertEqual(db.execute('select status from jobs').fetchone()[0],'failed')
            with patch.object(r,'chat',return_value=(answer(),{})) as mock,patch('sys.stdout',new=io.StringIO()):
                r.run(db,self.c,0,False);self.assertEqual(mock.call_count,0)
                r.run(db,self.c,0,True);self.assertEqual(mock.call_count,2)
    def test_disagreement_preserves_both(self):
        a=answer();b=copy.deepcopy(a);b.update(status='no_finding',findings=[])
        result=r.combine(a,b)
        self.assertTrue(result['review_disagreement'])
        self.assertTrue(result['manual_review_required'])
        self.assertEqual(len(result['reviews'][0]['findings']),1)
    def test_wrapped_and_unsupported(self):
        rows=[dict(self.rows[0],TEXT='procedure p wrapped\n'),dict(self.rows[0],NAME='J',TYPE='JAVA SOURCE')]
        self.write(rows)
        with r.database(self.path/'db') as db:
            r.ingest(db,self.file);r.plan(db,self.c)
            self.assertEqual(db.execute("select count(*) from jobs where status='blocked'").fetchone()[0],2)
    def test_chat_complete_and_truncated(self):
        from unittest.mock import MagicMock
        response=MagicMock()
        opener=MagicMock()
        opener.open.return_value.__enter__.return_value=response
        data={'choices':[{'finish_reason':'stop','message':{'content':json.dumps(answer())}}],'model':'mock'}
        response.read.return_value=json.dumps(data).encode()
        with patch.object(r.urllib.request,'build_opener',return_value=opener),patch.dict('os.environ',{'REMOTE_CHAT_API_KEY':'test-only'}):
            result,_=r.chat(self.c,[])
            self.assertEqual(result['status'],'risk')
            data['choices'][0]['finish_reason']='length'
            response.read.return_value=json.dumps(data).encode()
            with self.assertRaises(ValueError):r.chat(self.c,[])
    def test_auth_fails_without_retry(self):
        from unittest.mock import MagicMock
        opener=MagicMock()
        opener.open.side_effect=r.urllib.error.HTTPError('https://example.invalid',401,'unauthorized',{},None)
        with patch.object(r.urllib.request,'build_opener',return_value=opener),patch.dict('os.environ',{'REMOTE_CHAT_API_KEY':'test-only'}):
            with self.assertRaises(r.FatalAPI):r.chat(self.c,[])
            self.assertEqual(opener.open.call_count,1)
    def test_valid_first_pass_survives_second_pass_outage(self):
        with r.database(self.path/'db') as db:
            r.ingest(db,self.file)
            with patch.object(r,'chat',side_effect=[(answer(),{}),r.FatalAPI('HTTP 401')]),patch('sys.stdout',new=io.StringIO()):
                with self.assertRaises(RuntimeError):r.run(db,self.c,0,False)
            self.assertEqual(db.execute('select count(*) from calls').fetchone()[0],1)
            with patch.object(r,'chat',return_value=(answer(),{})) as mock,patch('sys.stdout',new=io.StringIO()):
                r.run(db,self.c,0,True)
                self.assertEqual(mock.call_count,1)
    def test_extractor_only_metadata_select(self):
        from unittest.mock import MagicMock
        module=MagicMock();conn=module.connect.return_value.__enter__.return_value
        cur=conn.cursor.return_value.__enter__.return_value
        cur.__iter__.return_value=iter([tuple(x[k] for k in ('OWNER','NAME','TYPE','LINE','TEXT')) for x in self.rows])
        with patch.dict(sys.modules,{'oracledb':module}),patch.dict('os.environ',{'ORACLE_USER':'u','ORACLE_PASSWORD':'p','ORACLE_DSN':'d'}):
            r.extract(self.c,["APP' OR 1=1 --"],self.path/'out.jsonl')
        sql,binds=cur.execute.call_args.args
        self.assertTrue(sql.startswith('SELECT owner, name, type, line, text FROM SYS.DBA_SOURCE'))
        self.assertNotIn("APP'",sql)
        self.assertEqual(binds['o0'],"APP' OR 1=1 --")
        self.assertEqual(cur.execute.call_count,1)

if __name__=='__main__':unittest.main()
