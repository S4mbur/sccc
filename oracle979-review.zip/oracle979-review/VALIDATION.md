# Teslimat test kaydı

Tarih: 2026-11-06
Ortam: Python 3.12.14, Linux; hedef RHEL üzerinde çalıştırılmadı.

15 unittest başarılı:
- Yanlış kaynak alıntısı / obje kimliği / temelsiz regresyon iddiası reddi
- Kısmi inceleme ve belirsiz dinamik SQL'in temiz sayılmaması
- Eksik / duplicate kaynak satırlarının reddi ve hatalı importta envanterin korunması
- Context bütçesi aşımının bloke edilmesi
- Package spec değişiminde body incelemesinin geçersizleşmesi
- İki tur, kaldığı yerden devam, CSV/JSON rapor üretimi
- Process kesintisi ve explicit başarısız iş retry
- Birinci tur kaydı korunarak ikinci tur API hatasından devam
- Turlar arası anlaşmazlıkta iki bulgunun da korunması
- Wrapped / unsupported kaynak ayrımı
- API final yanıtı kesilmişse reddetme, 401'de hemen durma
- Extractor'un yalnızca bind'li DBA_SOURCE SELECT yapması (mock bağlantı)

CLI smoke: 3 örnek obje import, plan ve report komutları başarılı;
üçü de henüz model incelemesi yapılmadığı için pending raporlandı.

Internal model/Oracle/RHEL entegrasyonu ve modelin tespit kalitesi test edilmedi.
Mock testler gerçek SQL semantiği veya 19.32 uyumluluğunu doğrulamaz.
