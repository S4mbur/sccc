-- Run in the database that will hold the audit repository.
-- Example: psql -d auditdb -f audit_schema.sql

CREATE TABLE IF NOT EXISTS audit_targets (
    table_name text PRIMARY KEY,
    enabled boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS audit_history (
    id bigserial PRIMARY KEY,
    event_time timestamptz NOT NULL,
    database_name text,
    db_user text,
    client_ip inet,
    application_name text,
    pid integer,
    session_id text,
    command_type text,
    table_name text NOT NULL,
    statement text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_history_event_time
    ON audit_history (event_time DESC);

CREATE INDEX IF NOT EXISTS idx_audit_history_table_time
    ON audit_history (table_name, event_time DESC);

CREATE INDEX IF NOT EXISTS idx_audit_history_user_time
    ON audit_history (db_user, event_time DESC);

-- Dedicated writer. Change the password immediately after creating the role.
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'audit_writer') THEN
        CREATE ROLE audit_writer LOGIN PASSWORD 'CHANGE_ME_NOW';
    END IF;
END
$$;

GRANT CONNECT ON DATABASE CURRENT_DATABASE() TO audit_writer;
GRANT USAGE ON SCHEMA public TO audit_writer;
GRANT SELECT ON audit_targets TO audit_writer;
GRANT INSERT ON audit_history TO audit_writer;
GRANT USAGE, SELECT ON SEQUENCE audit_history_id_seq TO audit_writer;

-- Critical: prevent collector INSERTs from being re-logged by log_statement=all.
ALTER ROLE audit_writer SET log_statement = 'none';
