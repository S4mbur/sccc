# PostgreSQL 15 filtered audit collector for RHEL

This package implements:

`log_statement=all -> PostgreSQL jsonlog -> collector -> table-name whitelist -> audit_history`

The whitelist intentionally contains only `table_name`; schema/database are not part
of the matching decision. `database_name` is still stored in audit_history directly
from PostgreSQL JSON metadata, not parsed from SQL.

## Why this design

- DBeaver metadata queries against `pg_catalog` / `information_schema` still exist in
  PostgreSQL raw logs, but they are not copied into `audit_history` unless their table
  name is explicitly present in `audit_targets`.
- Queries using `public.customer`, `"PUBLIC"."CUSTOMER"`, or just `customer` are matched
  using the final relation name (`customer`).
- One audit_history row is written for each matched target table.
- The collector uses a dedicated `audit_writer` role with `log_statement=none` to avoid
  recursively auditing its own INSERTs.
- It follows PostgreSQL's `current_logfiles`, so normal jsonlog rotation is supported.
- State is persisted so a service restart does not reread already-consumed log lines.

## Important limitation

`log_statement=all` is still global raw logging. This collector reduces the size/noise
of the audit repository, but it does NOT prevent PostgreSQL from writing non-target SQL
to the raw jsonlog first.

The SQL relation detector is deliberately lightweight and dependency-free. It covers
common SELECT/FROM/JOIN, INSERT, UPDATE, DELETE, MERGE, TRUNCATE, TABLE DDL, REFERENCES,
and CREATE INDEX ... ON patterns. Exotic dynamic SQL or unusual syntax should be tested
before treating this as a compliance-grade audit source.

## Installation

### 1. Create the audit database

Example:

```bash
sudo -u postgres createdb auditdb
sudo -u postgres psql -d auditdb -f audit_schema.sql
```

Change the generated placeholder password:

```sql
ALTER ROLE audit_writer PASSWORD 'a-strong-password';
```

### 2. PostgreSQL logging

Merge `postgresql_logging.conf.example` into your active `postgresql.conf`.

Check paths:

```sql
SHOW config_file;
SHOW data_directory;
SHOW logging_collector;
SHOW log_destination;
SHOW log_statement;
```

Restart PostgreSQL after enabling `logging_collector`.

Then check:

```bash
cat "$PGDATA/current_logfiles"
```

You should see a `jsonlog ...` line.

### 3. Install collector

```bash
sudo bash install.sh
```

Edit:

```bash
sudo vi /etc/pg-audit-collector/collector.env
```

Set `PGDATA`, connection details, and password.

### 4. Add targets

Single table:

```sql
INSERT INTO audit_targets(table_name) VALUES ('customer')
ON CONFLICT (table_name) DO UPDATE SET enabled=true;
```

Disable one:

```sql
UPDATE audit_targets SET enabled=false WHERE table_name='customer';
```

Add every existing user table across every connectable non-template DB:

```bash
sudo -u postgres AUDIT_DB=auditdb ./sync_all_tables.sh
```

Only selected databases:

```bash
sudo -u postgres \
  AUDIT_DB=auditdb \
  DATABASES="appdb reportingdb" \
  ./sync_all_tables.sh
```

Because the control table is name-only, duplicate table names in different schemas or
databases collapse to one target name. Consequently, if `customer` is enabled, every
`customer` table in every logged database is considered a target.

### 5. Start

```bash
sudo systemctl enable --now pg-audit-collector
sudo journalctl -u pg-audit-collector -f
```

### 6. Test

Run against a target table:

```sql
SELECT * FROM customer LIMIT 1;
```

Then:

```sql
SELECT event_time, database_name, db_user, client_ip,
       application_name, command_type, table_name, statement
FROM audit_history
ORDER BY id DESC
LIMIT 20;
```

A DBeaver query that only touches `pg_catalog.pg_class` should not enter audit_history
unless `pg_class` itself was added as a target.

## Operational recommendations

1. Keep raw jsonlog retention short (for example 1-7 days depending on policy/capacity).
2. Keep audit_history retention separately according to audit requirements.
3. Partition audit_history by event_time later if volume becomes large.
4. Do not expose audit_writer credentials to application users.
5. `log_statement=all` can log sensitive literal values. Protect raw logs and audit_history.
6. Load-test `log_statement=all` before production rollout.
