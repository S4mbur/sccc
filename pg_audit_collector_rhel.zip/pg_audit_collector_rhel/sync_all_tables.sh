#!/usr/bin/env bash
set -euo pipefail

# Adds ALL existing ordinary + partitioned user table names from the selected
# PostgreSQL databases into audit_targets. Matching stays table-name-only:
# database and schema are NOT stored in audit_targets.
#
# Run as postgres OS user (or another role that can connect/read catalogs).
#
# Usage:
#   sudo -u postgres ./sync_all_tables.sh
#
# Optional environment:
#   AUDIT_DB=auditdb
#   PGPORT=5432
#   DATABASES="appdb anotherdb"
# If DATABASES is empty, all connectable non-template databases are scanned.

AUDIT_DB="${AUDIT_DB:-auditdb}"
PGPORT="${PGPORT:-5432}"
DATABASES="${DATABASES:-}"

if [[ -z "$DATABASES" ]]; then
  DATABASES="$(psql -p "$PGPORT" -d postgres -Atqc \
    "SELECT datname
       FROM pg_database
      WHERE datallowconn
        AND NOT datistemplate
        AND datname <> '$AUDIT_DB'
      ORDER BY 1")"
fi

tmp="$(mktemp)"
trap 'rm -f "$tmp"' EXIT

for db in $DATABASES; do
  echo "Scanning database: $db" >&2
  psql -p "$PGPORT" -d "$db" -Atqc "
    SELECT DISTINCT c.relname
      FROM pg_class c
      JOIN pg_namespace n ON n.oid = c.relnamespace
     WHERE c.relkind IN ('r','p')
       AND n.nspname NOT IN ('pg_catalog','information_schema')
       AND n.nspname NOT LIKE 'pg_toast%'
     ORDER BY 1;
  " >> "$tmp"
done

sort -u "$tmp" -o "$tmp"

# Insert safely using psql \copy into a temp table, then ON CONFLICT upsert.
psql -p "$PGPORT" -d "$AUDIT_DB" <<SQL
CREATE TEMP TABLE _audit_sync_names(table_name text);
\copy _audit_sync_names(table_name) FROM '$tmp'
INSERT INTO audit_targets(table_name, enabled)
SELECT table_name, true
FROM _audit_sync_names
WHERE table_name IS NOT NULL AND btrim(table_name) <> ''
ON CONFLICT (table_name)
DO UPDATE SET enabled = EXCLUDED.enabled;
SQL

echo "Done. Enabled targets:"
psql -p "$PGPORT" -d "$AUDIT_DB" -c \
  "SELECT count(*) AS enabled_target_count FROM audit_targets WHERE enabled;"
