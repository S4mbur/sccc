#!/usr/bin/env python3
import json
import logging
import os
import re
import signal
import sys
import time
from pathlib import Path

import psycopg2
from psycopg2.extras import execute_values

RUNNING = True

def env(name, default=None):
    return os.environ.get(name, default)

PGDATA = Path(env("PGDATA", "/var/lib/pgsql/data"))
STATE_FILE = Path(env("STATE_FILE", "/var/lib/pg-audit-collector/state.json"))
TARGET_REFRESH_SECONDS = int(env("TARGET_REFRESH_SECONDS", "30"))
POLL_SECONDS = float(env("POLL_SECONDS", "0.5"))
BATCH_SIZE = int(env("BATCH_SIZE", "100"))
FLUSH_SECONDS = float(env("FLUSH_SECONDS", "2"))
START_AT_END = env("START_AT_END", "true").lower() in ("1","true","yes","on")
IGNORE_DB_USERS = {x.strip() for x in env("IGNORE_DB_USERS", "audit_writer").split(",") if x.strip()}
IGNORE_DATABASES = {x.strip() for x in env("IGNORE_DATABASES", "").split(",") if x.strip()}

logging.basicConfig(
    level=getattr(logging, env("COLLECTOR_LOG_LEVEL", "INFO").upper(), logging.INFO),
    format="%(asctime)s %(levelname)s %(message)s",
)
LOG = logging.getLogger("pg-audit-collector")

DB_KW = dict(
    host=env("AUDIT_HOST", "/var/run/postgresql"),
    port=int(env("AUDIT_PORT", "5432")),
    dbname=env("AUDIT_DB", "auditdb"),
    user=env("AUDIT_USER", "audit_writer"),
    password=env("AUDIT_PASSWORD", ""),
    connect_timeout=5,
    application_name="pg_audit_collector",
)

# We intentionally ignore schema/database while matching.
# Capture only the final relation identifier after relation-bearing SQL keywords.
IDENT = r'(?:"(?:[^"]|"")*"|[A-Za-z_][A-Za-z0-9_$]*)'
REL = rf'(?:(?:{IDENT})\s*\.\s*)?({IDENT})'

REL_PATTERNS = [
    re.compile(rf'\bFROM\s+{REL}', re.I),
    re.compile(rf'\bJOIN\s+{REL}', re.I),
    re.compile(rf'\bUPDATE\s+{REL}', re.I),
    re.compile(rf'\bINSERT\s+INTO\s+{REL}', re.I),
    re.compile(rf'\bDELETE\s+FROM\s+{REL}', re.I),
    re.compile(rf'\bMERGE\s+INTO\s+{REL}', re.I),
    re.compile(rf'\bTRUNCATE(?:\s+TABLE)?\s+{REL}', re.I),
    re.compile(rf'\bALTER\s+TABLE(?:\s+IF\s+EXISTS)?\s+{REL}', re.I),
    re.compile(rf'\bDROP\s+TABLE(?:\s+IF\s+EXISTS)?\s+{REL}', re.I),
    re.compile(rf'\bCREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?\s+{REL}', re.I),
    re.compile(rf'\bLOCK\s+TABLE\s+{REL}', re.I),
    re.compile(rf'\bREFERENCES\s+{REL}', re.I),
    re.compile(rf'\bCREATE(?:\s+UNIQUE)?\s+INDEX\b.*?\bON\s+{REL}', re.I | re.S),
    re.compile(rf'\bALTER\s+INDEX(?:\s+IF\s+EXISTS)?\s+{REL}', re.I),
    re.compile(rf'\bDROP\s+INDEX(?:\s+IF\s+EXISTS)?\s+{REL}', re.I),
]

MSG_SQL_RE = re.compile(r'^(?:statement|execute(?:\s+[^:]+)?):\s*(.*)$', re.I | re.S)

COMMANDS = (
    "SELECT", "INSERT", "UPDATE", "DELETE", "MERGE", "TRUNCATE",
    "CREATE", "ALTER", "DROP", "GRANT", "REVOKE", "COMMENT",
    "COPY", "CALL", "DO"
)

def stop_handler(signum, frame):
    global RUNNING
    RUNNING = False

signal.signal(signal.SIGTERM, stop_handler)
signal.signal(signal.SIGINT, stop_handler)

def normalize_ident(s):
    s = s.strip()
    if s.startswith('"') and s.endswith('"'):
        s = s[1:-1].replace('""', '"')
    return s.casefold()

def classify(sql):
    # Remove leading SQL comments enough for common cases.
    s = re.sub(r'^\s*(?:--[^\n]*\n\s*|/\*.*?\*/\s*)*', '', sql, flags=re.S)
    upper = s.upper()
    first = re.match(r'([A-Z]+)', upper)
    if first and first.group(1) != "WITH":
        return first.group(1)
    # WITH/CTE: best-effort classification.
    hits = []
    for cmd in COMMANDS:
        m = re.search(rf'\b{cmd}\b', upper)
        if m:
            hits.append((m.start(), cmd))
    return min(hits)[1] if hits else "UNKNOWN"

def extract_sql(entry):
    msg = entry.get("message") or ""
    m = MSG_SQL_RE.match(msg)
    if not m:
        return None
    return m.group(1).strip()

def extract_relation_names(sql):
    names = set()
    for pat in REL_PATTERNS:
        for m in pat.finditer(sql):
            names.add(normalize_ident(m.group(1)))
    return names

def current_jsonlog():
    f = PGDATA / "current_logfiles"
    if not f.exists():
        raise FileNotFoundError(f"{f} not found; logging_collector/jsonlog may not be active")
    for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
        dest, _, relpath = line.partition(" ")
        if dest.strip() == "jsonlog" and relpath.strip():
            p = Path(relpath.strip())
            return p if p.is_absolute() else PGDATA / p
    raise RuntimeError(f"No jsonlog entry found in {f}")

def load_state():
    try:
        return json.loads(STATE_FILE.read_text())
    except Exception:
        return {}

def save_state(path, inode, offset):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps({"path": str(path), "inode": inode, "offset": offset}))
    os.replace(tmp, STATE_FILE)

def db_connect():
    conn = psycopg2.connect(**DB_KW)
    conn.autocommit = False
    return conn

def load_targets(conn):
    with conn.cursor() as cur:
        cur.execute("SELECT table_name FROM audit_targets WHERE enabled")
        return {normalize_ident(r[0]) for r in cur.fetchall()}

def flush_rows(conn, rows):
    if not rows:
        return
    sql = """
        INSERT INTO audit_history
        (event_time, database_name, db_user, client_ip, application_name,
         pid, session_id, command_type, table_name, statement)
        VALUES %s
    """
    with conn.cursor() as cur:
        execute_values(cur, sql, rows, page_size=min(500, len(rows)))
    conn.commit()
    rows.clear()

def make_rows(entry, sql, targets):
    db_user = entry.get("user")
    dbname = entry.get("dbname")
    if db_user in IGNORE_DB_USERS or dbname in IGNORE_DATABASES:
        return []

    relations = extract_relation_names(sql)
    matched = sorted(relations & targets)
    if not matched:
        return []

    event_time = entry.get("timestamp")
    command = classify(sql)
    base = (
        event_time,
        dbname,
        db_user,
        entry.get("remote_host"),
        entry.get("application_name"),
        entry.get("pid"),
        entry.get("session_id"),
        command,
    )
    # One row per matched target table: easy to search/index and no arrays needed.
    return [base + (table_name, sql) for table_name in matched]

def open_follow_file(path, state):
    fh = path.open("r", encoding="utf-8", errors="replace")
    st = path.stat()
    inode = st.st_ino
    if state.get("path") == str(path) and state.get("inode") == inode:
        fh.seek(int(state.get("offset", 0)))
    elif START_AT_END:
        fh.seek(0, os.SEEK_END)
        LOG.info("Starting at end of %s", path)
    else:
        fh.seek(0)
        LOG.info("Starting at beginning of %s", path)
    return fh, inode

def main():
    LOG.info("collector starting; PGDATA=%s", PGDATA)
    conn = None
    targets = set()
    next_target_refresh = 0
    rows = []
    last_flush = time.monotonic()
    state = load_state()

    path = current_jsonlog()
    fh, inode = open_follow_file(path, state)

    while RUNNING:
        now = time.monotonic()

        # DB/repository connection and target refresh.
        if conn is None or conn.closed:
            try:
                conn = db_connect()
                next_target_refresh = 0
                LOG.info("connected to audit repository")
            except Exception as e:
                LOG.error("audit repository connection failed: %s", e)
                time.sleep(2)
                continue

        if now >= next_target_refresh:
            try:
                targets = load_targets(conn)
                conn.commit()
                next_target_refresh = now + TARGET_REFRESH_SECONDS
                LOG.debug("loaded %d enabled targets", len(targets))
            except Exception as e:
                conn.rollback()
                LOG.error("target refresh failed: %s", e)
                time.sleep(1)
                continue

        line = fh.readline()
        if line:
            try:
                entry = json.loads(line)
                sql = extract_sql(entry)
                if sql:
                    rows.extend(make_rows(entry, sql, targets))
            except json.JSONDecodeError:
                LOG.warning("invalid/incomplete JSON line skipped at %s:%d", path, fh.tell())
            except Exception:
                LOG.exception("processing error")
            save_state(path, inode, fh.tell())
        else:
            # Check for log rotation.
            try:
                new_path = current_jsonlog()
                new_inode = new_path.stat().st_ino
                if str(new_path) != str(path) or new_inode != inode:
                    # Current file has reached EOF; switch to newly advertised jsonlog.
                    fh.close()
                    path = new_path
                    state = {}
                    fh, inode = open_follow_file(path, state)
                    LOG.info("switched to rotated jsonlog %s", path)
            except Exception as e:
                LOG.warning("rotation check failed: %s", e)
            time.sleep(POLL_SECONDS)

        if rows and (len(rows) >= BATCH_SIZE or now - last_flush >= FLUSH_SECONDS):
            try:
                flush_rows(conn, rows)
                last_flush = now
            except Exception:
                if conn:
                    conn.rollback()
                LOG.exception("audit insert failed; rows retained for retry")
                time.sleep(1)

    try:
        if conn and rows:
            flush_rows(conn, rows)
    except Exception:
        LOG.exception("final flush failed")
    try:
        fh.close()
    except Exception:
        pass
    if conn:
        conn.close()
    LOG.info("collector stopped")

if __name__ == "__main__":
    main()
