#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[1/6] Installing runtime dependency from enabled RHEL repositories..."
dnf install -y python3 python3-psycopg2

echo "[2/6] Installing collector..."
install -d -m 0750 -o root -g postgres /opt/pg-audit-collector
install -m 0750 -o root -g postgres "$BASE_DIR/audit_collector.py" /opt/pg-audit-collector/audit_collector.py

echo "[3/6] Installing configuration..."
install -d -m 0750 -o root -g postgres /etc/pg-audit-collector
if [[ ! -f /etc/pg-audit-collector/collector.env ]]; then
  install -m 0640 -o root -g postgres "$BASE_DIR/collector.env.example" /etc/pg-audit-collector/collector.env
  echo "Created /etc/pg-audit-collector/collector.env"
else
  echo "Existing collector.env preserved."
fi

echo "[4/6] Installing persistent state directory..."
install -d -m 0750 -o postgres -g postgres /var/lib/pg-audit-collector

echo "[5/6] Installing systemd unit..."
install -m 0644 "$BASE_DIR/pg-audit-collector.service" /etc/systemd/system/pg-audit-collector.service
systemctl daemon-reload

echo "[6/6] Done."
echo
echo "NEXT STEPS:"
echo "  1) Create/configure audit repository:"
echo "       psql -d auditdb -f $BASE_DIR/audit_schema.sql"
echo "     Then change audit_writer password in PostgreSQL."
echo
echo "  2) Merge $BASE_DIR/postgresql_logging.conf.example into postgresql.conf"
echo "     and restart PostgreSQL because logging_collector needs restart."
echo
echo "  3) Edit /etc/pg-audit-collector/collector.env"
echo
echo "  4) Add target tables:"
echo "       sudo -u postgres AUDIT_DB=auditdb $BASE_DIR/sync_all_tables.sh"
echo
echo "  5) Test config:"
echo "       sudo -u postgres env \$(grep -v '^#' /etc/pg-audit-collector/collector.env | xargs) \\"
echo "         /usr/bin/python3 /opt/pg-audit-collector/audit_collector.py"
echo
echo "  6) Enable service:"
echo "       systemctl enable --now pg-audit-collector"
echo "       journalctl -u pg-audit-collector -f"
