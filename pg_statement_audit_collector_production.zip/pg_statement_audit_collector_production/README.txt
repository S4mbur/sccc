POSTGRESQL 15 DURABLE STATEMENT AUDIT COLLECTOR
===============================================

CORE MODEL
----------
Global setting:
    log_statement = none

Enable only selected role/database pairs:
    SELECT audit_watch_set('user1','appdb',true);

This function does both:
    1) audit_scope insert/update
    2) ALTER ROLE user1 IN DATABASE appdb SET log_statement='all'

Disable:
    SELECT audit_watch_set('user1','appdb',false);

A NEW DB CONNECTION is required before ALTER ROLE ... IN DATABASE settings apply.


INSTALL
-------
1. Unzip under /u01, /data, or another directory readable by postgres OS user.
2. Edit collector.env.
3. Run:
       sudo bash install.sh

Only one file is installed under /etc:
    /etc/systemd/system/pg-audit-collector.service

Python uses only standard-library modules.
DB access is via psql subprocess; no psycopg/psycopg2.


AUDIT_HISTORY
-------------
One PostgreSQL JSON log event becomes ONE audit_history row.
The SQL text is never duplicated once per referenced table.

Columns:
    id
    event_key
    event_time
    db_user
    client_host
    application_name
    session_id
    line_num
    query_id
    severity
    sqlstate
    statement
    detail
    message
    created_at

client_host is TEXT, so Unix-socket value [local] is valid.

Example:
    SELECT id,event_time,db_user,client_host,application_name,
           query_id,severity,sqlstate,statement,detail,message
    FROM audit_history
    ORDER BY id DESC
    LIMIT 50;

If an old-format audit_history exists, install preserves it once as:
    audit_history_legacy
and creates the new format as audit_history.


ERRORS / QUERY_ID / PARAMETERS
------------------------------
install.sh applies by default:
    log_statement = none              -- global baseline
    log_min_error_statement = error
    compute_query_id = on

JSON fields statement/detail/query_id/error_severity/state_code are consumed.
ERROR/FATAL/PANIC events inside audit_scope are retained.

For normal extended-protocol logging, PostgreSQL log_statement=all includes Bind
parameter values. For ERROR records, bind-value capture is separately controlled:

    LOG_PARAMETER_MAX_LENGTH_ON_ERROR=0

0  = no bind values in errors (safe default)
-1 = full values
N  = maximum N bytes per value

WARNING: -1 can expose passwords, tokens, personal data, etc. and adds overhead.


SCOPE
-----
Preferred exact role+database pair:
    SELECT audit_watch_set('user1','appdb',true);

Disable:
    SELECT audit_watch_set('user1','appdb',false);

Collector-only wildcard scope remains available:
    SELECT audit_scope_set('user1','*',true);
    SELECT audit_scope_set('*','appdb',true);
    SELECT audit_scope_set('*','*',true);

Important: wildcard scope only FILTERS logs that already exist. It does not
turn log_statement on for every role. Prefer exact audit_watch_set() pairs.

List:
    SELECT * FROM audit_scope ORDER BY database_name,db_user;


STRICT IGNORE RULES
-------------------
Default exact schemas only:
    pg_catalog
    information_schema
    pg_toast

There is NO LIKE, pg_%, prefix, regex, or wildcard ignore logic.

Add exact schema:
    SELECT audit_ignore_schema_set('monitoring',true);

Disable:
    SELECT audit_ignore_schema_set('monitoring',false);

Exact database+schema+table:
    SELECT audit_ignore_table_set(
        'appdb',
        'public',
        'heartbeat',
        true
    );

List:
    SELECT * FROM audit_ignore_schema ORDER BY schema_name;
    SELECT * FROM audit_ignore_table ORDER BY database_name,schema_name,table_name;

Fail-open behavior:
    SELECT * FROM pg_catalog.pg_class;
        -> exact pg_catalog can be ignored

    SELECT * FROM pg_class;
        -> schema unknown, so AUDIT it

Any parsing ambiguity => AUDIT it.
COPY is recognized.
UPDATE/DELETE/FROM ... ONLY are recognized.
Comma-FROM is considered ambiguous => AUDIT it.


NOISE WHITELIST
---------------
Relation-less normal statements beginning with these are dropped:
    SET
    RESET
    SHOW
    BEGIN
    START TRANSACTION
    COMMIT
    END
    ROLLBACK
    SAVEPOINT
    RELEASE

A statement where no table can be determined is otherwise kept.


DURABILITY / CRASH SAFETY
-------------------------
Order is:
    read log
      -> buffer
      -> COMMIT audit rows
      -> save state offset

State is NOT advanced past uncommitted audit rows.

Each row has deterministic SHA-256 event_key UNIQUE.
If DB commit succeeds but process dies before state.json is written, restart may
reread the event, but ON CONFLICT DO NOTHING avoids duplicates.

psql calls have:
    connection timeout
    statement_timeout
    lock_timeout
    Python subprocess timeout


ROTATION
--------
START_AT_END=true is used ONLY if there is no existing state/checkpoint.

At rotation:
    old file is read to EOF
    pending audit rows are committed
    checkpoint is saved
    next/backlog file starts at offset 0

The collector scans the JSON-log directory and follows intermediate rotated files,
not only the file currently named in current_logfiles.

If checkpoint offset > current file size, the file is considered truncated and
reopened from offset 0.

If the checkpoint file has already disappeared, collector continues from the
earliest available newer file and writes a possible-gap warning to heartbeat.


HEARTBEAT / MONITORING
----------------------
Table:
    audit_collector_status

Check:
    SELECT
        collector_name,
        last_seen,
        now()-last_seen AS heartbeat_age,
        last_successful_flush,
        last_log_event,
        lag_seconds,
        buffer_size,
        current_file,
        current_offset,
        last_error
    FROM audit_collector_status;

Typical alerts:
    heartbeat_age > 30 seconds
    lag_seconds > 30
    buffer_size > 1000
    last_error IS NOT NULL


SECURITY
--------
Installer applies:
    REVOKE CONNECT ON DATABASE auditdb FROM PUBLIC
    REVOKE CREATE ON SCHEMA public FROM PUBLIC
    REVOKE table access FROM PUBLIC
    REVOKE management function EXECUTE FROM PUBLIC

Only audit_writer receives required repository/config permissions.


RAW LOG CAPACITY
----------------
Filtering occurs AFTER PostgreSQL emits jsonlog, so global log_statement must stay
none and only selected roles/databases should get all.

Use a properly sized/monitored log filesystem and alert on free disk + collector lag.
