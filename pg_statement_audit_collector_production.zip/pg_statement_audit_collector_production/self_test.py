#!/usr/bin/env python3
import importlib.util
from pathlib import Path

p = Path(__file__).resolve().parent / 'audit_collector.py'
spec = importlib.util.spec_from_file_location('collector', p)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

schemas = {'pg_catalog','information_schema','pg_toast'}
tables = {('appdb','public','heartbeat')}

assert m.all_relations_explicitly_ignored('appdb','SELECT * FROM pg_catalog.pg_class',schemas,tables)
assert not m.all_relations_explicitly_ignored('appdb','SELECT * FROM pg_class',schemas,tables)
assert m.all_relations_explicitly_ignored('appdb','SELECT * FROM public.heartbeat',set(),tables)
assert not m.all_relations_explicitly_ignored('otherdb','SELECT * FROM public.heartbeat',set(),tables)
assert not m.all_relations_explicitly_ignored('appdb','UPDATE ONLY public.salaries SET x=1',schemas,tables)
assert not m.all_relations_explicitly_ignored('appdb','SELECT EXTRACT(YEAR FROM now())',schemas,tables)
assert not m.all_relations_explicitly_ignored('appdb','SELECT * FROM pg_catalog.pg_class, pg_catalog.pg_namespace',schemas,tables)
assert m.all_relations_explicitly_ignored('appdb','COPY pg_catalog.pg_class TO STDOUT',schemas,tables)

entry = {
    'timestamp':'2026-10-01 20:00:00+03',
    'user':'u1',
    'dbname':'appdb',
    'session_id':'abc',
    'line_num':1,
    'message':'statement: SELECT * FROM public.customer',
    'remote_host':'[local]'
}
store, sql = m.should_store(entry,{('u1','appdb')},schemas,tables)
assert store and sql == 'SELECT * FROM public.customer'

err = {
    'timestamp':'2026-10-01 20:00:01+03',
    'user':'u1',
    'dbname':'appdb',
    'session_id':'abc',
    'line_num':2,
    'error_severity':'ERROR',
    'state_code':'42501',
    'message':'permission denied for table customer',
    'statement':'SELECT * FROM public.customer'
}
store, sql = m.should_store(err,{('u1','appdb')},schemas,tables)
assert store and sql == 'SELECT * FROM public.customer'

print('self-test OK')
