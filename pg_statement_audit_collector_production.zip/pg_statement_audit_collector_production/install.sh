#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
ENV_FILE="$APP_DIR/collector.env"
SERVICE_FILE="/etc/systemd/system/pg-audit-collector.service"

if [[ "$(id -u)" -ne 0 ]]; then
    echo "Run as root: sudo bash install.sh"
    exit 1
fi

if [[ ! -f "$ENV_FILE" ]]; then
    echo "Missing $ENV_FILE"
    exit 1
fi

set -a
source "$ENV_FILE"
set +a

: "${PGDATA:=/data/postgres/data}"
: "${PGPORT:=5420}"
: "${AUDIT_DB:=auditdb}"
: "${AUDIT_USER:=audit_writer}"
: "${ADMIN_DB:=postgres}"
: "${ADMIN_DB_USER:=postgres}"
: "${SERVICE_OS_USER:=postgres}"
: "${SERVICE_OS_GROUP:=postgres}"
: "${PSQL_BIN:=/usr/bin/psql}"
: "${PYTHON_BIN:=/usr/bin/python3}"
: "${CREATEDB_BIN:=/usr/bin/createdb}"
: "${APPLY_BASE_LOGGING_SETTINGS:=true}"
: "${LOG_PARAMETER_MAX_LENGTH_ON_ERROR:=0}"

for ident in "$AUDIT_DB" "$AUDIT_USER" "$ADMIN_DB" "$ADMIN_DB_USER"; do
    if [[ ! "$ident" =~ ^[A-Za-z_][A-Za-z0-9_\$-]*$ ]]; then
        echo "Unsupported identifier: $ident"
        exit 1
    fi
done

if [[ ! "$PGPORT" =~ ^[0-9]+$ ]]; then
    echo "PGPORT must be numeric"
    exit 1
fi

if [[ ! "$LOG_PARAMETER_MAX_LENGTH_ON_ERROR" =~ ^-?[0-9]+$ ]]; then
    echo "LOG_PARAMETER_MAX_LENGTH_ON_ERROR must be integer"
    exit 1
fi

for cmd in "$PSQL_BIN" "$PYTHON_BIN" "$CREATEDB_BIN" sudo; do
    command -v "$cmd" >/dev/null 2>&1 || {
        echo "Required command not found: $cmd"
        exit 1
    }
done

echo "============================================================"
echo " PostgreSQL Statement Audit Collector"
echo "============================================================"
echo "Project : $APP_DIR"
echo "PGDATA  : $PGDATA"
echo "Port    : $PGPORT"
echo

systemctl stop pg-audit-collector 2>/dev/null || true

install -d -m 0750 -o "$SERVICE_OS_USER" -g "$SERVICE_OS_GROUP" "$APP_DIR/state"
chown root:"$SERVICE_OS_GROUP" \
    "$APP_DIR/collector.env" \
    "$APP_DIR/audit_collector.py" \
    "$APP_DIR/schema.sql"
chmod 0640 "$APP_DIR/collector.env" "$APP_DIR/schema.sql"
chmod 0750 "$APP_DIR/audit_collector.py" "$APP_DIR/install.sh"

if ! sudo -u "$SERVICE_OS_USER" test -r "$APP_DIR/audit_collector.py"; then
    echo "Service user $SERVICE_OS_USER cannot read/traverse $APP_DIR"
    echo "Extract under a traversable path such as /u01 or /data."
    exit 1
fi

admin_psql=(
    sudo -u "$SERVICE_OS_USER"
    "$PSQL_BIN"
    -X
    -v ON_ERROR_STOP=1
    -p "$PGPORT"
    -U "$ADMIN_DB_USER"
)

echo "[1/9] Checking admin connection..."
"${admin_psql[@]}" -d "$ADMIN_DB" -Atqc "SELECT 1" >/dev/null

if [[ "$APPLY_BASE_LOGGING_SETTINGS" == "true" ]]; then
    echo "[2/9] Applying global baseline: log_statement=none ..."
    "${admin_psql[@]}" -d "$ADMIN_DB" <<SQL
ALTER SYSTEM SET log_statement = 'none';
ALTER SYSTEM SET log_min_error_statement = 'error';
ALTER SYSTEM SET compute_query_id = 'on';
ALTER SYSTEM SET log_parameter_max_length_on_error = '$LOG_PARAMETER_MAX_LENGTH_ON_ERROR';
SELECT pg_reload_conf();
SQL
else
    echo "[2/9] Base logging settings skipped by collector.env"
fi

echo "[3/9] Checking jsonlog / logging_collector..."
logging_collector="$("${admin_psql[@]}" -d "$ADMIN_DB" -Atqc "SHOW logging_collector;")"
log_destination="$("${admin_psql[@]}" -d "$ADMIN_DB" -Atqc "SHOW log_destination;")"
global_statement="$("${admin_psql[@]}" -d "$ADMIN_DB" -Atqc "SHOW log_statement;")"

printf '  logging_collector=%s\n  log_destination=%s\n  global log_statement=%s\n' \
    "$logging_collector" "$log_destination" "$global_statement"

if [[ "$logging_collector" != "on" ]]; then
    echo "ERROR: logging_collector must be on (PostgreSQL restart required after enabling it)."
    exit 1
fi
if [[ "$log_destination" != *jsonlog* ]]; then
    echo "ERROR: log_destination must include jsonlog."
    exit 1
fi

echo "[4/9] Creating audit role/database if needed..."
role_exists="$("${admin_psql[@]}" -d "$ADMIN_DB" -Atqc \
    "SELECT 1 FROM pg_roles WHERE rolname='$AUDIT_USER';")"
if [[ "$role_exists" != "1" ]]; then
    "${admin_psql[@]}" -d "$ADMIN_DB" -c "CREATE ROLE \"$AUDIT_USER\" LOGIN;"
fi

# Collector's own repository SQL must never recursively enter statement logs.
"${admin_psql[@]}" -d "$ADMIN_DB" -c \
    "ALTER ROLE \"$AUDIT_USER\" SET log_statement='none';"

db_exists="$("${admin_psql[@]}" -d "$ADMIN_DB" -Atqc \
    "SELECT 1 FROM pg_database WHERE datname='$AUDIT_DB';")"
if [[ "$db_exists" != "1" ]]; then
    sudo -u "$SERVICE_OS_USER" "$CREATEDB_BIN" \
        -p "$PGPORT" -U "$ADMIN_DB_USER" -O "$ADMIN_DB_USER" "$AUDIT_DB"
fi

echo "[5/9] Creating/upgrading repository..."
"${admin_psql[@]}" -d "$AUDIT_DB" -f "$APP_DIR/schema.sql"

echo "[6/9] Hardening repository permissions..."
"${admin_psql[@]}" -d "$ADMIN_DB" -c \
    "REVOKE CONNECT ON DATABASE \"$AUDIT_DB\" FROM PUBLIC;"

"${admin_psql[@]}" -d "$AUDIT_DB" <<SQL
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON audit_history, audit_scope, audit_ignore_schema,
              audit_ignore_table, audit_collector_status FROM PUBLIC;

GRANT CONNECT ON DATABASE "$AUDIT_DB" TO "$AUDIT_USER";
GRANT USAGE ON SCHEMA public TO "$AUDIT_USER";

GRANT SELECT, INSERT, UPDATE, DELETE
ON audit_scope, audit_ignore_schema, audit_ignore_table
TO "$AUDIT_USER";

GRANT SELECT, INSERT ON audit_history TO "$AUDIT_USER";
GRANT SELECT, INSERT, UPDATE ON audit_collector_status TO "$AUDIT_USER";
GRANT USAGE, SELECT ON SEQUENCE audit_history_event_seq TO "$AUDIT_USER";

GRANT EXECUTE ON FUNCTION audit_scope_set(text,text,boolean) TO "$AUDIT_USER";
GRANT EXECUTE ON FUNCTION audit_scope_delete(text,text) TO "$AUDIT_USER";
GRANT EXECUTE ON FUNCTION audit_watch_set(text,text,boolean) TO "$AUDIT_USER";
GRANT EXECUTE ON FUNCTION audit_ignore_schema_set(text,boolean) TO "$AUDIT_USER";
GRANT EXECUTE ON FUNCTION audit_ignore_schema_delete(text) TO "$AUDIT_USER";
GRANT EXECUTE ON FUNCTION audit_ignore_table_set(text,text,text,boolean) TO "$AUDIT_USER";
GRANT EXECUTE ON FUNCTION audit_ignore_table_delete(text,text,text) TO "$AUDIT_USER";
SQL

# audit_watch_set is SECURITY DEFINER and must remain owned by the admin role.
"${admin_psql[@]}" -d "$AUDIT_DB" -c \
    "ALTER FUNCTION audit_watch_set(text,text,boolean) OWNER TO \"$ADMIN_DB_USER\";"

echo "[7/9] Testing collector's exact local psql connection..."
sudo -u "$SERVICE_OS_USER" "$PSQL_BIN" \
    -X -q -p "$PGPORT" -U "$AUDIT_USER" -d "$AUDIT_DB" \
    -Atqc "SELECT count(*) FROM audit_scope;" >/dev/null

echo "[8/9] Checking current_logfiles..."
if [[ ! -f "$PGDATA/current_logfiles" ]]; then
    echo "ERROR: $PGDATA/current_logfiles not found"
    exit 1
fi
if ! grep -q '^jsonlog ' "$PGDATA/current_logfiles"; then
    echo "ERROR: jsonlog line not found in current_logfiles"
    cat "$PGDATA/current_logfiles" || true
    exit 1
fi
grep '^jsonlog ' "$PGDATA/current_logfiles"

echo "[9/9] Installing the ONLY /etc artifact and starting..."
cat > "$SERVICE_FILE" <<UNIT
[Unit]
Description=PostgreSQL durable filtered statement audit collector
After=network.target

[Service]
Type=simple
User=$SERVICE_OS_USER
Group=$SERVICE_OS_GROUP
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/collector.env
ExecStart=$PYTHON_BIN $APP_DIR/audit_collector.py
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT

chmod 0644 "$SERVICE_FILE"
systemctl daemon-reload
systemctl reset-failed pg-audit-collector 2>/dev/null || true
systemctl enable pg-audit-collector >/dev/null
systemctl restart pg-audit-collector

sleep 2
systemctl --no-pager --full status pg-audit-collector || true

echo
echo "Installation complete."
echo "Enable exact role/database auditing from auditdb:"
echo "  SELECT audit_watch_set('user1','appdb',true);"
echo "Disable/reset:"
echo "  SELECT audit_watch_set('user1','appdb',false);"
