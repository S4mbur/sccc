#!/usr/bin/env python3
import csv
import hashlib
import io
import json
import logging
import os
import re
import signal
import subprocess
import time
from pathlib import Path

RUNNING = True
APP_DIR = Path(__file__).resolve().parent


def env(name, default=None):
    return os.environ.get(name, default)


def bool_env(name, default=False):
    return str(env(name, "true" if default else "false")).strip().lower() in (
        "1", "true", "yes", "on"
    )


def app_path(value):
    p = Path(value)
    return p if p.is_absolute() else APP_DIR / p


PGDATA = Path(env("PGDATA", "/data/postgres/data"))
PGPORT = str(env("PGPORT", "5420"))
AUDIT_DB = env("AUDIT_DB", "auditdb")
AUDIT_USER = env("AUDIT_USER", "audit_writer")
PSQL_BIN = env("PSQL_BIN", "/usr/bin/psql")

POLL_SECONDS = float(env("POLL_SECONDS", "0.25"))
BATCH_SIZE = int(env("BATCH_SIZE", "100"))
FLUSH_SECONDS = float(env("FLUSH_SECONDS", "2"))
SCOPE_REFRESH_SECONDS = int(env("SCOPE_REFRESH_SECONDS", "15"))
IGNORE_REFRESH_SECONDS = int(env("IGNORE_REFRESH_SECONDS", "30"))
HEARTBEAT_SECONDS = int(env("HEARTBEAT_SECONDS", "10"))
CHECKPOINT_SECONDS = float(env("CHECKPOINT_SECONDS", "2"))
START_AT_END = bool_env("START_AT_END", True)
SCOPE_ALLOW_ALL_IF_EMPTY = bool_env("SCOPE_ALLOW_ALL_IF_EMPTY", False)

PGCONNECT_TIMEOUT_SECONDS = int(env("PGCONNECT_TIMEOUT_SECONDS", "5"))
PSQL_TIMEOUT_SECONDS = int(env("PSQL_TIMEOUT_SECONDS", "15"))
STATEMENT_TIMEOUT_MS = int(env("STATEMENT_TIMEOUT_MS", "10000"))
LOCK_TIMEOUT_MS = int(env("LOCK_TIMEOUT_MS", "2000"))

COLLECTOR_NAME = env("COLLECTOR_NAME", "main")
STATE_FILE = app_path(env("STATE_FILE", "state/state.json"))

logging.basicConfig(
    level=getattr(logging, env("COLLECTOR_LOG_LEVEL", "INFO").upper(), logging.INFO),
    format="%(asctime)s %(levelname)s %(message)s",
)
LOG = logging.getLogger("pg-statement-audit")

# Explicit relation-less session/transaction chatter we intentionally drop.
NOISE_RE = re.compile(
    r"^\s*(?:"
    r"SET(?:\s+LOCAL|\s+SESSION)?\b|RESET\b|SHOW\b|"
    r"BEGIN\b|START\s+TRANSACTION\b|COMMIT\b|END\b|ROLLBACK\b|"
    r"SAVEPOINT\b|RELEASE(?:\s+SAVEPOINT)?\b"
    r")",
    re.I | re.S,
)

IDENT = r'(?:(?:"(?:[^"]|"")*")|(?:[A-Za-z_][A-Za-z0-9_$]*))'
REL = rf'(?:(?P<schema>{IDENT})\s*\.\s*)?(?P<table>{IDENT})'

# Used ONLY to prove that a statement touches exclusively exact ignored objects.
# If parsing is incomplete/ambiguous, the event is kept.
REL_PATTERNS = [
    re.compile(rf'\bFROM\s+(?:ONLY\s+)?{REL}', re.I),
    re.compile(rf'\bJOIN\s+(?:ONLY\s+)?{REL}', re.I),
    re.compile(rf'\bUPDATE\s+(?:ONLY\s+)?{REL}', re.I),
    re.compile(rf'\bINSERT\s+INTO\s+{REL}', re.I),
    re.compile(rf'\bDELETE\s+FROM\s+(?:ONLY\s+)?{REL}', re.I),
    re.compile(rf'\bMERGE\s+INTO\s+{REL}', re.I),
    re.compile(rf'\bTRUNCATE(?:\s+TABLE)?\s+(?:ONLY\s+)?{REL}', re.I),
    re.compile(rf'\bCOPY\s+{REL}\s+(?:FROM|TO)\b', re.I),
    re.compile(rf'\bALTER\s+TABLE(?:\s+IF\s+EXISTS)?\s+(?:ONLY\s+)?{REL}', re.I),
    re.compile(rf'\bDROP\s+TABLE(?:\s+IF\s+EXISTS)?\s+{REL}', re.I),
    re.compile(rf'\bCREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?\s+{REL}', re.I),
    re.compile(rf'\bLOCK\s+TABLE\s+(?:ONLY\s+)?{REL}', re.I),
    re.compile(rf'\bREFERENCES\s+{REL}', re.I),
    re.compile(rf'\bCREATE(?:\s+UNIQUE)?\s+INDEX\b.*?\bON\s+(?:ONLY\s+)?{REL}', re.I | re.S),
    re.compile(rf'\bGRANT\b.*?\bON(?:\s+TABLE)?\s+{REL}', re.I | re.S),
    re.compile(rf'\bREVOKE\b.*?\bON(?:\s+TABLE)?\s+{REL}', re.I | re.S),
]

CTE_RE = re.compile(
    rf'(?:\bWITH\b|,)\s*(?P<cte>{IDENT})\s*(?:\([^)]*\))?\s+AS\s*'
    rf'(?:NOT\s+MATERIALIZED\s+|MATERIALIZED\s+)?\(',
    re.I | re.S,
)

# If FROM contains a comma, we refuse to prove the statement safe-to-ignore.
FROM_COMMA_RE = re.compile(r'\bFROM\b[^;]*?,', re.I | re.S)
ERROR_SEVERITIES = {"ERROR", "FATAL", "PANIC"}


def stop_handler(signum, frame):
    global RUNNING
    RUNNING = False


signal.signal(signal.SIGTERM, stop_handler)
signal.signal(signal.SIGINT, stop_handler)


def psql_env():
    e = os.environ.copy()
    e["PGCONNECT_TIMEOUT"] = str(PGCONNECT_TIMEOUT_SECONDS)
    opts = (
        f"-c statement_timeout={STATEMENT_TIMEOUT_MS} "
        f"-c lock_timeout={LOCK_TIMEOUT_MS}"
    )
    if e.get("PGOPTIONS"):
        opts = e["PGOPTIONS"] + " " + opts
    e["PGOPTIONS"] = opts
    return e


def psql_base():
    # Deliberately no -h: same local socket behavior as psql -p ... -U ... -d ...
    return [
        PSQL_BIN, "-X", "-q", "-v", "ON_ERROR_STOP=1",
        "-p", PGPORT, "-U", AUDIT_USER, "-d", AUDIT_DB,
    ]


def run_psql(args, input_text=None):
    try:
        return subprocess.run(
            psql_base() + args,
            input=input_text,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=psql_env(),
            timeout=PSQL_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"psql timeout after {PSQL_TIMEOUT_SECONDS}s"
        ) from exc


def psql_csv_query(sql):
    proc = run_psql([
        "-c",
        f"COPY ({sql}) TO STDOUT WITH (FORMAT csv, NULL '\\\\N')",
    ])
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "psql query failed")

    return [
        [None if v == r"\N" else v for v in row]
        for row in csv.reader(io.StringIO(proc.stdout))
    ]


def sql_literal(value):
    if value is None:
        return "NULL"
    return "'" + str(value).replace("'", "''") + "'"


def load_scope():
    return {
        (r[0], r[1])
        for r in psql_csv_query("""
            SELECT db_user, database_name
            FROM audit_scope
            WHERE enabled
        """)
    }


def load_ignores():
    schemas = {
        r[0]
        for r in psql_csv_query("""
            SELECT schema_name
            FROM audit_ignore_schema
            WHERE enabled
        """)
    }
    tables = {
        (r[0], r[1], r[2])
        for r in psql_csv_query("""
            SELECT database_name, schema_name, table_name
            FROM audit_ignore_table
            WHERE enabled
        """)
    }
    return schemas, tables


def scope_allows(scope, user, dbname):
    if not scope:
        return SCOPE_ALLOW_ALL_IF_EMPTY

    user = user or ""
    dbname = dbname or ""
    return (
        ("*", "*") in scope
        or (user, "*") in scope
        or ("*", dbname) in scope
        or (user, dbname) in scope
    )


def ident_value(token):
    if token is None:
        return None
    token = token.strip()
    if token.startswith('"') and token.endswith('"'):
        return token[1:-1].replace('""', '"')
    return token.lower()


def relation_analysis(statement):
    """Return (relations, ambiguous). Uncertainty is intentionally fail-open."""
    ctes = {ident_value(m.group("cte")) for m in CTE_RE.finditer(statement)}
    relations = set()
    ambiguous = bool(FROM_COMMA_RE.search(statement))

    for pattern in REL_PATTERNS:
        for m in pattern.finditer(statement):
            gd = m.groupdict()
            schema = ident_value(gd.get("schema"))
            table = ident_value(gd.get("table"))
            if not table:
                ambiguous = True
                continue

            # CTE aliases are not physical relations; underlying relations are found too.
            if schema is None and table in ctes:
                continue

            relations.add((schema, table))
            if schema is None:
                ambiguous = True

    return relations, ambiguous


def all_relations_explicitly_ignored(dbname, statement, ignored_schemas, ignored_tables):
    relations, ambiguous = relation_analysis(statement)

    if not relations or ambiguous:
        return False

    for schema, table in relations:
        if schema in ignored_schemas:
            continue
        if (dbname, schema, table) in ignored_tables:
            continue
        return False

    return True


def extract_statement(entry):
    # For error records JSON log has a dedicated statement field when enabled.
    if entry.get("statement"):
        return str(entry["statement"])

    msg = str(entry.get("message") or "")

    m = re.match(r'^\s*statement:\s*(.*)$', msg, re.I | re.S)
    if m:
        return m.group(1).strip()

    # Extended protocol: execute <unnamed>: SELECT ...
    m = re.match(r'^\s*execute(?:\s+[^:]+)?:\s*(.*)$', msg, re.I | re.S)
    if m:
        return m.group(1).strip()

    return None


def should_store(entry, scope, ignored_schemas, ignored_tables):
    user = entry.get("user")
    dbname = entry.get("dbname")
    if not scope_allows(scope, user, dbname):
        return False, None

    severity = str(entry.get("error_severity") or "").upper()
    statement = extract_statement(entry)

    # Failed attempts are audit-worthy. Exact system-noise ignores may still suppress them.
    if severity in ERROR_SEVERITIES:
        if statement and all_relations_explicitly_ignored(
            dbname, statement, ignored_schemas, ignored_tables
        ):
            return False, statement
        return True, statement

    if statement:
        if NOISE_RE.match(statement):
            return False, statement
        if all_relations_explicitly_ignored(
            dbname, statement, ignored_schemas, ignored_tables
        ):
            return False, statement
        return True, statement

    # Ignore connection/checkpoint/autovacuum/general LOG chatter.
    return False, None


def event_key(entry):
    material = "\x1f".join([
        str(entry.get("session_id") or ""),
        str(entry.get("line_num") or ""),
        str(entry.get("timestamp") or ""),
        str(entry.get("message") or ""),
        str(entry.get("statement") or ""),
        str(entry.get("detail") or ""),
        str(entry.get("state_code") or ""),
    ])
    return hashlib.sha256(material.encode("utf-8", errors="replace")).hexdigest()


def event_row(entry, statement):
    return (
        event_key(entry),
        entry.get("timestamp"),
        entry.get("user"),
        entry.get("remote_host"),       # text: accepts [local]
        entry.get("application_name"),
        entry.get("session_id"),
        entry.get("line_num"),
        entry.get("query_id"),
        entry.get("error_severity"),
        entry.get("state_code"),
        statement,
        entry.get("detail"),
        entry.get("message"),
    )


def flush_rows(rows):
    if not rows:
        return

    columns = (
        "event_key,event_time,db_user,client_host,application_name,"
        "session_id,line_num,query_id,severity,sqlstate,statement,detail,message"
    )

    buf = io.StringIO(newline="")
    writer = csv.writer(buf, lineterminator="\n")
    for row in rows:
        writer.writerow([r"\N" if v is None else v for v in row])

    script = f"""BEGIN;
CREATE TEMP TABLE _audit_stage (
    event_key text,
    event_time timestamptz,
    db_user text,
    client_host text,
    application_name text,
    session_id text,
    line_num bigint,
    query_id text,
    severity text,
    sqlstate text,
    statement text,
    detail text,
    message text
) ON COMMIT DROP;
COPY _audit_stage ({columns}) FROM STDIN WITH (FORMAT csv, NULL '\\N');
{buf.getvalue()}\\.
INSERT INTO audit_history ({columns})
SELECT {columns}
FROM _audit_stage
ON CONFLICT (event_key) DO NOTHING;
COMMIT;
"""

    proc = run_psql(["-f", "-"], input_text=script)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "audit batch commit failed")


def list_json_files(directory):
    items = []
    for p in directory.iterdir():
        if not p.is_file() or p.suffix not in (".json", ".jsonlog"):
            continue
        try:
            st = p.stat()
        except FileNotFoundError:
            continue
        items.append((st.st_mtime_ns, p.name, p))

    items.sort(key=lambda x: (x[0], x[1]))
    return [x[2] for x in items]


def get_active_jsonlog():
    marker = PGDATA / "current_logfiles"
    if not marker.exists():
        raise FileNotFoundError(f"{marker} not found")

    for line in marker.read_text(encoding="utf-8", errors="replace").splitlines():
        dest, _, relpath = line.partition(" ")
        if dest.strip() != "jsonlog":
            continue

        p = Path(relpath.strip())
        if not p.is_absolute():
            p = PGDATA / p

        # Compatibility with earlier environment where current_logfiles resolved to a dir.
        if p.is_dir():
            candidates = list_json_files(p)
            if not candidates:
                raise RuntimeError(f"No JSON logs under {p}")
            return candidates[-1]

        return p

    raise RuntimeError(f"No jsonlog entry in {marker}")


def checkpoint_for(path, inode, offset):
    try:
        mtime_ns = path.stat().st_mtime_ns
    except FileNotFoundError:
        mtime_ns = 0
    return {
        "file_path": str(path),
        "inode": int(inode),
        "offset": int(offset),
        "file_mtime_ns": int(mtime_ns),
    }


def load_state():
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None


def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(state), encoding="utf-8")
    os.replace(tmp, STATE_FILE)


def locate_start():
    active = get_active_jsonlog()
    files = list_json_files(active.parent)
    state = load_state()

    if not state:
        if START_AT_END:
            st = active.stat()
            initial = checkpoint_for(active, st.st_ino, st.st_size)
            save_state(initial)
            return active, st.st_size, None
        first = files[0] if files else active
        return first, 0, None

    state_path = Path(state.get("file_path", ""))
    if state_path.exists():
        size = state_path.stat().st_size
        offset = int(state.get("offset", 0))
        warning = None
        if offset > size:
            warning = (
                f"checkpoint offset {offset} > file size {size}; "
                "file appears truncated, restarting at offset 0"
            )
            offset = 0
        return state_path, offset, warning

    old_mtime = int(state.get("file_mtime_ns", 0))
    newer = []
    for p in files:
        try:
            if p.stat().st_mtime_ns >= old_mtime:
                newer.append(p)
        except FileNotFoundError:
            pass

    chosen = newer[0] if newer else (files[0] if files else active)
    warning = (
        "checkpoint file no longer exists; possible audit gap. "
        f"Continuing from earliest available file {chosen}"
    )
    return chosen, 0, warning


def next_file_after(current):
    active = get_active_jsonlog()
    files = list_json_files(active.parent)

    for i, p in enumerate(files):
        if p == current:
            return files[i + 1] if i + 1 < len(files) else None

    # Current path may have been removed while still open. Prefer oldest available file.
    return files[0] if files else None


def heartbeat(current_file, current_offset, buffer_size, last_log_event,
              last_error, mark_flush=False):
    event_sql = sql_literal(last_log_event)
    err_sql = sql_literal(last_error[:2000] if last_error else None)
    file_sql = sql_literal(str(current_file) if current_file else None)
    flush_expr = "clock_timestamp()" if mark_flush else "NULL"

    sql = f"""
INSERT INTO audit_collector_status(
    collector_name,last_seen,last_successful_flush,last_log_event,
    lag_seconds,buffer_size,current_file,current_offset,last_error,updated_at
)
VALUES(
    {sql_literal(COLLECTOR_NAME)},
    clock_timestamp(),
    {flush_expr},
    {event_sql}::timestamptz,
    CASE WHEN {event_sql} IS NULL THEN NULL
         ELSE EXTRACT(EPOCH FROM (clock_timestamp() - {event_sql}::timestamptz))
    END,
    {int(buffer_size)},
    {file_sql},
    {int(current_offset)},
    {err_sql},
    clock_timestamp()
)
ON CONFLICT (collector_name)
DO UPDATE SET
    last_seen=EXCLUDED.last_seen,
    last_successful_flush=COALESCE(
        EXCLUDED.last_successful_flush,
        audit_collector_status.last_successful_flush
    ),
    last_log_event=EXCLUDED.last_log_event,
    lag_seconds=EXCLUDED.lag_seconds,
    buffer_size=EXCLUDED.buffer_size,
    current_file=EXCLUDED.current_file,
    current_offset=EXCLUDED.current_offset,
    last_error=EXCLUDED.last_error,
    updated_at=EXCLUDED.updated_at;
"""
    proc = run_psql(["-c", sql])
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "heartbeat update failed")


def main():
    LOG.info(
        "starting app_dir=%s PGDATA=%s port=%s audit_db=%s",
        APP_DIR, PGDATA, PGPORT, AUDIT_DB,
    )

    scope = set()
    ignored_schemas = set()
    ignored_tables = set()

    next_scope_refresh = 0.0
    next_ignore_refresh = 0.0
    next_heartbeat = 0.0
    next_checkpoint = 0.0

    rows = []
    pending_checkpoint = None
    last_flush_monotonic = time.monotonic()
    flush_dirty_for_heartbeat = False
    last_log_event = None
    last_error = None

    current, start_offset, warning = locate_start()
    if warning:
        LOG.warning(warning)
        last_error = warning

    fh = current.open("r", encoding="utf-8", errors="replace")
    inode = current.stat().st_ino
    fh.seek(start_offset)

    while RUNNING:
        now = time.monotonic()

        if now >= next_scope_refresh:
            try:
                scope = load_scope()
                next_scope_refresh = now + SCOPE_REFRESH_SECONDS
            except Exception as exc:
                last_error = f"scope refresh: {exc}"
                LOG.error(last_error)
                time.sleep(1)
                continue

        if now >= next_ignore_refresh:
            try:
                ignored_schemas, ignored_tables = load_ignores()
                next_ignore_refresh = now + IGNORE_REFRESH_SECONDS
            except Exception as exc:
                last_error = f"ignore refresh: {exc}"
                LOG.error(last_error)
                time.sleep(1)
                continue

        start_pos = fh.tell()
        line = fh.readline()

        if line:
            end_offset = fh.tell()

            # A writer can leave an incomplete last line temporarily. Never advance it.
            if not line.endswith("\n"):
                fh.seek(start_pos)
                time.sleep(POLL_SECONDS)
                continue

            candidate_checkpoint = checkpoint_for(current, inode, end_offset)

            try:
                entry = json.loads(line)
                if entry.get("timestamp"):
                    last_log_event = entry.get("timestamp")

                store, statement = should_store(
                    entry, scope, ignored_schemas, ignored_tables
                )
                if store:
                    rows.append(event_row(entry, statement))

                pending_checkpoint = candidate_checkpoint

            except Exception as exc:
                # Never skip a line we failed to process.
                fh.seek(start_pos)
                pending_checkpoint = None
                last_error = f"processing error {current}:{start_pos}: {exc}"
                LOG.exception(last_error)
                time.sleep(1)
                continue

            # With no uncommitted audit rows, checkpoint ignored/noise lines periodically.
            if not rows and pending_checkpoint and now >= next_checkpoint:
                save_state(pending_checkpoint)
                next_checkpoint = now + CHECKPOINT_SECONDS

        else:
            # Detect truncate/reuse while following a path.
            try:
                size = current.stat().st_size
                if fh.tell() > size:
                    warning = (
                        f"log truncated: offset {fh.tell()} > size {size}; "
                        f"reopening {current} from 0"
                    )
                    LOG.warning(warning)
                    last_error = warning
                    fh.close()
                    fh = current.open("r", encoding="utf-8", errors="replace")
                    inode = current.stat().st_ino
                    fh.seek(0)
                    pending_checkpoint = checkpoint_for(current, inode, 0)
                    continue
            except FileNotFoundError:
                pass

            # Never leave the current file with uncommitted auditable events.
            if rows:
                try:
                    flush_rows(rows)
                    rows.clear()
                    if pending_checkpoint:
                        save_state(pending_checkpoint)
                    last_flush_monotonic = now
                    flush_dirty_for_heartbeat = True
                except Exception as exc:
                    last_error = f"flush before rotation: {exc}"
                    LOG.error(last_error)
                    time.sleep(1)
                    continue

            if pending_checkpoint:
                save_state(pending_checkpoint)

            nxt = next_file_after(current)
            if nxt is not None and nxt != current:
                fh.close()
                current = nxt
                fh = current.open("r", encoding="utf-8", errors="replace")
                inode = current.stat().st_ino
                fh.seek(0)  # rotated/backlog files ALWAYS start from beginning
                pending_checkpoint = checkpoint_for(current, inode, 0)
                LOG.info("following next/backlog log from offset 0: %s", current)
                continue

            time.sleep(POLL_SECONDS)

        if rows and (
            len(rows) >= BATCH_SIZE
            or now - last_flush_monotonic >= FLUSH_SECONDS
        ):
            try:
                flush_rows(rows)
                rows.clear()

                # Durability rule: state advances only after successful DB COMMIT.
                if pending_checkpoint:
                    save_state(pending_checkpoint)

                last_flush_monotonic = now
                flush_dirty_for_heartbeat = True

            except Exception as exc:
                # No state advancement. Same batch will be retried.
                last_error = f"audit flush: {exc}"
                LOG.error(last_error)
                time.sleep(1)

        if now >= next_heartbeat:
            try:
                heartbeat(
                    current_file=current,
                    current_offset=fh.tell(),
                    buffer_size=len(rows),
                    last_log_event=last_log_event,
                    last_error=last_error,
                    mark_flush=flush_dirty_for_heartbeat,
                )
                flush_dirty_for_heartbeat = False
                next_heartbeat = now + HEARTBEAT_SECONDS
            except Exception as exc:
                LOG.error("heartbeat failed: %s", exc)
                next_heartbeat = now + min(HEARTBEAT_SECONDS, 5)

    # Graceful shutdown: commit, then checkpoint.
    try:
        if rows:
            flush_rows(rows)
            rows.clear()
            if pending_checkpoint:
                save_state(pending_checkpoint)
    except Exception as exc:
        LOG.error("final flush failed: %s", exc)

    try:
        heartbeat(
            current_file=current,
            current_offset=fh.tell(),
            buffer_size=len(rows),
            last_log_event=last_log_event,
            last_error=last_error,
            mark_flush=False,
        )
    except Exception:
        pass

    try:
        fh.close()
    except Exception:
        pass

    LOG.info("stopped")


if __name__ == "__main__":
    main()
