DO $$
BEGIN
    IF to_regclass('public.audit_history') IS NOT NULL
       AND NOT EXISTS (
           SELECT 1
           FROM information_schema.columns
           WHERE table_schema='public'
             AND table_name='audit_history'
             AND column_name='event_key'
       )
       AND to_regclass('public.audit_history_legacy') IS NULL
    THEN
        ALTER TABLE public.audit_history RENAME TO audit_history_legacy;
    END IF;
END
$$;

CREATE SEQUENCE IF NOT EXISTS audit_history_event_seq;

CREATE TABLE IF NOT EXISTS audit_history (
    id               bigint PRIMARY KEY DEFAULT nextval('audit_history_event_seq'),
    event_key        text NOT NULL UNIQUE,
    event_time       timestamptz NOT NULL,
    db_user          text,
    client_host      text,
    application_name text,
    session_id       text,
    line_num         bigint,
    query_id         text,
    severity         text,
    sqlstate         text,
    statement        text,
    detail           text,
    message          text,
    created_at       timestamptz NOT NULL DEFAULT now()
);
ALTER SEQUENCE audit_history_event_seq OWNED BY audit_history.id;

CREATE INDEX IF NOT EXISTS idx_audit_history_event_time
    ON audit_history(event_time DESC);
CREATE INDEX IF NOT EXISTS idx_audit_history_user_time
    ON audit_history(db_user, event_time DESC);
CREATE INDEX IF NOT EXISTS idx_audit_history_query_id
    ON audit_history(query_id) WHERE query_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS audit_scope (
    db_user       text NOT NULL,
    database_name text NOT NULL,
    enabled       boolean NOT NULL DEFAULT true,
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (db_user, database_name),
    CHECK (btrim(db_user) <> ''),
    CHECK (btrim(database_name) <> '')
);

CREATE TABLE IF NOT EXISTS audit_ignore_schema (
    schema_name text PRIMARY KEY,
    enabled     boolean NOT NULL DEFAULT true,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now(),
    CHECK (btrim(schema_name) <> ''),
    CHECK (schema_name <> '*')
);

CREATE TABLE IF NOT EXISTS audit_ignore_table (
    database_name text NOT NULL,
    schema_name   text NOT NULL,
    table_name    text NOT NULL,
    enabled       boolean NOT NULL DEFAULT true,
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (database_name, schema_name, table_name),
    CHECK (btrim(database_name) <> ''),
    CHECK (btrim(schema_name) <> ''),
    CHECK (btrim(table_name) <> ''),
    CHECK (database_name <> '*'),
    CHECK (schema_name <> '*'),
    CHECK (table_name <> '*')
);

CREATE TABLE IF NOT EXISTS audit_collector_status (
    collector_name         text PRIMARY KEY,
    last_seen              timestamptz,
    last_successful_flush  timestamptz,
    last_log_event         timestamptz,
    lag_seconds            numeric,
    buffer_size            integer NOT NULL DEFAULT 0,
    current_file           text,
    current_offset         bigint,
    last_error             text,
    updated_at             timestamptz NOT NULL DEFAULT now()
);

INSERT INTO audit_ignore_schema(schema_name, enabled)
VALUES
    ('pg_catalog', true),
    ('information_schema', true),
    ('pg_toast', true)
ON CONFLICT (schema_name) DO NOTHING;

CREATE OR REPLACE FUNCTION audit_scope_set(
    p_user text,
    p_database text,
    p_enabled boolean DEFAULT true
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_user IS NULL OR btrim(p_user) = '' OR
       p_database IS NULL OR btrim(p_database) = '' THEN
        RAISE EXCEPTION 'user/database must not be empty';
    END IF;

    INSERT INTO audit_scope(db_user, database_name, enabled, updated_at)
    VALUES (p_user, p_database, p_enabled, now())
    ON CONFLICT (db_user, database_name)
    DO UPDATE SET enabled=EXCLUDED.enabled, updated_at=now();
END
$$;

CREATE OR REPLACE FUNCTION audit_scope_delete(p_user text, p_database text)
RETURNS void
LANGUAGE sql
AS $$
    DELETE FROM audit_scope
    WHERE db_user=p_user AND database_name=p_database;
$$;

CREATE OR REPLACE FUNCTION audit_watch_set(
    p_user text,
    p_database text,
    p_enabled boolean DEFAULT true
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
BEGIN
    IF p_user IS NULL OR btrim(p_user) = '' OR p_user = '*' OR
       p_database IS NULL OR btrim(p_database) = '' OR p_database = '*' THEN
        RAISE EXCEPTION 'audit_watch_set requires exact role and database names';
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname=p_user) THEN
        RAISE EXCEPTION 'role % does not exist', p_user;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_database WHERE datname=p_database) THEN
        RAISE EXCEPTION 'database % does not exist', p_database;
    END IF;

    INSERT INTO public.audit_scope(db_user, database_name, enabled, updated_at)
    VALUES (p_user, p_database, p_enabled, now())
    ON CONFLICT (db_user, database_name)
    DO UPDATE SET enabled=EXCLUDED.enabled, updated_at=now();

    IF p_enabled THEN
        EXECUTE format(
            'ALTER ROLE %I IN DATABASE %I SET log_statement = %L',
            p_user, p_database, 'all'
        );
    ELSE
        EXECUTE format(
            'ALTER ROLE %I IN DATABASE %I RESET log_statement',
            p_user, p_database
        );
    END IF;
END
$$;

CREATE OR REPLACE FUNCTION audit_ignore_schema_set(
    p_schema text,
    p_enabled boolean DEFAULT true
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_schema IS NULL OR btrim(p_schema)='' OR p_schema='*' THEN
        RAISE EXCEPTION 'ignore schema must be exact; wildcard forbidden';
    END IF;
    INSERT INTO audit_ignore_schema(schema_name, enabled, updated_at)
    VALUES (p_schema, p_enabled, now())
    ON CONFLICT (schema_name)
    DO UPDATE SET enabled=EXCLUDED.enabled, updated_at=now();
END
$$;

CREATE OR REPLACE FUNCTION audit_ignore_schema_delete(p_schema text)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_schema='*' THEN RAISE EXCEPTION 'wildcard forbidden'; END IF;
    DELETE FROM audit_ignore_schema WHERE schema_name=p_schema;
END
$$;

CREATE OR REPLACE FUNCTION audit_ignore_table_set(
    p_database text,
    p_schema text,
    p_table text,
    p_enabled boolean DEFAULT true
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_database IS NULL OR btrim(p_database)='' OR p_database='*' OR
       p_schema IS NULL OR btrim(p_schema)='' OR p_schema='*' OR
       p_table IS NULL OR btrim(p_table)='' OR p_table='*' THEN
        RAISE EXCEPTION 'database/schema/table must be exact; wildcard forbidden';
    END IF;

    INSERT INTO audit_ignore_table(
        database_name, schema_name, table_name, enabled, updated_at
    )
    VALUES (p_database, p_schema, p_table, p_enabled, now())
    ON CONFLICT (database_name, schema_name, table_name)
    DO UPDATE SET enabled=EXCLUDED.enabled, updated_at=now();
END
$$;

CREATE OR REPLACE FUNCTION audit_ignore_table_delete(
    p_database text,
    p_schema text,
    p_table text
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_database='*' OR p_schema='*' OR p_table='*' THEN
        RAISE EXCEPTION 'wildcard forbidden';
    END IF;
    DELETE FROM audit_ignore_table
    WHERE database_name=p_database
      AND schema_name=p_schema
      AND table_name=p_table;
END
$$;

REVOKE ALL ON FUNCTION audit_scope_set(text,text,boolean) FROM PUBLIC;
REVOKE ALL ON FUNCTION audit_scope_delete(text,text) FROM PUBLIC;
REVOKE ALL ON FUNCTION audit_watch_set(text,text,boolean) FROM PUBLIC;
REVOKE ALL ON FUNCTION audit_ignore_schema_set(text,boolean) FROM PUBLIC;
REVOKE ALL ON FUNCTION audit_ignore_schema_delete(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION audit_ignore_table_set(text,text,text,boolean) FROM PUBLIC;
REVOKE ALL ON FUNCTION audit_ignore_table_delete(text,text,text) FROM PUBLIC;
