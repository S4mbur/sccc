# -*- coding: utf-8 -*-
"""Talepler arasi script identiklik kontrolu.

Kural: TEST / PREPROD / PROD taleplerindeki script BIREBIR AYNI olmalidir -
tek bir karakter bile farkli olamaz. Karsilastirma ham byte uzerinden
SHA-256 ile yapilir; fark varsa nerede oldugu satir/karakter duzeyinde
gosterilir.
"""
from __future__ import annotations

import difflib
import hashlib
from typing import Dict, List

INVISIBLE = {
    " ": "NBSP (kirilmayan bosluk)",
    "​": "ZERO WIDTH SPACE",
    "‌": "ZERO WIDTH NON-JOINER",
    "‍": "ZERO WIDTH JOINER",
    "﻿": "BOM / ZERO WIDTH NO-BREAK SPACE",
    " ": "LINE SEPARATOR",
    " ": "PARAGRAPH SEPARATOR",
    "\t": "TAB",
}


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _describe_char(ch: str) -> str:
    if ch in INVISIBLE:
        return "%s (U+%04X)" % (INVISIBLE[ch], ord(ch))
    if ch == "\n":
        return "satir sonu (LF)"
    if ch == "\r":
        return "satir sonu (CR)"
    if ord(ch) < 32:
        return "kontrol karakteri U+%04X" % ord(ch)
    return "'%s' (U+%04X)" % (ch, ord(ch))


def first_difference(a: str, b: str) -> Dict:
    """Iki metnin ilk farkli karakterini bulur."""
    n = min(len(a), len(b))
    for i in range(n):
        if a[i] != b[i]:
            line = a.count("\n", 0, i) + 1
            col = i - (a.rfind("\n", 0, i) + 1) + 1
            return {
                "offset": i, "line": line, "column": col,
                "left": _describe_char(a[i]), "right": _describe_char(b[i]),
                "reason": "Satir %d, sutun %d: solda %s / sagda %s"
                          % (line, col, _describe_char(a[i]),
                             _describe_char(b[i])),
            }
    if len(a) != len(b):
        longer, shorter = (a, b) if len(a) > len(b) else (b, a)
        i = len(shorter)
        line = shorter.count("\n") + 1
        extra = longer[i:i + 40].replace("\n", "\\n")
        return {
            "offset": i, "line": line, "column": 1,
            "left": "", "right": "",
            "reason": "Metinlerden biri %d karakter daha uzun; fazlalik: '%s'"
                      % (len(longer) - len(shorter), extra),
        }
    return {}


def normalized_diff_kind(a: str, b: str) -> str:
    """Farkin turu: sadece bosluk/satirsonu mu, yoksa gercek icerik mi?"""
    if a == b:
        return "IDENTICAL"
    if a.replace("\r\n", "\n") == b.replace("\r\n", "\n"):
        return "ONLY_LINE_ENDINGS"
    if "".join(a.split()) == "".join(b.split()):
        return "ONLY_WHITESPACE"
    if a.strip().upper() == b.strip().upper():
        return "ONLY_CASE"
    return "CONTENT"


DIFF_KIND_TEXT = {
    "IDENTICAL": "Birebir ayni",
    "ONLY_LINE_ENDINGS": "Yalniz satir sonu farki (CRLF/LF) - yine de REDDEDILIR",
    "ONLY_WHITESPACE": "Yalniz bosluk/girinti farki - yine de REDDEDILIR",
    "ONLY_CASE": "Yalniz buyuk/kucuk harf farki - yine de REDDEDILIR",
    "CONTENT": "Icerik farki",
}


def unified_diff(a: str, b: str, a_name="referans", b_name="karsilastirilan",
                 context=3) -> List[str]:
    return list(difflib.unified_diff(
        a.splitlines(keepends=False), b.splitlines(keepends=False),
        fromfile=a_name, tofile=b_name, lineterm="", n=context))


def scan_invisible(text: str) -> List[Dict]:
    """Metindeki gorunmez karakterleri raporlar (identiklik tartismalarinin
    en sik sebebi)."""
    out = []
    for ch, label in INVISIBLE.items():
        if ch == "\t":
            continue
        idx = text.find(ch)
        if idx >= 0:
            out.append({"char": "U+%04X" % ord(ch), "label": label,
                        "line": text.count("\n", 0, idx) + 1,
                        "count": text.count(ch)})
    return out


def compare_many(items: List[Dict]) -> Dict:
    """items: [{'label': 'TEST talebi', 'text': '...'}, ...]

    Ilk oge referans kabul edilir.
    """
    if not items:
        return {"identical": False, "error": "Karsilastirilacak script yok."}

    ref = items[0]
    ref_hash = sha256_text(ref["text"])
    rows = []
    all_same = True

    for it in items:
        h = sha256_text(it["text"])
        same = h == ref_hash
        all_same = all_same and same
        kind = normalized_diff_kind(ref["text"], it["text"])
        row = {
            "label": it.get("label", "?"),
            "ref_id": it.get("ref_id", ""),
            "env": it.get("env", ""),
            "sha256": h,
            "sha_short": h[:12],
            "identical": same,
            "diff_kind": kind,
            "diff_kind_text": DIFF_KIND_TEXT.get(kind, kind),
            "lines": it["text"].count("\n") + 1,
            "chars": len(it["text"]),
            "invisible": scan_invisible(it["text"]),
        }
        if not same:
            row["first_difference"] = first_difference(ref["text"], it["text"])
            row["diff"] = unified_diff(ref["text"], it["text"],
                                       ref.get("label", "referans"),
                                       it.get("label", "karsilastirilan"))
        rows.append(row)

    return {
        "identical": all_same,
        "reference": ref.get("label", "?"),
        "reference_sha256": ref_hash,
        "rows": rows,
        "verdict": "IDENTICAL" if all_same else "MISMATCH",
        "message": ("Tum scriptler birebir ayni (SHA-256 eslesiyor)."
                    if all_same else
                    "Scriptler ayni DEGIL - pipeline ilerleyemez."),
    }
