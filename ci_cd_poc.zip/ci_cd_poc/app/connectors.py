# -*- coding: utf-8 -*-
"""Orkestra ve Octopus için MOCK/HTTP adaptörleri."""
from __future__ import annotations

import hashlib
import json
import time
import urllib.error
import urllib.request
from typing import Dict, List, Optional


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


class JsonHttpClient(object):
    def __init__(self, base_url="", headers=None):
        self.base_url = str(base_url or "").rstrip("/")
        self.headers = dict(headers or {})
        self.last_error = ""

    def request(self, method, path, payload=None, timeout=10):
        if not self.base_url:
            self.last_error = "Base URL tanımlı değil."
            return None
        data = None
        headers = dict(self.headers)
        if payload is not None:
            data = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"
        try:
            request = urllib.request.Request(
                self.base_url + path, data=data, method=method,
                headers=headers)
            with urllib.request.urlopen(request, timeout=timeout) as response:
                raw = response.read().decode("utf-8", "replace")
            return json.loads(raw) if raw.strip() else {"ok": True}
        except (urllib.error.URLError, ValueError, OSError) as exc:
            self.last_error = str(exc)
            return None


class OrkestraClient(object):
    REQUESTS_PATH = "/api/requests"

    def __init__(self, mode="MOCK", base_url="", token="", store=None):
        self.mode = str(mode or "MOCK").upper()
        self.store = store
        self.http = JsonHttpClient(
            base_url, {"Authorization": "Bearer " + str(token or "")})

    @property
    def last_error(self):
        return self.http.last_error

    def ping(self) -> Dict:
        if self.mode == "MOCK":
            operation_requests = getattr(
                self.store, "operation_requests", {}) if self.store else {}
            count = len(operation_requests)
            return {"ok": True, "mode": "MOCK",
                    "detail": "Orkestra mock hazır (%d gelen talep)." % count}
        result = self.http.request("GET", "/api/health", timeout=5)
        return {"ok": bool(result), "mode": "HTTP",
                "detail": (json.dumps(result, ensure_ascii=False)[:300]
                           if result else self.last_error)}

    def list_requests(self) -> List[Dict]:
        if self.mode == "MOCK":
            return list(self.store.orkestra_requests.values()) if self.store else []
        result = self.http.request("GET", self.REQUESTS_PATH)
        if isinstance(result, list):
            return result
        return (result or {}).get("requests", [])

    def get_request(self, request_id: str) -> Optional[Dict]:
        if self.mode == "MOCK":
            return self.store.orkestra_requests.get(request_id) if self.store else None
        result = self.http.request("GET", "%s/%s" %
                                   (self.REQUESTS_PATH, request_id))
        return (result or {}).get("request", result)

    def create_request(self, payload: Dict,
                       environment_sequence: List[str]) -> Dict:
        if self.mode == "MOCK":
            return self.store.create_orkestra_request(
                payload, environment_sequence) if self.store else {
                    "ok": False, "error": "Mock store bulunamadı."}
        sequence = [str(value).upper() for value in environment_sequence]
        environment = str(payload.get("environment") or "").upper()
        if environment not in sequence:
            return {"ok": False, "error": "Geçersiz pipeline ortamı."}
        index = sequence.index(environment)
        if index:
            previous = self.get_request(payload.get("previous_request_id", ""))
            if not previous or previous.get("status") != "COMPLETED":
                return {"ok": False,
                        "error": "Önceki ortam talebi tamamlanmış olmalı."}
            if previous.get("environment") != sequence[index - 1] or \
                    previous.get("pipeline_type") != payload.get("pipeline_type"):
                return {"ok": False,
                        "error": "Önceki talep pipeline terfi sırasıyla uyuşmuyor."}
            digest = hashlib.sha256(
                str(payload.get("script") or "").encode("utf-8")).hexdigest()
            if previous.get("script_sha256") != digest:
                return {"ok": False,
                        "error": "Ortam terfisinde script birebir aynı olmalı."}
        result = self.http.request("POST", self.REQUESTS_PATH, payload)
        if not result:
            return {"ok": False, "error": self.last_error}
        return {"ok": True, "request": result.get("request", result)}

    def accept_request(self, request_id: str, actor: str, talep_no: str,
                       run_id: str, octopus_code: str) -> Dict:
        payload = {"actor": actor, "talep_no": talep_no, "run_id": run_id,
                   "octopus_code": octopus_code}
        if self.mode == "MOCK":
            return self.store.accept_orkestra_request(
                request_id, actor, talep_no, run_id, octopus_code)
        result = self.http.request(
            "POST", "%s/%s/accept" % (self.REQUESTS_PATH, request_id), payload)
        return ({"ok": True, "request": result.get("request", result)}
                if result else {"ok": False, "error": self.last_error})

    def reject_request(self, request_id: str, actor: str,
                       reason: str = "") -> Dict:
        if self.mode == "MOCK":
            return self.store.reject_orkestra_request(request_id, actor, reason)
        result = self.http.request(
            "POST", "%s/%s/reject" % (self.REQUESTS_PATH, request_id),
            {"actor": actor, "reason": reason})
        return ({"ok": True, "request": result.get("request", result)}
                if result else {"ok": False, "error": self.last_error})

    def complete_request(self, request_id: str, actor: str) -> Dict:
        if self.mode == "MOCK":
            return self.store.complete_orkestra_request(request_id, actor)
        result = self.http.request(
            "POST", "%s/%s/complete" % (self.REQUESTS_PATH, request_id),
            {"actor": actor})
        return ({"ok": True, "request": result.get("request", result)}
                if result else {"ok": False, "error": self.last_error})

    def write_note(self, talep_no: str, note: str) -> Dict:
        if self.mode == "MOCK":
            request = self.store.get_talep(talep_no) if self.store else None
            if not request:
                return {"ok": False, "detail": "Talep bulunamadı: %s" % talep_no}
            request.setdefault("notes", []).append({"at": _now(), "text": note})
            return {"ok": True, "detail": "Not yazıldı."}
        result = self.http.request("POST", "/api/talep/%s/note" % talep_no,
                                   {"text": note})
        return ({"ok": True, "detail": "Not yazıldı."} if result else
                {"ok": False, "detail": self.last_error})

    def close_talep(self, talep_no: str, result: str) -> Dict:
        if self.mode == "MOCK":
            request = self.store.get_talep(talep_no) if self.store else None
            if not request:
                return {"ok": False, "detail": "Talep bulunamadı."}
            request["status"] = "KAPALI"
            request["result"] = result
            request.setdefault("notes", []).append(
                {"at": _now(), "text": "Talep kapatıldı: %s" % result})
            return {"ok": True, "detail": "Talep kapatıldı."}
        response = self.http.request("POST", "/api/talep/%s/close" % talep_no,
                                     {"result": result})
        return ({"ok": True, "detail": "Talep kapatıldı."} if response else
                {"ok": False, "detail": self.last_error})


class OctopusClient(object):
    def __init__(self, mode="MOCK", base_url="", api_key="", store=None):
        self.mode = str(mode or "MOCK").upper()
        self.store = store
        self.http = JsonHttpClient(
            base_url, {"X-Octopus-ApiKey": str(api_key or "")})

    @property
    def last_error(self):
        return self.http.last_error

    def ping(self) -> Dict:
        if self.mode == "MOCK":
            releases = len(self.store.octopus_releases) if self.store else 0
            deployments = len(self.store.deployments) if self.store else 0
            return {"ok": True, "mode": "MOCK",
                    "detail": "Octopus mock hazır (%d release, %d deployment)." %
                              (releases, deployments)}
        result = self.http.request("GET", "/api", timeout=5)
        return {"ok": bool(result), "mode": "HTTP",
                "detail": (json.dumps(result, ensure_ascii=False)[:300]
                           if result else self.last_error)}

    def list_releases(self) -> List[Dict]:
        if self.mode == "MOCK":
            return list(self.store.octopus_releases.values()) if self.store else []
        result = self.http.request("GET", "/api/releases")
        return (result or {}).get("Items", result if isinstance(result, list) else [])

    def list_deployments(self) -> List[Dict]:
        if self.mode == "MOCK":
            return list(self.store.deployments.values()) if self.store else []
        result = self.http.request("GET", "/api/deployments")
        return (result or {}).get("Items", result if isinstance(result, list) else [])

    def reserve_release(self, env: str, pipeline_type: str, request_id: str,
                        project: str) -> Dict:
        if self.mode == "MOCK":
            return self.store.reserve_octopus_release(
                env, pipeline_type, request_id, project)
        payload = {"ProjectId": project, "EnvironmentName": env,
                   "RequestId": request_id, "PipelineType": pipeline_type}
        result = self.http.request("POST", "/api/releases", payload)
        if not result:
            return {"ok": False, "error": self.last_error}
        release = result.get("release", result)
        release.setdefault("code", release.get("Version") or release.get("Id"))
        return {"ok": True, "release": release}

    def set_release_result(self, code: str, success: bool,
                           detail: str = "") -> Dict:
        if self.mode == "MOCK":
            return self.store.set_octopus_release_result(code, success, detail)
        return {"ok": False,
                "error": "HTTP modunda sonuç Octopus tarafından güncellenir."}

    def create_deployment(self, env: str, project: str, script_sha: str,
                          talep_no: str, release_code: str = "") -> Dict:
        if self.mode == "MOCK":
            return self.store.create_deployment(
                env, project, script_sha, talep_no, release_code)
        payload = {"EnvironmentName": env, "ProjectName": project,
                   "ScriptSha256": script_sha, "RequestNo": talep_no,
                   "ReleaseCode": release_code}
        result = self.http.request("POST", "/api/deployments", payload)
        if not result:
            return {"ok": False, "error": self.last_error}
        return {"ok": True, "deployment": result.get("deployment", result)}

    def get_deployment(self, dep_id: str) -> Optional[Dict]:
        if self.mode == "MOCK":
            return self.store.deployments.get(dep_id)
        result = self.http.request("GET", "/api/deployments/%s" % dep_id)
        return (result or {}).get("deployment", result)

    def set_deployment_result(self, dep_id: str, success: bool,
                              detail: str = "") -> Dict:
        if self.mode != "MOCK":
            return {"ok": False,
                    "detail": "HTTP modunda sonuç Octopus tarafından oluşur."}
        deployment = self.store.deployments.get(dep_id) if self.store else None
        if not deployment:
            return {"ok": False, "detail": "Deployment bulunamadı."}
        deployment["state"] = "Success" if success else "Failed"
        deployment["detail"] = detail
        deployment["completed_at"] = _now()
        code = deployment.get("octopus_code")
        if code:
            self.store.set_octopus_release_result(code, success, detail)
        return {"ok": True,
                "detail": "Durum güncellendi: %s" % deployment["state"]}


TalepClient = OrkestraClient
