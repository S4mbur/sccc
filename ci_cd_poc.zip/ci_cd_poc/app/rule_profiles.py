# -*- coding: utf-8 -*-
"""Data-driven validator rule selection profiles."""
from __future__ import annotations

import io
import json
import os

import validator_api
from store import STORE


PROFILE_FILE = os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "rule_profiles.json")


def load_profiles():
    try:
        with io.open(PROFILE_FILE, encoding="utf-8") as handle:
            definitions = (json.load(handle) or {}).get("profiles", [])
    except Exception as exc:  # noqa: BLE001
        STORE.log("HATA", "rule_profiles.json okunamadı: %s" % exc)
        return []

    rules = validator_api.list_rules()
    result = []
    for definition in definitions:
        include_ids = definition.get("include_ids")
        if include_ids is not None:
            selected = {str(x) for x in include_ids}
        else:
            selected = {r["id"] for r in rules}
            if definition.get("default_enabled_only"):
                selected = {r["id"] for r in rules if r.get("enabled")}
            categories = {str(x).upper() for x in
                          definition.get("categories", [])}
            if categories:
                selected &= {r["id"] for r in rules
                             if str(r.get("category", "")).upper() in categories}
            severities = {str(x).upper() for x in
                          definition.get("severities", [])}
            if severities:
                selected &= {r["id"] for r in rules
                             if str(r.get("severity", "")).upper() in severities}
        selected -= {str(x) for x in definition.get("exclude_ids", [])}
        ordered = [r["id"] for r in rules if r["id"] in selected]
        result.append({
            "id": definition.get("id"),
            "name": definition.get("name"),
            "description": definition.get("description", ""),
            "rule_ids": ordered,
            "rule_count": len(ordered),
        })
    return result
