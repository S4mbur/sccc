# -*- coding: utf-8 -*-
"""Pipeline motoru: asamalar, kapilar (gate) ve gecis kurallari.

Cekirdek fikir: her asamanin gecmesi icin TUM kapilari yesil olmalidir.
Kapi degerlendirmesi her istekte yeniden hesaplanir - yani bir talep sonradan
degistirilirse (script degisti, talep kapandi) asama otomatik olarak kirmizi
olur. Boylece "bir kez gecti, hep gecti" durumu olusmaz.
"""
from __future__ import annotations

import io
import json
import os
import re
import tempfile
import time
from typing import Dict, List, Optional

import compare
import inventory
import validator_api
from store import STORE

PIPE_FILE = os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "pipelines.json")

STATUS_PENDING = "PENDING"     # onceki asamalar bitmedi
STATUS_READY = "READY"         # kapilar yesil, ilerletilebilir
STATUS_BLOCKED = "BLOCKED"     # sira burada ama kapi kirmizi
STATUS_DONE = "DONE"
STATUS_FAILED = "FAILED"

GATE_LABELS = {
    "talep_exists": "Talep baglanmis",
    "talep_open": "Talep acik",
    "validator_pass": "Validator karari",
    "script_identical": "Script birebir ayni",
    "octopus_ref_prev": "Onceki deployment no talebe yazilmis",
    "deployment_ref_prev": "Önceki deployment kanıtı talebe yazılmış",
    "octopus_success": "Deployment basarili",
    "database_success": "Oracle çalıştırması başarılı",
    "target_available": "Deployment hedefi kullanılabilir",
    "approval_two_eyes": "Dort-goz onayi",
    "script_type_allowed": "Script türü pipeline ile uyumlu",
    "prod_change_policy": "PROD geçiş politikası",
}

STAGE_TYPES = {"TALEP", "VALIDATE", "DEPLOY", "APPROVAL"}
EXECUTORS = {"OCTOPUS", "DATABASE"}


def _now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def load_pipelines() -> List[Dict]:
    try:
        with io.open(PIPE_FILE, encoding="utf-8") as f:
            return (json.load(f) or {}).get("pipelines", [])
    except Exception as exc:                                 # noqa: BLE001
        STORE.log("HATA", "pipelines.json okunamadi: %s" % exc)
        return []


def get_pipeline(pid: str) -> Optional[Dict]:
    for p in load_pipelines():
        if p.get("id") == pid:
            return p
    return None


def request_environment_sequence(pipeline_id: str) -> List[str]:
    definition = get_pipeline(pipeline_id) or {}
    sequence = []
    for stage in definition.get("stages", []):
        environment = str(stage.get("env") or "").upper()
        if stage.get("type") == "TALEP" and environment and environment not in sequence:
            sequence.append(environment)
    return sequence


def capabilities() -> Dict:
    return {
        "stage_types": sorted(STAGE_TYPES),
        "executors": sorted(EXECUTORS),
        "gates": [{"id": key, "name": value}
                  for key, value in GATE_LABELS.items()],
    }


def validate_definition(definition: Dict) -> List[str]:
    errors = []
    if not isinstance(definition, dict):
        return ["Pipeline tanımı bir JSON nesnesi olmalı."]
    pid = str(definition.get("id") or "")
    if not re.match(r"^[a-z][a-z0-9_-]{2,49}$", pid):
        errors.append("id küçük harfle başlamalı; yalnız a-z, 0-9, _ ve - içermeli.")
    if not str(definition.get("name") or "").strip():
        errors.append("name zorunlu.")
    if not isinstance(definition.get("applies_to"), list) or not definition.get("applies_to"):
        errors.append("applies_to en az bir script sınıfı içermeli.")
    stages = definition.get("stages")
    if not isinstance(stages, list) or not stages:
        errors.append("stages en az bir aşama içermeli.")
        return errors
    seen = set()
    for index, stage in enumerate(stages, 1):
        prefix = "%d. aşama" % index
        if not isinstance(stage, dict):
            errors.append("%s: JSON nesnesi olmalı." % prefix)
            continue
        sid = str(stage.get("id") or "")
        if not re.match(r"^[a-z][a-z0-9_-]{1,49}$", sid):
            errors.append("%s: geçerli id zorunlu." % prefix)
        if sid in seen:
            errors.append("%s: aşama id tekrar ediyor: %s" % (prefix, sid))
        seen.add(sid)
        stage_type = str(stage.get("type") or "").upper()
        if stage_type not in STAGE_TYPES:
            errors.append("%s: bilinmeyen type: %s" % (prefix, stage_type))
        executor = str(stage.get("executor") or "OCTOPUS").upper()
        if stage_type == "DEPLOY" and executor not in EXECUTORS:
            errors.append("%s: bilinmeyen executor: %s" % (prefix, executor))
        unknown = [g for g in stage.get("gates", []) if g not in GATE_LABELS]
        if unknown:
            errors.append("%s: bilinmeyen gate: %s" %
                          (prefix, ", ".join(unknown)))
    return errors


def save_definition(definition: Dict) -> Dict:
    errors = validate_definition(definition)
    if errors:
        return {"ok": False, "error": " ".join(errors), "errors": errors}
    with io.open(PIPE_FILE, encoding="utf-8") as handle:
        document = json.load(handle) or {}
    pipelines = document.setdefault("pipelines", [])
    pid = definition["id"]
    replaced = False
    for index, current in enumerate(pipelines):
        if current.get("id") == pid:
            pipelines[index] = definition
            replaced = True
            break
    if not replaced:
        pipelines.append(definition)
    directory = os.path.dirname(PIPE_FILE)
    fd, temp_path = tempfile.mkstemp(prefix="pipelines-", suffix=".json",
                                     dir=directory)
    try:
        with io.open(fd, "w", encoding="utf-8") as handle:
            json.dump(document, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(temp_path, PIPE_FILE)
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)
    STORE.log("PIPELINE", "Pipeline tanımı %s: %s" %
              ("güncellendi" if replaced else "eklendi", pid))
    return {"ok": True, "pipeline": definition, "created": not replaced}


def delete_definition(pipeline_id: str) -> Dict:
    with io.open(PIPE_FILE, encoding="utf-8") as handle:
        document = json.load(handle) or {}
    pipelines = document.get("pipelines", [])
    kept = [item for item in pipelines if item.get("id") != pipeline_id]
    if len(kept) == len(pipelines):
        return {"ok": False, "error": "Pipeline bulunamadı: %s" % pipeline_id}
    document["pipelines"] = kept
    fd, temp_path = tempfile.mkstemp(prefix="pipelines-", suffix=".json",
                                     dir=os.path.dirname(PIPE_FILE))
    try:
        with io.open(fd, "w", encoding="utf-8") as handle:
            json.dump(document, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(temp_path, PIPE_FILE)
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)
    STORE.log("PIPELINE", "Pipeline tanımı silindi: %s" % pipeline_id)
    return {"ok": True}


def generate_target_pipeline(spec: Dict) -> Dict:
    """Build a regular pipeline definition from an ordered target topology."""
    spec = dict(spec or {})
    pipeline_id = str(spec.get("id") or "").strip()
    name = str(spec.get("name") or "").strip()
    target_ids = [str(value) for value in spec.get("target_ids", [])]
    applies_to = [str(value).upper() for value in
                  spec.get("applies_to", ["DDL", "DML"])
                  if str(value).upper() in ("DDL", "DML", "DCL", "SELECT")]
    if not target_ids:
        return {"ok": False, "error": "En az bir deployment hedefi seçin."}
    targets = []
    for target_id in target_ids:
        target = STORE.targets.get(target_id)
        if not target:
            return {"ok": False, "error": "Hedef bulunamadı: %s" % target_id}
        if not target.get("enabled", True):
            return {"ok": False, "error": "Hedef devre dışı: %s" % target["name"]}
        targets.append(target)
    if not applies_to:
        return {"ok": False, "error": "En az bir script türü seçin."}

    stages = []
    for index, target in enumerate(targets, 1):
        env = target["environment"]
        base = "s%02d_%s" % (index, env.lower())
        request_gates = ["talep_exists", "talep_open"]
        if index > 1 and bool(spec.get("require_identical", True)):
            request_gates.extend(["script_identical", "deployment_ref_prev"])
        stages.append({
            "id": base + "_request", "name": "%s talebi" % target["name"],
            "env": env, "type": "TALEP", "target_id": target["id"],
            "gates": request_gates,
            "help": "Bu hedef için talep otomatik hazırlanabilir.",
        })
        stages.append({
            "id": base + "_validate", "name": "%s validator" % target["name"],
            "env": env, "type": "VALIDATE", "target_id": target["id"],
            "allowed_kinds": applies_to,
            "gates": ["validator_pass", "script_type_allowed"],
        })
        if env == "PROD" and bool(spec.get("approval_on_prod", True)):
            stages.append({
                "id": base + "_approval", "name": "%s dört-göz onayı" % target["name"],
                "env": env, "type": "APPROVAL", "target_id": target["id"],
                "gates": ["approval_two_eyes"],
            })
        deploy_gates = ["target_available"]
        if env == "PROD":
            deploy_gates.append("prod_change_policy")
        deploy_gates.append("database_success")
        stages.append({
            "id": base + "_deploy", "name": "%s Oracle deployment" % target["name"],
            "env": env, "type": "DEPLOY", "executor": "DATABASE",
            "target_id": target["id"], "gates": deploy_gates,
            "help": "Sabit hedef: %s -> %s" %
                    (target["name"], target.get("database_profile_id", "")),
        })

    definition = {
        "id": pipeline_id, "name": name,
        "description": str(spec.get("description") or
                           " -> ".join(target["name"] for target in targets)),
        "applies_to": applies_to,
        "auto_prepare_requests": bool(spec.get("auto_prepare_requests", True)),
        "gate_policy": ("ALLOW_WARN" if spec.get("gate_policy") == "ALLOW_WARN"
                        else "PASS_ONLY"),
        "generated_from_targets": True,
        "topology": [{"target_id": target["id"], "name": target["name"],
                      "environment": target["environment"]}
                     for target in targets],
        "stages": stages,
    }
    result = save_definition(definition)
    if result.get("ok"):
        result["pipeline"] = definition
    return result


# =========================================================== kosum olusturma
def create_run(pipeline_id: str, title: str, reference_script: str = "",
               owner: str = "RUNNER", selected_rule_ids=None,
               script_name: str = "01-change.sql") -> Dict:
    p = get_pipeline(pipeline_id)
    if not p:
        return {"ok": False, "error": "Pipeline bulunamadi: %s" % pipeline_id}

    run_id = STORE.next_run_id()
    if selected_rule_ids is None:
        selected_rule_ids = [r["id"] for r in validator_api.list_rules()
                             if r.get("enabled")]
    else:
        available = {r["id"] for r in validator_api.list_rules()}
        selected_rule_ids = [str(x) for x in selected_rule_ids
                             if str(x) in available]

    stages = []
    for source in p.get("stages", []):
        stage = dict(source)
        stage.update({
            "id": source["id"], "name": source.get("name", source["id"]),
            "env": source.get("env", ""),
            "type": source.get("type", "TALEP"),
            "target_id": source.get("target_id", ""),
            "gates": list(source.get("gates", [])),
            "help": source.get("help", ""),
            "status": STATUS_PENDING,
            "talep_no": "", "deployment_id": "", "db_profile_id": "",
            "approved_by": "", "approved_at": "",
            "validation": None, "checks": [], "done_at": "",
        })
        stages.append(stage)

    run = {
        "id": run_id,
        "pipeline_id": pipeline_id,
        "pipeline_type": pipeline_id,
        "pipeline_name": p.get("name", pipeline_id),
        "title": title or "(baslik yok)",
        "owner": owner,
        "created_at": _now(),
        "status": "RUNNING",
        "reference_script": reference_script,
        "script_name": script_name or "01-change.sql",
        "reference_sha256": (compare.sha256_text(reference_script)
                             if reference_script else ""),
        "applies_to": list(p.get("applies_to", [])),
        "auto_prepare_requests": bool(p.get("auto_prepare_requests", False)),
        "gate_policy": p.get("gate_policy") or STORE.settings.get("gate_policy",
                                                                    "PASS_ONLY"),
        "generated_from_targets": bool(p.get("generated_from_targets", False)),
        "topology": list(p.get("topology", [])),
        "selected_rule_ids": selected_rule_ids,
        "stages": stages,
    }
    STORE.runs[run_id] = run
    STORE.log("PIPELINE", "Kosum baslatildi: %s (%s)" % (run_id, p.get("name")),
              run_id=run_id)
    evaluate(run)
    return {"ok": True, "run": run}


def get_run(run_id: str) -> Optional[Dict]:
    return STORE.runs.get(run_id)


# ==================================================================== kapilar
def _script_of(talep_no: str) -> str:
    t = STORE.get_talep(talep_no)
    return (t or {}).get("script", "")


def _prev_deploy_stage(run: Dict, idx: int) -> Optional[Dict]:
    """idx'ten onceki en yakin DEPLOY asamasi."""
    for j in range(idx - 1, -1, -1):
        if run["stages"][j]["type"] == "DEPLOY":
            return run["stages"][j]
    return None


def _gate_result(gate: str, run: Dict, stage: Dict, idx: int) -> Dict:
    """Tek bir kapiyi degerlendirir -> {gate, label, ok, detail}"""
    label = GATE_LABELS.get(gate, gate)
    talep_no = stage.get("talep_no") or _inherit_talep(run, idx)
    talep = STORE.get_talep(talep_no) if talep_no else None
    settings = STORE.settings

    if gate == "talep_exists":
        return _r(gate, label, bool(talep),
                  "Talep: %s" % talep_no if talep else
                  "Bu asamaya (%s) bir talep baglanmamis." % stage["env"])

    if gate == "talep_open":
        if not talep:
            return _r(gate, label, False, "Talep yok.")
        ok = talep.get("status") == "ACIK"
        return _r(gate, label, ok,
                  "Talep durumu: %s" % talep.get("status"))

    if gate == "validator_pass":
        v = stage.get("validation")
        if not v:
            return _r(gate, label, False,
                      "Validator henuz calistirilmadi.")
        verdict = v.get("verdict")
        policy = run.get("gate_policy") or settings.get("gate_policy", "PASS_ONLY")
        ok = (verdict == "PASS") if policy == "PASS_ONLY" else \
             (verdict in ("PASS", "WARN"))
        s = v.get("summary") or {}
        return _r(gate, label, ok,
                  "Karar: %s (FAIL:%s WARN:%s INFO:%s) - politika: %s"
                  % (verdict, s.get("fail", 0), s.get("warn", 0),
                     s.get("info", 0), policy))

    if gate == "script_identical":
        if not settings.get("require_identical", True):
            return _r(gate, label, True, "Kural kapali (ayarlar).")
        if not talep:
            return _r(gate, label, False, "Talep yok.")
        ref = run.get("reference_script", "")
        if not ref:
            return _r(gate, label, True,
                      "Referans script henuz belirlenmedi (ilk talep).")
        cur = talep.get("script", "")
        if cur == ref:
            return _r(gate, label, True,
                      "SHA-256 eslesiyor: %s"
                      % compare.sha256_text(cur)[:12])
        kind = compare.normalized_diff_kind(ref, cur)
        d = compare.first_difference(ref, cur)
        return _r(gate, label, False,
                  "%s | %s" % (compare.DIFF_KIND_TEXT.get(kind, kind),
                               d.get("reason", "")))

    if gate in ("octopus_ref_prev", "deployment_ref_prev"):
        if not settings.get("require_octopus_ref", True):
            return _r(gate, label, True, "Kural kapali (ayarlar).")
        prev = _prev_deploy_stage(run, idx)
        if not prev:
            return _r(gate, label, True, "Oncesinde deployment asamasi yok.")
        need = prev.get("deployment_id", "")
        if not need:
            return _r(gate, label, False,
                      "Onceki asamada (%s) deployment henuz olusmadi."
                      % prev["name"])
        if not talep:
            return _r(gate, label, False, "Talep yok.")
        written = (talep.get("octopus_ref") or "").strip()
        notes = " ".join(n.get("text", "") for n in talep.get("notes", []))
        ok = (written == need) or (need in notes)
        return _r(gate, label, ok,
                  "Beklenen: %s | Talepte: %s"
                  % (need, written or "(bos)"))

    if gate == "octopus_success":
        dep_id = stage.get("deployment_id")
        if not dep_id:
            return _r(gate, label, False, "Deployment henuz olusturulmadi.")
        d = STORE.deployments.get(dep_id) or {}
        ok = d.get("state") == "Success"
        return _r(gate, label, ok,
                  "%s durumu: %s" % (dep_id, d.get("state", "?")))

    if gate == "database_success":
        dep_id = stage.get("deployment_id")
        if not dep_id:
            return _r(gate, label, False,
                      "Oracle üzerinde çalıştırma henüz başlatılmadı.")
        d = STORE.deployments.get(dep_id) or {}
        ok = d.get("state") == "Success" and d.get("executor") == "DATABASE"
        return _r(gate, label, ok,
                  "%s / %s / %s" % (dep_id, d.get("database_name", "?"),
                                      d.get("state", "?")))

    if gate == "target_available":
        target_id = stage.get("target_id")
        target = STORE.targets.get(target_id) if target_id else None
        if not target:
            return _r(gate, label, False,
                      "Aşamaya deployment hedefi bağlanmamış veya hedef silinmiş.")
        profile = STORE.databases.get(target.get("database_profile_id"))
        ok = bool(target.get("enabled", True) and profile)
        return _r(gate, label, ok,
                  "%s (%s) -> %s" %
                  (target.get("name"), target.get("environment"),
                   profile.get("name") if profile else "bağlantı yok"))

    if gate == "script_type_allowed":
        if not talep:
            return _r(gate, label, False, "Scripti olan bağlı bir talep yok.")
        try:
            kinds = inventory.analyze_inventory(
                talep.get("script", ""), talep.get("script_name", "x.sql")
            ).get("file_kinds", [])
        except Exception as exc:  # noqa: BLE001
            return _r(gate, label, False, "Script türü okunamadı: %s" % exc)
        material = {x for x in kinds if x in ("DDL", "DML", "DCL", "SELECT")}
        allowed = set(stage.get("allowed_kinds") or run.get("applies_to") or [])
        ok = bool(material) and material.issubset(allowed)
        return _r(gate, label, ok,
                  "Bulunan: %s | İzin verilen: %s" %
                  (", ".join(sorted(material)) or "BOŞ",
                   ", ".join(sorted(allowed)) or "tanımsız"))

    if gate == "prod_change_policy":
        if stage.get("env") != "PROD":
            return _r(gate, label, True, "PROD dışı ortam.")
        if not talep:
            return _r(gate, label, False, "Scripti olan bağlı bir PROD talebi yok.")
        try:
            kinds = set(inventory.analyze_inventory(
                talep.get("script", ""), talep.get("script_name", "x.sql")
            ).get("file_kinds", []))
        except Exception as exc:  # noqa: BLE001
            return _r(gate, label, False, "Script türü okunamadı: %s" % exc)
        if "DDL" in kinds and "DML" in kinds:
            return _r(gate, label, False,
                      "DDL ve DML aynı dosyada; değişiklikler ayrılmalı.")
        if "DDL" not in kinds:
            return _r(gate, label, "DML" in kinds,
                      "DML doğrudan PROD'a gidebilir; onay ve validator kapıları yine zorunlu.")
        promoted = False
        evidence = ""
        for previous in run["stages"][:idx]:
            if previous.get("type") != "DEPLOY" or previous.get("env") != "PREPROD":
                continue
            dep = STORE.deployments.get(previous.get("deployment_id")) or {}
            if previous.get("status") == STATUS_DONE and dep.get("state") == "Success":
                promoted = True
                evidence = dep.get("id", "")
                break
        return _r(gate, label, promoted,
                  ("DDL için PREPROD kanıtı bulundu: %s" % evidence) if promoted else
                  "DDL doğrudan PROD'a çalıştırılamaz; başarılı PREPROD deployment'ı zorunlu.")

    if gate == "approval_two_eyes":
        who = stage.get("approved_by", "")
        if not who:
            return _r(gate, label, False, "Onay bekleniyor.")
        opener = (talep or {}).get("owner", "") or run.get("owner", "")
        ok = who.strip().lower() != opener.strip().lower()
        return _r(gate, label, ok,
                  "Onaylayan: %s | Talebi acan: %s%s"
                  % (who, opener,
                     "" if ok else " - AYNI KISI OLAMAZ"))

    return _r(gate, label, False, "Bilinmeyen kapi: %s" % gate)


def _r(gate, label, ok, detail):
    return {"gate": gate, "label": label, "ok": bool(ok), "detail": detail}


def _inherit_talep(run: Dict, idx: int) -> str:
    """VALIDATE/DEPLOY/APPROVAL asamalari, ayni ortamdaki son TALEP
    asamasinin talebini kullanir."""
    env = run["stages"][idx].get("env")
    for j in range(idx, -1, -1):
        s = run["stages"][j]
        if s["type"] == "TALEP" and s.get("env") == env and s.get("talep_no"):
            return s["talep_no"]
    return ""


# ============================================================ degerlendirme
def evaluate(run: Dict) -> Dict:
    """Tum asamalarin kapilarini yeniden hesaplar ve durumlari gunceller."""
    blocked_reached = False
    for idx, stage in enumerate(run["stages"]):
        stage["effective_talep_no"] = stage.get("talep_no") or _inherit_talep(run, idx)
        checks = [_gate_result(g, run, stage, idx) for g in stage.get("gates", [])]
        stage["checks"] = checks
        all_ok = all(c["ok"] for c in checks) if checks else True

        prev_done = all(s["status"] == STATUS_DONE for s in run["stages"][:idx])

        if stage["status"] == STATUS_DONE:
            # Tamamlanmis asama sonradan bozulduysa geri al (fail-closed)
            if not all_ok:
                stage["status"] = STATUS_BLOCKED
                stage["done_at"] = ""
            continue
        if stage["status"] == STATUS_FAILED:
            blocked_reached = True
            continue

        if not prev_done:
            stage["status"] = STATUS_PENDING
        elif all_ok:
            stage["status"] = STATUS_READY
        else:
            stage["status"] = STATUS_BLOCKED
            blocked_reached = True

    if all(s["status"] == STATUS_DONE for s in run["stages"]):
        run["status"] = "DONE"
    elif any(s["status"] == STATUS_FAILED for s in run["stages"]):
        run["status"] = "FAILED"
    elif blocked_reached:
        run["status"] = "BLOCKED"
    else:
        run["status"] = "RUNNING"
    return run


def _stage(run: Dict, stage_id: str):
    for i, s in enumerate(run["stages"]):
        if s["id"] == stage_id:
            return i, s
    return -1, None


# ================================================================ eylemler
def attach_talep(run_id: str, stage_id: str, talep_no: str) -> Dict:
    run = get_run(run_id)
    if not run:
        return {"ok": False, "error": "Kosum yok."}
    idx, stage = _stage(run, stage_id)
    if not stage:
        return {"ok": False, "error": "Asama yok."}
    t = STORE.get_talep(talep_no)
    if not t:
        return {"ok": False, "error": "Talep bulunamadi: %s" % talep_no}
    if t.get("env") and stage.get("env") and t["env"] != stage["env"]:
        return {"ok": False,
                "error": "Talep ortami (%s) asama ortamiyla (%s) uyusmuyor."
                         % (t["env"], stage["env"])}
    if t.get("pipeline_type") and t.get("pipeline_type") != run["pipeline_id"]:
        return {"ok": False,
                "error": "Talep pipeline tipi (%s), koşum tipiyle (%s) uyuşmuyor." %
                         (t["pipeline_type"], run["pipeline_id"])}
    stage["talep_no"] = talep_no
    t["run_id"] = run_id
    t["pipeline_id"] = run["pipeline_id"]
    t["pipeline_type"] = run["pipeline_id"]

    # Ilk baglanan talep referans scripti belirler
    if not run.get("reference_script"):
        run["reference_script"] = t.get("script", "")
        run["reference_sha256"] = compare.sha256_text(run["reference_script"])
        STORE.log("PIPELINE",
                  "Referans script belirlendi (%s): %s"
                  % (talep_no, run["reference_sha256"][:12]), run_id=run_id)

    STORE.log("PIPELINE", "%s asamasina %s talebi baglandi"
              % (stage["name"], talep_no), run_id=run_id, talep_no=talep_no)
    evaluate(run)
    return {"ok": True, "run": run}


def prepare_requests(run_id: str, script: str = "", script_name: str = "01-change.sql",
                     owner: str = "RUNNER") -> Dict:
    """Create and attach one ready request for every TALEP stage."""
    run = get_run(run_id)
    if not run:
        return {"ok": False, "error": "Koşum yok."}
    artifact = script or run.get("reference_script", "")
    if not artifact:
        return {"ok": False,
                "error": "Talepleri hazırlamak için bir referans script gerekli."}
    if not run.get("reference_script"):
        run["reference_script"] = artifact
        run["reference_sha256"] = compare.sha256_text(artifact)
    created = []
    for stage in run["stages"]:
        if stage.get("type") != "TALEP" or stage.get("talep_no"):
            continue
        target = STORE.targets.get(stage.get("target_id", "")) or {}
        request = STORE.create_talep(
            stage.get("env", "TEST"),
            "%s — %s" % (run.get("title", "Değişiklik"),
                          target.get("name") or stage.get("env", "")),
            artifact, script_name, owner or run.get("owner", "RUNNER"),
            pipeline_id=run.get("pipeline_id", ""), run_id=run_id,
            target_id=stage.get("target_id", ""),
            pipeline_type=run.get("pipeline_id", ""))
        attach_talep(run_id, stage["id"], request["talep_no"])
        created.append(request)
    evaluate(run)
    STORE.log("PIPELINE", "%s için %d ortam talebi hazırlandı." %
              (run_id, len(created)), run_id=run_id)
    return {"ok": True, "run": run, "talepler": created,
            "message": "%d talep hazırlandı ve aşamalara bağlandı." % len(created)}


def next_action(run_id: str) -> Dict:
    run = get_run(run_id)
    if not run:
        return {"ok": False, "error": "Koşum yok."}
    evaluate(run)
    stage = next((item for item in run["stages"]
                  if item.get("status") != STATUS_DONE), None)
    if not stage:
        return {"ok": True, "done": True, "run": run,
                "message": "Pipeline tamamlandı."}
    target = STORE.targets.get(stage.get("target_id", ""))
    return {"ok": True, "done": False, "stage": stage,
            "target": target, "run": run}


def advance_run(run_id: str, databases, octopus=None, password: str = "",
                confirmation: str = "", approver: str = "",
                transaction_mode: str = "SCRIPT") -> Dict:
    """Perform the next safe, deterministic action for a run.

    This powers the click-by-click demo flow. It never bypasses a gate: it only
    prepares missing evidence, invokes the normal action function, and then
    completes the stage through ``complete_stage``.
    """
    info = next_action(run_id)
    if not info.get("ok") or info.get("done"):
        return info
    run = info["run"]
    stage = info["stage"]
    stage_id = stage["id"]
    kind = stage.get("type")

    if kind == "TALEP":
        if not stage.get("talep_no"):
            prepared = prepare_requests(
                run_id, run.get("reference_script", ""),
                run.get("script_name", "01-change.sql"), run.get("owner", ""))
            if not prepared.get("ok"):
                return prepared
            stage = _stage(run, stage_id)[1]
        talep = STORE.get_talep(stage.get("talep_no"))
        previous = _prev_deploy_stage(run, run["stages"].index(stage))
        if previous and previous.get("deployment_id") and talep:
            reference = previous["deployment_id"]
            talep["octopus_ref"] = reference
            note_text = "Önceki deployment kanıtı: %s" % reference
            if not any(reference in note.get("text", "")
                       for note in talep.get("notes", [])):
                talep.setdefault("notes", []).append({"at": _now(),
                                                      "text": note_text})
        completed = complete_stage(run_id, stage_id)
        if not completed.get("ok"):
            return completed
        return {"ok": True, "action": "REQUEST_COMPLETED", "stage_id": stage_id,
                "message": "%s hazırlandı ve tamamlandı." % stage["name"],
                "run": completed["run"]}

    if kind == "VALIDATE":
        validation = run_validation(run_id, stage_id)
        if not validation.get("ok"):
            return validation
        completed = complete_stage(run_id, stage_id)
        if not completed.get("ok"):
            return completed
        return {"ok": True, "action": "VALIDATED", "stage_id": stage_id,
                "message": "Validator çalıştı: %s" %
                           validation["validation"].get("verdict"),
                "validation": validation["validation"], "run": completed["run"]}

    if kind == "APPROVAL":
        if not approver.strip():
            return {"ok": False, "needs": "approver",
                    "error": "Bu adım için onaylayan kullanıcı gerekli.",
                    "stage": stage, "run": run}
        approved = approve(run_id, stage_id, approver)
        if not approved.get("ok"):
            return approved
        completed = complete_stage(run_id, stage_id)
        if not completed.get("ok"):
            return completed
        return {"ok": True, "action": "APPROVED", "stage_id": stage_id,
                "message": "%s onayı kaydedildi." % approver,
                "run": completed["run"]}

    if kind == "DEPLOY":
        executor = str(stage.get("executor", "OCTOPUS")).upper()
        if executor == "DATABASE":
            deployed = execute_database_deployment(
                run_id, stage_id, databases, password=password,
                confirmation=confirmation, transaction_mode=transaction_mode,
                target_id=stage.get("target_id", ""))
            if not deployed.get("ok"):
                return deployed
        else:
            if octopus is None:
                return {"ok": False, "error": "Octopus bağlantısı yok."}
            deployed = create_deployment(run_id, stage_id, octopus)
            if not deployed.get("ok"):
                return deployed
            if getattr(octopus, "mode", "") == "MOCK":
                octopus.set_deployment_result(deployed["deployment"]["id"], True,
                                              "Hızlı akış mock sonucu")
                evaluate(run)
        completed = complete_stage(run_id, stage_id)
        if not completed.get("ok"):
            return completed
        return {"ok": True, "action": "DEPLOYED", "stage_id": stage_id,
                "message": "%s başarıyla tamamlandı." % stage["name"],
                "deployment": deployed.get("deployment"),
                "execution": deployed.get("execution"), "run": completed["run"]}

    return {"ok": False, "error": "Desteklenmeyen aşama tipi: %s" % kind}


def run_validation(run_id: str, stage_id: str) -> Dict:
    run = get_run(run_id)
    if not run:
        return {"ok": False, "error": "Kosum yok."}
    idx, stage = _stage(run, stage_id)
    if not stage:
        return {"ok": False, "error": "Asama yok."}
    talep_no = stage.get("talep_no") or _inherit_talep(run, idx)
    t = STORE.get_talep(talep_no) if talep_no else None
    if not t:
        return {"ok": False, "error": "Bu asamaya bagli talep yok."}

    res = validator_api.validate_text(
        t.get("script", ""), t.get("script_name", "01-degisiklik.sql"),
        overrides=STORE.settings.get("rule_overrides") or {},
        selected_rule_ids=run.get("selected_rule_ids"))
    stage["validation"] = res
    t["validation"] = {"verdict": res.get("verdict"),
                       "summary": res.get("summary"),
                       "at": _now()}
    STORE.log("VALIDATOR", "%s -> %s (%s)"
              % (talep_no, res.get("verdict"), stage["name"]),
              run_id=run_id, talep_no=talep_no)
    evaluate(run)
    return {"ok": True, "run": run, "validation": res}


def create_deployment(run_id: str, stage_id: str, octopus) -> Dict:
    run = get_run(run_id)
    if not run:
        return {"ok": False, "error": "Kosum yok."}
    idx, stage = _stage(run, stage_id)
    if not stage:
        return {"ok": False, "error": "Asama yok."}
    if stage["type"] != "DEPLOY":
        return {"ok": False, "error": "Bu asama bir deployment asamasi degil."}
    if str(stage.get("executor", "OCTOPUS")).upper() == "DATABASE":
        return {"ok": False,
                "error": "Bu aşama doğrudan Oracle çalıştırıcısı kullanıyor."}

    talep_no = stage.get("talep_no") or _inherit_talep(run, idx)
    t = STORE.get_talep(talep_no) if talep_no else None
    if not t:
        return {"ok": False, "error": "Bagli talep yok."}

    # Deployment olusturmadan once o ortamin validator kapisi gecmis olmali
    for j in range(idx - 1, -1, -1):
        s = run["stages"][j]
        if s["type"] == "VALIDATE" and s.get("env") == stage.get("env"):
            if s["status"] != STATUS_DONE:
                return {"ok": False,
                        "error": "Once '%s' asamasi tamamlanmali." % s["name"]}
            break

    res = octopus.create_deployment(
        stage.get("env", "?"), STORE.settings.get("octopus_project",
                                                  "OracleDeploy"),
        compare.sha256_text(t.get("script", "")), talep_no,
        t.get("octopus_code", ""))
    if not res or not res.get("ok"):
        return {"ok": False, "error": "Octopus deployment olusturulamadi."}
    dep = res["deployment"]
    stage["deployment_id"] = dep["id"]
    STORE.log("OCTOPUS", "%s icin deployment: %s" % (stage["name"], dep["id"]),
              run_id=run_id, talep_no=talep_no)
    evaluate(run)
    return {"ok": True, "run": run, "deployment": dep}


def execute_database_deployment(run_id: str, stage_id: str, databases,
                                profile_id: str = "", password: str = "",
                                confirmation: str = "",
                                transaction_mode: str = "SCRIPT",
                                target_id: str = "") -> Dict:
    """Execute the attached request script on a configured Oracle target."""
    run = get_run(run_id)
    if not run:
        return {"ok": False, "error": "Koşum yok."}
    idx, stage = _stage(run, stage_id)
    if not stage:
        return {"ok": False, "error": "Aşama yok."}
    if stage.get("type") != "DEPLOY" or \
            str(stage.get("executor", "OCTOPUS")).upper() != "DATABASE":
        return {"ok": False, "error": "Bu aşama Oracle DB deployment aşaması değil."}
    if not all(s.get("status") == STATUS_DONE for s in run["stages"][:idx]):
        return {"ok": False, "error": "Önceki pipeline aşamaları tamamlanmalı."}

    talep_no = stage.get("talep_no") or _inherit_talep(run, idx)
    talep = STORE.get_talep(talep_no) if talep_no else None
    if not talep:
        return {"ok": False, "error": "Bağlı talep yok."}
    target_id = target_id or stage.get("target_id", "")
    target = databases.store.targets.get(target_id) if target_id else None
    if target:
        profile_id = target.get("database_profile_id", "")
    profile = databases.store.databases.get(profile_id)
    if not profile:
        return {"ok": False, "error": "Oracle bağlantı profili bulunamadı."}
    effective_environment = ((target or {}).get("environment") or
                             profile.get("environment"))
    if effective_environment not in (stage.get("env"), "SHARED"):
        return {"ok": False,
                "error": "Hedef ortamı (%s), aşama ortamı (%s) ile uyuşmuyor." %
                         (effective_environment, stage.get("env"))}

    # Check all policy gates except the deployment result gate, which can only
    # become green after this action.
    evaluate(run)
    red_policy = [c for c in stage.get("checks", [])
                  if not c.get("ok") and c.get("gate") != "database_success"]
    if red_policy:
        return {"ok": False, "error": "Deployment politikası geçilemedi: %s" %
                "; ".join(c.get("detail", "") for c in red_policy)}

    execution = databases.execute(
        profile_id, talep.get("script", ""),
        talep.get("script_name", "01-degisiklik.sql"),
        password=password, selected_rule_ids=run.get("selected_rule_ids"),
        gate_policy=run.get("gate_policy") or
                    STORE.settings.get("gate_policy", "PASS_ONLY"),
        confirmation=confirmation, transaction_mode=transaction_mode,
        environment=stage.get("env", ""),
        confirmation_name=(target or {}).get("name", ""),
        current_schema=(target or {}).get("schema", ""))
    deployment_result = STORE.create_database_deployment(
        stage.get("env", ""), profile,
        compare.sha256_text(talep.get("script", "")), talep_no, execution,
        target=target)
    deployment = deployment_result["deployment"]
    stage["deployment_id"] = deployment["id"]
    stage["db_profile_id"] = profile_id
    stage["target_id"] = target_id
    evaluate(run)
    if not execution.get("ok"):
        return {"ok": False, "error": execution.get("error") or
                execution.get("message"), "execution": execution,
                "deployment": deployment, "run": run}
    return {"ok": True, "execution": execution,
            "deployment": deployment, "run": run}


def approve(run_id: str, stage_id: str, who: str) -> Dict:
    run = get_run(run_id)
    if not run:
        return {"ok": False, "error": "Kosum yok."}
    idx, stage = _stage(run, stage_id)
    if not stage:
        return {"ok": False, "error": "Asama yok."}
    stage["approved_by"] = who
    stage["approved_at"] = _now()
    STORE.log("ONAY", "%s onayladi: %s" % (who, stage["name"]), run_id=run_id)
    evaluate(run)
    return {"ok": True, "run": run}


def complete_stage(run_id: str, stage_id: str) -> Dict:
    """Kapilari yesil olan asamayi tamamlar."""
    run = get_run(run_id)
    if not run:
        return {"ok": False, "error": "Kosum yok."}
    idx, stage = _stage(run, stage_id)
    if not stage:
        return {"ok": False, "error": "Asama yok."}
    evaluate(run)
    if stage["status"] not in (STATUS_READY, STATUS_DONE):
        red = [c for c in stage.get("checks", []) if not c["ok"]]
        return {"ok": False,
                "error": "Asama ilerletilemez. Kirmizi kapi(lar): %s"
                         % "; ".join("%s -> %s" % (c["label"], c["detail"])
                                     for c in red),
                "run": run}
    stage["status"] = STATUS_DONE
    stage["done_at"] = _now()
    STORE.log("PIPELINE", "Asama tamamlandi: %s" % stage["name"], run_id=run_id)
    evaluate(run)
    return {"ok": True, "run": run}


def fail_stage(run_id: str, stage_id: str, reason: str) -> Dict:
    run = get_run(run_id)
    if not run:
        return {"ok": False, "error": "Kosum yok."}
    idx, stage = _stage(run, stage_id)
    if not stage:
        return {"ok": False, "error": "Asama yok."}
    stage["status"] = STATUS_FAILED
    stage["fail_reason"] = reason
    STORE.log("PIPELINE", "Asama basarisiz: %s (%s)" % (stage["name"], reason),
              run_id=run_id)
    evaluate(run)
    return {"ok": True, "run": run}


def run_identity_report(run_id: str) -> Dict:
    """Kosumdaki tum taleplerin scriptlerini karsilastirir."""
    run = get_run(run_id)
    if not run:
        return {"ok": False, "error": "Kosum yok."}
    items = []
    seen = set()
    for s in run["stages"]:
        no = s.get("talep_no")
        if not no or no in seen:
            continue
        seen.add(no)
        t = STORE.get_talep(no)
        if not t:
            continue
        items.append({"label": "%s (%s)" % (no, t.get("env", "")),
                      "ref_id": no, "env": t.get("env", ""),
                      "text": t.get("script", "")})
    if not items:
        return {"ok": True, "identical": True, "rows": [],
                "message": "Henuz talep baglanmadi."}
    res = compare.compare_many(items)
    res["ok"] = True
    return res
