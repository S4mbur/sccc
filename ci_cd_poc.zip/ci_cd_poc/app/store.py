# -*- coding: utf-8 -*-
"""Thread-safe JSON store used by the POC.

Passwords are deliberately not part of this store. Database profiles only
contain connection metadata; secrets live in process memory or environment
variables and therefore never end up in ``data/state.json``.
"""
from __future__ import annotations

import io
import hashlib
import json
import os
import threading
import time
from collections import OrderedDict

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "data")
STATE_FILE = os.path.join(DATA_DIR, "state.json")


def _now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


class Store(object):
    def __init__(self):
        self.lock = threading.RLock()
        self.talepler = OrderedDict()      # talep_no -> talep
        self.orkestra_requests = OrderedDict()
        self.operation_pipelines = OrderedDict()
        self.operation_requests = OrderedDict()
        self.octopus_releases = OrderedDict()
        self.deployments = OrderedDict()   # dep_id  -> deployment
        self.runs = OrderedDict()          # run_id  -> pipeline kosumu
        self.databases = OrderedDict()     # profile_id -> public DB metadata
        self.targets = OrderedDict()       # target_id -> env alias -> DB profile
        self.db_executions = []            # newest first, bounded audit trail
        self.events = []                   # olay gunlugu
        self.counters = {"talep": 0, "orkestra": 0, "promotion": 0,
                         "octopus_release": 0, "dep": 0, "run": 0,
                         "db": 0, "target": 0, "dbexec": 0,
                         "operation_pipeline": 0, "operation_request": 0}
        self.settings = {
            "orkestra_mode": "MOCK", "orkestra_url": "",
            "orkestra_token": "",
            "octopus_mode": "MOCK", "octopus_url": "", "octopus_key": "",
            "octopus_project": "OracleDeploy",
            # Kural override'lari: {"ORA020": {"enabled": true}}
            "rule_overrides": {},
            # None: motor varsayilanlari, []: hicbir kural, [id...]: tam secim
            "selected_rule_ids": None,
            # Kapi politikasi: PASS_ONLY | ALLOW_WARN
            "gate_policy": "PASS_ONLY",
            "require_identical": True,
            "require_octopus_ref": True,
        }
        os.makedirs(DATA_DIR, exist_ok=True)

    # ------------------------------------------------------------- kayit
    def log(self, kind, message, **extra):
        with self.lock:
            ev = {"at": _now(), "kind": kind, "message": message}
            ev.update(extra)
            self.events.insert(0, ev)
            del self.events[500:]
            return ev

    # ------------------------------------------------------------ talep
    def next_talep_no(self, prefix="CHG"):
        with self.lock:
            self.counters["talep"] += 1
            return "%s-%s-%04d" % (prefix, time.strftime("%Y"),
                                   self.counters["talep"])

    def create_talep(self, env, title, script, script_name="01-degisiklik.sql",
                     owner="", talep_no=None, octopus_ref="",
                     pipeline_id="", run_id="", target_id="",
                     pipeline_type="", promotion_id="",
                     external_request_id="", octopus_code=""):
        with self.lock:
            no = talep_no or self.next_talep_no()
            t = {
                "talep_no": no,
                "env": env,
                "title": title,
                "owner": owner or "RUNNER",
                "script": script,
                "script_name": script_name,
                "octopus_ref": octopus_ref,
                "octopus_code": octopus_code,
                "pipeline_id": pipeline_id,
                "pipeline_type": pipeline_type or pipeline_id,
                "run_id": run_id,
                "target_id": target_id,
                "promotion_id": promotion_id,
                "external_request_id": external_request_id,
                "status": "ACIK",
                "result": "",
                "created_at": _now(),
                "notes": [],
                "validation": None,
            }
            self.talepler[no] = t
            self.log("TALEP", "Talep olusturuldu: %s (%s)" % (no, env),
                     talep_no=no, env=env)
            return t

    def get_talep(self, no):
        return self.talepler.get(no)

    # ---------------------------------------------------------- Orkestra
    def create_orkestra_request(self, data, environment_sequence):
        data = dict(data or {})
        sequence = [str(value).upper() for value in environment_sequence or []]
        environment = str(data.get("environment") or "").strip().upper()
        pipeline_type = str(data.get("pipeline_type") or "").strip()
        title = str(data.get("title") or "").strip()
        script = str(data.get("script") or "")
        if environment not in sequence:
            return {"ok": False,
                    "error": "Bu pipeline için geçerli ortam sırası: %s" %
                             " -> ".join(sequence)}
        if not pipeline_type or not title or not script.strip():
            return {"ok": False,
                    "error": "Pipeline tipi, başlık ve script zorunlu."}

        index = sequence.index(environment)
        previous = None
        previous_id = str(data.get("previous_request_id") or "").strip()
        if index:
            previous = self.orkestra_requests.get(previous_id)
            expected = sequence[index - 1]
            if not previous:
                return {"ok": False,
                        "error": "%s talebi için tamamlanmış %s talebi seçin." %
                                 (environment, expected)}
            if previous.get("environment") != expected or \
                    previous.get("pipeline_type") != pipeline_type:
                return {"ok": False,
                        "error": "Önceki talep aynı pipeline'ın %s adımı olmalı." %
                                 expected}
            if previous.get("status") != "COMPLETED":
                return {"ok": False,
                        "error": "Önceki %s talebi tamamlanmadan %s açılamaz." %
                                 (expected, environment)}
            previous_hash = previous.get("script_sha256") or ""
            current_hash = hashlib.sha256(script.encode("utf-8")).hexdigest()
            if previous_hash != current_hash:
                return {"ok": False,
                        "error": "Ortam terfisinde script birebir aynı olmalı."}

        with self.lock:
            self.counters["orkestra"] += 1
            request_id = "ORK-%s-%04d" % (
                time.strftime("%Y"), self.counters["orkestra"])
            if previous:
                promotion_id = previous.get("promotion_id", "")
            else:
                self.counters["promotion"] += 1
                promotion_id = "PROM-%s-%04d" % (
                    time.strftime("%Y"), self.counters["promotion"])
            duplicate = next((item for item in self.orkestra_requests.values()
                              if item.get("promotion_id") == promotion_id and
                              item.get("environment") == environment and
                              item.get("status") != "REJECTED"), None)
            if duplicate:
                return {"ok": False,
                        "error": "%s için bu promotion zincirinde zaten %s var." %
                                 (environment, duplicate.get("id"))}
            request = {
                "id": request_id,
                "promotion_id": promotion_id,
                "previous_request_id": previous_id,
                "previous_deployment_id": (previous or {}).get(
                    "successful_deployment_id", ""),
                "environment": environment,
                "pipeline_type": pipeline_type,
                "title": title,
                "owner": str(data.get("owner") or "RUNNER").strip(),
                "script": script,
                "script_name": str(data.get("script_name") or
                                   "01-change.sql").strip(),
                "script_sha256": hashlib.sha256(
                    script.encode("utf-8")).hexdigest(),
                "status": "PENDING",
                "local_talep_no": "",
                "run_id": "",
                "octopus_code": "",
                "accepted_by": "",
                "accepted_at": "",
                "completed_by": "",
                "completed_at": "",
                "rejected_by": "",
                "rejected_at": "",
                "rejection_reason": "",
                "created_at": _now(),
                "notes": [],
            }
            self.orkestra_requests[request_id] = request
            self.log("ORKESTRA", "Gelen talep oluşturuldu: %s (%s)" %
                     (request_id, environment), request_id=request_id,
                     promotion_id=promotion_id)
            return {"ok": True, "request": request}

    def accept_orkestra_request(self, request_id, actor, talep_no, run_id,
                                octopus_code):
        with self.lock:
            request = self.orkestra_requests.get(request_id)
            if not request:
                return {"ok": False, "error": "Orkestra talebi bulunamadı."}
            if request.get("status") != "PENDING":
                return {"ok": False, "error": "Yalnız bekleyen talep kabul edilebilir."}
            request.update({
                "status": "ACCEPTED", "accepted_by": actor,
                "accepted_at": _now(), "local_talep_no": talep_no,
                "run_id": run_id, "octopus_code": octopus_code,
            })
            self.log("ORKESTRA", "%s kabul edildi." % request_id,
                     request_id=request_id, run_id=run_id, talep_no=talep_no)
            return {"ok": True, "request": request}

    def reject_orkestra_request(self, request_id, actor, reason=""):
        with self.lock:
            request = self.orkestra_requests.get(request_id)
            if not request:
                return {"ok": False, "error": "Orkestra talebi bulunamadı."}
            if request.get("status") != "PENDING":
                return {"ok": False, "error": "Yalnız bekleyen talep reddedilebilir."}
            request.update({
                "status": "REJECTED", "rejected_by": actor,
                "rejected_at": _now(), "rejection_reason": reason,
            })
            self.log("ORKESTRA", "%s reddedildi: %s" % (request_id, reason),
                     request_id=request_id)
            return {"ok": True, "request": request}

    def complete_orkestra_request(self, request_id, actor):
        with self.lock:
            request = self.orkestra_requests.get(request_id)
            if not request:
                return {"ok": False, "error": "Orkestra talebi bulunamadı."}
            if request.get("status") != "ACCEPTED":
                return {"ok": False, "error": "Yalnız kabul edilmiş talep tamamlanabilir."}
            talep_no = request.get("local_talep_no")
            successful = [item for item in self.deployments.values()
                          if item.get("talep_no") == talep_no and
                          item.get("state") == "Success"]
            release = self.octopus_releases.get(request.get("octopus_code")) or {}
            if not successful and release.get("state") != "Success":
                return {"ok": False,
                        "error": "Talep için başarılı Oracle/Octopus kanıtı bulunamadı."}
            evidence = successful[-1].get("id") if successful else release.get("code")
            request.update({
                "status": "COMPLETED", "completed_by": actor,
                "completed_at": _now(), "successful_deployment_id": evidence,
            })
            self.log("ORKESTRA", "%s tamamlandı: %s" % (request_id, evidence),
                     request_id=request_id, deployment_id=evidence)
            return {"ok": True, "request": request}

    # ----------------------------------------------------------- Octopus
    def reserve_octopus_release(self, env, pipeline_type, request_id,
                                project="OracleDeploy"):
        with self.lock:
            self.counters["octopus_release"] += 1
            code = "OCT-%s-%04d" % (
                time.strftime("%Y%m"), self.counters["octopus_release"])
            release = {
                "code": code, "environment": env,
                "pipeline_type": pipeline_type, "request_id": request_id,
                "project": project, "state": "Reserved", "detail": "",
                "created_at": _now(), "completed_at": "",
            }
            self.octopus_releases[code] = release
            self.log("OCTOPUS", "Release kodu ayrıldı: %s" % code,
                     request_id=request_id, octopus_code=code)
            return {"ok": True, "release": release}

    def set_octopus_release_result(self, code, success, detail=""):
        with self.lock:
            release = self.octopus_releases.get(code)
            if not release:
                return {"ok": False, "error": "Octopus release bulunamadı."}
            release["state"] = "Success" if success else "Failed"
            release["detail"] = detail
            release["completed_at"] = _now()
            self.log("OCTOPUS", "%s sonucu: %s" % (code, release["state"]),
                     octopus_code=code)
            return {"ok": True, "release": release}

    # -------------------------------------------------------- deployment
    def create_deployment(self, env, project, script_sha, talep_no,
                          octopus_code=""):
        with self.lock:
            self.counters["dep"] += 1
            dep_id = "Deployments-%d" % (1000 + self.counters["dep"])
            rel = "%s.%d" % (time.strftime("%Y.%m"), self.counters["dep"])
            d = {
                "id": dep_id,
                "release": rel,
                "environment": env,
                "project": project,
                "script_sha256": script_sha,
                "talep_no": talep_no,
                "octopus_code": octopus_code,
                "state": "Executing",
                "detail": "",
                "created_at": _now(),
                "completed_at": "",
            }
            self.deployments[dep_id] = d
            if octopus_code in self.octopus_releases:
                self.octopus_releases[octopus_code]["state"] = "Executing"
                self.octopus_releases[octopus_code]["deployment_id"] = dep_id
            self.log("OCTOPUS",
                     "Deployment olusturuldu: %s (%s / release %s)"
                     % (dep_id, env, rel), deployment_id=dep_id, env=env)
            return {"ok": True, "deployment": d}

    def create_database_deployment(self, env, profile, script_sha, talep_no,
                                   execution, target=None, octopus_code=""):
        """Create a deployment record backed by a real Oracle execution."""
        with self.lock:
            self.counters["dep"] += 1
            dep_id = "DBDeployments-%d" % (1000 + self.counters["dep"])
            ok = bool((execution or {}).get("ok"))
            d = {
                "id": dep_id,
                "release": "DB.%s.%d" % (time.strftime("%Y%m%d"),
                                           self.counters["dep"]),
                "environment": env,
                "project": "Oracle direct execution",
                "executor": "DATABASE",
                "database_profile_id": (profile or {}).get("id", ""),
                "database_name": (profile or {}).get("name", ""),
                "target_id": (target or {}).get("id", ""),
                "target_name": (target or {}).get("name", ""),
                "script_sha256": script_sha,
                "talep_no": talep_no,
                "state": "Success" if ok else "Failed",
                "detail": (execution or {}).get("message", ""),
                "execution_id": (execution or {}).get("id", ""),
                "created_at": _now(),
                "completed_at": _now(),
            }
            self.deployments[dep_id] = d
            local_request = self.talepler.get(talep_no) or {}
            octopus_code = octopus_code or local_request.get("octopus_code", "")
            if octopus_code in self.octopus_releases:
                release = self.octopus_releases[octopus_code]
                release["state"] = d["state"]
                release["deployment_id"] = dep_id
                release["detail"] = d["detail"]
                release["completed_at"] = d["completed_at"]
            self.log("DATABASE", "Database deployment: %s (%s / %s)" %
                     (dep_id, env, d["state"]), deployment_id=dep_id,
                     env=env)
            return {"ok": ok, "deployment": d}

    def record_db_execution(self, record):
        with self.lock:
            self.counters["dbexec"] += 1
            item = dict(record or {})
            item.setdefault("id", "DBEXEC-%05d" % self.counters["dbexec"])
            item.setdefault("created_at", _now())
            self.db_executions.insert(0, item)
            del self.db_executions[200:]
            return item

    # ------------------------------------------------------------- kosum
    def next_run_id(self):
        with self.lock:
            self.counters["run"] += 1
            return "RUN-%04d" % self.counters["run"]

    # -------------------------------------------------------- kalicilik
    def to_dict(self):
        return {
            "talepler": self.talepler,
            "orkestra_requests": self.orkestra_requests,
            "operation_pipelines": self.operation_pipelines,
            "operation_requests": self.operation_requests,
            "octopus_releases": self.octopus_releases,
            "deployments": self.deployments,
            "runs": self.runs, "databases": self.databases,
            "targets": self.targets,
            "db_executions": self.db_executions[:200],
            "events": self.events[:200],
            "counters": self.counters, "settings": self.settings,
        }

    def save(self):
        with self.lock:
            try:
                with io.open(STATE_FILE, "w", encoding="utf-8") as f:
                    json.dump(self.to_dict(), f, ensure_ascii=False, indent=1)
                return True
            except Exception:                                # noqa: BLE001
                return False

    def load(self):
        if not os.path.exists(STATE_FILE):
            return False
        try:
            with io.open(STATE_FILE, encoding="utf-8") as f:
                d = json.load(f)
        except Exception:                                    # noqa: BLE001
            return False
        with self.lock:
            self.talepler = OrderedDict(d.get("talepler") or {})
            self.orkestra_requests = OrderedDict(
                d.get("orkestra_requests") or {})
            self.operation_pipelines = OrderedDict(
                d.get("operation_pipelines") or {})
            self.operation_requests = OrderedDict(
                d.get("operation_requests") or {})
            self.octopus_releases = OrderedDict(
                d.get("octopus_releases") or {})
            self.deployments = OrderedDict(d.get("deployments") or {})
            self.runs = OrderedDict(d.get("runs") or {})
            self.databases = OrderedDict(d.get("databases") or {})
            self.targets = OrderedDict(d.get("targets") or {})
            self.db_executions = d.get("db_executions") or []
            self.events = d.get("events") or []
            self.counters.update(d.get("counters") or {})
            self.settings.update(d.get("settings") or {})
            if "talep_mode" in self.settings and "orkestra_mode" not in d.get("settings", {}):
                self.settings["orkestra_mode"] = self.settings.get("talep_mode", "MOCK")
                self.settings["orkestra_url"] = self.settings.get("talep_url", "")
                self.settings["orkestra_token"] = self.settings.get("talep_token", "")
            for request in self.talepler.values():
                request.setdefault("pipeline_type", request.get("pipeline_id", ""))
                request.setdefault("promotion_id", "")
                request.setdefault("external_request_id", "")
                request.setdefault("octopus_code", "")
        return True

    def reset(self, keep_connections=True):
        with self.lock:
            self.talepler.clear()
            self.orkestra_requests.clear()
            self.operation_pipelines.clear()
            self.operation_requests.clear()
            self.octopus_releases.clear()
            self.deployments.clear()
            self.runs.clear()
            self.db_executions = []
            if not keep_connections:
                self.databases.clear()
                self.targets.clear()
            self.events = []
            self.counters.update({"talep": 0, "orkestra": 0,
                                  "promotion": 0, "octopus_release": 0,
                                  "dep": 0, "run": 0, "dbexec": 0,
                                  "operation_pipeline": 0,
                                  "operation_request": 0})
            if not keep_connections:
                self.counters["db"] = 0
                self.counters["target"] = 0
            self.log("SISTEM", "Tum POC verisi sifirlandi.")


STORE = Store()
