# -*- coding: utf-8 -*-
"""Simple operations workflow for database-bound script requests."""
from __future__ import annotations

import hashlib
import time


def _now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


class OperationsService(object):
    """Manage ordered database pipelines and one-click script approvals."""

    def __init__(self, store, database_manager, octopus_factory):
        self.store = store
        self.databases = database_manager
        self.octopus_factory = octopus_factory

    def public_pipeline(self, pipeline):
        item = dict(pipeline or {})
        steps = []
        for position, database_id in enumerate(
                item.get("database_ids") or [], start=1):
            profile = self.store.databases.get(database_id)
            steps.append({
                "position": position,
                "database_id": database_id,
                "database_name": (profile or {}).get(
                    "name", "Bağlantı bulunamadı"),
                "available": bool(profile),
            })
        item["steps"] = steps
        item["sequence_label"] = " -> ".join(
            step["database_name"] for step in steps)
        item["available"] = bool(steps) and all(
            step["available"] for step in steps)
        return item

    def list_pipelines(self):
        return [self.public_pipeline(item)
                for item in self.store.operation_pipelines.values()]

    def save_pipeline(self, data, actor="RUNNER"):
        data = dict(data or {})
        name = str(data.get("name") or "").strip()
        description = str(data.get("description") or "").strip()
        database_ids = [str(value or "").strip()
                        for value in data.get("database_ids") or []]
        database_ids = [value for value in database_ids if value]
        pipeline_id = str(data.get("id") or "").strip()
        if not name:
            return {"ok": False, "error": "Pipeline adı zorunlu."}
        if not database_ids:
            return {"ok": False,
                    "error": "Pipeline'a en az bir veritabanı ekleyin."}
        if len(database_ids) != len(set(database_ids)):
            return {"ok": False,
                    "error": "Aynı veritabanı pipeline'da bir kez kullanılabilir."}
        missing = [value for value in database_ids
                   if value not in self.store.databases]
        if missing:
            return {"ok": False,
                    "error": "Pipeline'daki bir veritabanı bulunamadı: %s" %
                             ", ".join(missing)}

        with self.store.lock:
            duplicate = next((item for item in
                              self.store.operation_pipelines.values()
                              if item.get("name", "").casefold() ==
                              name.casefold() and item.get("id") != pipeline_id),
                             None)
            if duplicate:
                return {"ok": False,
                        "error": "Bu adla bir pipeline zaten var."}
            old = self.store.operation_pipelines.get(pipeline_id) or {}
            if pipeline_id and not old:
                return {"ok": False, "error": "Pipeline bulunamadı."}
            active = next((item for item in
                           self.store.operation_requests.values()
                           if item.get("pipeline_id") == pipeline_id and
                           item.get("status") in ("PENDING", "EXECUTING")),
                          None)
            if old and active and old.get("database_ids") != database_ids:
                return {"ok": False,
                        "error": "Pipeline sırası bekleyen talep varken "
                                 "değiştirilemez: %s" % active.get("id")}
            if not pipeline_id:
                self.store.counters["operation_pipeline"] += 1
                pipeline_id = "OPP-%04d" % self.store.counters[
                    "operation_pipeline"]
            pipeline = {
                "id": pipeline_id,
                "name": name,
                "description": description,
                "database_ids": database_ids,
                "created_by": old.get("created_by") or actor,
                "created_at": old.get("created_at") or _now(),
                "updated_by": actor,
                "updated_at": _now(),
            }
            self.store.operation_pipelines[pipeline_id] = pipeline
            self.store.log(
                "OPERATION_PIPELINE",
                "Pipeline kaydedildi: %s (%s)" %
                (name, " -> ".join(database_ids)),
                pipeline_id=pipeline_id)
            self.store.save()
            return {"ok": True,
                    "pipeline": self.public_pipeline(pipeline)}

    def delete_pipeline(self, pipeline_id):
        with self.store.lock:
            pipeline = self.store.operation_pipelines.get(pipeline_id)
            if not pipeline:
                return {"ok": False, "error": "Pipeline bulunamadı."}
            active = next((item for item in
                           self.store.operation_requests.values()
                           if item.get("pipeline_id") == pipeline_id and
                           item.get("status") in ("PENDING", "EXECUTING")),
                          None)
            if active:
                return {"ok": False,
                        "error": "Pipeline bekleyen bir talepte kullanılıyor: %s" %
                                 active.get("id")}
            self.store.operation_pipelines.pop(pipeline_id, None)
            self.store.log("OPERATION_PIPELINE",
                           "Pipeline silindi: %s" % pipeline.get("name"),
                           pipeline_id=pipeline_id)
            self.store.save()
            return {"ok": True}

    def list_requests(self):
        return list(self.store.operation_requests.values())

    def create_request(self, data, actor="RUNNER", source="ORKESTRA_MOCK"):
        data = dict(data or {})
        pipeline_id = str(data.get("pipeline_id") or "").strip()
        database_id = str(data.get("database_id") or "").strip()
        title = str(data.get("title") or "").strip()
        script = str(data.get("script") or "")
        pipeline = self.store.operation_pipelines.get(pipeline_id)
        profile = self.store.databases.get(database_id)
        if not pipeline:
            return {"ok": False, "error": "Geçerli bir pipeline seçin."}
        if database_id not in pipeline.get("database_ids", []):
            return {"ok": False,
                    "error": "Talep veritabanı seçilen pipeline'da bulunmuyor."}
        if not profile:
            return {"ok": False, "error": "Veritabanı bulunamadı."}
        if not title or not script.strip():
            return {"ok": False,
                    "error": "Talep başlığı ve script zorunlu."}

        with self.store.lock:
            self.store.counters["operation_request"] += 1
            request_id = "REQ-%s-%04d" % (
                time.strftime("%Y"),
                self.store.counters["operation_request"])
            step_index = pipeline["database_ids"].index(database_id)
            request = {
                "id": request_id,
                "title": title,
                "owner": str(data.get("owner") or actor or "RUNNER").strip(),
                "pipeline_id": pipeline_id,
                "pipeline_name": pipeline.get("name", ""),
                "database_id": database_id,
                "database_name": profile.get("name", ""),
                "step_index": step_index,
                "step_number": step_index + 1,
                "step_count": len(pipeline.get("database_ids") or []),
                "script_name": str(data.get("script_name") or
                                   "01-change.sql").strip(),
                "script": script,
                "script_sha256": hashlib.sha256(
                    script.encode("utf-8")).hexdigest(),
                "source": source,
                "status": "PENDING",
                "approved_by": "",
                "approved_at": "",
                "completed_at": "",
                "execution_id": "",
                "deployment_id": "",
                "octopus_code": "",
                "result_message": "",
                "error": "",
                "created_at": _now(),
            }
            self.store.operation_requests[request_id] = request
            self.store.log(
                "OPERATION_REQUEST",
                "Script talebi geldi: %s -> %s" %
                (request_id, profile.get("name")),
                request_id=request_id, pipeline_id=pipeline_id,
                database_id=database_id)
            self.store.save()
            return {"ok": True, "request": request}

    def approve_request(self, request_id, actor="RUNNER"):
        with self.store.lock:
            request = self.store.operation_requests.get(request_id)
            if not request:
                return {"ok": False, "error": "Script talebi bulunamadı."}
            if request.get("status") != "PENDING":
                return {"ok": False,
                        "error": "Yalnız bekleyen bir talep onaylanabilir."}
            profile = self.store.databases.get(request.get("database_id"))
            pipeline = self.store.operation_pipelines.get(
                request.get("pipeline_id"))
            if not profile:
                return {"ok": False,
                        "error": "Talebin veritabanı bağlantısı bulunamadı."}
            if not pipeline or request.get("database_id") not in \
                    pipeline.get("database_ids", []):
                return {"ok": False,
                        "error": "Talebin pipeline bağlantısı artık geçerli değil."}
            public_profile = self.databases.public_profile(profile)
            if not public_profile.get("secret_available"):
                return {"ok": False,
                        "error": "Veritabanı parolası oturumda hazır değil. "
                                 "Veritabanları ekranından parolayı yükleyip "
                                 "bağlantıyı test edin."}
            if not profile.get("allow_execute"):
                return {"ok": False,
                        "error": "Bu veritabanı script çalıştırmaya kapalı."}
            request.update({
                "status": "EXECUTING",
                "approved_by": actor,
                "approved_at": _now(),
                "error": "",
            })
            self.store.save()

        octopus = self.octopus_factory()
        release_result = octopus.reserve_release(
            profile.get("name", ""), request.get("pipeline_id", ""),
            request_id, self.store.settings.get(
                "octopus_project", "OracleDeploy"))
        release = release_result.get("release") or {}
        octopus_code = release.get("code") or release.get("Id") or ""
        integration_warning = "" if release_result.get("ok") else \
            release_result.get("error", "Octopus release ayrılamadı.")
        request["octopus_code"] = octopus_code
        self.store.save()

        try:
            execution = self.databases.execute(
                request["database_id"], request["script"],
                request["script_name"], selected_rule_ids=[],
                gate_policy="PASS_ONLY", transaction_mode="SCRIPT",
                environment="OPERATION")
        except Exception as exc:  # noqa: BLE001
            execution = {"ok": False, "id": "", "message": "",
                         "error": "%s: %s" % (type(exc).__name__, exc)}

        deployment_result = self.store.create_database_deployment(
            profile.get("name", ""), profile,
            request.get("script_sha256", ""), request_id, execution,
            octopus_code=octopus_code)
        deployment = deployment_result.get("deployment") or {}
        if octopus_code:
            octopus.set_release_result(
                octopus_code, bool(execution.get("ok")),
                execution.get("message") or execution.get("error") or "")
            stored_release = self.store.octopus_releases.get(octopus_code)
            if stored_release:
                stored_release["deployment_id"] = deployment.get("id", "")

        with self.store.lock:
            request.update({
                "status": "SUCCESS" if execution.get("ok") else "FAILED",
                "completed_at": _now(),
                "execution_id": execution.get("id", ""),
                "deployment_id": deployment.get("id", ""),
                "result_message": execution.get("message", ""),
                "error": execution.get("error", ""),
                "integration_warning": integration_warning,
            })
            self.store.log(
                "OPERATION_APPROVAL",
                "%s onaylandı ve %s sonucuyla tamamlandı." %
                (request_id, request["status"]),
                request_id=request_id, database_id=request["database_id"],
                execution_id=request["execution_id"])
            self.store.save()
        return {"ok": True, "execution_ok": bool(execution.get("ok")),
                "request": request, "execution": execution,
                "deployment": deployment, "release": release}
