# -*- coding: utf-8 -*-
"""Oracle database profiles and execution service.

The module intentionally keeps credentials out of the JSON store. A password
can be supplied for a request, cached only for the current Python process, or
read from the environment variable configured on the profile.

``python-oracledb`` is imported lazily so the rest of the POC and its static
validator continue to work on machines where the Oracle driver is not yet
installed.
"""
from __future__ import annotations

import datetime as _datetime
import decimal
import hashlib
import importlib
import os
import re
import time
from typing import Dict, List, Optional

import inventory
import validator_api
from store import STORE


class DatabaseServiceError(RuntimeError):
    pass


def _now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _slug(value):
    out = re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-")
    return out[:40] or "oracle"


def _json_value(value):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (decimal.Decimal,)):
        return str(value)
    if isinstance(value, (_datetime.date, _datetime.datetime, _datetime.time)):
        return value.isoformat()
    if isinstance(value, bytes):
        return value.hex()
    if hasattr(value, "read"):
        try:
            return value.read()
        except Exception:  # noqa: BLE001
            pass
    return str(value)


class DatabaseManager(object):
    """Manages many Oracle targets and exposes a small action registry."""

    ACTIONS = [
        {"id": "TEST", "name": "Bağlantıyı test et",
         "description": "Oturum açar ve veritabanı kimliğini okur.",
         "needs_script": False, "mutates": False},
        {"id": "CONTEXT", "name": "Oturum bağlamını oku",
         "description": "Database, container, şema ve session kullanıcısını gösterir.",
         "needs_script": False, "mutates": False},
        {"id": "INVENTORY", "name": "Şema envanterini getir",
         "description": "Kullanıcının objelerini tip bazında sayar.",
         "needs_script": False, "mutates": False},
        {"id": "QUERY", "name": "Salt-okunur sorgu çalıştır",
         "description": "SELECT, SELECT DISTINCT veya WITH sorgusunu en fazla 200 satırla çalıştırır.",
         "needs_script": True, "mutates": False},
        {"id": "PREFLIGHT", "name": "Canlı katalogla doğrula",
         "description": "Oracle metadata'sını okuyup ORA250-252 preflight kurallarına verir.",
         "needs_script": True, "mutates": False},
        {"id": "PREVIEW", "name": "Çalıştırma planı oluştur",
         "description": "Bağlantı açmadan çalıştırılacak ifadeleri listeler.",
         "needs_script": True, "mutates": False},
        {"id": "EXECUTE", "name": "Scripti çalıştır",
         "description": "Validator kapısından sonra ifadeleri Oracle üzerinde sırayla çalıştırır.",
         "needs_script": True, "mutates": True},
    ]

    def __init__(self, store=None, driver=None):
        self.store = store or STORE
        self._driver = driver
        self._driver_error = ""
        self._secrets = {}

    # ------------------------------------------------------------- driver
    def _load_driver(self):
        if self._driver is not None:
            return self._driver
        if self._driver_error:
            return None
        try:
            self._driver = importlib.import_module("oracledb")
        except Exception as exc:  # noqa: BLE001
            self._driver_error = "%s: %s" % (type(exc).__name__, exc)
        return self._driver

    def driver_info(self):
        driver = self._load_driver()
        if not driver:
            return {
                "installed": False,
                "name": "python-oracledb",
                "install": "python -m pip install -r requirements.txt",
                "detail": self._driver_error or "Sürücü bulunamadı.",
            }
        return {
            "installed": True,
            "name": "python-oracledb",
            "version": getattr(driver, "__version__", "unknown"),
            "mode": "thin",
        }

    # ------------------------------------------------------------ profile
    def public_profile(self, profile):
        if not profile:
            return None
        out = {k: v for k, v in profile.items()
               if k not in ("password", "secret")}
        out["secret_available"] = bool(
            self._secrets.get(out.get("id")) or
            (out.get("password_env") and os.environ.get(out["password_env"])))
        out["dsn_preview"] = self.build_dsn(out)
        out["target_count"] = sum(
            1 for target in self.store.targets.values()
            if target.get("database_profile_id") == out.get("id"))
        return out

    def list_profiles(self):
        return [self.public_profile(p) for p in self.store.databases.values()]

    def save_profile(self, data):
        data = dict(data or {})
        name = str(data.get("name") or "").strip()
        if not name:
            return {"ok": False, "error": "Bağlantı adı zorunlu."}
        pid = str(data.get("id") or "").strip()
        if not pid:
            base = "db-%s" % _slug(name)
            pid = base
            suffix = 2
            while pid in self.store.databases:
                pid = "%s-%d" % (base, suffix)
                suffix += 1

        host = str(data.get("host") or "").strip()
        service = str(data.get("service_name") or "").strip()
        connect_string = str(data.get("connect_string") or "").strip()
        username = str(data.get("username") or "").strip()
        if not connect_string and (not host or not service):
            return {"ok": False,
                    "error": "Host ve servis adı veya doğrudan bağlantı dizesi zorunlu."}
        if not username:
            return {"ok": False, "error": "Kullanıcı adı zorunlu."}
        try:
            port = int(data.get("port") or 1521)
        except (TypeError, ValueError):
            return {"ok": False, "error": "Port sayısal olmalı."}
        if port < 1 or port > 65535:
            return {"ok": False, "error": "Port 1-65535 aralığında olmalı."}

        old = self.store.databases.get(pid) or {}
        profile = {
            "id": pid,
            "name": name,
            # Environment belongs to deployment targets. Keep the legacy field
            # for old state files and direct API callers.
            "environment": str(data.get("environment") or
                               old.get("environment") or "SHARED").upper(),
            "host": host,
            "port": port,
            "service_name": service,
            "connect_string": connect_string,
            "username": username,
            "password_env": str(data.get("password_env") or "").strip(),
            "allow_execute": bool(data.get("allow_execute", False)),
            "call_timeout_seconds": max(1, min(600, int(
                data.get("call_timeout_seconds") or 60))),
            "created_at": old.get("created_at") or _now(),
            "updated_at": _now(),
            "last_test": old.get("last_test"),
        }
        self.store.databases[pid] = profile
        password = data.get("password")
        if password:
            self._secrets[pid] = str(password)
        self.store.log("DATABASE", "DB profili kaydedildi: %s (%s)" %
                       (name, profile["environment"]), profile_id=pid)
        self.store.save()
        return {"ok": True, "profile": self.public_profile(profile)}

    def delete_profile(self, profile_id):
        if profile_id not in self.store.databases:
            return {"ok": False, "error": "DB profili bulunamadı."}
        operation_pipelines = getattr(self.store, "operation_pipelines", {})
        used_by_pipeline = [item.get("name", item.get("id", ""))
                            for item in operation_pipelines.values()
                            if profile_id in item.get("database_ids", [])]
        if used_by_pipeline:
            return {"ok": False,
                    "error": "Bağlantı şu operasyon pipeline'larında "
                             "kullanılıyor: %s" %
                             ", ".join(used_by_pipeline)}
        used_by = [target["name"] for target in self.store.targets.values()
                   if target.get("database_profile_id") == profile_id]
        if used_by:
            return {"ok": False,
                    "error": "Bağlantı şu hedeflerde kullanılıyor: %s. Önce hedefleri kaldırın." %
                             ", ".join(used_by)}
        profile = self.store.databases.pop(profile_id)
        self._secrets.pop(profile_id, None)
        self.store.log("DATABASE", "DB profili silindi: %s" % profile["name"],
                       profile_id=profile_id)
        self.store.save()
        return {"ok": True}

    # ------------------------------------------------------------- targets
    def public_target(self, target):
        if not target:
            return None
        out = dict(target)
        profile = self.store.databases.get(target.get("database_profile_id")) or {}
        out["database_name"] = profile.get("name", "Bağlantı bulunamadı")
        out["username"] = profile.get("username", "")
        out["dsn_preview"] = self.build_dsn(profile) if profile else ""
        out["profile_available"] = bool(profile)
        out["secret_available"] = bool(
            profile and (self._secrets.get(profile.get("id")) or
                         (profile.get("password_env") and
                          os.environ.get(profile["password_env"]))))
        return out

    def list_targets(self):
        return [self.public_target(target)
                for target in self.store.targets.values()]

    def save_target(self, data):
        data = dict(data or {})
        name = str(data.get("name") or "").strip()
        environment = str(data.get("environment") or "").strip().upper()
        profile_id = str(data.get("database_profile_id") or "").strip()
        if not name:
            return {"ok": False, "error": "Hedef adı zorunlu."}
        if environment not in ("DEV", "TEST", "PREPROD", "PROD", "DR"):
            return {"ok": False, "error": "Geçerli bir ortam seçin."}
        if profile_id not in self.store.databases:
            return {"ok": False, "error": "Fiziksel Oracle bağlantısı bulunamadı."}
        target_id = str(data.get("id") or "").strip()
        if not target_id:
            base = "target-%s" % _slug(name)
            target_id = base
            suffix = 2
            while target_id in self.store.targets:
                target_id = "%s-%d" % (base, suffix)
                suffix += 1
        old = self.store.targets.get(target_id) or {}
        target = {
            "id": target_id,
            "name": name,
            "environment": environment,
            "database_profile_id": profile_id,
            "schema": str(data.get("schema") or "").strip().upper(),
            "enabled": bool(data.get("enabled", True)),
            "description": str(data.get("description") or "").strip(),
            "created_at": old.get("created_at") or _now(),
            "updated_at": _now(),
        }
        self.store.targets[target_id] = target
        self.store.log("TARGET", "Deployment hedefi kaydedildi: %s -> %s" %
                       (name, self.store.databases[profile_id]["name"]),
                       target_id=target_id, profile_id=profile_id)
        self.store.save()
        return {"ok": True, "target": self.public_target(target)}

    def delete_target(self, target_id):
        if target_id not in self.store.targets:
            return {"ok": False, "error": "Deployment hedefi bulunamadı."}
        active = [run["id"] for run in self.store.runs.values()
                  if any(stage.get("target_id") == target_id
                         for stage in run.get("stages", []))
                  and run.get("status") not in ("DONE", "FAILED")]
        if active:
            return {"ok": False,
                    "error": "Hedef aktif koşumlarda kullanılıyor: %s" %
                             ", ".join(active)}
        target = self.store.targets.pop(target_id)
        self.store.log("TARGET", "Deployment hedefi silindi: %s" % target["name"],
                       target_id=target_id)
        self.store.save()
        return {"ok": True}

    def seed_environment_targets(self, profile_id, prefix="Örnek"):
        profile = self.store.databases.get(profile_id)
        if not profile:
            return {"ok": False, "error": "Oracle bağlantısı bulunamadı."}
        created = []
        for environment in ("TEST", "PREPROD", "PROD"):
            existing = next((target for target in self.store.targets.values()
                             if target.get("database_profile_id") == profile_id and
                             target.get("environment") == environment), None)
            if existing:
                created.append(self.public_target(existing))
                continue
            result = self.save_target({
                "name": "%s %s" % (prefix or profile["name"], environment),
                "environment": environment,
                "database_profile_id": profile_id,
                "schema": profile.get("username", ""),
                "description": ("POC topoloji hedefi. Aynı fiziksel bağlantıyı "
                                "%s ortamı olarak temsil eder." % environment),
                "enabled": True,
            })
            if not result.get("ok"):
                return result
            created.append(result["target"])
        return {"ok": True, "targets": created,
                "warning": "Üç hedef aynı fiziksel Oracle bağlantısını kullanıyor. Bu yalnız POC/simülasyon içindir."}

    def build_dsn(self, profile):
        if (profile or {}).get("connect_string"):
            return profile["connect_string"]
        return "%s:%s/%s" % (profile.get("host", ""),
                              profile.get("port", 1521),
                              profile.get("service_name", ""))

    def _password(self, profile, supplied=""):
        pid = profile["id"]
        if supplied:
            self._secrets[pid] = str(supplied)
        value = self._secrets.get(pid)
        if not value and profile.get("password_env"):
            value = os.environ.get(profile["password_env"])
        if not value:
            raise DatabaseServiceError(
                "Parola yok. Bu istek için parola girin veya profile bir parola ortam değişkeni tanımlayın.")
        return value

    def connect(self, profile_id, password="", current_schema=""):
        profile = self.store.databases.get(profile_id)
        if not profile:
            raise DatabaseServiceError("DB profili bulunamadı: %s" % profile_id)
        driver = self._load_driver()
        if not driver:
            raise DatabaseServiceError(
                "python-oracledb kurulu değil. requirements.txt bağımlılıklarını kurun.")
        conn = driver.connect(user=profile["username"],
                              password=self._password(profile, password),
                              dsn=self.build_dsn(profile))
        try:
            conn.call_timeout = int(profile.get("call_timeout_seconds", 60)) * 1000
        except Exception:  # noqa: BLE001
            pass
        schema = str(current_schema or "").strip().upper()
        if schema:
            if not re.match(r"^[A-Z][A-Z0-9_$#]{0,127}$", schema):
                conn.close()
                raise DatabaseServiceError("Geçersiz hedef şema adı.")
            cursor = conn.cursor()
            cursor.execute("ALTER SESSION SET CURRENT_SCHEMA = %s" % schema)
            cursor.close()
        return profile, conn

    # --------------------------------------------------------------- plan
    @staticmethod
    def statement_plan(script, script_name="01-change.sql"):
        ctx = validator_api.build_context(script, script_name)
        items = []
        for st in ctx.statements:
            raw = st.raw.strip()
            verb = st.first_word or "?"
            if st.kind == "sqlplus":
                action = "CLIENT"
                executable = False
                sql = ""
            else:
                action = inventory.VERB_CLASS.get(verb, "PLSQL" if
                                                   st.kind == "plsql" else "OTHER")
                executable = True
                sql = raw
                if st.kind == "plsql":
                    sql = re.sub(r"\n\s*/\s*$", "", sql).strip()
                elif sql.endswith(";"):
                    sql = sql[:-1].rstrip()
            items.append({
                "index": st.index + 1,
                "line": st.start_line,
                "end_line": st.end_line,
                "verb": verb,
                "kind": st.kind,
                "action": action,
                "executable": executable,
                "sql": sql,
                "preview": re.sub(r"\s+", " ", raw)[:180],
            })
        return items

    # -------------------------------------------------------------- reads
    @staticmethod
    def _rows(cursor, limit=100):
        description = cursor.description or []
        columns = [getattr(col, "name", None) or col[0] for col in description]
        rows = []
        for row in cursor.fetchmany(limit):
            rows.append([_json_value(v) for v in row])
        return {"columns": columns, "rows": rows, "limit": limit,
                "truncated": len(rows) >= limit}

    def test(self, profile_id, password="", current_schema=""):
        started = time.time()
        try:
            profile, conn = self.connect(profile_id, password, current_schema)
            cur = conn.cursor()
            cur.execute(
                "SELECT SYS_CONTEXT('USERENV','DB_NAME'), "
                "SYS_CONTEXT('USERENV','CON_NAME'), "
                "SYS_CONTEXT('USERENV','CURRENT_SCHEMA') FROM dual")
            row = cur.fetchone()
            result = {
                "ok": True,
                "database": _json_value(row[0]) if row else "",
                "container": _json_value(row[1]) if row else "",
                "schema": _json_value(row[2]) if row else "",
                "version": str(getattr(conn, "version", "")),
                "duration_ms": int((time.time() - started) * 1000),
            }
            cur.close()
            conn.close()
        except Exception as exc:  # noqa: BLE001
            result = {"ok": False, "error": "%s: %s" %
                      (type(exc).__name__, exc),
                      "duration_ms": int((time.time() - started) * 1000)}
        profile = self.store.databases.get(profile_id)
        if profile:
            profile["last_test"] = dict(result, at=_now())
            self.store.log("DATABASE", "Bağlantı testi %s: %s" %
                           (profile["name"], "başarılı" if result["ok"] else "başarısız"),
                           profile_id=profile_id)
            self.store.save()
        return result

    def read_context(self, profile_id, password="", current_schema=""):
        profile, conn = self.connect(profile_id, password, current_schema)
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT SYS_CONTEXT('USERENV','DB_NAME') DB_NAME, "
                "SYS_CONTEXT('USERENV','CON_NAME') CON_NAME, "
                "SYS_CONTEXT('USERENV','INSTANCE_NAME') INSTANCE_NAME, "
                "SYS_CONTEXT('USERENV','CURRENT_SCHEMA') CURRENT_SCHEMA, "
                "SYS_CONTEXT('USERENV','SESSION_USER') SESSION_USER FROM dual")
            data = self._rows(cur, 1)
            cur.close()
            return {"ok": True, "profile": self.public_profile(profile),
                    "result": data}
        finally:
            conn.close()

    def read_inventory(self, profile_id, password="", current_schema=""):
        profile, conn = self.connect(profile_id, password, current_schema)
        try:
            cur = conn.cursor()
            cur.execute("SELECT object_type, COUNT(*) object_count "
                        "FROM user_objects GROUP BY object_type "
                        "ORDER BY object_count DESC, object_type")
            data = self._rows(cur, 200)
            cur.close()
            return {"ok": True, "profile": self.public_profile(profile),
                    "result": data}
        finally:
            conn.close()

    def query(self, profile_id, sql, password="", limit=200,
              current_schema=""):
        """Execute one read-only SELECT/WITH statement, including DISTINCT."""
        plan = self.statement_plan(sql, "query.sql")
        executable = [item for item in plan if item["executable"]]
        if len(executable) != 1 or executable[0]["verb"] not in ("SELECT", "WITH"):
            return {"ok": False,
                    "error": "Salt-okunur alanda yalnız tek bir SELECT veya WITH sorgusu çalıştırılabilir.",
                    "plan": plan}
        started = time.time()
        profile, conn = self.connect(profile_id, password, current_schema)
        try:
            cur = conn.cursor()
            cur.execute(executable[0]["sql"])
            result = self._rows(cur, max(1, min(500, int(limit or 200))))
            cur.close()
            return {"ok": True, "message": "Sorgu başarıyla çalıştı.",
                    "profile": self.public_profile(profile), "result": result,
                    "duration_ms": int((time.time() - started) * 1000),
                    "query_type": ("SELECT DISTINCT" if
                                   re.match(r"^\s*SELECT\s+DISTINCT\b",
                                            executable[0]["sql"], re.I)
                                   else executable[0]["verb"])}
        finally:
            conn.close()

    @staticmethod
    def _owner_list(owners, fallback):
        raw = owners if isinstance(owners, list) else str(owners or "").split(",")
        values = []
        for value in raw:
            owner = str(value).strip().upper()
            if owner and re.match(r"^[A-Z][A-Z0-9_$#]{0,127}$", owner):
                values.append(owner)
        return values or [str(fallback or "").upper()]

    def build_catalog(self, profile_id, password="", owners=None,
                      current_schema=""):
        """Read a validator-compatible catalog from an Oracle connection."""
        profile, conn = self.connect(profile_id, password, current_schema)
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT SYS_CONTEXT('USERENV','DB_NAME'), "
                "SYS_CONTEXT('USERENV','CON_NAME'), "
                "SYS_CONTEXT('USERENV','CURRENT_SCHEMA') FROM dual")
            identity = cur.fetchone() or ("", "", profile["username"])
            owner_list = self._owner_list(owners, identity[2])
            binds = {"o%d" % i: owner for i, owner in enumerate(owner_list)}
            placeholders = ",".join(":" + key for key in binds)

            catalog = {
                "database": {"name": _json_value(identity[0]),
                             "container": _json_value(identity[1]),
                             "version": str(getattr(conn, "version", "")),
                             "generated_at": _now(), "owners": owner_list},
                "objects": {}, "columns": {}, "constraints": {},
                "indexes": {}, "tablespaces": [],
            }
            cur.execute("SELECT owner, object_name, object_type, status "
                        "FROM all_objects WHERE owner IN (%s)" % placeholders,
                        binds)
            for owner, name, kind, status in cur.fetchall():
                catalog["objects"]["%s.%s" % (owner, name)] = {
                    "type": kind, "status": status}

            cur.execute("SELECT owner, table_name, column_name "
                        "FROM all_tab_columns WHERE owner IN (%s) "
                        "ORDER BY owner, table_name, column_id" % placeholders,
                        binds)
            for owner, table, column in cur.fetchall():
                catalog["columns"].setdefault("%s.%s" % (owner, table), []).append(column)

            cur.execute(
                "SELECT c.owner, c.table_name, c.constraint_name, "
                "c.constraint_type, cc.column_name "
                "FROM all_constraints c JOIN all_cons_columns cc "
                "ON cc.owner=c.owner AND cc.constraint_name=c.constraint_name "
                "WHERE c.owner IN (%s) AND c.constraint_type IN ('P','U','R') "
                "ORDER BY c.owner,c.table_name,c.constraint_name,cc.position" % placeholders,
                binds)
            constraints = {}
            for owner, table, name, kind, column in cur.fetchall():
                key = (owner, table, name)
                constraints.setdefault(key, {"name": name, "type": kind,
                                             "columns": []})["columns"].append(column)
            for (owner, table, _), item in constraints.items():
                catalog["constraints"].setdefault(
                    "%s.%s" % (owner, table), []).append(item)

            cur.execute(
                "SELECT table_owner, table_name, index_name, column_name "
                "FROM all_ind_columns WHERE table_owner IN (%s) "
                "ORDER BY table_owner,table_name,index_name,column_position" % placeholders,
                binds)
            indexes = {}
            for owner, table, name, column in cur.fetchall():
                key = (owner, table, name)
                indexes.setdefault(key, {"name": name, "columns": []})[
                    "columns"].append(column)
            for (owner, table, _), item in indexes.items():
                catalog["indexes"].setdefault("%s.%s" % (owner, table), []).append(item)

            try:
                cur.execute("SELECT tablespace_name FROM user_tablespaces")
                catalog["tablespaces"] = [row[0] for row in cur.fetchall()]
            except Exception:  # noqa: BLE001 - optional privilege
                catalog["tablespaces"] = []
            cur.close()
            return {"ok": True, "profile": self.public_profile(profile),
                    "catalog": catalog}
        finally:
            conn.close()

    def preflight(self, profile_id, script, script_name="01-change.sql",
                  password="", owners=None, selected_rule_ids=None,
                  current_schema=""):
        catalog_result = self.build_catalog(profile_id, password, owners,
                                            current_schema)
        validation = validator_api.validate_text(
            script, script_name, catalog=catalog_result["catalog"],
            selected_rule_ids=selected_rule_ids)
        return {"ok": validation.get("ok", False),
                "validation": validation,
                "catalog_summary": {
                    "database": catalog_result["catalog"]["database"],
                    "objects": len(catalog_result["catalog"]["objects"]),
                    "tables": len(catalog_result["catalog"]["columns"]),
                    "indexes": sum(len(v) for v in
                                   catalog_result["catalog"]["indexes"].values()),
                }}

    # ------------------------------------------------------------ execute
    def execute(self, profile_id, script, script_name="01-change.sql",
                password="", selected_rule_ids=None, gate_policy="PASS_ONLY",
                confirmation="", transaction_mode="SCRIPT",
                environment="", confirmation_name="", current_schema=""):
        profile = self.store.databases.get(profile_id)
        if not profile:
            return {"ok": False, "error": "DB profili bulunamadı."}
        if not profile.get("allow_execute"):
            return {"ok": False,
                    "error": "Bu profilde script çalıştırma yetkisi kapalı."}
        effective_environment = str(environment or
                                    profile.get("environment") or "SHARED").upper()
        expected_confirmation = confirmation_name or profile.get("name")
        if effective_environment == "PROD" and confirmation != expected_confirmation:
            return {"ok": False,
                    "error": "PROD çalıştırması için hedef adını onay alanına birebir yazın."}

        validation = validator_api.validate_text(
            script, script_name, selected_rule_ids=selected_rule_ids)
        verdict = validation.get("verdict")
        accepted = verdict == "PASS" if gate_policy == "PASS_ONLY" \
            else verdict in ("PASS", "WARN")
        if not validation.get("ok") or not accepted:
            return {"ok": False, "phase": "VALIDATION",
                    "error": "Validator kapısı geçilemedi: %s" % verdict,
                    "validation": validation}

        plan = self.statement_plan(script, script_name)
        executable = [item for item in plan if item["executable"]]
        if not executable:
            return {"ok": False, "phase": "PLAN",
                    "error": "Çalıştırılabilir SQL veya PL/SQL ifadesi yok.",
                    "validation": validation, "plan": plan}

        started = time.time()
        statement_results = []
        conn = None
        has_ddl = any(x["action"] == "DDL" for x in executable)
        try:
            _, conn = self.connect(profile_id, password, current_schema)
            cur = conn.cursor()
            for item in executable:
                before = time.time()
                verb = item["verb"]
                result = {"index": item["index"], "line": item["line"],
                          "verb": verb, "action": item["action"],
                          "status": "SUCCESS"}
                if verb == "COMMIT":
                    conn.commit()
                    result["rowcount"] = 0
                elif verb == "ROLLBACK":
                    conn.rollback()
                    result["rowcount"] = 0
                else:
                    cur.execute(item["sql"])
                    result["rowcount"] = int(getattr(cur, "rowcount", 0) or 0)
                    if cur.description:
                        result["query"] = self._rows(cur, 100)
                result["duration_ms"] = int((time.time() - before) * 1000)
                statement_results.append(result)

            tx = str(transaction_mode or "SCRIPT").upper()
            if tx == "COMMIT_AFTER_SUCCESS":
                conn.commit()
            elif tx == "ROLLBACK_AFTER_TEST":
                conn.rollback()
            cur.close()
            message = "%d ifade Oracle üzerinde başarıyla çalıştırıldı." % len(executable)
            success = True
            error = ""
        except Exception as exc:  # noqa: BLE001
            success = False
            error = "%s: %s" % (type(exc).__name__, exc)
            message = "Çalıştırma başarısız oldu."
            if conn is not None:
                try:
                    conn.rollback()
                except Exception:  # noqa: BLE001
                    pass
            if len(statement_results) < len(executable):
                failed = executable[len(statement_results)]
                statement_results.append({
                    "index": failed["index"], "line": failed["line"],
                    "verb": failed["verb"], "action": failed["action"],
                    "status": "FAILED", "error": error,
                })
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:  # noqa: BLE001
                    pass

        duration = int((time.time() - started) * 1000)
        audit = self.store.record_db_execution({
            "profile_id": profile_id, "database_name": profile["name"],
            "environment": effective_environment, "script_name": script_name,
            "sha256": hashlib.sha256(script.encode("utf-8")).hexdigest(),
            "statement_count": len(executable), "ok": success,
            "message": message, "error": error,
            "duration_ms": duration, "transaction_mode": transaction_mode,
            "has_ddl": has_ddl,
            "statements": [{k: v for k, v in row.items() if k != "query"}
                           for row in statement_results],
        })
        self.store.log("DATABASE", "%s / %s / %s" %
                       (profile["name"], script_name,
                        "SUCCESS" if success else "FAILED"),
                       profile_id=profile_id, execution_id=audit["id"])
        self.store.save()
        return {
            "ok": success, "id": audit["id"], "message": message,
            "error": error, "duration_ms": duration,
            "validation": validation, "plan": plan,
            "statements": statement_results,
            "warning": ("DDL ifadeleri Oracle tarafından örtük commit edilebilir; "
                        "rollback garantisi yoktur." if has_ddl else ""),
        }

    # -------------------------------------------------------------- facade
    def action(self, profile_id, action, payload=None):
        payload = payload or {}
        action = str(action or "").upper()
        target = self.store.targets.get(payload.get("target_id", ""))
        if target:
            profile_id = target.get("database_profile_id", profile_id)
        current_schema = (target or {}).get("schema", "")
        try:
            if action == "TEST":
                return self.test(profile_id, payload.get("password", ""),
                                 current_schema)
            if action == "CONTEXT":
                return self.read_context(profile_id, payload.get("password", ""),
                                         current_schema)
            if action == "INVENTORY":
                return self.read_inventory(profile_id, payload.get("password", ""),
                                           current_schema)
            if action == "QUERY":
                return self.query(profile_id, payload.get("script", ""),
                                  payload.get("password", ""),
                                  payload.get("limit", 200), current_schema)
            if action == "PREVIEW":
                script = payload.get("script", "")
                return {"ok": True, "plan": self.statement_plan(
                    script, payload.get("script_name", "01-change.sql"))}
            if action == "PREFLIGHT":
                return self.preflight(
                    profile_id, payload.get("script", ""),
                    payload.get("script_name", "01-change.sql"),
                    password=payload.get("password", ""),
                    owners=payload.get("owners", ""),
                    selected_rule_ids=payload.get("selected_rule_ids"),
                    current_schema=current_schema)
            if action == "EXECUTE":
                return self.execute(
                    profile_id, payload.get("script", ""),
                    payload.get("script_name", "01-change.sql"),
                    password=payload.get("password", ""),
                    selected_rule_ids=payload.get("selected_rule_ids"),
                    gate_policy=payload.get("gate_policy", "PASS_ONLY"),
                    confirmation=payload.get("confirmation", ""),
                    transaction_mode=payload.get("transaction_mode", "SCRIPT"),
                    environment=(target or {}).get("environment", ""),
                    confirmation_name=(target or {}).get("name", ""),
                    current_schema=current_schema)
            return {"ok": False, "error": "Bilinmeyen DB aksiyonu: %s" % action}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": "%s: %s" %
                    (type(exc).__name__, exc)}


DATABASES = DatabaseManager(STORE)
