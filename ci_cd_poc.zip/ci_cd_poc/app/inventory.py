# -*- coding: utf-8 -*-
"""Script icerik envanteri ve kategorizasyon.

"Bu talepte 8 CREATE, 3 ALTER var" seklinde kategorize gorunum uretir.
Sayim, validator'un lexer'i uzerinden yapilir; yorum ve string icindeki
kelimeler sayilmaz, PL/SQL govdesindeki ifadeler de dogru siniflandirilir.
"""
from __future__ import annotations

import hashlib
import re
from collections import OrderedDict

from validator_api import build_context

# Ifade sinifi -> (etiket, renk, tehlike seviyesi 0-3)
CLASS_META = OrderedDict([
    ("DDL",     ("DDL",           "#dc2626", 3)),
    ("DML",     ("DML",           "#d97706", 2)),
    ("DCL",     ("DCL (yetki)",   "#7c3aed", 3)),
    ("TCL",     ("TCL (commit)",  "#0891b2", 1)),
    ("SELECT",  ("SELECT",        "#059669", 0)),
    ("PLSQL",   ("PL/SQL blok",   "#2563eb", 2)),
    ("CLIENT",  ("SQL*Plus",      "#64748b", 0)),
    ("DIGER",   ("Diger",         "#94a3b8", 1)),
])

VERB_CLASS = {
    "CREATE": "DDL", "ALTER": "DDL", "DROP": "DDL", "TRUNCATE": "DDL",
    "RENAME": "DDL", "COMMENT": "DDL", "PURGE": "DDL", "FLASHBACK": "DDL",
    "ANALYZE": "DDL", "AUDIT": "DDL", "NOAUDIT": "DDL",
    "INSERT": "DML", "UPDATE": "DML", "DELETE": "DML", "MERGE": "DML",
    "LOCK": "DML",
    "GRANT": "DCL", "REVOKE": "DCL",
    "COMMIT": "TCL", "ROLLBACK": "TCL", "SAVEPOINT": "TCL",
    "SELECT": "SELECT", "WITH": "SELECT",
    "BEGIN": "PLSQL", "DECLARE": "PLSQL",
}

# CREATE/ALTER/DROP sonrasi obje tipi
OBJ_RX = re.compile(
    r"^\s*(CREATE|ALTER|DROP)\s+(?:OR\s+REPLACE\s+)?"
    r"(?:(?:NON)?EDITIONABLE\s+)?"
    r"(?:GLOBAL\s+TEMPORARY\s+|PRIVATE\s+TEMPORARY\s+|UNIQUE\s+|BITMAP\s+|"
    r"MATERIALIZED\s+|PUBLIC\s+|FORCE\s+|NOFORCE\s+|SHARED\s+|EDITIONING\s+)*"
    r"([A-Z]+(?:\s+(?:BODY|VIEW|LOG|LINK))?)", re.I)

NAME_RX = re.compile(
    r'((?:"?[A-Za-z_$#][\w$#]*"?\s*\.\s*)?"?[A-Za-z_$#][\w$#]*"?)')


def _object_of(masked: str, verb: str, otype: str) -> str:
    """CREATE TABLE X.Y -> 'X.Y'"""
    pat = r"%s\s+(?:\w+\s+)*?%s\s+%s" % (verb, otype.replace(" ", r"\s+"),
                                         NAME_RX.pattern)
    m = re.search(pat, masked, re.I)
    if m:
        return re.sub(r"\s+", "", m.group(1)).strip('"')
    m = NAME_RX.search(masked[len(verb):])
    return re.sub(r"\s+", "", m.group(1)).strip('"') if m else ""


def analyze_inventory(text: str, path: str = "script.sql") -> dict:
    """Script icerigini kategorize eder."""
    ctx = build_context(text, path)

    by_class = OrderedDict((k, 0) for k in CLASS_META)
    by_verb = {}
    by_object_type = {}
    objects = []
    statements = []

    for st in ctx.all_statements:
        if st.kind == "sqlplus":
            cls = "CLIENT"
        else:
            cls = VERB_CLASS.get(st.first_word, "DIGER")
            if st.kind == "plsql" and cls in ("DIGER", "PLSQL"):
                cls = "PLSQL"

        by_class[cls] = by_class.get(cls, 0) + 1
        verb = st.first_word or "?"
        by_verb[verb] = by_verb.get(verb, 0) + 1

        otype = ""
        oname = ""
        if verb in ("CREATE", "ALTER", "DROP"):
            m = OBJ_RX.match(st.masked)
            if m:
                otype = re.sub(r"\s+", " ", m.group(2).upper())
                key = "%s %s" % (verb, otype)
                by_object_type[key] = by_object_type.get(key, 0) + 1
                oname = _object_of(st.masked, verb, otype)
                if oname:
                    objects.append({"verb": verb, "type": otype, "name": oname,
                                    "line": st.start_line})

        statements.append({
            "index": st.index,
            "line": st.start_line,
            "end_line": st.end_line,
            "verb": verb,
            "cls": cls,
            "object_type": otype,
            "object_name": oname,
            "nested": st.kind == "plsql_inner",
            "preview": (st.norm[:110] + ("..." if len(st.norm) > 110 else "")),
        })

    top = [s for s in ctx.statements if s.kind != "sqlplus"]
    kinds = []
    if ctx.top_ddl_statements:
        kinds.append("DDL")
    if ctx.top_dml_statements:
        kinds.append("DML")
    if any(s.first_word in ("SELECT", "WITH") for s in top):
        kinds.append("SELECT")
    if any(s.first_word in ("GRANT", "REVOKE") for s in top):
        kinds.append("DCL")

    return {
        "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "lines": len(ctx.lines),
        "chars": len(text),
        "statement_count": len(ctx.statements),
        "statement_count_all": len(ctx.all_statements),
        "classes": [
            {"key": k, "label": CLASS_META[k][0], "color": CLASS_META[k][1],
             "danger": CLASS_META[k][2], "count": v}
            for k, v in by_class.items() if v
        ],
        "verbs": [{"verb": k, "count": v}
                  for k, v in sorted(by_verb.items(), key=lambda x: -x[1])],
        "object_types": [{"label": k, "count": v}
                         for k, v in sorted(by_object_type.items(),
                                            key=lambda x: -x[1])],
        "objects": objects,
        "statements": statements,
        "file_kinds": kinds or ["BOS"],
        "summary_text": summarize(by_object_type, by_verb),
    }


def summarize(by_object_type, by_verb) -> str:
    """'8 CREATE TABLE, 3 ALTER TABLE, 12 INSERT' gibi tek satirlik ozet."""
    parts = ["%d %s" % (v, k) for k, v in
             sorted(by_object_type.items(), key=lambda x: -x[1])]
    for verb in ("INSERT", "UPDATE", "DELETE", "MERGE", "GRANT", "REVOKE",
                 "COMMIT", "SELECT"):
        if by_verb.get(verb):
            parts.append("%d %s" % (by_verb[verb], verb))
    return ", ".join(parts) if parts else "calistirilabilir ifade yok"
