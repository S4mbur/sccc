# -*- coding: utf-8 -*-
"""Mevcut ora_script_validator motorunu POC uygulamasina baglar.

Kural seti, config ve lexer aynen kullanilir; burada sadece HTTP/JSON'a
uygun bir sarmalayici vardir.
"""
from __future__ import annotations

import hashlib
import os
import sys
import threading

# ../..  -> ora_script_validator kok dizini
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from core import reporter                                   # noqa: E402
from core.config import load_config                         # noqa: E402
from core.context import ScriptContext                      # noqa: E402
from core.reader import read_source                         # noqa: E402
from core.registry import EngineError, discover_rules, run_rules   # noqa: E402

_CACHE = {"config": None, "rules": None, "error": None}
_RUN_LOCK = threading.RLock()


def _load():
    if _CACHE["rules"] is not None or _CACHE["error"]:
        return
    try:
        cfg_path = os.path.join(ROOT, "config.yaml")
        cfg = load_config(cfg_path if os.path.exists(cfg_path) else None)
        rules = discover_rules(config=cfg)
        _CACHE["config"] = cfg
        _CACHE["rules"] = rules
    except Exception as exc:                                 # noqa: BLE001
        _CACHE["error"] = "%s: %s" % (type(exc).__name__, exc)


def engine_info() -> dict:
    _load()
    if _CACHE["error"]:
        return {"ok": False, "error": _CACHE["error"]}
    rules = _CACHE["rules"]
    cats = {}
    for r in rules:
        cats[r.category] = cats.get(r.category, 0) + 1
    return {
        "ok": True,
        "root": ROOT,
        "rules_total": len(rules),
        "rules_active": len([r for r in rules if r.enabled]),
        "categories": [{"name": k, "count": v}
                       for k, v in sorted(cats.items(), key=lambda x: -x[1])],
    }


def list_rules() -> list:
    _load()
    if _CACHE["error"]:
        return []
    return [{"id": r.id, "name": r.name, "category": r.category,
             "severity": r.severity, "enabled": r.enabled,
             "description": r.description, "rationale": r.rationale,
             "remediation": r.remediation, "tags": list(r.tags or [])}
            for r in _CACHE["rules"]]


def build_context(text: str, path: str = "script.sql") -> ScriptContext:
    _load()
    settings = (_CACHE["config"] or {}).get("settings", {})
    return ScriptContext(path, text, settings=settings, meta={})


def validate_text(text: str, path: str = "script.sql",
                  overrides: dict = None, catalog: dict = None,
                  selected_rule_ids=None) -> dict:
    """Script metnini dogrular. overrides: {ORA020: {'enabled':False}} gibi.

    ``selected_rule_ids`` has exact-selection semantics:

    * ``None`` keeps engine defaults (then applies overrides),
    * ``[]`` runs no rules,
    * a list enables only the listed rule ids.

    Donen: verdict, exit_code, findings[], summary, engine bilgisi.
    """
    _load()
    if _CACHE["error"]:
        return {"ok": False, "verdict": "ENGINE_ERROR", "exit_code": 3,
                "error": _CACHE["error"], "findings": [], "summary": {}}

    cfg = _CACHE["config"]
    rules = _CACHE["rules"]

    settings = dict(cfg.get("settings", {}))
    if catalog:
        settings["catalog"] = catalog

    meta = read_source(path, "utf-8", data=text.encode("utf-8"))
    meta["member_name"] = os.path.basename(path)

    # Rule objects are shared by the threaded HTTP server. Keep temporary
    # selections isolated so concurrent parses cannot leak configuration.
    with _RUN_LOCK:
        saved = [(r, r.enabled, r.severity) for r in rules]
        selected = None if selected_rule_ids is None else {
            str(rule_id) for rule_id in selected_rule_ids}
        try:
            if selected is not None:
                for r in rules:
                    r.enabled = r.id in selected
            for r in rules:
                ov = (overrides or {}).get(r.id)
                if ov is None:
                    continue
                if "enabled" in ov:
                    r.enabled = bool(ov["enabled"])
                if ov.get("severity"):
                    r.severity = str(ov["severity"]).upper()

            ctx = ScriptContext(path, meta.get("text", ""), settings=settings,
                                meta=meta)
            findings = run_rules(rules, ctx)
            if meta.get("fatal"):
                findings = [f for f in findings
                            if f.rule_id in ("ORA260", "ORA261")]
            rep = reporter.build_report(rules=rules, ctx=ctx, findings=findings,
                                        duration_ms=0.0)
            verdict = rep["verdict"]
            out = {
                "ok": True,
                "verdict": verdict,
                "exit_code": rep["exit_code"],
                "summary": rep["summary"],
                "script_stats": rep["script_stats"],
                "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                "findings": [f.to_dict() for f in findings],
                "rules_active": len([r for r in rules if r.enabled]),
                "selected_rule_ids": [r.id for r in rules if r.enabled],
            }
        except EngineError as exc:
            out = {"ok": False, "verdict": "ENGINE_ERROR", "exit_code": 3,
                   "error": str(exc), "findings": [], "summary": {}}
        except Exception as exc:                             # noqa: BLE001
            out = {"ok": False, "verdict": "ENGINE_ERROR", "exit_code": 3,
                   "error": "%s: %s" % (type(exc).__name__, exc),
                   "findings": [], "summary": {}}
        finally:
            for r, en, sev in saved:
                r.enabled, r.severity = en, sev
    return out
