#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""POC duman testi - sunucuyu acmadan once calistirin.

    python selftest.py

Tum modulleri import eder, validator motorunu yukler ve uctan uca bir
talep -> validator pipeline senaryosunu HTTP olmadan kosturur.
Hata varsa nerede oldugunu acikca yazar.
"""
from __future__ import annotations

import os
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
for p in (os.path.join(HERE, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

OK, FAIL = 0, 0


def check(label, fn):
    global OK, FAIL
    try:
        res = fn()
        print("  [OK]   %s%s" % (label, ("  -> %s" % res) if res else ""))
        OK += 1
        return True
    except Exception as exc:                                 # noqa: BLE001
        print("  [HATA] %s" % label)
        print("         %s: %s" % (type(exc).__name__, exc))
        print("         " + traceback.format_exc().replace("\n", "\n         ")[:1200])
        FAIL += 1
        return False


print("=" * 70)
print(" POC DUMAN TESTI")
print("=" * 70)

print("\n1) Moduller")
check("store",         lambda: __import__("store"))
check("compare",       lambda: __import__("compare"))
check("connectors",    lambda: __import__("connectors"))
check("operations",    lambda: __import__("operations"))
check("validator_api", lambda: __import__("validator_api"))
check("inventory",     lambda: __import__("inventory"))
check("pipeline",      lambda: __import__("pipeline"))

import compare                      # noqa: E402
import inventory                    # noqa: E402
import pipeline                     # noqa: E402
import validator_api                # noqa: E402
from store import STORE             # noqa: E402

print("\n2) Validator motoru")


def _engine():
    info = validator_api.engine_info()
    if not info.get("ok"):
        raise RuntimeError(info.get("error"))
    return "%d kural (%d aktif)" % (info["rules_total"], info["rules_active"])


check("motor yuklendi", _engine)

SCRIPT = """/*
 * TALEP NO  : CHG-2026-0001
 * YAZAN     : burak.yalcin
 * TARIH     : 2026-08-12
 * AMAC      : Risk skoru tablosu
 * GERI ALMA : 99-rollback.sql
 */
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;
SET DEFINE OFF;

CREATE TABLE BANKAPP.MUSTERI_RISK (
  MUSTERI_NO NUMBER NOT NULL,
  SKOR       NUMBER(3) DEFAULT 0
) TABLESPACE TS_BANKAPP;

ALTER TABLE BANKAPP.MUSTERI_RISK
  ADD CONSTRAINT PK_MUSTERI_RISK PRIMARY KEY (MUSTERI_NO);

COMMENT ON TABLE BANKAPP.MUSTERI_RISK IS 'Musteri risk skoru';

EXIT SUCCESS;
"""


def _validate():
    r = validator_api.validate_text(SCRIPT, "01-test.sql")
    if not r.get("ok"):
        raise RuntimeError(r.get("error"))
    return "karar=%s exit=%s" % (r["verdict"], r["exit_code"])


def _inventory():
    inv = inventory.analyze_inventory(SCRIPT, "01-test.sql")
    return inv["summary_text"]


print("\n3) Parse ve envanter")
check("validate_text", _validate)
check("analyze_inventory", _inventory)


def _compare_same():
    r = compare.compare_many([{"label": "A", "text": SCRIPT},
                              {"label": "B", "text": SCRIPT}])
    assert r["identical"], "ayni scriptler farkli goruldu"
    return "identical=True"


def _compare_invisible():
    mod = SCRIPT[:50] + "​" + SCRIPT[50:]
    r = compare.compare_many([{"label": "A", "text": SCRIPT},
                              {"label": "B", "text": mod}])
    assert not r["identical"], "gorunmez karakter farki yakalanmadi"
    return "gorunmez karakter yakalandi"


print("\n4) Identiklik")
check("ayni scriptler", _compare_same)
check("gorunmez karakter", _compare_invisible)


def _pipeline_flow():
    STORE.reset()
    res = pipeline.create_run("validation_only", "Duman testi", "", "burak.yalcin")
    assert res.get("ok"), res.get("error")
    run = res["run"]
    rid = run["id"]
    t1 = STORE.create_talep("TEST", "Risk tablosu", SCRIPT, "01-x.sql", "burak.yalcin")
    r = pipeline.attach_talep(rid, "review_talep", t1["talep_no"])
    assert r.get("ok"), r.get("error")
    r = pipeline.complete_stage(rid, "review_talep")
    assert r.get("ok"), r.get("error")
    r = pipeline.run_validation(rid, "review_validate")
    assert r.get("ok"), r.get("error")
    verdict = r["validation"]["verdict"]
    if verdict != "PASS":
        STORE.settings["gate_policy"] = "ALLOW_WARN"
        # Politika her run olusturulurken snapshot olarak sabitlenir. Duman
        # testindeki WARN sonucunu kabul etmek icin run snapshot'ini guncelle.
        pipeline.get_run(rid)["gate_policy"] = "ALLOW_WARN"
        pipeline.evaluate(pipeline.get_run(rid))
    r = pipeline.complete_stage(rid, "review_validate")
    assert r.get("ok"), "validate asamasi tamamlanamadi: %s" % r.get("error")
    assert pipeline.get_run(rid)["status"] == "DONE"
    return "talep -> validator akisi dogru calisiyor"


print("\n5) Uctan uca pipeline")
check("validation_only akisi", _pipeline_flow)

print("\n6) Mock konnektorler")
import connectors                                            # noqa: E402
check("talep ping", lambda: connectors.TalepClient("MOCK", store=STORE).ping()["detail"])
check("octopus ping", lambda: connectors.OctopusClient("MOCK", store=STORE).ping()["detail"])

print("\n7) Statik dosyalar")
check("index.html", lambda: "%d byte" % os.path.getsize(
    os.path.join(HERE, "static", "index.html")))
check("pipelines.json", lambda: "%d pipeline" % len(pipeline.load_pipelines()))

STORE.reset()

print("\n" + "=" * 70)
print(" SONUC: %d basarili, %d hatali" % (OK, FAIL))
print("=" * 70)
if FAIL:
    print(" Hatalari duzeltmeden sunucuyu acmayin.")
else:
    print(" Her sey hazir.  python server.py   ->  http://127.0.0.1:8080")
sys.exit(1 if FAIL else 0)
