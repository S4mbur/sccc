"""CI/CD POC test package."""
