# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for path in (os.path.join(HERE, "app"), HERE):
    if path not in sys.path:
        sys.path.insert(0, path)

import database_service  # noqa: E402
import connectors  # noqa: E402
import operations  # noqa: E402
import pipeline  # noqa: E402
import rule_profiles  # noqa: E402
import server  # noqa: E402
import validator_api  # noqa: E402
from store import STORE  # noqa: E402


class FakeCursor(object):
    def __init__(self, connection):
        self.connection = connection
        self.description = None
        self.rows = []
        self.rowcount = 0

    def execute(self, sql, binds=None):
        self.connection.sql.append(sql)
        upper = sql.upper()
        if "SYS_CONTEXT" in upper:
            self.description = [("DB_NAME",), ("CON_NAME",), ("CURRENT_SCHEMA",)]
            self.rows = [("TESTDB", "TESTPDB", "DEPLOY_USER")]
            self.rowcount = 1
        elif "FROM ALL_OBJECTS" in upper:
            self.description = [("OWNER",), ("OBJECT_NAME",),
                                ("OBJECT_TYPE",), ("STATUS",)]
            self.rows = [("BANKAPP", "T", "TABLE", "VALID")]
            self.rowcount = 1
        elif "FROM ALL_TAB_COLUMNS" in upper:
            self.description = [("OWNER",), ("TABLE_NAME",), ("COLUMN_NAME",)]
            self.rows = [("BANKAPP", "T", "ID"), ("BANKAPP", "T", "A")]
            self.rowcount = 2
        elif "FROM ALL_CONSTRAINTS" in upper:
            self.description = [("OWNER",), ("TABLE_NAME",),
                                ("CONSTRAINT_NAME",), ("CONSTRAINT_TYPE",),
                                ("COLUMN_NAME",)]
            self.rows = [("BANKAPP", "T", "PK_T", "P", "ID")]
            self.rowcount = 1
        elif "FROM ALL_IND_COLUMNS" in upper:
            self.description = [("TABLE_OWNER",), ("TABLE_NAME",),
                                ("INDEX_NAME",), ("COLUMN_NAME",)]
            self.rows = [("BANKAPP", "T", "PK_T", "ID")]
            self.rowcount = 1
        elif "USER_TABLESPACES" in upper:
            self.description = [("TABLESPACE_NAME",)]
            self.rows = [("TS_BANKAPP",)]
            self.rowcount = 1
        elif "USER_OBJECTS" in upper:
            self.description = [("OBJECT_TYPE",), ("OBJECT_COUNT",)]
            self.rows = [("TABLE", 12), ("INDEX", 18)]
            self.rowcount = 2
        elif upper.startswith(("SELECT", "WITH")):
            self.description = [("VALUE",)]
            self.rows = [(1,)]
            self.rowcount = 1
        else:
            self.description = None
            self.rows = []
            self.rowcount = 1

    def fetchone(self):
        return self.rows[0] if self.rows else None

    def fetchmany(self, limit):
        return self.rows[:limit]

    def fetchall(self):
        return self.rows[:]

    def close(self):
        pass


class FakeConnection(object):
    version = "23.0-test"

    def __init__(self):
        self.sql = []
        self.commits = 0
        self.rollbacks = 0
        self.closed = False

    def cursor(self):
        return FakeCursor(self)

    def commit(self):
        self.commits += 1

    def rollback(self):
        self.rollbacks += 1

    def close(self):
        self.closed = True


class FakeDriver(object):
    __version__ = "test"

    def __init__(self):
        self.connections = []
        self.last_connect = None

    def connect(self, **kwargs):
        self.last_connect = kwargs
        conn = FakeConnection()
        self.connections.append(conn)
        return conn


class PocTestCase(unittest.TestCase):
    def setUp(self):
        self.real_save = STORE.save
        STORE.save = lambda: True
        STORE.reset(keep_connections=False)
        STORE.settings["gate_policy"] = "PASS_ONLY"
        STORE.settings["selected_rule_ids"] = None
        STORE.settings["orkestra_mode"] = "MOCK"
        STORE.settings["octopus_mode"] = "MOCK"

    def tearDown(self):
        STORE.reset(keep_connections=False)
        STORE.save = self.real_save

    def test_empty_rule_selection_runs_parser_but_no_rules(self):
        result = validator_api.validate_text(
            "DELETE FROM BANKAPP.MUSTERI_RISK;", "02-delete.sql",
            selected_rule_ids=[])
        self.assertTrue(result["ok"])
        self.assertEqual("PASS", result["verdict"])
        self.assertEqual(0, result["rules_active"])
        self.assertEqual([], result["findings"])

    def test_exact_rule_selection_only_runs_checked_rule(self):
        result = validator_api.validate_text(
            "DELETE FROM BANKAPP.MUSTERI_RISK;", "02-delete.sql",
            selected_rule_ids=["ORA003"])
        self.assertEqual(1, result["rules_active"])
        self.assertEqual({"ORA003"}, {finding["rule_id"]
                                     for finding in result["findings"]})

    def test_rule_profiles_are_data_driven_and_include_none(self):
        profiles = {item["id"]: item for item in rule_profiles.load_profiles()}
        self.assertGreater(profiles["engine-default"]["rule_count"], 50)
        self.assertEqual(0, profiles["none"]["rule_count"])
        self.assertEqual([], profiles["none"]["rule_ids"])

    def _manager_with_profile(self, environment="TEST", allow_execute=True):
        driver = FakeDriver()
        manager = database_service.DatabaseManager(STORE, driver=driver)
        saved = manager.save_profile({
            "name": "%s BANKDB" % environment,
            "environment": environment,
            "host": "db.internal", "port": 1521,
            "service_name": "BANKPDB", "username": "DEPLOY_USER",
            "password": "super-secret-value",
            "allow_execute": allow_execute,
        })
        self.assertTrue(saved["ok"])
        return manager, driver, saved["profile"]

    def test_database_password_is_never_persisted(self):
        manager, _, profile = self._manager_with_profile()
        self.assertTrue(profile["secret_available"])
        serialized = json.dumps(STORE.to_dict())
        self.assertNotIn("super-secret-value", serialized)
        self.assertNotIn("password", STORE.databases[profile["id"]])
        test = manager.test(profile["id"])
        self.assertTrue(test["ok"])
        self.assertEqual("TESTDB", test["database"])

    def test_operation_pipeline_and_one_click_database_execution(self):
        driver = FakeDriver()
        manager = database_service.DatabaseManager(STORE, driver=driver)
        x = manager.save_profile({
            "name": "X", "host": "x.internal", "port": 1521,
            "service_name": "XPDB", "username": "RUNNER",
            "password": "secret-x", "allow_execute": True,
            "environment": "OPERATION",
        })["profile"]
        y = manager.save_profile({
            "name": "Y", "host": "y.internal", "port": 1521,
            "service_name": "YPDB", "username": "RUNNER",
            "password": "secret-y", "allow_execute": True,
            "environment": "OPERATION",
        })["profile"]
        service = operations.OperationsService(
            STORE, manager,
            lambda: connectors.OctopusClient("MOCK", store=STORE))

        saved = service.save_pipeline({
            "name": "X to Y", "database_ids": [x["id"], y["id"]],
        }, "RUNNER")
        self.assertTrue(saved["ok"])
        definition = saved["pipeline"]
        self.assertEqual("X -> Y", definition["sequence_label"])
        self.assertNotIn("environment", definition)
        self.assertNotIn("script_type", definition)

        created = service.create_request({
            "pipeline_id": definition["id"], "database_id": y["id"],
            "title": "Add audit row", "owner": "RUNNER",
            "script_name": "01-audit.sql",
            "script": "UPDATE AUDIT_LOG SET VALUE=1 WHERE ID=1;\nCOMMIT;",
        })
        self.assertTrue(created["ok"])
        changed_while_pending = service.save_pipeline({
            "id": definition["id"], "name": definition["name"],
            "database_ids": [y["id"], x["id"]],
        })
        self.assertFalse(changed_while_pending["ok"])
        approved = service.approve_request(created["request"]["id"], "RUNNER")
        self.assertTrue(approved["ok"])
        self.assertTrue(approved["execution_ok"])
        self.assertEqual("SUCCESS", approved["request"]["status"])
        self.assertEqual(y["id"], approved["request"]["database_id"])
        self.assertTrue(approved["request"]["deployment_id"])
        self.assertEqual("Success", STORE.octopus_releases[
            approved["request"]["octopus_code"]]["state"])
        self.assertIn("UPDATE AUDIT_LOG", driver.connections[-1].sql[0])

        duplicate = service.approve_request(created["request"]["id"], "RUNNER")
        self.assertFalse(duplicate["ok"])

    def test_operation_request_must_use_pipeline_database(self):
        driver = FakeDriver()
        manager = database_service.DatabaseManager(STORE, driver=driver)
        x = manager.save_profile({
            "name": "X", "host": "x.internal", "service_name": "XPDB",
            "username": "RUNNER", "password": "secret-x",
            "allow_execute": True,
        })["profile"]
        outside = manager.save_profile({
            "name": "Outside", "host": "outside.internal",
            "service_name": "OUTPDB", "username": "RUNNER",
            "password": "secret-out", "allow_execute": True,
        })["profile"]
        service = operations.OperationsService(
            STORE, manager,
            lambda: connectors.OctopusClient("MOCK", store=STORE))
        pipeline_result = service.save_pipeline({
            "name": "Only X", "database_ids": [x["id"]],
        })
        created = service.create_request({
            "pipeline_id": pipeline_result["pipeline"]["id"],
            "database_id": outside["id"], "title": "Wrong target",
            "script": "SELECT 1 FROM DUAL;",
        })
        self.assertFalse(created["ok"])

    def test_operation_approval_waits_for_database_secret(self):
        driver = FakeDriver()
        manager = database_service.DatabaseManager(STORE, driver=driver)
        profile = manager.save_profile({
            "name": "Secure DB", "host": "secure.internal",
            "service_name": "SECPDB", "username": "RUNNER",
            "allow_execute": True,
        })["profile"]
        service = operations.OperationsService(
            STORE, manager,
            lambda: connectors.OctopusClient("MOCK", store=STORE))
        pipeline_result = service.save_pipeline({
            "name": "Secure flow", "database_ids": [profile["id"]],
        })
        created = service.create_request({
            "pipeline_id": pipeline_result["pipeline"]["id"],
            "database_id": profile["id"], "title": "Waiting secret",
            "script": "SELECT 1 FROM DUAL;",
        })
        approved = service.approve_request(created["request"]["id"], "RUNNER")
        self.assertFalse(approved["ok"])
        self.assertEqual("PENDING", created["request"]["status"])
        self.assertEqual([], driver.connections)

    def test_database_preview_skips_sqlplus_commands(self):
        plan = database_service.DatabaseManager.statement_plan(
            "SET DEFINE OFF;\nUPDATE X SET A=1 WHERE ID=2;\nCOMMIT;",
            "02-update.sql")
        self.assertFalse(plan[0]["executable"])
        self.assertEqual("UPDATE X SET A=1 WHERE ID=2", plan[1]["sql"])
        self.assertEqual("COMMIT", plan[2]["verb"])

    def test_select_distinct_runs_in_read_only_workbench(self):
        manager, _, profile = self._manager_with_profile(allow_execute=False)
        result = manager.query(
            profile["id"],
            "SELECT DISTINCT OBJECT_TYPE FROM USER_OBJECTS ORDER BY OBJECT_TYPE;")
        self.assertTrue(result["ok"])
        self.assertEqual("SELECT DISTINCT", result["query_type"])
        rejected = manager.query(
            profile["id"], "DELETE FROM BANKAPP.T WHERE ID=1;")
        self.assertFalse(rejected["ok"])

    def test_one_connection_can_seed_three_environment_targets(self):
        manager, _, profile = self._manager_with_profile()
        seeded = manager.seed_environment_targets(profile["id"], "Örnek")
        self.assertTrue(seeded["ok"])
        self.assertEqual(["TEST", "PREPROD", "PROD"],
                         [target["environment"] for target in seeded["targets"]])
        self.assertEqual({profile["id"]},
                         {target["database_profile_id"]
                          for target in seeded["targets"]})
        self.assertEqual(3, manager.public_profile(
            STORE.databases[profile["id"]])["target_count"])

    def test_live_catalog_preflight_feeds_catalog_rules(self):
        manager, _, profile = self._manager_with_profile()
        result = manager.preflight(
            profile["id"], "UPDATE BANKAPP.T SET A=1 WHERE ID=2;",
            "02-update.sql", owners="BANKAPP", selected_rule_ids=["ORA250", "ORA251"])
        self.assertTrue(result["ok"])
        self.assertEqual(1, result["catalog_summary"]["objects"])
        self.assertEqual("PASS", result["validation"]["verdict"])

    def test_database_execution_and_prod_confirmation(self):
        manager, driver, profile = self._manager_with_profile("PROD")
        script = "UPDATE BANKAPP.T SET A=1 WHERE ID=2;\nCOMMIT;"
        rejected = manager.execute(profile["id"], script, "02-update.sql",
                                   selected_rule_ids=[])
        self.assertFalse(rejected["ok"])
        accepted = manager.execute(
            profile["id"], script, "02-update.sql", selected_rule_ids=[],
            confirmation=profile["name"])
        self.assertTrue(accepted["ok"])
        self.assertEqual(2, len(accepted["statements"]))
        self.assertEqual(1, driver.connections[-1].commits)

    def test_direct_prod_policy_allows_dml_and_blocks_ddl(self):
        dml_run = pipeline.create_run("dml_direct_prod", "DML", "", "maker",
                                      selected_rule_ids=[])["run"]
        dml = STORE.create_talep(
            "PROD", "DML", "UPDATE BANKAPP.T SET A=1 WHERE ID=2;\nCOMMIT;",
            "02-update.sql", "maker")
        pipeline.attach_talep(dml_run["id"], "prod_talep", dml["talep_no"])
        deploy = next(stage for stage in dml_run["stages"]
                      if stage["id"] == "prod_deploy")
        policy = next(check for check in deploy["checks"]
                      if check["gate"] == "prod_change_policy")
        self.assertTrue(policy["ok"])

        ddl_run = pipeline.create_run("dml_direct_prod", "DDL", "", "maker",
                                      selected_rule_ids=[])["run"]
        ddl = STORE.create_talep(
            "PROD", "DDL", "CREATE TABLE BANKAPP.X (ID NUMBER);",
            "01-create.sql", "maker")
        pipeline.attach_talep(ddl_run["id"], "prod_talep", ddl["talep_no"])
        deploy = next(stage for stage in ddl_run["stages"]
                      if stage["id"] == "prod_deploy")
        policy = next(check for check in deploy["checks"]
                      if check["gate"] == "prod_change_policy")
        self.assertFalse(policy["ok"])
        self.assertIn("doğrudan PROD", policy["detail"])

    def test_catalog_and_examples_are_loadable(self):
        pipelines = pipeline.load_pipelines()
        self.assertGreaterEqual(len(pipelines), 4)
        for definition in pipelines:
            ids = [stage["id"] for stage in definition["stages"]]
            self.assertEqual(len(ids), len(set(ids)))
        examples = server.load_examples()
        self.assertGreaterEqual(len(examples), 7)
        self.assertTrue(all(item["script"].strip() for item in examples))
        self.assertIn("select-distinct", {item["id"] for item in examples})
        self.assertIn("lab-release-schema", {item["id"] for item in examples})
        remote_examples = [item for item in examples
                           if item["id"].startswith("remote-demo-")]
        self.assertEqual(8, len(remote_examples))
        for item in remote_examples:
            plan = database_service.DatabaseManager.statement_plan(
                item["script"], item["script_name"])
            executable = [statement for statement in plan
                          if statement["executable"]]
            self.assertTrue(executable, item["id"])
            self.assertTrue(all(not statement["sql"].startswith(
                ("WHENEVER", "SET ")) for statement in executable))

    def test_runner_authentication_defaults_are_active(self):
        self.assertTrue(server.authenticate(server.AUTH_USERNAME,
                                            server.AUTH_PASSWORD))
        self.assertFalse(server.authenticate(server.AUTH_USERNAME,
                                             "wrong-password"))

    def test_pipeline_request_environment_sequence_is_data_driven(self):
        self.assertEqual(
            ["TEST", "PREPROD", "PROD"],
            pipeline.request_environment_sequence("ddl_database_promoted"))
        self.assertEqual(
            ["PROD"],
            pipeline.request_environment_sequence("dml_direct_prod"))

    def test_orkestra_request_promotion_requires_completed_previous_stage(self):
        script = "UPDATE ODC_CUSTOMER SET CUSTOMER_STATE='ACTIVE' " \
                 "WHERE CUSTOMER_NO='C-1001';\nCOMMIT;"
        created = server.api("/api/orkestra/requests", "POST", {
            "pipeline_type": "ddl_database_promoted",
            "environment": "TEST", "title": "Customer release",
            "owner": "RUNNER", "script_name": "02-release.sql",
            "script": script,
        }, {})
        self.assertTrue(created["ok"])
        request_id = created["request"]["id"]

        blocked = server.api("/api/orkestra/requests", "POST", {
            "pipeline_type": "ddl_database_promoted",
            "environment": "PREPROD", "previous_request_id": request_id,
            "title": "Customer release", "owner": "RUNNER",
            "script_name": "02-release.sql", "script": script,
        }, {})
        self.assertFalse(blocked["ok"])

        accepted = server.accept_orkestra_request(request_id, "RUNNER")
        self.assertTrue(accepted["ok"])
        self.assertEqual("ddl_database_promoted",
                         accepted["talep"]["pipeline_type"])
        self.assertEqual(request_id,
                         accepted["talep"]["external_request_id"])
        self.assertTrue(accepted["talep"]["octopus_code"])

        code = accepted["release"]["code"]
        result = server.api("/api/octopus/releases/%s/result" % code,
                            "POST", {"success": True}, {})
        self.assertTrue(result["ok"])
        completed = server.api(
            "/api/orkestra/requests/%s/complete" % request_id,
            "POST", {"_actor": "RUNNER"}, {})
        self.assertTrue(completed["ok"])

        changed_script = server.api("/api/orkestra/requests", "POST", {
            "pipeline_type": "ddl_database_promoted",
            "environment": "PREPROD", "previous_request_id": request_id,
            "title": "Customer release", "owner": "RUNNER",
            "script_name": "02-release.sql", "script": script + "\n-- changed",
        }, {})
        self.assertFalse(changed_script["ok"])

        promoted = server.api("/api/orkestra/requests", "POST", {
            "pipeline_type": "ddl_database_promoted",
            "environment": "PREPROD", "previous_request_id": request_id,
            "title": "Customer release", "owner": "RUNNER",
            "script_name": "02-release.sql", "script": script,
        }, {})
        self.assertTrue(promoted["ok"])
        self.assertEqual(created["request"]["promotion_id"],
                         promoted["request"]["promotion_id"])
        duplicate = server.api("/api/orkestra/requests", "POST", {
            "pipeline_type": "ddl_database_promoted",
            "environment": "PREPROD", "previous_request_id": request_id,
            "title": "Customer release", "owner": "RUNNER",
            "script_name": "02-release.sql", "script": script,
        }, {})
        self.assertFalse(duplicate["ok"])

    def test_octopus_promoted_request_runs_through_mock_pipeline(self):
        STORE.settings["selected_rule_ids"] = []
        script = "UPDATE ODC_CUSTOMER SET CUSTOMER_STATE='ACTIVE' " \
                 "WHERE CUSTOMER_NO='C-1001';\nCOMMIT;"
        created = server.api("/api/orkestra/requests", "POST", {
            "pipeline_type": "octopus_promoted", "environment": "TEST",
            "title": "Octopus release", "owner": "RUNNER",
            "script_name": "02-octopus.sql", "script": script,
        }, {})
        accepted = server.accept_orkestra_request(
            created["request"]["id"], "RUNNER")
        self.assertTrue(accepted["ok"])
        run_id = accepted["run"]["id"]
        octopus = server.octopus_client()

        for _ in range(3):
            advanced = pipeline.advance_run(
                run_id, database_service.DATABASES, octopus=octopus)
            self.assertTrue(advanced["ok"], advanced.get("error"))

        deployment = next(iter(STORE.deployments.values()))
        self.assertEqual("Success", deployment["state"])
        self.assertEqual(accepted["release"]["code"],
                         deployment["octopus_code"])
        completed = server.api(
            "/api/orkestra/requests/%s/complete" % created["request"]["id"],
            "POST", {"_actor": "RUNNER"}, {})
        self.assertTrue(completed["ok"])
        self.assertEqual("ACIK", accepted["talep"]["status"])

    def test_talep_pipeline_type_must_match_run(self):
        run = pipeline.create_run(
            "validation_only", "Validation", selected_rule_ids=[])["run"]
        request = STORE.create_talep(
            "TEST", "Wrong type", "SELECT 1 FROM DUAL;",
            pipeline_type="dml_direct_prod")
        attached = pipeline.attach_talep(
            run["id"], "review_talep", request["talep_no"])
        self.assertFalse(attached["ok"])
        self.assertIn("pipeline tipi", attached["error"])

    def test_oracle_lab_seed_creates_isolated_profiles_and_targets(self):
        seeded = server.seed_oracle_lab({"password": "run123"})
        self.assertTrue(seeded["ok"])
        self.assertEqual(
            {"RUNNER_TEST", "RUNNER_PREPROD", "RUNNER_PROD"},
            {profile["username"] for profile in seeded["profiles"]})
        self.assertEqual(
            {"TEST", "PREPROD", "PROD"},
            {target["environment"] for target in seeded["targets"]})
        self.assertNotIn("run123", json.dumps(STORE.to_dict()))

    def test_pipeline_definition_can_be_added_and_removed_atomically(self):
        original = pipeline.PIPE_FILE
        definition = {
            "id": "test_custom_flow", "name": "Custom flow",
            "description": "test", "applies_to": ["DML"],
            "stages": [{"id": "request", "name": "Request", "env": "TEST",
                        "type": "TALEP", "gates": ["talep_exists"]}],
        }
        try:
            with tempfile.TemporaryDirectory() as directory:
                pipeline.PIPE_FILE = os.path.join(directory, "pipelines.json")
                with open(pipeline.PIPE_FILE, "w", encoding="utf-8") as handle:
                    json.dump({"pipelines": []}, handle)
                saved = pipeline.save_definition(definition)
                self.assertTrue(saved["ok"])
                self.assertEqual("test_custom_flow", pipeline.load_pipelines()[0]["id"])
                deleted = pipeline.delete_definition("test_custom_flow")
                self.assertTrue(deleted["ok"])
                self.assertEqual([], pipeline.load_pipelines())
        finally:
            pipeline.PIPE_FILE = original

    def test_generated_target_pipeline_prepares_requests_and_advances(self):
        manager, _, profile = self._manager_with_profile()
        targets = manager.seed_environment_targets(profile["id"], "Örnek")[
            "targets"]
        original = pipeline.PIPE_FILE
        try:
            with tempfile.TemporaryDirectory() as directory:
                pipeline.PIPE_FILE = os.path.join(directory, "pipelines.json")
                with open(pipeline.PIPE_FILE, "w", encoding="utf-8") as handle:
                    json.dump({"pipelines": []}, handle)
                generated = pipeline.generate_target_pipeline({
                    "id": "generated_flow", "name": "Generated flow",
                    "target_ids": [target["id"] for target in targets],
                    "applies_to": ["DML"], "auto_prepare_requests": True,
                    "approval_on_prod": True, "require_identical": True,
                })
                self.assertTrue(generated["ok"], generated.get("error"))
                run = pipeline.create_run(
                    "generated_flow", "Quick release",
                    "UPDATE BANKAPP.T SET A=1 WHERE ID=2;\nCOMMIT;",
                    "maker", selected_rule_ids=[], script_name="02-update.sql")["run"]
                prepared = pipeline.prepare_requests(
                    run["id"], run["reference_script"], "02-update.sql", "maker")
                self.assertTrue(prepared["ok"])
                self.assertEqual(3, len(prepared["talepler"]))

                for _ in range(20):
                    next_info = pipeline.next_action(run["id"])
                    if next_info.get("done"):
                        break
                    stage = next_info["stage"]
                    target = STORE.targets.get(stage.get("target_id")) or {}
                    result = pipeline.advance_run(
                        run["id"], manager, password="super-secret-value",
                        approver="reviewer",
                        confirmation=(target.get("name", "")
                                      if stage.get("env") == "PROD" else ""))
                    self.assertTrue(result["ok"], result.get("error"))
                self.assertEqual("DONE", pipeline.get_run(run["id"])["status"])
                self.assertEqual(3, len(STORE.deployments))
                self.assertTrue(all(request.get("target_id")
                                    for request in prepared["talepler"]))
        finally:
            pipeline.PIPE_FILE = original


if __name__ == "__main__":
    unittest.main()
