"use strict";

const APP = {
  state: {settings:{}, talepler:[], operation_pipelines:[], operation_requests:[], orkestra_requests:[], octopus_releases:[], runs:[], deployments:[], databases:[], targets:[], db_executions:[], events:[]},
  rules: [], ruleProfiles: [], examples: [], pipelines: [], pipelineCapabilities: {}, health: {},
  selectedRules: new Set(), selectedPipelineId: "", currentRun: null,
  builderTargets: [], operationPipelineSteps: [], workspace: "development", user: ""
};

const byId = id => document.getElementById(id);
const esc = value => String(value == null ? "" : value).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[ch]));
const attr = esc;
const ruleIds = () => APP.rules.filter(rule => APP.selectedRules.has(rule.id)).map(rule => rule.id);
const statusPill = status => `<span class="status-pill ${esc(String(status || "").toLowerCase())}">${esc(status || "-")}</span>`;
let toastTimer;

function toast(message, error=false){
  const el = byId("toast");
  el.textContent = message;
  el.className = `toast show${error ? " error" : ""}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.className = "toast", 3600);
}

async function api(path, body){
  const options = body === undefined ? {} : {
    method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)
  };
  const response = await fetch(path, options);
  let data;
  try { data = await response.json(); }
  catch (_) { throw new Error(`Sunucu geçersiz yanıt verdi (${response.status}).`); }
  if(response.status===401){showLogin();throw new Error(data.error||"Oturum süresi doldu.");}
  if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
  return data;
}

function showLogin(message=""){
  document.body.classList.add("auth-pending");
  byId("loginGate").classList.remove("hidden");
  byId("loginError").textContent=message;
}

function hideLogin(username){
  APP.user=username;byId("currentUser").textContent=username;
  byId("orkestraOwner").value=username;byId("requestOwner").value=username;
  document.body.classList.remove("auth-pending");byId("loginGate").classList.add("hidden");
}

async function login(event){
  event.preventDefault();byId("loginError").textContent="";
  const response=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:byId("loginUsername").value,password:byId("loginPassword").value})});
  const result=await response.json();
  if(!response.ok)return showLogin(result.error||"Oturum açılamadı.");
  hideLogin(result.username);await boot();
}

async function logout(){await fetch("/api/auth/logout",{method:"POST"});showLogin("Oturum kapatıldı.");}

function navigate(view){
  document.querySelectorAll(".view").forEach(el => el.classList.toggle("active", el.id === `view-${view}`));
  document.querySelectorAll("#mainNav button").forEach(el => el.classList.toggle("active", el.dataset.view === view));
  if (view === "connections") renderConnections();
  if (view === "pipelines") renderPipelinePage();
  if (view === "operations") renderOperations();
  if (view === "operation-databases") renderOperationDatabases();
  if (view === "operation-pipelines") renderOperationPipelines();
  if (view === "orkestra" || view === "octopus") refreshExternalSystems();
}

function switchWorkspace(area,view=""){
  APP.workspace=area;
  document.querySelectorAll("#mainNav button").forEach(button=>button.classList.toggle("hidden",button.dataset.area!==area));
  byId("developmentSwitch").classList.toggle("active",area==="development");
  byId("operationsSwitch").classList.toggle("active",area==="operations");
  navigate(view||(area==="operations"?"operations":"overview"));
}

document.querySelectorAll("#mainNav button").forEach(button => button.addEventListener("click", () => navigate(button.dataset.view)));

// ---------------------------------------------------------------- overview
function renderOverview(){
  const s = APP.state;
  const activeRuns = s.runs.filter(run => !["DONE","FAILED"].includes(run.status)).length;
  const healthyDbs = s.databases.filter(db => db.last_test && db.last_test.ok).length;
  const selected = APP.selectedRules.size;
  byId("overviewMetrics").innerHTML = [
    [s.runs.length, "Toplam pipeline koşumu", `${activeRuns} aktif veya bekliyor`, ""],
    [s.talepler.length, "Değişiklik talebi", `${s.deployments.length} deployment kaydı`, "green"],
    [selected, "Seçili validator kuralı", `${APP.rules.length} kullanılabilir kural`, "amber"],
    [healthyDbs, "Test edilmiş Oracle bağlantısı", `${s.databases.length} fiziksel bağlantı · ${(s.targets||[]).length} ortam hedefi`, healthyDbs ? "green" : "red"]
  ].map(([value,label,detail,kind]) => `<article class="metric ${kind}"><strong>${value}</strong><span>${esc(label)}</span><small>${esc(detail)}</small></article>`).join("");

  byId("overviewPipelines").innerHTML = APP.pipelines.slice(0,5).map(pipe => {
    const envs = [...new Set(pipe.stages.map(stage => stage.env).filter(Boolean))];
    return `<div class="compact-item"><div><strong>${esc(pipe.name)}</strong><p>${esc(pipe.description)}</p></div><div>${statusPill(pipe.applies_to.join(" / "))}<p>${esc(envs.join(" / "))}</p></div></div>`;
  }).join("") || `<p class="muted">Pipeline tanımı bulunamadı.</p>`;

  byId("overviewEvents").innerHTML = s.events.slice(0,8).map(event => `<div class="event"><code>${esc(event.kind)}</code><div><p>${esc(event.message)}</p><time>${esc(event.at)}</time></div></div>`).join("") || `<p class="muted">Henüz olay kaydı yok.</p>`;
}

// ------------------------------------------------------------------ rules
function initializeRuleSelection(){
  const configured = APP.state.settings.selected_rule_ids;
  const initial = Array.isArray(configured) ? configured : APP.rules.filter(rule => rule.enabled).map(rule => rule.id);
  APP.selectedRules = new Set(initial);
}

function populateRuleControls(){
  const categories = [...new Set(APP.rules.map(rule => rule.category))].sort();
  byId("ruleCategory").innerHTML = `<option value="">Tüm kategoriler</option>` + categories.map(value => `<option value="${attr(value)}">${esc(value)}</option>`).join("");
  byId("ruleProfileSelect").innerHTML = `<option value="custom">Özel seçim</option>` + APP.ruleProfiles.map(profile => `<option value="${attr(profile.id)}">${esc(profile.name)} (${profile.rule_count})</option>`).join("");
  byId("gatePolicy").value=APP.state.settings.gate_policy||"PASS_ONLY";
  renderRules();
}

function visibleRules(){
  const query = byId("ruleSearch").value.trim().toLocaleLowerCase("tr-TR");
  const category = byId("ruleCategory").value;
  return APP.rules.filter(rule => (!category || rule.category === category) && (!query || `${rule.id} ${rule.name} ${rule.description} ${rule.category}`.toLocaleLowerCase("tr-TR").includes(query)));
}

function renderRules(){
  const rows = visibleRules();
  byId("ruleList").innerHTML = rows.map(rule => `<label class="rule-item"><input type="checkbox" ${APP.selectedRules.has(rule.id) ? "checked" : ""} onchange="toggleRule('${attr(rule.id)}',this.checked)"><span><strong>${esc(rule.id)}</strong> <b>${esc(rule.name)}</b><p>${esc(rule.description || rule.rationale || "")}</p><span class="rule-meta"><i class="mini-tag ${String(rule.severity).toLowerCase()}">${esc(rule.severity)}</i><i class="mini-tag">${esc(rule.category)}</i>${rule.enabled ? "" : `<i class="mini-tag">motor varsayılanında kapalı</i>`}</span></span></label>`).join("") || `<p class="muted small">Filtreye uyan kural yok.</p>`;
  byId("ruleCount").textContent = `${APP.selectedRules.size} / ${APP.rules.length}`;
  byId("runRuleCount").textContent = `${APP.selectedRules.size} kuralı`;
  byId("rulesEmptyNote").classList.toggle("hidden", APP.selectedRules.size !== 0);
}

function toggleRule(id, checked){
  checked ? APP.selectedRules.add(id) : APP.selectedRules.delete(id);
  byId("ruleProfileSelect").value = "custom";
  renderRules(); renderOverview();
}
function selectVisibleRules(checked){ visibleRules().forEach(rule => checked ? APP.selectedRules.add(rule.id) : APP.selectedRules.delete(rule.id)); byId("ruleProfileSelect").value="custom"; renderRules(); renderOverview(); }
function clearRules(){ APP.selectedRules.clear(); byId("ruleProfileSelect").value="none"; renderRules(); renderOverview(); }
function applyRuleProfile(id){
  if (id === "custom") return;
  const profile = APP.ruleProfiles.find(item => item.id === id);
  if (!profile) return;
  APP.selectedRules = new Set(profile.rule_ids);
  renderRules(); renderOverview();
  toast(`${profile.name}: ${profile.rule_count} kural seçildi.`);
}
async function saveRuleSelection(){
  const result = await api("/api/settings", {selected_rule_ids:ruleIds(),gate_policy:byId("gatePolicy").value});
  APP.state.settings = result.settings;
  toast(`${APP.selectedRules.size} kural varsayılan seçim olarak kaydedildi.`);
}

// --------------------------------------------------------------- examples
function populateExamples(){
  const options = APP.examples.map(item => `<option value="${attr(item.id)}">${esc(item.name)} — ${esc(item.expected)}</option>`).join("");
  byId("exampleSelect").innerHTML = `<option value="">Örnek seçin</option>${options}`;
  byId("requestExample").innerHTML = `<option value="">Örnek seçin</option>${options}`;
  byId("runExample").innerHTML = `<option value="">Örnek seçin</option>${options}`;
  byId("orkestraExample").innerHTML = `<option value="">Örnek seçin</option>${options}`;
}
function populatePipelineControls(){const options=APP.pipelines.map(pipe=>`<option value="${attr(pipe.id)}">${esc(pipe.name)} (${esc(pipe.applies_to.join(" / "))})</option>`).join("");const select=byId("requestPipelineType"),old=select.value;select.innerHTML=options;select.value=old&&APP.pipelines.some(pipe=>pipe.id===old)?old:(APP.pipelines[0]?.id||"");}
function loadExample(id){
  const item = APP.examples.find(example => example.id === id);
  if (!item) return;
  byId("parseScript").value = item.script;
  byId("parseName").value = item.script_name;
  updateEditorStats();
  toast(`${item.name} editöre yüklendi.`);
}
function loadRequestExample(id){
  const item = APP.examples.find(example => example.id === id);
  if (!item) return;
  byId("requestScript").value = item.script;
  byId("requestFile").value = item.script_name;
  byId("requestTitle").value = item.name;
}
function loadRunExample(id){const item=APP.examples.find(example=>example.id===id);if(!item)return;byId("runScript").value=item.script;byId("runScriptName").value=item.script_name;if(!byId("runTitle").value)byId("runTitle").value=item.name;}
function loadOrkestraExample(id){const item=APP.examples.find(example=>example.id===id);if(!item)return;byId("orkestraScript").value=item.script;byId("orkestraScriptName").value=item.script_name;if(!byId("orkestraTitle").value)byId("orkestraTitle").value=item.name;}
function copyParseToRun(){byId("runScript").value=byId("parseScript").value;byId("runScriptName").value=byId("parseName").value||"01-change.sql";toast("Parse editöründeki script koşuma aktarıldı.");}
function clearEditor(){ byId("parseScript").value=""; byId("parseResult").className="result-space empty-state"; byId("parseResult").innerHTML="<strong>Analiz sonucu burada görünecek</strong>"; updateEditorStats(); }
function updateEditorStats(){ const value=byId("parseScript").value; byId("editorStats").textContent=`${value ? value.split(/\r?\n/).length : 0} satır, ${value.length} karakter`; }
byId("parseScript").addEventListener("input", updateEditorStats);

// ------------------------------------------------------------------ parse
async function runParse(){
  const script = byId("parseScript").value;
  if (!script.trim()) return toast("Analiz için bir script girin.", true);
  byId("parseResult").className = "result-space empty-state";
  byId("parseResult").innerHTML = "<strong>Script analiz ediliyor</strong>";
  try {
    const policy=byId("gatePolicy").value;
    if(policy!==APP.state.settings.gate_policy){const settings=await api("/api/settings",{gate_policy:policy});APP.state.settings=settings.settings;}
    const result = await api("/api/parse", {script, name:byId("parseName").value || "01-change.sql", selected_rule_ids:ruleIds()});
    renderParseResult(result);
  } catch (error) {
    byId("parseResult").innerHTML = `<strong>Analiz çalışmadı</strong><p>${esc(error.message)}</p>`;
    toast(error.message, true);
  }
}

function renderParseResult(result){
  const validation = result.validation || {}, summary = validation.summary || {}, inv = result.inventory || {};
  const verdictClass = result.would_run ? "" : (validation.verdict === "WARN" ? "warn" : "blocked");
  const decision = result.would_run ? "ÇALIŞTIRILABİLİR" : "ÇALIŞTIRILMAZ";
  const classes = (inv.classes || []).map(item => `<span class="chip ${String(item.key).toLowerCase()}">${esc(item.label)} ${item.count}</span>`).join("");
  const statements = (inv.statements || []).map(item => `<tr><td><code>${item.line}${item.end_line !== item.line ? `–${item.end_line}` : ""}</code></td><td><span class="chip ${String(item.cls).toLowerCase()}">${esc(item.cls)}</span></td><td><strong>${esc(item.verb)}</strong></td><td><code>${esc(item.object_name || item.preview)}</code></td></tr>`).join("");
  const findings = (validation.findings || []).map(finding => `<div class="finding"><div><span class="finding-code">${esc(finding.rule_id)}</span><br>${statusPill(finding.severity)}</div><div><h4>Satır ${esc(finding.line || "-")} — ${esc(finding.message)}</h4>${finding.evidence ? `<p><code>${esc(finding.evidence)}</code></p>` : ""}${finding.remediation ? `<p class="remediation"><strong>Öneri:</strong> ${esc(finding.remediation)}</p>` : ""}</div></div>`).join("");

  byId("parseResult").className = "result-space";
  byId("parseResult").innerHTML = `
    <div class="verdict-banner ${verdictClass}"><div><p class="eyebrow">KAPI KARARI</p><h2>Bu script ${decision}</h2><p>${esc(result.reason)}</p></div><span class="verdict-code">${esc(validation.verdict || "ERROR")}</span></div>
    <div class="stat-strip"><div><strong>${validation.rules_active || 0}</strong><span>Çalışan kural</span></div><div><strong>${summary.fail || 0}</strong><span>Fail</span></div><div><strong>${summary.warn || 0}</strong><span>Warn</span></div><div><strong>${inv.statement_count_all || 0}</strong><span>İfade</span></div></div>
    <div class="analysis-grid">
      <article class="panel"><div class="panel-heading"><div><p class="eyebrow">YAPI</p><h2>Script envanteri</h2></div></div><p>${esc(inv.summary_text || "İfade bulunamadı")}</p><div class="chips">${classes || `<span class="chip">BOŞ</span>`}</div><p class="muted small">SHA-256: <code>${esc((inv.sha256 || "").slice(0,16))}</code></p></article>
      <article class="panel"><div class="panel-heading"><div><p class="eyebrow">İFADELER</p><h2>Parse dökümü</h2></div><span class="count-badge">${(inv.statements || []).length}</span></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Satır</th><th>Sınıf</th><th>Fiil</th><th>Obje / ifade</th></tr></thead><tbody>${statements || `<tr><td colspan="4">İfade bulunamadı.</td></tr>`}</tbody></table></div></article>
    </div>
    <article class="panel"><div class="panel-heading"><div><p class="eyebrow">BULGULAR</p><h2>Validator açıklamaları</h2></div><span class="count-badge">${(validation.findings || []).length}</span></div>${findings || `<div class="inline-note">Seçili kurallar bu script için bulgu üretmedi.</div>`}</article>`;
}

// --------------------------------------------------------------- pipeline
function slugify(value){return String(value||"").toLocaleLowerCase("tr-TR").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/ı/g,"i").replace(/[^a-z0-9]+/g,"_").replace(/^_+|_+$/g,"").slice(0,48);}
function suggestPipelineId(){if(!byId("builderId").dataset.edited)byId("builderId").value=slugify(byId("builderName").value);}
byId("builderId").addEventListener("input",()=>byId("builderId").dataset.edited="1");
function resetPipelineBuilder(){APP.builderTargets=[];byId("builderName").value="";byId("builderId").value="";byId("builderId").dataset.edited="";byId("builderDescription").value="";byId("builderGatePolicy").value="PASS_ONLY";renderPipelineBuilder();}
function renderPipelineBuilder(){
  const available=APP.state.targets.filter(target=>target.enabled!==false);
  byId("builderTargetSelect").innerHTML=`<option value="">Hedef seçin</option>`+available.map(target=>`<option value="${attr(target.id)}">${esc(target.environment)} — ${esc(target.name)} / ${esc(target.database_name)}</option>`).join("");
  byId("builderStageCount").textContent=`${APP.builderTargets.length} hedef`;
  byId("builderTargetSequence").innerHTML=APP.builderTargets.map((id,index)=>{const target=APP.state.targets.find(item=>item.id===id);if(!target)return"";return `<div class="sequence-item"><span class="sequence-number">${String(index+1).padStart(2,"0")}</span><div><strong>${esc(target.name)}</strong><small>${esc(target.environment)} · ${esc(target.database_name)} · ${esc(target.dsn_preview)}</small></div><div class="sequence-actions"><button class="button quiet small" ${index===0?"disabled":""} onclick="moveBuilderTarget(${index},-1)">Yukarı</button><button class="button quiet small" ${index===APP.builderTargets.length-1?"disabled":""} onclick="moveBuilderTarget(${index},1)">Aşağı</button><button class="text-button danger-text" onclick="removeBuilderTarget(${index})">Kaldır</button></div></div>`;}).join("")||`<div class="empty-state small-empty"><strong>Hedef sırası boş</strong><p>Önce TEST, sonra PREPROD, ardından PROD hedefini ekleyebilirsiniz.</p></div>`;
}
function addBuilderTarget(){const id=byId("builderTargetSelect").value;if(!id)return toast("Sıraya eklenecek hedefi seçin.",true);if(APP.builderTargets.includes(id))return toast("Bu hedef zaten pipeline sırasında bulunuyor.",true);APP.builderTargets.push(id);renderPipelineBuilder();}
function moveBuilderTarget(index,direction){const next=index+direction;if(next<0||next>=APP.builderTargets.length)return;[APP.builderTargets[index],APP.builderTargets[next]]=[APP.builderTargets[next],APP.builderTargets[index]];renderPipelineBuilder();}
function removeBuilderTarget(index){APP.builderTargets.splice(index,1);renderPipelineBuilder();}
async function saveGeneratedPipeline(){const applies=[];if(byId("builderDdl").checked)applies.push("DDL");if(byId("builderDml").checked)applies.push("DML");if(byId("builderDcl").checked)applies.push("DCL");const spec={id:byId("builderId").value.trim(),name:byId("builderName").value.trim(),description:byId("builderDescription").value.trim(),target_ids:APP.builderTargets,applies_to:applies,require_identical:byId("builderIdentical").checked,approval_on_prod:byId("builderApproval").checked,auto_prepare_requests:byId("builderRequests").checked,gate_policy:byId("builderGatePolicy").value};const r=await api("/api/pipelines/generate",{pipeline:spec});if(!r.ok)return toast(r.error,true);const catalog=await api("/api/pipelines");APP.pipelines=catalog.pipelines||[];APP.pipelineCapabilities=catalog.capabilities||{};APP.selectedPipelineId=r.pipeline.id;populatePipelineControls();renderPipelinePage();renderOverview();toast(`${r.pipeline.name} hedef sırasından oluşturuldu.`);}
function renderPipelinePage(){ renderPipelineBuilder(); renderPipelineCatalog(); renderRuns(); if (APP.currentRun) renderRunDetail(APP.currentRun); }
function renderPipelineCatalog(){
  if (!APP.selectedPipelineId && APP.pipelines.length) APP.selectedPipelineId = APP.pipelines[0].id;
  byId("pipelineCatalog").innerHTML = APP.pipelines.map(pipe => {
    const envs=[...new Set(pipe.stages.map(stage => stage.env).filter(Boolean))];
    return `<button class="pipeline-option ${pipe.id===APP.selectedPipelineId?"active":""}" onclick="selectPipeline('${attr(pipe.id)}')"><strong>${esc(pipe.name)}</strong><span>${esc(pipe.applies_to.join(" / "))} · ${pipe.stages.length} aşama</span><span class="flow">${esc(envs.join(" / ") || "BAĞLANTISIZ")}</span></button>`;
  }).join("");
  renderSelectedPipeline();
}
function selectPipeline(id){ APP.selectedPipelineId=id; renderPipelineCatalog(); }
function renderSelectedPipeline(){
  const pipe=APP.pipelines.find(item=>item.id===APP.selectedPipelineId);
  if(!pipe){byId("selectedPipelineInfo").innerHTML="";return;}
  const flow=pipe.stages.map(stage=>`${stage.env || "GENEL"}: ${stage.name}`).join(" / ");
  byId("selectedPipelineInfo").innerHTML=`<p class="eyebrow">SEÇİLİ AKIŞ</p><h2>${esc(pipe.name)}</h2><p>${esc(pipe.description)}</p><p class="small"><code>${esc(flow)}</code></p>`;
  const caps=APP.pipelineCapabilities;
  byId("pipelineCapabilities").textContent=`Aşama tipleri: ${(caps.stage_types||[]).join(", ")} · Çalıştırıcılar: ${(caps.executors||[]).join(", ")} · Kapılar: ${(caps.gates||[]).map(item=>item.id).join(", ")}`;
}
function loadPipelineDefinition(copy=false){const pipe=APP.pipelines.find(item=>item.id===APP.selectedPipelineId);if(!pipe)return toast("Önce bir pipeline seçin.",true);const data=JSON.parse(JSON.stringify(pipe));if(copy){data.id=`${data.id}-copy`;data.name=`${data.name} kopyası`;}byId("pipelineDefinition").value=JSON.stringify(data,null,2);}
async function savePipelineDefinition(){let definition;try{definition=JSON.parse(byId("pipelineDefinition").value);}catch(error){return toast(`JSON okunamadı: ${error.message}`,true);}const r=await api("/api/pipelines/save",{pipeline:definition});if(!r.ok)return toast(r.error,true);const catalog=await api("/api/pipelines");APP.pipelines=catalog.pipelines||[];APP.pipelineCapabilities=catalog.capabilities||{};APP.selectedPipelineId=definition.id;populatePipelineControls();renderPipelinePage();renderOverview();toast(r.created?"Yeni pipeline eklendi.":"Pipeline tanımı güncellendi.");}
async function deletePipelineDefinition(){const pipe=APP.pipelines.find(item=>item.id===APP.selectedPipelineId);if(!pipe||!confirm(`${pipe.name} tanımını katalogdan kaldırmak istiyor musunuz? Mevcut koşum snapshot'ları etkilenmez.`))return;const r=await api(`/api/pipelines/${pipe.id}/delete`,{});if(!r.ok)return toast(r.error,true);const catalog=await api("/api/pipelines");APP.pipelines=catalog.pipelines||[];APP.pipelineCapabilities=catalog.capabilities||{};APP.selectedPipelineId=APP.pipelines[0]?.id||"";byId("pipelineDefinition").value="";renderPipelinePage();renderOverview();toast("Pipeline tanımı kaldırıldı.");}
async function createRun(){
  if(!APP.selectedPipelineId) return toast("Bir pipeline seçin.",true);
  const title=byId("runTitle").value.trim();
  if(!title) return toast("Koşum başlığı zorunlu.",true);
  const script=byId("runScript").value;
  if(byId("runAutoRequests").checked&&!script.trim())return toast("Hazır talepler için referans script seçin veya yapıştırın.",true);
  const result=await api("/api/runs",{pipeline_id:APP.selectedPipelineId,title,owner:byId("runOwner").value.trim(),selected_rule_ids:ruleIds(),reference_script:script,script_name:byId("runScriptName").value||"01-change.sql",auto_prepare_requests:byId("runAutoRequests").checked});
  if(!result.ok) return toast(result.error||"Koşum oluşturulamadı.",true);
  byId("runTitle").value=""; await refreshAll(); await selectRun(result.run.id); toast(`${result.run.id} başladı; ${(result.prepared_requests||[]).length} talep hazırlandı.`);
}
function renderRuns(){
  const runs=[...APP.state.runs].reverse();
  byId("runsList").innerHTML=runs.map(run=>{const done=run.stages.filter(stage=>stage.status==="DONE").length;const pct=run.stages.length?Math.round(done*100/run.stages.length):0;return `<div class="run-row"><code>${esc(run.id)}</code><div><strong>${esc(run.title)}</strong><small>${esc(run.pipeline_name)}</small><div class="progress"><i style="width:${pct}%"></i></div></div><div>${statusPill(run.status)} <small>${done}/${run.stages.length} aşama</small></div><button class="button quiet small" onclick="selectRun('${attr(run.id)}')">Detay</button></div>`;}).join("")||`<p class="muted">Henüz pipeline koşumu yok.</p>`;
}
async function selectRun(id){
  const result=await api(`/api/runs/${encodeURIComponent(id)}`);
  if(!result.ok) return toast(result.error,true);
  APP.currentRun=result.run; APP.currentRun.identity=result.identity; renderRunDetail(APP.currentRun);
}
function requestOptions(env,current){
  return `<option value="">Talep seçin</option>`+APP.state.talepler.filter(item=>item.env===env).map(item=>`<option value="${attr(item.talep_no)}" ${item.talep_no===current?"selected":""}>${esc(item.talep_no)} — ${esc(item.title)}</option>`).join("");
}
function targetOptions(env,current){
  return `<option value="">Deployment hedefi seçin</option>`+APP.state.targets.filter(item=>item.environment===env&&item.enabled!==false).map(item=>`<option value="${attr(item.id)}" ${item.id===current?"selected":""}>${esc(item.name)} — ${esc(item.database_name)}</option>`).join("");
}
function renderQuickRunner(run){const next=run.stages.find(stage=>stage.status!=="DONE");if(!next)return `<div class="quick-runner quick-done"><h3>Pipeline tamamlandı</h3><p>Tüm talepler, validator kontrolleri, onaylar ve deployment aşamaları tamamlandı.</p></div>`;const target=APP.state.targets.find(item=>item.id===next.target_id);let controls="";if(next.type==="APPROVAL")controls+=`<label class="field"><span>Onaylayan kullanıcı</span><input id="quickApprover" placeholder="Talep sahibinden farklı kullanıcı"></label>`;if(next.type==="DEPLOY"&&String(next.executor||"OCTOPUS").toUpperCase()==="DATABASE"){controls+=`<label class="field"><span>Bu istek için parola</span><input id="quickPassword" type="password" placeholder="İlk deployment'ta gerekli"></label><label class="field"><span>Transaction</span><select id="quickTransaction"><option value="SCRIPT">Script yönetsin</option><option value="COMMIT_AFTER_SUCCESS">Başarıda commit</option><option value="ROLLBACK_AFTER_TEST">Test sonrası rollback</option></select></label>`;if(next.env==="PROD")controls+=`<label class="field"><span>PROD onayı: ${esc(target?.name||"hedef adı")}</span><input id="quickConfirmation" placeholder="Hedef adını birebir yazın"></label>`;}return `<div class="quick-runner"><p class="eyebrow">SIRADAKİ TEK ADIM</p><h3>${esc(next.name)}</h3><p>${esc(next.env)} · ${esc(next.type)}${target?` · ${esc(target.name)} → ${esc(target.database_name)}`:""}</p><div class="quick-controls">${controls}<button class="button primary" onclick="advanceRun('${attr(run.id)}')">Bu adımı çalıştır ve ilerle</button></div></div>`;}
function renderRunDetail(run){
  const done=run.stages.filter(stage=>stage.status==="DONE").length;
  const stages=run.stages.map((stage,index)=>{
    const checks=(stage.checks||[]).map(check=>`<div class="gate ${check.ok?"ok":"bad"}"><strong>${esc(check.label)}</strong><span>${esc(check.detail)}</span></div>`).join("");
    let actions="";
    if(stage.type==="TALEP") actions=`<label class="field"><span>${esc(stage.env)} talebi</span><select id="attach-${attr(stage.id)}">${requestOptions(stage.env,stage.talep_no)}</select></label><button class="button quiet small" onclick="attachRequest('${attr(run.id)}','${attr(stage.id)}')">Talebi bağla</button>${stage.talep_no&&index>0?`<button class="button quiet small" onclick="writePreviousDeployment('${attr(run.id)}','${attr(stage.id)}','${attr(stage.talep_no)}')">Önceki deployment'ı talebe yaz</button>`:""}`;
    if(stage.type==="VALIDATE") actions=`<button class="button quiet small" onclick="pipelineAction('${attr(run.id)}','${attr(stage.id)}','validate')">Validator'u çalıştır</button>${stage.validation?statusPill(stage.validation.verdict):""}`;
    if(stage.type==="APPROVAL") actions=`<label class="field"><span>Onaylayan</span><input id="approval-${attr(stage.id)}" value="${attr(stage.approved_by||"")}" placeholder="Talep sahibinden farklı kullanıcı"></label><button class="button quiet small" onclick="approveStage('${attr(run.id)}','${attr(stage.id)}')">Onayla</button>`;
    if(stage.type==="DEPLOY"&&String(stage.executor||"OCTOPUS").toUpperCase()==="DATABASE") actions=`<label class="field"><span>${esc(stage.env)} deployment hedefi</span><select id="stage-target-${attr(stage.id)}">${targetOptions(stage.env,stage.target_id)}</select></label><label class="field"><span>Parola</span><input id="stage-pw-${attr(stage.id)}" type="password" placeholder="Gerekirse"></label>${stage.env==="PROD"?`<label class="field"><span>PROD onayı: hedef adı</span><input id="stage-confirm-${attr(stage.id)}" placeholder="Hedef adını yazın"></label>`:""}<label class="field"><span>Transaction</span><select id="stage-tx-${attr(stage.id)}"><option value="SCRIPT">Script yönetsin</option><option value="COMMIT_AFTER_SUCCESS">Başarıda commit</option><option value="ROLLBACK_AFTER_TEST">Test sonrası rollback</option></select></label><button class="button primary small" onclick="runDatabaseDeployment('${attr(run.id)}','${attr(stage.id)}')">Oracle'da çalıştır</button>`;
    if(stage.type==="DEPLOY"&&String(stage.executor||"OCTOPUS").toUpperCase()!=="DATABASE") actions=`<button class="button quiet small" onclick="pipelineAction('${attr(run.id)}','${attr(stage.id)}','deploy')">Octopus deployment oluştur</button>${stage.deployment_id?`<button class="button quiet small" onclick="setDeploymentResult('${attr(stage.deployment_id)}',true)">Başarılı işaretle</button><button class="button quiet small" onclick="setDeploymentResult('${attr(stage.deployment_id)}',false)">Başarısız işaretle</button>`:""}`;
    const complete=`<button class="button ${stage.status==="READY"?"primary":"quiet"} small" ${stage.status==="READY"?"":"disabled"} onclick="pipelineAction('${attr(run.id)}','${attr(stage.id)}','complete')">Aşamayı tamamla</button>`;
    return `<article class="stage-card ${String(stage.status).toLowerCase()}"><div class="stage-top"><div><p class="eyebrow">${String(index+1).padStart(2,"0")} · ${esc(stage.env||"GENEL")} · ${esc(stage.type)}${stage.executor?` · ${esc(stage.executor)}`:""}</p><h3>${esc(stage.name)}</h3><p>${esc(stage.help||"")}</p></div>${statusPill(stage.status)}</div><div class="gate-list">${checks||`<div class="gate ok"><strong>Kapı yok</strong><span>Aşama doğrudan ilerleyebilir.</span></div>`}</div><div class="stage-actions">${actions}${complete}</div></article>`;
  }).join("");
  const identity=run.identity||{};
  byId("runDetail").className="";
  byId("runDetail").innerHTML=`<article class="panel"><div class="run-summary"><div><p class="eyebrow">${esc(run.id)} · ${esc(run.pipeline_name)}</p><h2>${esc(run.title)}</h2><p class="muted small">Sahip: ${esc(run.owner)} · ${run.selected_rule_ids?.length||0} kural snapshot · ${esc(run.gate_policy||"PASS_ONLY")} · Oluşturma: ${esc(run.created_at)}</p></div><div>${statusPill(run.status)} <span class="count-badge">${done}/${run.stages.length}</span></div></div>${renderQuickRunner(run)}<div class="stage-list">${stages}</div><div class="inline-note ${identity.identical===false?"danger":""}"><strong>Script identiklik raporu:</strong> ${esc(identity.message||"Henüz talep bağlanmadı.")}</div></article>`;
  byId("runDetail").scrollIntoView({behavior:"smooth",block:"start"});
}
async function attachRequest(runId,stageId){const value=byId(`attach-${stageId}`).value;if(!value)return toast("Bir talep seçin.",true);const r=await api(`/api/runs/${runId}/attach`,{stage_id:stageId,talep_no:value});if(!r.ok)return toast(r.error,true);await refreshAll();await selectRun(runId);}
async function pipelineAction(runId,stageId,action){const r=await api(`/api/runs/${runId}/${action}`,{stage_id:stageId});if(!r.ok)toast(r.error||"Aksiyon tamamlanamadı.",true);else toast("Pipeline aşaması güncellendi.");await refreshAll();await selectRun(runId);}
async function approveStage(runId,stageId){const who=byId(`approval-${stageId}`).value.trim();if(!who)return toast("Onaylayan kullanıcı zorunlu.",true);const r=await api(`/api/runs/${runId}/approve`,{stage_id:stageId,who});if(!r.ok)return toast(r.error,true);await refreshAll();await selectRun(runId);}
async function runDatabaseDeployment(runId,stageId){const targetId=byId(`stage-target-${stageId}`).value;const target=APP.state.targets.find(item=>item.id===targetId);if(!target)return toast("Aşama ortamına ait deployment hedefini seçin.",true);const r=await api(`/api/runs/${runId}/db-deploy`,{stage_id:stageId,target_id:targetId,profile_id:target.database_profile_id,password:byId(`stage-pw-${stageId}`).value,confirmation:byId(`stage-confirm-${stageId}`)?.value||"",transaction_mode:byId(`stage-tx-${stageId}`).value});if(!r.ok)toast(r.error||"Oracle deployment başarısız.",true);else toast(`${r.deployment.id} başarıyla tamamlandı.`);await refreshAll();await selectRun(runId);}
async function advanceRun(runId){const payload={password:byId("quickPassword")?.value||"",confirmation:byId("quickConfirmation")?.value||"",approver:byId("quickApprover")?.value||"",transaction_mode:byId("quickTransaction")?.value||"SCRIPT"};const r=await api(`/api/runs/${runId}/advance`,payload);if(!r.ok)toast(r.error||"Sıradaki adım tamamlanamadı.",true);else toast(r.message||"Sıradaki adım tamamlandı.");await refreshAll();await selectRun(runId);}
async function setDeploymentResult(id,success){const r=await api(`/api/deployments/${id}/result`,{success,detail:"POC arayüzünden sonuç güncellendi"});if(!r.ok)return toast(r.detail||"Durum güncellenemedi.",true);await refreshAll();await refreshExternalSystems();if(APP.currentRun)await selectRun(APP.currentRun.id);}
async function writePreviousDeployment(runId,stageId,talepNo){const index=APP.currentRun.stages.findIndex(stage=>stage.id===stageId);const previous=[...APP.currentRun.stages.slice(0,index)].reverse().find(stage=>stage.type==="DEPLOY"&&stage.deployment_id);if(!previous)return toast("Önceki deployment kaydı bulunamadı.",true);const r=await api(`/api/talep/${talepNo}/octopus-ref`,{octopus_ref:previous.deployment_id});if(!r.ok)return toast(r.error,true);toast(`${previous.deployment_id} talebe yazıldı.`);await refreshAll();await selectRun(runId);}

// ------------------------------------------------------------ operations
function externalStatus(connection,label){const info=connection||{};return `<div class="connector-banner ${info.ok?"ready":"missing"}"><div><p class="eyebrow">${esc(label)} · ${esc(info.mode||"-")}</p><strong>${info.ok?"Bağlantı hazır":"Bağlantı kurulamadı"}</strong><span>${esc(info.detail||"")}</span></div>${statusPill(info.ok?"READY":"FAILED")}</div>`;}
function renderOperations(){
  const requests=APP.state.operation_requests||[];
  const pending=requests.filter(item=>item.status==="PENDING");
  const success=requests.filter(item=>item.status==="SUCCESS").length;
  const failed=requests.filter(item=>item.status==="FAILED").length;
  byId("operationMetrics").innerHTML=[
    [pending.length,"Onay bekleyen talep","Tek tıkla Oracle'da çalıştırılır","amber"],
    [success,"Başarılı çalışma","Tamamlanan script talepleri","green"],
    [failed,"Başarısız çalışma","Oracle hata kayıtları",failed?"red":""],
    [(APP.state.operation_pipelines||[]).length,"Tanımlı pipeline",`${APP.state.databases.length} veritabanı`,""]
  ].map(([value,label,detail,kind])=>`<article class="metric ${kind}"><strong>${value}</strong><span>${esc(label)}</span><small>${esc(detail)}</small></article>`).join("");
  byId("operationIncomingCount").textContent=pending.length;
  byId("operationIncoming").innerHTML=pending.map(item=>`<article class="approval-card"><div class="approval-card-top"><div><code>${esc(item.id)}</code><h3>${esc(item.title)}</h3><p>${esc(item.pipeline_name)} · ${esc(item.database_name)} · ${esc(item.owner)}</p></div>${statusPill(item.status)}</div><div class="evidence-line"><span>Veritabanı<strong>${esc(item.database_name)}</strong></span><span>Pipeline adımı<strong>${item.step_number}/${item.step_count}</strong></span><span>Dosya<strong>${esc(item.script_name)}</strong></span></div><details class="script-preview"><summary>Scripti görüntüle</summary><pre>${esc(item.script)}</pre></details><button class="button primary full-button" onclick="approveOperationRequest('${attr(item.id)}',this)">Onayla ve veritabanında çalıştır</button></article>`).join("")||`<div class="empty-state small-empty"><strong>Onay bekleyen talep yok</strong><p>Orkestra Mock ekranından bir script talebi gönderebilirsiniz.</p></div>`;
  const history=[...requests].filter(item=>!['PENDING','EXECUTING'].includes(item.status)).reverse();
  byId("operationHistoryCount").textContent=history.length;
  byId("operationHistory").innerHTML=history.map(item=>`<div class="external-row"><div><code>${esc(item.id)}</code><strong>${esc(item.title)}</strong><small>${esc(item.database_name)} · ${esc(item.pipeline_name)} · ${esc(item.completed_at||item.created_at)}</small><small>${esc(item.result_message||item.error||"")}</small></div><div>${statusPill(item.status)}${item.deployment_id?`<small class="record-id">${esc(item.deployment_id)}</small>`:""}</div></div>`).join("")||`<div class="empty-state small-empty"><strong>Henüz sonuç yok</strong><p>Onaylanan talepler burada listelenecek.</p></div>`;
}

async function approveOperationRequest(id,button){
  button.disabled=true;button.textContent="Oracle'da çalıştırılıyor...";
  let result;
  try{result=await api(`/api/operation-requests/${encodeURIComponent(id)}/approve`,{});}
  catch(error){button.disabled=false;button.textContent="Onayla ve veritabanında çalıştır";return toast(error.message,true);}
  await refreshAll();await refreshExternalSystems();
  if(!result.ok)return toast(result.error||"Talep onaylanamadı.",true);
  if(!result.execution_ok)return toast(result.execution?.error||"Script Oracle üzerinde başarısız oldu.",true);
  toast(`${id} onaylandı ve Oracle üzerinde başarıyla çalıştırıldı.`);
}

function renderOperationDatabases(){
  const driver=APP.health.database_driver||{};
  byId("operationDbDriver").innerHTML=`<div class="connector-banner ${driver.installed?"ready":"missing"}"><div><p class="eyebrow">ORACLE DRIVER</p><strong>${driver.installed?`${esc(driver.name)} ${esc(driver.version)} hazır`:"python-oracledb kurulu değil"}</strong><span>${driver.installed?"Eklenen bağlantılar gerçek Oracle üzerinde test edilebilir.":esc(driver.install||"")}</span></div>${statusPill(driver.installed?"READY":"MISSING")}</div>`;
  const list=APP.state.databases||[];
  byId("operationDbCount").textContent=list.length;
  byId("operationDbList").innerHTML=list.map(db=>{const execution=(APP.state.db_executions||[]).find(item=>item.profile_id===db.id);return `<article class="external-card"><div class="external-card-top"><div><code>${esc(db.id)}</code><h3>${esc(db.name)}</h3><p>${esc(db.username)}@${esc(db.dsn_preview)}</p></div>${statusPill(db.last_test?.ok?"CONNECTED":(db.secret_available?"READY":"PASSWORD"))}</div><div class="chips"><span class="chip">${db.secret_available?"Parola hazır":"Parola yüklenmeli"}</span>${db.last_test?`<span class="chip">Son test: ${db.last_test.ok?"Başarılı":"Başarısız"}</span>`:""}</div>${execution?`<div class="db-last-test">Son script: <strong>${esc(execution.script_name)}</strong> · ${execution.ok?"Başarılı":"Başarısız"} · ${esc(execution.id)} · ${execution.duration_ms||0} ms</div>`:""}${db.last_test&&!db.last_test.ok?`<p class="operation-error">${esc(db.last_test.error||"")}</p>`:""}<div class="external-actions"><button class="button quiet small" onclick="testOperationDatabase('${attr(db.id)}')">Bağlantıyı test et</button><button class="text-button" onclick="editOperationDatabase('${attr(db.id)}')">Düzenle</button><button class="text-button danger-text" onclick="deleteOperationDatabase('${attr(db.id)}')">Sil</button></div></article>`;}).join("")||`<div class="empty-state small-empty"><strong>Veritabanı eklenmemiş</strong><p>İlk Oracle bağlantısını soldaki formdan ekleyin.</p></div>`;
}

function resetOperationDatabaseForm(){
  byId("operationDbId").value="";byId("operationDbName").value="";byId("operationDbHost").value="127.0.0.1";byId("operationDbPort").value="1521";byId("operationDbService").value="FREEPDB1";byId("operationDbConnectString").value="";byId("operationDbUsername").value="RUNNER";byId("operationDbPassword").value="run123";byId("operationDbFormTitle").textContent="Yeni veritabanı ekle";
}

function editOperationDatabase(id){
  const db=APP.state.databases.find(item=>item.id===id);if(!db)return;
  byId("operationDbId").value=db.id;byId("operationDbName").value=db.name;byId("operationDbHost").value=db.host||"";byId("operationDbPort").value=db.port||1521;byId("operationDbService").value=db.service_name||"";byId("operationDbConnectString").value=db.connect_string||"";byId("operationDbUsername").value=db.username||"";byId("operationDbPassword").value="";byId("operationDbFormTitle").textContent=`${db.name} bağlantısını düzenle`;window.scrollTo({top:0,behavior:"smooth"});
}

async function saveOperationDatabase(){
  const payload={id:byId("operationDbId").value,name:byId("operationDbName").value.trim(),host:byId("operationDbHost").value.trim(),port:byId("operationDbPort").value,service_name:byId("operationDbService").value.trim(),connect_string:byId("operationDbConnectString").value.trim(),username:byId("operationDbUsername").value.trim(),password:byId("operationDbPassword").value};
  const result=await api("/api/operation-databases",payload);if(!result.ok)return toast(result.error,true);
  resetOperationDatabaseForm();await refreshAll();toast(`${result.profile.name} veritabanı kaydedildi.`);
}

async function testOperationDatabase(id){
  const db=APP.state.databases.find(item=>item.id===id);let password="";
  if(!db?.secret_available){password=prompt("Veritabanı parolası:")||"";if(!password)return;}
  const result=await api(`/api/operation-databases/${encodeURIComponent(id)}/test`,{password});await refreshAll();
  if(!result.ok)return toast(result.error,true);toast(`${db.name} bağlantısı başarılı.`);
}

async function deleteOperationDatabase(id){
  const db=APP.state.databases.find(item=>item.id===id);if(!db||!confirm(`${db.name} bağlantısını silmek istiyor musunuz?`))return;
  const result=await api(`/api/operation-databases/${encodeURIComponent(id)}/delete`,{});if(!result.ok)return toast(result.error,true);await refreshAll();toast("Veritabanı bağlantısı silindi.");
}

function renderOperationPipelines(){
  const databases=APP.state.databases||[],selected=byId("operationPipelineDatabase").value;
  byId("operationPipelineDatabase").innerHTML=`<option value="">Veritabanı seçin</option>`+databases.map(db=>`<option value="${attr(db.id)}">${esc(db.name)}</option>`).join("");
  if(databases.some(db=>db.id===selected))byId("operationPipelineDatabase").value=selected;
  APP.operationPipelineSteps=APP.operationPipelineSteps.filter(id=>databases.some(db=>db.id===id));
  renderOperationPipelineSequence();
  const list=APP.state.operation_pipelines||[];byId("operationPipelineCount").textContent=list.length;
  byId("operationPipelineList").innerHTML=list.map(pipe=>`<article class="external-card"><div class="external-card-top"><div><code>${esc(pipe.id)}</code><h3>${esc(pipe.name)}</h3><p>${esc(pipe.description||"Sıralı veritabanı akışı")}</p></div>${statusPill(pipe.available?"READY":"BROKEN")}</div><div class="pipeline-route">${(pipe.steps||[]).map(step=>`<span>${esc(step.database_name)}</span>`).join("<i></i>")}</div><div class="external-actions"><button class="text-button" onclick="editOperationPipeline('${attr(pipe.id)}')">Düzenle</button><button class="text-button danger-text" onclick="deleteOperationPipeline('${attr(pipe.id)}')">Sil</button></div></article>`).join("")||`<div class="empty-state small-empty"><strong>Pipeline oluşturulmamış</strong><p>Veritabanlarını soldaki alanda sıraya dizin.</p></div>`;
  populateOperationRequestControls();
}

function renderOperationPipelineSequence(){
  byId("operationPipelineSequence").innerHTML=APP.operationPipelineSteps.map((id,index)=>{const db=APP.state.databases.find(item=>item.id===id);return `<div class="operation-sequence-item"><b>${index+1}</b><strong>${esc(db?.name||id)}</strong><div><button class="text-button" onclick="moveOperationPipelineStep(${index},-1)" ${index===0?"disabled":""}>Yukarı</button><button class="text-button" onclick="moveOperationPipelineStep(${index},1)" ${index===APP.operationPipelineSteps.length-1?"disabled":""}>Aşağı</button><button class="text-button danger-text" onclick="removeOperationPipelineStep(${index})">Kaldır</button></div></div>`;}).join("")||`<div class="empty-state small-empty"><strong>Akış boş</strong><p>Bir veritabanı seçip sıraya ekleyin.</p></div>`;
}

function addOperationPipelineStep(){const id=byId("operationPipelineDatabase").value;if(!id)return toast("Bir veritabanı seçin.",true);if(APP.operationPipelineSteps.includes(id))return toast("Bu veritabanı zaten sırada.",true);APP.operationPipelineSteps.push(id);renderOperationPipelineSequence();}
function removeOperationPipelineStep(index){APP.operationPipelineSteps.splice(index,1);renderOperationPipelineSequence();}
function moveOperationPipelineStep(index,direction){const target=index+direction;if(target<0||target>=APP.operationPipelineSteps.length)return;[APP.operationPipelineSteps[index],APP.operationPipelineSteps[target]]=[APP.operationPipelineSteps[target],APP.operationPipelineSteps[index]];renderOperationPipelineSequence();}
function resetOperationPipelineForm(){APP.operationPipelineSteps=[];byId("operationPipelineId").value="";byId("operationPipelineName").value="";byId("operationPipelineDescription").value="";byId("operationPipelineFormTitle").textContent="Pipeline oluştur";renderOperationPipelineSequence();}
function editOperationPipeline(id){const pipe=(APP.state.operation_pipelines||[]).find(item=>item.id===id);if(!pipe)return;byId("operationPipelineId").value=pipe.id;byId("operationPipelineName").value=pipe.name;byId("operationPipelineDescription").value=pipe.description||"";APP.operationPipelineSteps=[...(pipe.database_ids||[])];byId("operationPipelineFormTitle").textContent=`${pipe.name} pipeline'ını düzenle`;renderOperationPipelineSequence();window.scrollTo({top:0,behavior:"smooth"});}
async function saveOperationPipeline(){const payload={id:byId("operationPipelineId").value,name:byId("operationPipelineName").value.trim(),description:byId("operationPipelineDescription").value.trim(),database_ids:APP.operationPipelineSteps};const result=await api("/api/operation-pipelines",payload);if(!result.ok)return toast(result.error,true);resetOperationPipelineForm();await refreshAll();toast(`${result.pipeline.name} pipeline'ı kaydedildi.`);}
async function deleteOperationPipeline(id){const pipe=(APP.state.operation_pipelines||[]).find(item=>item.id===id);if(!pipe||!confirm(`${pipe.name} pipeline'ını silmek istiyor musunuz?`))return;const result=await api(`/api/operation-pipelines/${encodeURIComponent(id)}/delete`,{});if(!result.ok)return toast(result.error,true);await refreshAll();toast("Pipeline silindi.");}

function populateOperationRequestControls(){
  const select=byId("orkestraPipelineType"),old=select.value,pipelines=APP.state.operation_pipelines||[];
  select.innerHTML=`<option value="">Pipeline seçin</option>`+pipelines.map(pipe=>`<option value="${attr(pipe.id)}">${esc(pipe.name)} — ${esc(pipe.sequence_label)}</option>`).join("");
  if(pipelines.some(pipe=>pipe.id===old))select.value=old;updateOrkestraForm();
}

function updateOrkestraForm(){
  const pipeline=(APP.state.operation_pipelines||[]).find(item=>item.id===byId("orkestraPipelineType").value),select=byId("orkestraDatabase"),old=select.value;
  select.innerHTML=`<option value="">Veritabanı seçin</option>`+(pipeline?.steps||[]).map(step=>`<option value="${attr(step.database_id)}">${step.position}. ${esc(step.database_name)}</option>`).join("");
  if((pipeline?.steps||[]).some(step=>step.database_id===old))select.value=old;
}

async function createOrkestraRequest(){
  const payload={pipeline_id:byId("orkestraPipelineType").value,database_id:byId("orkestraDatabase").value,owner:byId("orkestraOwner").value.trim()||APP.user,title:byId("orkestraTitle").value.trim(),script_name:byId("orkestraScriptName").value||"01-change.sql",script:byId("orkestraScript").value};
  if(!payload.pipeline_id||!payload.database_id||!payload.title||!payload.script.trim())return toast("Pipeline, veritabanı, başlık ve script zorunlu.",true);
  const result=await api("/api/operation-requests",payload);if(!result.ok)return toast(result.error,true);await refreshAll();toast(`${result.request.id} talebi uygulamaya gönderildi.`);
}

function renderOrkestra(connection){
  const list=[...(APP.state.operation_requests||[])].reverse();byId("orkestraStatus").innerHTML=externalStatus(connection,"ORKESTRA MOCK");byId("orkestraRequestCount").textContent=list.length;
  byId("orkestraRequestList").innerHTML=list.map(item=>`<article class="external-card"><div class="external-card-top"><div><code>${esc(item.id)}</code><h3>${esc(item.title)}</h3><p>${esc(item.pipeline_name)} · ${esc(item.database_name)} · ${esc(item.owner)}</p></div>${statusPill(item.status)}</div><div class="evidence-line"><span>Pipeline adımı<strong>${item.step_number}/${item.step_count}</strong></span><span>Dosya<strong>${esc(item.script_name)}</strong></span><span>SHA-256<strong>${esc(item.script_sha256?.slice(0,12)||"-")}</strong></span></div></article>`).join("")||`<div class="empty-state small-empty"><strong>Talep gönderilmemiş</strong><p>Soldaki form gerçek Orkestra isteğini mocklamak için hazır.</p></div>`;populateOperationRequestControls();
}

function renderOctopus(connection){
  const releases=[...(APP.state.octopus_releases||[])].filter(item=>String(item.request_id||"").startsWith("REQ-")).reverse();
  const deployments=[...(APP.state.deployments||[])].filter(item=>String(item.talep_no||"").startsWith("REQ-")).reverse();
  byId("octopusStatus").innerHTML=externalStatus(connection,"OCTOPUS MOCK");byId("octopusReleaseCount").textContent=releases.length;byId("octopusDeploymentCount").textContent=deployments.length;
  byId("octopusReleaseList").innerHTML=releases.map(item=>`<article class="external-card"><div class="external-card-top"><div><code>${esc(item.code)}</code><h3>${esc(item.project)}</h3><p>${esc(item.environment)} · ${esc(item.request_id)}</p></div>${statusPill(item.state)}</div><p class="muted small">${esc(item.detail||"Admin onayıyla görev çekildi.")}</p></article>`).join("")||`<div class="empty-state small-empty"><strong>Çekilmiş görev yok</strong><p>Bir talep onaylandığında Octopus mock görevi burada oluşur.</p></div>`;
  byId("octopusDeploymentList").innerHTML=deployments.map(item=>`<article class="external-card"><div class="external-card-top"><div><code>${esc(item.id)}</code><h3>${esc(item.database_name||item.environment)}</h3><p>${esc(item.talep_no)} · ${esc(item.execution_id||item.release)}</p></div>${statusPill(item.state)}</div><p class="muted small">${esc(item.detail||"")}</p></article>`).join("")||`<div class="empty-state small-empty"><strong>Oracle sonucu yok</strong><p>Onaylanan scriptin sonucu burada görüntülenir.</p></div>`;
}

async function refreshExternalSystems(){
  try{const [orkestra,octopus]=await Promise.all([api("/api/orkestra"),api("/api/octopus")]);APP.state.octopus_releases=octopus.releases||[];APP.state.deployments=octopus.deployments||APP.state.deployments;renderOrkestra(orkestra.connection);renderOctopus(octopus.connection);renderOperations();}
  catch(error){toast(error.message,true);}
}

// ------------------------------------------------------------ databases
function renderConnections(){ renderDriver(); renderDbProfiles(); populateTargetDatabases(); renderTargets(); populateWorkbenchTargets(); fillConnectorSettings(); }
function renderDriver(){const d=APP.health.database_driver||{};byId("driverBanner").innerHTML=`<div class="driver-banner ${d.installed?"ready":"missing"}"><div><strong>${d.installed?`${esc(d.name)} ${esc(d.version)} hazır`:`${esc(d.name||"python-oracledb")} henüz kurulu değil`}</strong><p>${d.installed?"Thin mode ile Oracle hedeflerine bağlanabilirsiniz.":"Profil ve önizleme kullanılabilir; gerçek bağlantı için sürücüyü kurun."}</p></div>${d.installed?statusPill("READY"):`<code>${esc(d.install||"python -m pip install oracledb")}</code>`}</div>`;}
function newDbProfile(){["dbId","dbName","dbHost","dbService","dbConnectString","dbUsername","dbPasswordEnv","dbPassword"].forEach(id=>byId(id).value="");byId("dbEnvironment").value="SHARED";byId("dbPort").value="1521";byId("dbTimeout").value="60";byId("dbAllowExecute").checked=false;byId("dbFormTitle").textContent="Yeni Oracle bağlantısı";byId("dbProfilePanel").scrollIntoView({behavior:"smooth",block:"start"});}
function editDbProfile(id){const db=APP.state.databases.find(item=>item.id===id);if(!db)return;byId("dbId").value=db.id;byId("dbName").value=db.name;byId("dbEnvironment").value=db.environment;byId("dbHost").value=db.host||"";byId("dbPort").value=db.port||1521;byId("dbService").value=db.service_name||"";byId("dbConnectString").value=db.connect_string||"";byId("dbUsername").value=db.username||"";byId("dbPasswordEnv").value=db.password_env||"";byId("dbTimeout").value=db.call_timeout_seconds||60;byId("dbPassword").value="";byId("dbAllowExecute").checked=!!db.allow_execute;byId("dbFormTitle").textContent=`${db.name} profilini düzenle`;byId("dbProfilePanel").scrollIntoView({behavior:"smooth",block:"start"});}
async function saveDbProfile(){const payload={id:byId("dbId").value,name:byId("dbName").value,environment:byId("dbEnvironment").value,host:byId("dbHost").value,port:byId("dbPort").value,service_name:byId("dbService").value,connect_string:byId("dbConnectString").value,username:byId("dbUsername").value,password_env:byId("dbPasswordEnv").value,password:byId("dbPassword").value,call_timeout_seconds:byId("dbTimeout").value,allow_execute:byId("dbAllowExecute").checked};const r=await api("/api/databases",payload);if(!r.ok)return toast(r.error,true);toast(`${r.profile.name} kaydedildi.`);newDbProfile();await refreshAll();renderConnections();}
function renderDbProfiles(){const list=APP.state.databases;byId("dbProfileCount").textContent=list.length;byId("dbProfiles").innerHTML=list.map(db=>{const test=db.last_test;return `<article class="db-card"><div class="db-card-top"><div><h3>${esc(db.name)}</h3><p>${esc(db.username)}@${esc(db.dsn_preview)}</p></div><span class="count-badge">${db.target_count||0} hedef</span></div><div class="chips"><span class="chip">${db.allow_execute?"Script çalıştırma açık":"Salt okunur"}</span><span class="chip">${db.secret_available?"Parola hazır":"Parola gerekli"}</span></div>${test?`<div class="db-last-test">Son test: ${test.ok?"Başarılı":"Başarısız"} · ${esc(test.at||"")} · ${esc(test.database||test.error||"")}</div>`:""}<div class="db-card-actions"><button class="text-button" onclick="testPhysicalConnection('${attr(db.id)}')">Bağlantıyı test et</button><button class="text-button" onclick="selectDbForTargets('${attr(db.id)}')">Hedef oluştur</button><button class="text-button" onclick="editDbProfile('${attr(db.id)}')">Düzenle</button><button class="text-button danger-text" onclick="deleteDbProfile('${attr(db.id)}')">Sil</button></div></article>`;}).join("")||`<div class="empty-state small-empty"><strong>Fiziksel Oracle bağlantısı yok</strong><p>Bağlantıyı bir kez ekleyip birden fazla ortama eşleyebilirsiniz.</p></div>`;}
async function deleteDbProfile(id){const db=APP.state.databases.find(item=>item.id===id);if(!db||!confirm(`${db.name} profilini silmek istiyor musunuz?`))return;const r=await api(`/api/databases/${id}/delete`,{});if(!r.ok)return toast(r.error,true);await refreshAll();renderConnections();toast("Oracle profili silindi.");}
async function testPhysicalConnection(id){const password=prompt("Bu bağlantı için parola (oturum belleğinde tutulur):")||"";const r=await api(`/api/databases/${id}/action`,{action:"TEST",password});if(!r.ok)return toast(r.error,true);toast(`${r.database||"Oracle"} bağlantısı başarılı.`);await refreshAll();renderConnections();}
function populateTargetDatabases(){const current=byId("targetDatabase").value;byId("targetDatabase").innerHTML=`<option value="">Fiziksel bağlantı seçin</option>`+APP.state.databases.map(db=>`<option value="${attr(db.id)}" ${db.id===current?"selected":""}>${esc(db.name)} — ${esc(db.dsn_preview)}</option>`).join("");}
function selectDbForTargets(id){byId("targetDatabase").value=id;byId("targetPanel").scrollIntoView({behavior:"smooth",block:"start"});}
function newTarget(){byId("targetId").value="";byId("targetName").value="";byId("targetEnvironment").value="TEST";byId("targetSchema").value="";byId("targetEnabled").checked=true;byId("targetFormTitle").textContent="Ortam hedefi ekle";}
function editTarget(id){const target=APP.state.targets.find(item=>item.id===id);if(!target)return;byId("targetId").value=target.id;byId("targetName").value=target.name;byId("targetEnvironment").value=target.environment;byId("targetDatabase").value=target.database_profile_id;byId("targetSchema").value=target.schema||"";byId("targetEnabled").checked=target.enabled!==false;byId("targetFormTitle").textContent=`${target.name} hedefini düzenle`;byId("targetPanel").scrollIntoView({behavior:"smooth",block:"start"});}
async function saveTarget(){const payload={id:byId("targetId").value,name:byId("targetName").value,environment:byId("targetEnvironment").value,database_profile_id:byId("targetDatabase").value,schema:byId("targetSchema").value,enabled:byId("targetEnabled").checked};const r=await api("/api/targets",payload);if(!r.ok)return toast(r.error,true);toast(`${r.target.name} deployment hedefi kaydedildi.`);newTarget();await refreshAll();renderConnections();renderPipelineBuilder();}
async function seedTargetsFromConnection(){const profileId=byId("targetDatabase").value;if(!profileId)return toast("Önce fiziksel Oracle bağlantısını seçin.",true);const r=await api("/api/targets/seed",{database_profile_id:profileId,prefix:"Örnek"});if(!r.ok)return toast(r.error,true);await refreshAll();APP.builderTargets=(r.targets||[]).map(target=>target.id);renderConnections();renderPipelineBuilder();toast("Örnek TEST, PREPROD ve PROD hedefleri hazırlandı; pipeline sırasına da eklendi.");}
async function seedOracleLab(){const result=await api("/api/oracle-lab/seed",{password:"run123"});if(!result.ok)return toast(result.error,true);APP.builderTargets=(result.targets||[]).map(target=>target.id);await refreshAll();renderConnections();toast("Docker Oracle Lab için üç bağlantı ve hedef eklendi.");}
async function deleteTarget(id){const target=APP.state.targets.find(item=>item.id===id);if(!target||!confirm(`${target.name} hedefini kaldırmak istiyor musunuz?`))return;const r=await api(`/api/targets/${id}/delete`,{});if(!r.ok)return toast(r.error,true);await refreshAll();renderConnections();renderPipelineBuilder();toast("Deployment hedefi kaldırıldı.");}
function renderTargets(){const list=APP.state.targets;byId("targetCount").textContent=list.length;byId("targetList").innerHTML=list.map(target=>`<article class="target-card ${String(target.environment).toLowerCase()}"><div class="target-card-top"><div><h3>${esc(target.name)}</h3><p>${esc(target.environment)} → ${esc(target.database_name)} / ${esc(target.username)}@${esc(target.dsn_preview)}</p></div>${statusPill(target.enabled===false?"DISABLED":target.environment)}</div><div class="db-card-actions"><button class="text-button" onclick="openTargetWorkbench('${attr(target.id)}')">Aksiyon merkezi</button><button class="text-button" onclick="editTarget('${attr(target.id)}')">Düzenle</button><button class="text-button danger-text" onclick="deleteTarget('${attr(target.id)}')">Sil</button></div></article>`).join("")||`<div class="empty-state small-empty"><strong>Deployment hedefi yok</strong><p>Tek bağlantıdan üç örnek hedef oluşturabilir veya ortamları tek tek ekleyebilirsiniz.</p></div>`;}
function populateWorkbenchTargets(){const current=byId("workbenchTarget").value;byId("workbenchTarget").innerHTML=`<option value="">Deployment hedefi seçin</option>`+APP.state.targets.filter(target=>target.enabled!==false).map(target=>`<option value="${attr(target.id)}" ${target.id===current?"selected":""}>${esc(target.environment)} — ${esc(target.name)} / ${esc(target.database_name)}</option>`).join("");updateWorkbenchTarget();}
function openTargetWorkbench(id){byId("workbenchTarget").value=id;updateWorkbenchTarget();document.querySelector(".workbench").scrollIntoView({behavior:"smooth",block:"start"});}
function updateWorkbenchAction(){const action=byId("workbenchAction").value;const needsScript=["QUERY","PREFLIGHT","PREVIEW","EXECUTE"].includes(action);byId("workbenchScript").closest("label").classList.toggle("hidden",!needsScript);byId("catalogOwnersField").classList.toggle("hidden",action!=="PREFLIGHT");if(action==="QUERY"&&!byId("workbenchScript").value.trim())byId("workbenchScript").value="SELECT DISTINCT OBJECT_TYPE\n  FROM USER_OBJECTS\n ORDER BY OBJECT_TYPE;";updateWorkbenchTarget();}
function updateWorkbenchTarget(){const target=APP.state.targets.find(item=>item.id===byId("workbenchTarget").value);const isProd=target&&target.environment==="PROD"&&byId("workbenchAction").value==="EXECUTE";byId("prodConfirmation").classList.toggle("hidden",!isProd);}
function copyParseToWorkbench(){byId("workbenchScript").value=byId("parseScript").value;byId("workbenchAction").value="PREVIEW";updateWorkbenchAction();toast("Script aksiyon merkezine kopyalandı.");}
async function runDatabaseAction(){const target=APP.state.targets.find(item=>item.id===byId("workbenchTarget").value);if(!target)return toast("Deployment hedefi seçin.",true);const action=byId("workbenchAction").value;byId("dbActionResult").className="action-result";byId("dbActionResult").innerHTML="<p>İşlem sürüyor...</p>";const payload={action,target_id:target.id,password:byId("workbenchPassword").value,script:byId("workbenchScript").value,script_name:byId("parseName").value||"01-change.sql",owners:byId("catalogOwners").value,confirmation:byId("dbConfirmation").value,transaction_mode:byId("transactionMode").value,selected_rule_ids:ruleIds(),gate_policy:APP.state.settings.gate_policy||"PASS_ONLY"};const r=await api(`/api/databases/${target.database_profile_id}/action`,payload);renderDatabaseResult(r,action);if(!r.ok)toast(r.error||"DB aksiyonu başarısız.",true);else toast("DB aksiyonu tamamlandı.");await refreshAll();renderDbProfiles();renderTargets();}
function renderDatabaseResult(result,action){let html=`<div class="verdict-banner ${result.ok?"":"blocked"}"><div><p class="eyebrow">${esc(action)} SONUCU</p><h2>${result.ok?"Aksiyon başarılı":"Aksiyon başarısız"}</h2><p>${esc(result.message||result.error||"")}</p></div>${statusPill(result.validation?.verdict||(result.ok?"PASS":"FAIL"))}</div>`;if(result.database)html+=`<div class="stat-strip"><div><strong>${esc(result.database)}</strong><span>Database</span></div><div><strong>${esc(result.container||"-")}</strong><span>Container</span></div><div><strong>${esc(result.schema||"-")}</strong><span>Şema</span></div><div><strong>${result.duration_ms||0} ms</strong><span>Süre</span></div></div>`;if(result.catalog_summary){const c=result.catalog_summary;html+=`<div class="stat-strip"><div><strong>${esc(c.database?.name||"-")}</strong><span>Database</span></div><div><strong>${c.objects||0}</strong><span>Obje</span></div><div><strong>${c.tables||0}</strong><span>Tablo / view</span></div><div><strong>${c.indexes||0}</strong><span>İndeks</span></div></div>`;}if(result.validation){const v=result.validation;html+=`<div class="result-block"><strong>Canlı katalog validator sonucu: ${esc(v.verdict)}</strong>${(v.findings||[]).map(f=>`<div class="finding"><div><span class="finding-code">${esc(f.rule_id)}</span><br>${statusPill(f.severity)}</div><div><h4>Satır ${esc(f.line||"-")} — ${esc(f.message)}</h4><p>${esc(f.remediation||"")}</p></div></div>`).join("")||`<div class="inline-note">Bulgu üretilmedi.</div>`}</div>`;}if(result.plan){html+=`<div class="result-block"><strong>Çalıştırma planı</strong><div class="table-wrap"><table class="data-table"><thead><tr><th>#</th><th>Satır</th><th>Sınıf</th><th>İfade</th><th>Durum</th></tr></thead><tbody>${result.plan.map(item=>`<tr><td>${item.index}</td><td>${item.line}</td><td>${esc(item.action)}</td><td><code>${esc(item.preview)}</code></td><td>${item.executable?"Çalıştırılır":"İstemci komutu, atlanır"}</td></tr>`).join("")}</tbody></table></div></div>`;}if(result.result){html+=renderQueryResult(result.result);}if(result.statements){html+=`<div class="result-block"><strong>İfade sonuçları</strong><div class="table-wrap"><table class="data-table"><thead><tr><th>#</th><th>Satır</th><th>Fiil</th><th>Durum</th><th>Satır sayısı</th><th>Süre</th></tr></thead><tbody>${result.statements.map(row=>`<tr><td>${row.index}</td><td>${row.line}</td><td>${esc(row.verb)}</td><td>${statusPill(row.status)}</td><td>${row.rowcount??"-"}</td><td>${row.duration_ms??"-"} ms</td></tr>${row.query?`<tr><td colspan="6">${renderQueryResult(row.query)}</td></tr>`:""}`).join("")}</tbody></table></div>${result.warning?`<div class="inline-note warning">${esc(result.warning)}</div>`:""}</div>`;}byId("dbActionResult").innerHTML=html;}
function renderQueryResult(data){return `<div class="table-wrap"><table class="data-table"><thead><tr>${(data.columns||[]).map(col=>`<th>${esc(col)}</th>`).join("")}</tr></thead><tbody>${(data.rows||[]).map(row=>`<tr>${row.map(cell=>`<td><code>${esc(cell)}</code></td>`).join("")}</tr>`).join("")||`<tr><td>Satır dönmedi.</td></tr>`}</tbody></table></div>`;}
function fillConnectorSettings(){const s=APP.state.settings;byId("orkestraMode").value=s.orkestra_mode||"MOCK";byId("orkestraUrl").value=s.orkestra_url||"";byId("octopusMode").value=s.octopus_mode||"MOCK";byId("octopusUrl").value=s.octopus_url||"";byId("octopusProject").value=s.octopus_project||"OracleDeploy";}
async function saveConnectorSettings(){const r=await api("/api/settings",{orkestra_mode:byId("orkestraMode").value,orkestra_url:byId("orkestraUrl").value,orkestra_token:byId("orkestraToken").value,octopus_mode:byId("octopusMode").value,octopus_url:byId("octopusUrl").value,octopus_key:byId("octopusKey").value,octopus_project:byId("octopusProject").value});APP.state.settings=r.settings;byId("orkestraToken").value="";byId("octopusKey").value="";toast("Dış sistem ayarları kaydedildi.");}
async function testConnectors(){const r=await api("/api/connectors/test",{which:"both"});const result=r.result||{};byId("connectorResult").innerHTML=`<div class="inline-note"><strong>Orkestra:</strong> ${esc(result.orkestra?.detail||"Yanıt yok")}<br><strong>Octopus:</strong> ${esc(result.octopus?.detail||"Yanıt yok")}</div>`;}

// --------------------------------------------------------------- requests
function renderRequests(){const list=[...APP.state.talepler].reverse();byId("requestCount").textContent=list.length;byId("requestList").innerHTML=list.map(item=>`<div class="request-row"><code>${esc(item.talep_no)}</code><div>${statusPill(item.env)}</div><div><strong>${esc(item.title)}</strong><small>${esc(item.pipeline_type||"Serbest talep")} · ${esc(item.script_name)} · ${esc(item.owner)}</small></div><button class="button quiet small" onclick="openRequest('${attr(item.talep_no)}')">Detay</button></div>`).join("")||`<p class="muted">Henüz talep yok.</p>`;const opts=`<option value="">Talep seçin</option>`+APP.state.talepler.map(item=>`<option value="${attr(item.talep_no)}">${esc(item.talep_no)} — ${esc(item.env)}</option>`).join("");["compareSelectA","compareSelectB","compareSelectC"].forEach(id=>{const old=byId(id).value;byId(id).innerHTML=opts;byId(id).value=old;});}
async function createRequest(){const payload={env:byId("requestEnv").value,pipeline_type:byId("requestPipelineType").value,owner:byId("requestOwner").value,title:byId("requestTitle").value,script_name:byId("requestFile").value,octopus_ref:byId("requestRef").value,script:byId("requestScript").value};if(!payload.title.trim()||!payload.script.trim())return toast("Talep başlığı ve script zorunlu.",true);const r=await api("/api/talep",payload);if(!r.ok)return toast(r.error,true);toast(`${r.talep.talep_no} oluşturuldu.`);byId("requestTitle").value="";byId("requestRef").value="";await refreshAll();await openRequest(r.talep.talep_no);}
async function openRequest(no){const r=await api(`/api/talep/${encodeURIComponent(no)}`);if(!r.ok)return toast(r.error,true);const t=r.talep,inv=r.inventory||{};byId("requestDetail").className="request-detail panel";byId("requestDetail").innerHTML=`<div class="panel-heading"><div><p class="eyebrow">${esc(t.env)} · ${esc(t.status)}</p><h2>${esc(t.talep_no)} — ${esc(t.title)}</h2><p class="muted small">${esc(t.owner)} · ${esc(t.created_at)} · ${esc(inv.summary_text||"")}</p></div>${statusPill(t.validation?.verdict||"NOT VALIDATED")}</div><div class="form-row two"><label class="field"><span>Önceki deployment no</span><input id="detailRef" value="${attr(t.octopus_ref||"")}"></label><div class="button-row"><button class="button quiet small" onclick="saveRequestRef('${attr(no)}')">Kanıtı kaydet</button><button class="button quiet small" onclick="openRequestInParser('${attr(no)}')">Parse ekranında aç</button></div><label class="field span2"><span>${esc(t.script_name)}</span><textarea id="detailScript" class="code-editor request-code" spellcheck="false">${esc(t.script)}</textarea></label></div><button class="button quiet" onclick="saveRequestScript('${attr(no)}')">Scripti kaydet</button>`;byId("requestDetail").scrollIntoView({behavior:"smooth",block:"start"});}
async function saveRequestRef(no){const r=await api(`/api/talep/${no}/octopus-ref`,{octopus_ref:byId("detailRef").value});if(!r.ok)return toast(r.error,true);toast("Deployment kanıtı kaydedildi.");await refreshAll();}
async function saveRequestScript(no){const r=await api(`/api/talep/${no}/script`,{script:byId("detailScript").value});if(!r.ok)return toast(r.error,true);toast("Talep scripti güncellendi; pipeline kapıları yeniden hesaplanacak.");await refreshAll();}
function openRequestInParser(no){const t=APP.state.talepler.find(item=>item.talep_no===no);if(!t)return;byId("parseScript").value=t.script;byId("parseName").value=t.script_name;updateEditorStats();navigate("parse");}

// --------------------------------------------------------------- compare
function fillCompareFromRequest(which){const no=byId(`compareSelect${which}`).value;const t=APP.state.talepler.find(item=>item.talep_no===no);if(t)byId(`compare${which}`).value=t.script;}
function injectInvisibleCharacter(){const area=byId("compareB"),value=area.value;if(!value)return toast("Önce B scriptini doldurun.",true);const pos=Math.floor(value.length/2);area.value=value.slice(0,pos)+"\u200b"+value.slice(pos);toast("B scriptine bir zero-width space eklendi.");}
async function runCompare(){const items=["A","B","C"].map(label=>({label:`Script ${label}`,text:byId(`compare${label}`).value})).filter(item=>item.text.length);if(items.length<2)return toast("En az iki script doldurun.",true);const r=await api("/api/compare",{items});const rows=(r.rows||[]).map(row=>`<tr><td><strong>${esc(row.label)}</strong></td><td><code>${esc(row.sha_short)}</code></td><td>${statusPill(row.identical?"PASS":"FAIL")}</td><td>${esc(row.diff_kind_text)}</td><td>${row.first_difference?esc(row.first_difference.reason):"-"}</td></tr>`).join("");const diffs=(r.rows||[]).filter(row=>row.diff?.length).map(row=>`<div class="result-block"><strong>${esc(row.label)} farkı</strong><pre class="diff-block">${esc(row.diff.join("\n"))}</pre></div>`).join("");byId("compareResult").className="result-space";byId("compareResult").innerHTML=`<div class="compare-verdict ${r.identical?"":"bad"}"><h2>${r.identical?"Scriptler birebir aynı":"Scriptler farklı"}</h2><p>${esc(r.message)}</p></div><article class="panel"><div class="table-wrap"><table class="data-table"><thead><tr><th>Script</th><th>SHA-256</th><th>Karar</th><th>Fark türü</th><th>İlk fark</th></tr></thead><tbody>${rows}</tbody></table></div>${diffs}</article>`;}

// -------------------------------------------------------------- refresh
async function refreshAll(){const state=await api("/api/state");APP.state=state;renderOverview();renderRuns();renderRequests();renderDbProfiles();populateTargetDatabases();renderTargets();populateWorkbenchTargets();renderPipelineBuilder();renderOperations();renderOperationDatabases();renderOperationPipelines();}
async function seedDemo(){const r=await api("/api/seed",{});if(!r.ok)return toast(r.error,true);await refreshAll();toast(r.message);navigate("pipelines");if(r.run_id)await selectRun(r.run_id);}

async function boot(){
  try{
    const [health,state,rules,profiles,examples,pipelines]=await Promise.all([
      api("/api/health"),api("/api/state"),api("/api/rules"),api("/api/rule-profiles"),api("/api/examples"),api("/api/pipelines")
    ]);
    APP.health=health;APP.state=state;APP.rules=rules.rules||[];APP.ruleProfiles=profiles.profiles||[];APP.examples=examples.examples||[];APP.pipelines=pipelines.pipelines||[];APP.pipelineCapabilities=pipelines.capabilities||{};
    const engine=health.engine||{};const status=byId("engineStatus");status.className=`health ${engine.ok?"ok":"bad"}`;status.innerHTML=`<i></i>${engine.ok?`${engine.rules_active} aktif / ${engine.rules_total} kural`:`Motor hatası: ${esc(engine.error)}`}`;
    initializeRuleSelection();populateRuleControls();populateExamples();populatePipelineControls();renderOverview();renderPipelinePage();renderRequests();renderConnections();renderOperations();renderOperationDatabases();renderOperationPipelines();updateWorkbenchAction();
    if(APP.examples.length)loadExample(APP.examples[0].id);
    await refreshExternalSystems();
  }catch(error){byId("engineStatus").className="health bad";byId("engineStatus").innerHTML=`<i></i>Başlatma hatası`;toast(error.message,true);}
}

async function init(){try{const response=await fetch("/api/auth/me");const result=await response.json();if(!response.ok)return showLogin();hideLogin(result.username);await boot();}catch(error){showLogin("Sunucuya bağlanılamadı.");}}

init();
