# Oracle Delivery Control POC

Oracle SQL/PLSQL değişikliklerini analiz eden ve onaylanan script taleplerini
seçilen Oracle veritabanında çalıştıran localhost uygulamasıdır. Uygulama iki
çalışma alanı sunar:

- **Geliştirme:** script analizi, kural seçimi, pipeline tasarımı, Oracle
  bağlantıları, yerel talepler ve byte seviyesinde script karşılaştırması.
- **Operasyon:** gerçek veritabanı bağlantıları ekleme, bunları `X → Y` gibi
  sıralı pipeline'larda kullanma, Orkestra mock talebi gönderme, talebi tek
  tıkla onaylayıp seçilen veritabanında çalıştırma ve Octopus mock sonucunu
  izleme.

## Hızlı başlangıç

Python 3.10+ ile:

```powershell
python -m pip install -r requirements.txt
python server.py
```

Arayüz: `http://127.0.0.1:8080`

Yerel POC kullanıcısı:

```text
Kullanıcı: RUNNER
Parola:    run123
```

Bu değerler `APP_USERNAME` ve `APP_PASSWORD` ortam değişkenleriyle
değiştirilebilir. Oturum cookie'si yalnız süreç belleğinde tutulur; sunucu
yeniden başladığında tekrar giriş yapılır.

Testler:

```powershell
python -m unittest discover -s tests -v
python selftest.py
node --check static/app.js
```

## Operasyon akışı

Orkestra ve Octopus mock, Oracle ise gerçek bağlantı olarak kullanılır:

1. **Operasyon → Veritabanları** ekranında Oracle bağlantılarını istediğiniz
   isimlerle ekleyin ve bağlantıyı test edin. Operasyon modelinde PROD, TEST
   veya başka bir ortam etiketi yoktur.
2. **Operasyon → Pipeline'lar** ekranında veritabanlarını sıraya koyarak
   `X → Y` ya da `A → X → Y` gibi bir pipeline kaydedin.
3. **Operasyon → Orkestra Mock** ekranında pipeline'ı, talebin açıldığı
   veritabanını ve scripti seçip talebi gönderin.
4. **Operasyon → Talepler** ekranında **Onayla ve veritabanında çalıştır**
   düğmesine bir kez basın. Ayrı çalıştırma veya tamamlama adımı yoktur.
5. Sistem aynı HTTP isteğinde talebi kilitler, scripti seçilen Oracle
   bağlantısında çalıştırır ve talep, deployment, audit ile Octopus mock
   kayıtlarını `SUCCESS` veya `FAILED` sonucu ile kapatır.
6. **Operasyon → Octopus Mock** ekranında çekilen işi ve Oracle sonucunu
   izleyin.

Her operasyon talebi `pipeline_id`, `database_id`, sıra numarası, script,
`script_sha256`, onaylayan kullanıcı, Oracle execution id, deployment id ve
Octopus kodunu taşır. Aynı talep yalnız `PENDING` durumundayken onaylanabildiği
için çift tıklama veya yinelenen HTTP isteği scripti ikinci kez çalıştırmaz.

## Başka Oracle sunucusunda A/X/Y demosu

[oracle/scripts/remote-demo](oracle/scripts/remote-demo) paketi başka bir test
Oracle sunucusunda uygulamayı uçtan uca denemek için hazırlanmıştır. Hedef
PDB/service üzerinde DBA hesabıyla şu dosyayı çalıştırın:

```text
sqlplus "system/<DBA_PASSWORD>@//<HOST>:<PORT>/<SERVICE>" @20_install_all.sql
sqlplus "system/<DBA_PASSWORD>@//<HOST>:<PORT>/<SERVICE>" @30_verify_all.sql
```

Kurulum `ODC_A`, `ODC_X`, `ODC_Y` kullanıcılarını ve her birinde aynı temel
`ODC_CUSTOMER`, `ODC_ORDER`, `ODC_SCRIPT_RUN` tablolarını oluşturur. Varsayılan
parola `run123`, varsayılan tablespace `USERS` değeridir; ikisi de
`00_create_demo_users.sql` başından değiştirilebilir. Master kurulum tekrar
çalıştırılabilir ve var olan objeleri yeniden oluşturmaya çalışmaz.

Hazır Oracle kullanıcıları kullanılacaksa DBA kurulumuna gerek yoktur. Her
hedef bağlantıda `10_install_current_schema.sql`, ardından
`31_verify_current_schema.sql` çalıştırılabilir. Aynı service üzerindeki A/X/Y
şemaları test kolaylığı içindir; gerçek A/X/Y bağlantıları farklı Oracle
sunucularına veya service'lere yönlendirilebilir.

Uygulamada aynı host/service için üç bağlantı ekleyin:

| Bağlantı adı | Oracle kullanıcısı | Parola |
| --- | --- | --- |
| A | `ODC_A` | `run123` |
| X | `ODC_X` | `run123` |
| Y | `ODC_Y` | `run123` |

Ardından `A → X → Y` operasyon pipeline'ını oluşturun. Orkestra Mock
ekranındaki **Örnekten doldur** alanında `Operasyon Demo:` ile başlayan sekiz
hazır script bulunur. Hangi scriptin bağımsız, hangisinin sıralı çalıştırılması
gerektiği ve kaldırma komutu paketin
[ayrıntılı README dosyasında](oracle/scripts/remote-demo/README.md) yer alır.

## Docker Oracle Lab

Tek Oracle Free container içinde birbirinden ayrı üç gerçek Oracle şeması
kurulur:

| Ortam | Oracle kullanıcısı | Parola | Service |
| --- | --- | --- | --- |
| TEST | `RUNNER_TEST` | `run123` | `FREEPDB1` |
| PREPROD | `RUNNER_PREPROD` | `run123` | `FREEPDB1` |
| PROD | `RUNNER_PROD` | `run123` | `FREEPDB1` |

Başlatma:

```powershell
docker compose up -d oracle
docker compose ps
docker compose logs -f oracle
```

İlk image indirme ve veritabanı kurulumu birkaç dakika sürebilir. Container
sağlıklı olduktan sonra uygulamada **Geliştirme → Bağlantılar → Docker Oracle
Lab'ı ekle** düğmesi üç bağlantı profilini ve üç deployment hedefini hazırlar.
Parola yalnız çalışan Python sürecinin belleğinde tutulur; `data/state.json`
dosyasına yazılmaz.

Şemaları terminalden doğrulamak için:

```powershell
.\scripts\test-oracle-lab.ps1
```

Bir SQL dosyasını belirli ortama uygulamak için:

```powershell
.\scripts\apply-oracle-script.ps1 `
  -Schema RUNNER_TEST `
  -Script .\oracle\scripts\schema\01_create_release_management.sql
```

Temel domain şemasını sırayla kurmak için `oracle/scripts/schema/01` ile `06`
arasındaki dosyaları kullanın. `deployments/`, `queries/` ve `rollback/`
klasörleri kontrollü değişiklik, smoke test ve geri alma örnekleri içerir.
Init scriptleri yalnız boş Docker volume'unun ilk kurulumunda çalışır.

Lab'ı tamamen sıfırlamak veri siler:

```powershell
docker compose down -v
docker compose up -d oracle
```

## Geliştirme pipeline'ları ve kapılar

Hazır akışlar:

1. `ddl_database_promoted`: TEST → PREPROD → PROD
2. `dml_direct_prod`: onaylı doğrudan PROD
3. `dml_promoted`: TEST → PROD
4. `octopus_promoted`: Orkestra + Octopus ile TEST → PREPROD → PROD
5. `validation_only`: yalnız validator

Bu hazır akışlar yalnız **Geliştirme** çalışma alanındaki ayrıntılı doğrulama
motoruna aittir. Görsel oluşturucu kayıtlı deployment hedeflerini sıralayarak
standart
`TALEP`, `VALIDATE`, `APPROVAL` ve `DEPLOY` aşamalarını üretir. Bir tanım
oluşturulduğunda geliştirme pipeline kataloğuna eklenir. Operasyon pipeline'ları
bundan ayrıdır; yalnız sıralı gerçek veritabanı kimliklerini tutar ve script
türü ya da ortam politikası içermez.

Başlıca güvenlik kapıları:

- DDL doğrudan PROD'a gidemez; başarılı PREPROD kanıtı gerekir.
- DML doğrudan PROD'a gidebilir ancak validator, dört-göz onayı ve açık PROD
  hedef adı onayı gerekir.
- Ortamlar arasındaki script ham SHA-256 ile birebir aynı olmalıdır.
- Talebin `pipeline_type` değeri bağlanacağı koşumla eşleşmelidir.
- Tamamlanmış bir kayıt veya kanıt sonradan bozulursa kapılar tekrar hesaplanır.
- Oracle parolaları JSON state'e veya tarayıcı local storage'a yazılmaz.

## Oracle aksiyonları

Bağlantı profili fiziksel erişimi; deployment hedefi ise ortam ve şema rolünü
temsil eder. Böylece Docker Lab'daki üç şema daha sonra pipeline tanımları
değişmeden üç ayrı fiziksel Oracle veritabanına yönlendirilebilir.

Bağlantılar ekranında şunlar yapılabilir:

- Bağlantı ve oturum bağlamı testi
- Şema envanteri ve salt-okunur `SELECT` çalıştırma
- Script execution plan önizlemesi
- Canlı Oracle kataloğuyla preflight doğrulaması
- İfade bazında gerçek SQL/PLSQL çalıştırma
- TEST için rollback-after-test, başarıda commit veya script-controlled işlem
- PROD hedef adıyla açık onay

## Orkestra ve Octopus bağlantı sınırı

Her iki bağlayıcı `MOCK` ve `HTTP` modlarını aynı normalize edilmiş arayüzle
uygular. Bağlantı ayarları **Geliştirme → Bağlantılar → Dış Sistemler**
bölümündedir. Orkestra mock ekranının gönderdiği payload, gerçek adaptörün
normalize edeceği operasyon talebiyle aynıdır; Oracle executor dış sistem
alanlarını bilmez.

Gerçek sistemde endpoint veya alan adları farklıysa yalnız
`app/connectors.py` içindeki adaptör eşlemesi değiştirilir. Store, pipeline,
Oracle executor ve ekran akışı aynı kalır. Beklenen HTTP sözleşmeleri ve alan
eşleme noktaları [docs/integrations.md](docs/integrations.md) dosyasındadır.

## Kalıcılık ve güvenlik sınırı

Talepler, koşum snapshot'ları, mock dış sistem kayıtları, Oracle profil
metadata'sı ve audit olayları `data/state.json` içinde saklanır. Parolalar,
Orkestra token'ı ve Octopus API key'i public API cevaplarında gösterilmez.

Bu POC yalnız localhost içindir. `RUNNER/run123`, süreç içi session store ve
dosya tabanlı state üretim güvenliği sağlamaz. Kurumsal kullanımdan önce SSO,
RBAC, CSRF koruması, TLS, secrets manager, ilişkisel kalıcı store, merkezi audit
ve arka plan job queue eklenmelidir.

## Dizin yapısı

```text
ci_cd_poc/
├── app/
│   ├── connectors.py          # Orkestra/Octopus MOCK ve HTTP adaptörleri
│   ├── database_service.py    # Oracle bağlantı, preflight ve execution
│   ├── operations.py          # sade pipeline, talep ve tek tık onay akışı
│   ├── pipeline.py            # data-driven aşama ve gate motoru
│   └── store.py               # thread-safe JSON state
├── docs/integrations.md       # gerçek sistem geçiş sözleşmesi
├── oracle/
│   ├── init/                  # ilk container kurulum SQL'leri
│   └── scripts/               # schema, deployment ve taşınabilir A/X/Y demosu
├── scripts/                   # Oracle Lab PowerShell yardımcıları
├── static/                    # bağımlılıksız web arayüzü
├── tests/                     # unit ve entegrasyon testleri
├── docker-compose.yml
├── examples.json
├── pipelines.json
└── server.py
```
