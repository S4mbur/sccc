# Dış Sistem Entegrasyon Sözleşmesi

Operasyon akışında uygulamanın iç modeli Orkestra, Octopus ve Oracle'a ait
alanları birbirinden ayırır. Mock ekranları gerçek entegrasyonun göndereceği
payload'ı kullanır; gerçek sisteme geçişte talep, onay veya Oracle yürütme
modelinin değiştirilmesi gerekmez.

```text
Orkestra -> operation request -> admin approval -> Oracle executor
                                      |
                                      +----------> Octopus adapter
```

## Orkestra talebi

Mock UI aşağıdaki localhost endpointini kullanır:

```text
GET  /api/operation-requests
POST /api/operation-requests
```

Normalize edilmiş istek:

```json
{
  "pipeline_id": "OPP-0001",
  "database_id": "db-muhasebe",
  "title": "Add audit column",
  "owner": "RUNNER",
  "script_name": "01-change.sql",
  "script": "ALTER TABLE ..."
}
```

`pipeline_id` kayıtlı operasyon pipeline'ını, `database_id` ise talebin
açıldığı gerçek bağlantıyı gösterir. Veritabanı seçilen pipeline'ın sıralı
adımlarından biri değilse talep reddedilir. Modelde ortam veya DDL/DML alanı
yoktur. Uygulama sıra numarasını, veritabanı ve pipeline adlarının snapshot'ını
ve script SHA-256 değerini kendisi ekler.

Gerçek Orkestra'dan veri çekmek için `app/connectors.py` içinde ayrı bir mapping
metodu eklenmeli ve uzak alanlar yukarıdaki altı alana normalize edilmelidir.
Uzak talep id'si ayrıca `external_request_id` olarak saklanabilir. Bearer token,
uzak URL ve timeout gibi ulaşım ayrıntıları yalnız adaptörde kalmalıdır.

## Admin onayı

```text
POST /api/operation-requests/{request_id}/approve
```

Yalnız `PENDING` talep onaylanabilir. Endpoint önce talebi atomik olarak
`EXECUTING` durumuna geçirir, sonra talepteki `database_id` ile Oracle
bağlantısını açar. Sonuç aynı çağrıda talebe, database execution audit'ine,
deployment kaydına ve Octopus işine yazılır. Başarılı sonuç `SUCCESS`, Oracle
hatası `FAILED` olur. Aynı talebin ikinci kez onaylanması yürütme başlamadan
reddedilir.

Parola JSON state'e yazılmaz. Sunucu yeniden başladığında bağlantı parolası
**Veritabanları** ekranından tekrar yüklenip test edilmelidir; parola hazır
değilse talep `PENDING` kalır.

## Octopus

Mock modunda admin onayı aşağıdaki normalize edilmiş release kaydını oluşturur:

```json
{
  "code": "OCT-202608-0001",
  "environment": "Muhasebe DB",
  "pipeline_type": "OPP-0001",
  "request_id": "REQ-2026-0001",
  "project": "OracleDeploy",
  "state": "Success"
}
```

Eski alan adları adaptör uyumluluğu için korunur: `environment` burada ortam
değil veritabanı adını, `pipeline_type` ise operasyon pipeline id'sini taşır.
Gerçek Octopus entegrasyonunda bunlar `ProjectId`, `EnvironmentId`, release
version ve task id alanlarına `OctopusClient` içinde eşlenmelidir. Uygulamanın
talep veya Oracle modellerine Octopus'a özel id eklenmemelidir.

## Üretim güvenilirliği

Gerçek entegrasyonda `request_id` idempotency key olarak gönderilmeli, güvenli
GET çağrıları sınırlı exponential backoff ile tekrar denenmeli ve belirsiz POST
sonuçları uzlaştırma endpointiyle sorgulanmalıdır. Uzun Oracle scriptleri HTTP
isteği içinde çalıştırılmak yerine kalıcı bir job queue'ya alınmalı; admin
onayı yalnız işi kuyruğa yazmalıdır. Worker lease'i, heartbeat ve retry sayacı
ile `EXECUTING` durumunda kalmış işler güvenli biçimde toparlanmalıdır.

Geliştirme çalışma alanındaki eski aşamalı pipeline motoru da aynı
`OrkestraClient` ve `OctopusClient` adaptörlerini kullanır. Bu motorun
TEST/PREPROD/PROD, DDL/DML ve gate kuralları operasyon pipeline modeline
karıştırılmamalıdır.
