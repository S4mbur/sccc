/*
 * TALEP NO  : CHG-2026-0142
 * YAZAN     : db.delivery
 * TARIH     : 2026-08-12
 * AMAC      : Musteri risk tablosu degisikligini geri almak
 * GERI ALMA : Uygulanamaz; bu dosyanin kendisi rollback planidir
 * VERITABANI: BANKDB
 */
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;
SET DEFINE OFF;

DROP TABLE BANKAPP.MUSTERI_RISK PURGE;

EXIT SUCCESS;
