$ErrorActionPreference = "Stop"

docker compose up -d oracle

Write-Host "Oracle container baslatildi. Ilk kurulum birkac dakika surebilir."
Write-Host "Durum: docker compose ps"
Write-Host "Loglar: docker compose logs -f oracle"
