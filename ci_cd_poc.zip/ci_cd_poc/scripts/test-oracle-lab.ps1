$ErrorActionPreference = "Stop"

$schemas = @("RUNNER_TEST", "RUNNER_PREPROD", "RUNNER_PROD")
foreach ($schema in $schemas) {
    $query = "SELECT SYS_CONTEXT('USERENV','CURRENT_SCHEMA') AS SCHEMA_NAME FROM DUAL;`nEXIT;"
    $query | docker exec -i oracle-delivery-lab sqlplus -s "$schema/run123@//localhost:1521/FREEPDB1"
    if ($LASTEXITCODE -ne 0) {
        throw "$schema baglantisi basarisiz."
    }
}

Write-Host "Tum Oracle Lab semalari erisilebilir."
