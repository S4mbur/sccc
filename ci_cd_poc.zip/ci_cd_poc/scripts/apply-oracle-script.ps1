param(
    [ValidateSet("RUNNER_TEST", "RUNNER_PREPROD", "RUNNER_PROD")]
    [string]$Schema = "RUNNER_TEST",
    [Parameter(Mandatory = $true)]
    [string]$Script
)

$ErrorActionPreference = "Stop"
$resolved = Resolve-Path -LiteralPath $Script

Get-Content -LiteralPath $resolved -Raw |
    docker exec -i oracle-delivery-lab sqlplus -s "$Schema/run123@//localhost:1521/FREEPDB1"

if ($LASTEXITCODE -ne 0) {
    throw "SQL scripti Oracle tarafinda basarisiz oldu."
}
