# Remote Oracle Demo Package

Bu paket yalnız test veritabanında kullanılmak üzere üç bağımsız demo şeması
oluşturur. Uygulamada bağlantıları `A`, `X` ve `Y` adıyla ekleyip
`A -> X -> Y` pipeline'ı oluşturabilirsiniz.

## Gereksinimler

- Oracle 12c veya sonrası
- Hedef database/PDB üzerinde kullanıcı oluşturabilen bir DBA hesabı
- Varsayılan `USERS` tablespace'i veya scriptte belirteceğiniz başka bir
  tablespace
- SQL*Plus, SQLcl veya uyumlu bir Oracle istemcisi

`20_install_all.sql` dosyasını CDB root yerine uygulamanın bağlanacağı hedef
PDB/service üzerinde çalıştırın. Script şu demo kullanıcılarını oluşturur:

| Uygulamadaki ad | Oracle kullanıcısı | Varsayılan parola |
| --- | --- | --- |
| A | `ODC_A` | `run123` |
| X | `ODC_X` | `run123` |
| Y | `ODC_Y` | `run123` |

Parolayı veya `USERS` tablespace'ini değiştirmek için
`00_create_demo_users.sql` dosyasındaki iki `DEFINE` değerini kurulumdan önce
değiştirin.

## Kurulum

Klasörü hedef sunucuya kopyalayın ve DBA hesabıyla hedef service'e bağlanın:

```text
sqlplus "system/<DBA_PASSWORD>@//<HOST>:<PORT>/<SERVICE>"
SQL> @20_install_all.sql
SQL> @30_verify_all.sql
```

SYS kullanmanız gerekiyorsa:

```text
sqlplus "sys/<DBA_PASSWORD>@//<HOST>:<PORT>/<SERVICE> as sysdba" @20_install_all.sql
```

Kurulum tekrar çalıştırılabilir. Var olan tablolar yeniden oluşturulmaz ve
seed kayıtları `MERGE` ile yalnız eksikse eklenir. Demo kullanıcılarının
parolası kurulumda varsayılan değere geri ayarlanır.

DBA yetkiniz yoksa ve hazır uygulama kullanıcıları kullanılacaksa her hedefe
o kullanıcıyla bağlanıp yalnız aşağıdaki dosyaları çalıştırın:

```text
sqlplus "<APP_USER>/<PASSWORD>@//<HOST>:<PORT>/<SERVICE>"
SQL> @10_install_current_schema.sql
SQL> @31_verify_current_schema.sql
```

Bu yol kullanıcı oluşturmaz ve başka şemalara dokunmaz; bağlı kullanıcının
`CREATE TABLE` ve `CREATE INDEX` yetkileri ile tablespace kotası hazır
olmalıdır.

## Uygulama bağlantıları

**Operasyon -> Veritabanları** ekranında aynı host, port ve service ile üç
bağlantı ekleyin. Kullanıcı adları sırasıyla `ODC_A`, `ODC_X`, `ODC_Y`, parola
ise değiştirmediyseniz `run123` olmalıdır. Bağlantı adları serbesttir; örnek
akış için `A`, `X`, `Y` kullanın.

Aynı Oracle service içindeki üç ayrı şema yalnız yerel/test simülasyonudur.
Gerçek denemede A, X ve Y bağlantıları farklı host veya service'lere gidebilir;
her hedefte `10_install_current_schema.sql` çalıştırılması yeterlidir.

**Operasyon -> Pipeline'lar** ekranında bağlantıları şu sırada ekleyin:

```text
A -> X -> Y
```

## Uygulama içinden çalıştırılacak scriptler

Scriptler Orkestra Mock ekranındaki **Örnekten doldur** alanında da görünür.

1. `requests/01_safe_customer_update.sql`: Tek başına ve tekrar çalışabilir.
2. `requests/02_upsert_demo_order.sql`: Siparişi idempotent oluşturur/günceller.
3. `requests/03_approve_demo_order.sql`: `02` sonrasında siparişi onaylar.
4. `requests/04_record_pipeline_run.sql`: Pipeline çalışma kaydını upsert eder.
5. `requests/05_add_order_note_column.sql`: Kolonu yoksa ekler; tekrar güvenlidir.
6. `requests/06_update_order_note.sql`: `05` sonrasında notu günceller.
7. `requests/07_pipeline_verification_query.sql`: Üç temel tablonun sayılarını
   döndürür.
8. `requests/90_rollback_order_note.sql`: `05` değişikliğini varsa geri alır.

`01`, `02`, `04`, `05` ve `07` temiz kurulumdan hemen sonra çalıştırılabilir.
`03` için önce `02`, `06` için önce `02` ve `05` çalıştırılmalıdır. Bu sıra
izlendiğinde eksik tablo veya kolon hatası oluşmaz.

## Kaldırma

Aşağıdaki komut üç demo kullanıcısını tüm verileriyle siler:

```text
sqlplus "system/<DBA_PASSWORD>@//<HOST>:<PORT>/<SERVICE>" @99_uninstall_all.sql
```

Bu işlem geri alınamaz ve yalnız demo şemalarında kullanılmalıdır.
