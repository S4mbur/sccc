#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Oracle DB CI/CD Pipeline POC - HTTP sunucu ve JSON API.

Calistirma:
    python server.py            (varsayilan http://127.0.0.1:8080)
    python server.py --port 9000 --host 0.0.0.0

HTTP sunucusu standart kutuphane ile calisir; gercek Oracle erisimi icin
python-oracledb kullanilir.
"""
from __future__ import annotations

import argparse
import hmac
import json
import os
import secrets
import sys
import threading
import time
import traceback
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(HERE, "app")
for p in (APP, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

import compare                      # noqa: E402
import connectors                   # noqa: E402
import database_service             # noqa: E402
import inventory                    # noqa: E402
import operations                   # noqa: E402
import pipeline                     # noqa: E402
import rule_profiles                # noqa: E402
import validator_api                # noqa: E402
from store import STORE             # noqa: E402

STATIC = os.path.join(HERE, "static")
EXAMPLES_FILE = os.path.join(HERE, "examples.json")
AUTH_USERNAME = os.environ.get("APP_USERNAME", "RUNNER")
AUTH_PASSWORD = os.environ.get("APP_PASSWORD", "run123")
SESSION_TTL_SECONDS = 12 * 60 * 60
SESSIONS = {}
SESSION_LOCK = threading.RLock()


def authenticate(username, password):
    return (hmac.compare_digest(str(username or ""), AUTH_USERNAME) and
            hmac.compare_digest(str(password or ""), AUTH_PASSWORD))


def create_session(username):
    token = secrets.token_urlsafe(32)
    with SESSION_LOCK:
        SESSIONS[token] = {"username": username, "created_at": time.time()}
    return token


def session_user(cookie_header):
    cookie = SimpleCookie()
    try:
        cookie.load(cookie_header or "")
        token = cookie.get("odc_session").value if cookie.get("odc_session") else ""
    except (AttributeError, KeyError):
        return ""
    with SESSION_LOCK:
        session = SESSIONS.get(token)
        if not session:
            return ""
        if time.time() - session["created_at"] > SESSION_TTL_SECONDS:
            SESSIONS.pop(token, None)
            return ""
        return session["username"]


def delete_session(cookie_header):
    cookie = SimpleCookie()
    try:
        cookie.load(cookie_header or "")
        token = cookie.get("odc_session").value if cookie.get("odc_session") else ""
    except (AttributeError, KeyError):
        token = ""
    with SESSION_LOCK:
        SESSIONS.pop(token, None)


def public_settings():
    """Return UI-safe settings without connector credentials."""
    out = dict(STORE.settings)
    out["orkestra_token_configured"] = bool(out.pop("orkestra_token", ""))
    out.pop("talep_token", None)
    out["octopus_key_configured"] = bool(out.pop("octopus_key", ""))
    return out


def load_examples():
    try:
        with open(EXAMPLES_FILE, encoding="utf-8") as handle:
            definitions = (json.load(handle) or {}).get("examples", [])
        result = []
        for definition in definitions:
            item = dict(definition)
            rel = item.pop("file", "")
            full = os.path.abspath(os.path.join(HERE, rel))
            if not full.startswith(os.path.abspath(HERE) + os.sep):
                continue
            with open(full, encoding="utf-8") as script_file:
                item["script"] = script_file.read()
            item["script_name"] = os.path.basename(full)
            result.append(item)
        return result
    except Exception as exc:  # noqa: BLE001
        STORE.log("HATA", "Örnekler okunamadı: %s" % exc)
        return []


# ------------------------------------------------------------- konnektorler
def orkestra_client():
    s = STORE.settings
    return connectors.OrkestraClient(s.get("orkestra_mode", "MOCK"),
                                     s.get("orkestra_url", ""),
                                     s.get("orkestra_token", ""), STORE)


def talep_client():
    return orkestra_client()


def octopus_client():
    s = STORE.settings
    return connectors.OctopusClient(s.get("octopus_mode", "MOCK"),
                                    s.get("octopus_url", ""),
                                    s.get("octopus_key", ""), STORE)


OPERATIONS = operations.OperationsService(
    STORE, database_service.DATABASES, octopus_client)


def accept_orkestra_request(request_id, actor="RUNNER"):
    client = orkestra_client()
    request = client.get_request(request_id)
    if not request:
        return {"ok": False, "error": "Orkestra talebi bulunamadı."}
    if request.get("status") != "PENDING":
        return {"ok": False, "error": "Yalnız bekleyen talep kabul edilebilir."}
    pipeline_type = request.get("pipeline_type", "")
    definition = pipeline.get_pipeline(pipeline_type)
    if not definition:
        return {"ok": False, "error": "Pipeline tipi bulunamadı: %s" % pipeline_type}

    previous = STORE.orkestra_requests.get(request.get("previous_request_id", ""))
    run = STORE.runs.get((previous or {}).get("run_id", ""))
    created_run = False
    if not run:
        result = pipeline.create_run(
            pipeline_type, request.get("title", ""), request.get("script", ""),
            request.get("owner") or actor,
            STORE.settings.get("selected_rule_ids"),
            request.get("script_name", "01-change.sql"))
        if not result.get("ok"):
            return result
        run = result["run"]
        created_run = True

    stage = next((item for item in run.get("stages", [])
                  if item.get("type") == "TALEP" and
                  item.get("env") == request.get("environment") and
                  not item.get("talep_no")), None)
    if not stage:
        if created_run:
            STORE.runs.pop(run["id"], None)
        return {"ok": False,
                "error": "Koşumda bağlanabilecek %s talep aşaması yok." %
                         request.get("environment", "")}

    release_result = octopus_client().reserve_release(
        request.get("environment", ""), pipeline_type, request_id,
        STORE.settings.get("octopus_project", "OracleDeploy"))
    if not release_result.get("ok"):
        if created_run:
            STORE.runs.pop(run["id"], None)
        return release_result
    release = release_result["release"]
    octopus_code = release.get("code") or release.get("Id", "")
    local = STORE.create_talep(
        request.get("environment", "TEST"), request.get("title", ""),
        request.get("script", ""), request.get("script_name", "01-change.sql"),
        request.get("owner") or actor,
        octopus_ref=request.get("previous_deployment_id", ""),
        pipeline_id=pipeline_type, run_id=run["id"],
        target_id=stage.get("target_id", ""), pipeline_type=pipeline_type,
        promotion_id=request.get("promotion_id", ""),
        external_request_id=request_id, octopus_code=octopus_code)
    attached = pipeline.attach_talep(run["id"], stage["id"], local["talep_no"])
    if not attached.get("ok"):
        STORE.talepler.pop(local["talep_no"], None)
        if created_run:
            STORE.runs.pop(run["id"], None)
        return attached
    accepted = client.accept_request(
        request_id, actor, local["talep_no"], run["id"], octopus_code)
    if not accepted.get("ok"):
        stage["talep_no"] = ""
        STORE.talepler.pop(local["talep_no"], None)
        STORE.octopus_releases.pop(octopus_code, None)
        if created_run:
            STORE.runs.pop(run["id"], None)
        else:
            pipeline.evaluate(run)
        return accepted
    if client.mode != "MOCK":
        shadow = dict(request)
        shadow.update({"status": "ACCEPTED", "accepted_by": actor,
                       "accepted_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                       "local_talep_no": local["talep_no"],
                       "run_id": run["id"], "octopus_code": octopus_code})
        STORE.orkestra_requests[request_id] = shadow
    STORE.save()
    return {"ok": True, "request": accepted.get("request", request),
            "talep": local, "run": run, "release": release}


def seed_oracle_lab(payload):
    payload = dict(payload or {})
    password = str(payload.get("password") or "run123")
    host = str(payload.get("host") or "127.0.0.1")
    service = str(payload.get("service_name") or "FREEPDB1")
    profiles = []
    targets = []
    for environment in ("TEST", "PREPROD", "PROD"):
        profile_result = database_service.DATABASES.save_profile({
            "id": "oracle-lab-%s" % environment.lower(),
            "name": "Oracle Lab %s" % environment,
            "environment": "SHARED", "host": host, "port": 1521,
            "service_name": service, "username": "RUNNER_%s" % environment,
            "password": password, "allow_execute": True,
            "call_timeout_seconds": 60,
        })
        if not profile_result.get("ok"):
            return profile_result
        profile = profile_result["profile"]
        target_result = database_service.DATABASES.save_target({
            "id": "target-oracle-lab-%s" % environment.lower(),
            "name": "Oracle Lab %s" % environment,
            "environment": environment,
            "database_profile_id": profile["id"],
            "schema": "RUNNER_%s" % environment, "enabled": True,
            "description": "Docker Oracle laboratuvar hedefi.",
        })
        if not target_result.get("ok"):
            return target_result
        profiles.append(profile)
        targets.append(target_result["target"])
    STORE.save()
    return {"ok": True, "profiles": profiles, "targets": targets}


# ================================================================== API
def api(path, method, body, query):
    # ---------------------------------------------------------- genel
    if path == "/api/health":
        return {"ok": True, "engine": validator_api.engine_info(),
                "database_driver": database_service.DATABASES.driver_info(),
                "talepler": len(STORE.talepler),
                "operation_requests": len(STORE.operation_requests),
                "operation_pipelines": len(STORE.operation_pipelines),
                "orkestra_requests": len(STORE.orkestra_requests),
                "octopus_releases": len(STORE.octopus_releases),
                "deployments": len(STORE.deployments),
                "runs": len(STORE.runs), "targets": len(STORE.targets)}

    if path == "/api/rules":
        return {"ok": True, "rules": validator_api.list_rules()}

    if path == "/api/rule-profiles":
        return {"ok": True, "profiles": rule_profiles.load_profiles()}

    if path == "/api/examples":
        return {"ok": True, "examples": load_examples()}

    if path == "/api/settings":
        if method == "POST":
            incoming = dict(body or {})
            incoming.pop("_actor", None)
            # Empty secret fields mean "keep current secret", not erase it.
            if not incoming.get("orkestra_token"):
                incoming.pop("orkestra_token", None)
            if not incoming.get("octopus_key"):
                incoming.pop("octopus_key", None)
            if "selected_rule_ids" in incoming:
                value = incoming["selected_rule_ids"]
                incoming["selected_rule_ids"] = (None if value is None else
                                                   [str(x) for x in value])
            STORE.settings.update(incoming)
            STORE.log("AYAR", "Ayarlar guncellendi.")
            STORE.save()
        return {"ok": True, "settings": public_settings()}

    if path == "/api/events":
        return {"ok": True, "events": STORE.events[:120]}

    if path == "/api/state":
        return {"ok": True,
                "talepler": list(STORE.talepler.values()),
                "operation_pipelines": OPERATIONS.list_pipelines(),
                "operation_requests": OPERATIONS.list_requests(),
                "orkestra_requests": list(STORE.orkestra_requests.values()),
                "octopus_releases": list(STORE.octopus_releases.values()),
                "deployments": list(STORE.deployments.values()),
                "runs": list(STORE.runs.values()),
                "databases": database_service.DATABASES.list_profiles(),
                "targets": database_service.DATABASES.list_targets(),
                "db_executions": STORE.db_executions[:100],
                "events": STORE.events[:60],
                "settings": public_settings()}

    if path == "/api/reset" and method == "POST":
        STORE.reset(keep_connections=not bool((body or {}).get("include_connections")))
        STORE.save()
        return {"ok": True}

    if path == "/api/seed" and method == "POST":
        return seed_demo(body or {})

    if path == "/api/oracle-lab/seed" and method == "POST":
        return seed_oracle_lab(body or {})

    if path == "/api/operation-pipelines":
        if method == "GET":
            return {"ok": True, "pipelines": OPERATIONS.list_pipelines()}
        return OPERATIONS.save_pipeline(
            body or {}, (body or {}).get("_actor") or "RUNNER")

    if path.startswith("/api/operation-pipelines/") and method == "POST":
        parts = path.split("/")
        pipeline_id = parts[3] if len(parts) > 3 else ""
        action = parts[4] if len(parts) > 4 else ""
        if action == "delete":
            return OPERATIONS.delete_pipeline(pipeline_id)
        return {"ok": False, "error": "Bilinmeyen pipeline aksiyonu."}

    if path == "/api/operation-requests":
        if method == "GET":
            return {"ok": True, "requests": OPERATIONS.list_requests()}
        return OPERATIONS.create_request(
            body or {}, (body or {}).get("_actor") or "RUNNER")

    if path.startswith("/api/operation-requests/") and method == "POST":
        parts = path.split("/")
        request_id = parts[3] if len(parts) > 3 else ""
        action = parts[4] if len(parts) > 4 else ""
        if action == "approve":
            return OPERATIONS.approve_request(
                request_id, (body or {}).get("_actor") or "RUNNER")
        return {"ok": False, "error": "Bilinmeyen talep aksiyonu."}

    if path == "/api/operation-databases":
        if method == "GET":
            return {"ok": True,
                    "databases": database_service.DATABASES.list_profiles()}
        payload = dict(body or {})
        payload.update({"environment": "OPERATION", "allow_execute": True})
        return database_service.DATABASES.save_profile(payload)

    if path.startswith("/api/operation-databases/") and method == "POST":
        parts = path.split("/")
        profile_id = parts[3] if len(parts) > 3 else ""
        action = parts[4] if len(parts) > 4 else ""
        if action == "test":
            return database_service.DATABASES.test(
                profile_id, (body or {}).get("password", ""))
        if action == "delete":
            return database_service.DATABASES.delete_profile(profile_id)
        return {"ok": False, "error": "Bilinmeyen veritabani aksiyonu."}

    # ---------------------------------------------- ORKESTRA / OCTOPUS MOCK
    if path == "/api/orkestra" and method == "GET":
        client = orkestra_client()
        return {"ok": True, "connection": client.ping(),
                "requests": client.list_requests()}

    if path == "/api/orkestra/requests" and method == "POST":
        payload = dict(body or {})
        pipeline_type = str(payload.get("pipeline_type") or "")
        sequence = pipeline.request_environment_sequence(pipeline_type)
        if not sequence:
            return {"ok": False,
                    "error": "Talep aşaması olan geçerli bir pipeline tipi seçin."}
        result = orkestra_client().create_request(payload, sequence)
        if result.get("ok"):
            STORE.save()
        return result

    if path.startswith("/api/orkestra/requests/") and method == "POST":
        parts = path.split("/")
        request_id = parts[4] if len(parts) > 4 else ""
        action = parts[5] if len(parts) > 5 else ""
        actor = (body or {}).get("actor") or (body or {}).get("_actor") or "RUNNER"
        if action == "accept":
            return accept_orkestra_request(request_id, actor)
        if action == "reject":
            result = orkestra_client().reject_request(
                request_id, actor, (body or {}).get("reason", ""))
        elif action == "complete":
            result = orkestra_client().complete_request(request_id, actor)
        else:
            return {"ok": False, "error": "Bilinmeyen Orkestra aksiyonu."}
        if result.get("ok"):
            STORE.save()
        return result

    if path == "/api/octopus" and method == "GET":
        client = octopus_client()
        return {"ok": True, "connection": client.ping(),
                "releases": client.list_releases(),
                "deployments": client.list_deployments()}

    if path.startswith("/api/octopus/releases/") and path.endswith("/result") \
            and method == "POST":
        code = path.split("/")[4]
        result = octopus_client().set_release_result(
            code, bool((body or {}).get("success")),
            (body or {}).get("detail", ""))
        if result.get("ok"):
            STORE.save()
        return result

    # ------------------------------------------------- 1) PARSE EKRANI
    if path == "/api/parse" and method == "POST":
        text = (body or {}).get("script", "")
        name = (body or {}).get("name", "01-degisiklik.sql")
        overrides = (body or {}).get("overrides")
        if overrides is None:
            overrides = STORE.settings.get("rule_overrides") or {}
        if "selected_rule_ids" in (body or {}):
            selected_rule_ids = (body or {}).get("selected_rule_ids")
        else:
            selected_rule_ids = STORE.settings.get("selected_rule_ids")
        val = validator_api.validate_text(text, name, overrides=overrides,
                                          selected_rule_ids=selected_rule_ids)
        try:
            inv = inventory.analyze_inventory(text, name)
        except Exception as exc:                             # noqa: BLE001
            inv = {"error": "%s: %s" % (type(exc).__name__, exc)}
        policy = STORE.settings.get("gate_policy", "PASS_ONLY")
        verdict = val.get("verdict")
        would_run = (verdict == "PASS") if policy == "PASS_ONLY" \
            else verdict in ("PASS", "WARN")
        blockers = [f for f in val.get("findings", [])
                    if f.get("severity") == "FAIL"]
        if not would_run and not blockers and verdict == "WARN":
            reason = ("Karar WARN. Kapi politikasi PASS_ONLY oldugu icin "
                      "otomatik calistirilmaz; manuel onaya duser.")
        elif not would_run:
            reason = ("%d engelleyici bulgu var." % len(blockers)) \
                if blockers else "Karar: %s" % verdict
        else:
            reason = "Tum kapilar yesil; bu script otomatik calistirilabilir."
        return {"ok": True, "validation": val, "inventory": inv,
                "would_run": would_run, "reason": reason,
                "gate_policy": policy}

    # ------------------------------------------- 2) KARSILASTIRMA EKRANI
    if path == "/api/compare" and method == "POST":
        items = (body or {}).get("items", [])
        return dict(compare.compare_many(items), ok=True)

    # --------------------------------------------------- 3) TALEPLER
    if path == "/api/talep" and method == "GET":
        return {"ok": True, "talepler": list(STORE.talepler.values())}

    if path == "/api/talep" and method == "POST":
        b = body or {}
        pipeline_type = str(b.get("pipeline_type") or "")
        if pipeline_type and not pipeline.get_pipeline(pipeline_type):
            return {"ok": False, "error": "Pipeline tipi bulunamadı."}
        t = STORE.create_talep(
            env=b.get("env", "TEST"), title=b.get("title", ""),
            script=b.get("script", ""),
            script_name=b.get("script_name", "01-degisiklik.sql"),
            owner=b.get("owner") or b.get("_actor") or "RUNNER",
            talep_no=b.get("talep_no") or None,
            octopus_ref=b.get("octopus_ref", ""),
            pipeline_type=pipeline_type)
        STORE.save()
        return {"ok": True, "talep": t}

    if path.startswith("/api/talep/") and path.endswith("/note") \
            and method == "POST":
        no = path.split("/")[3]
        res = talep_client().write_note(no, (body or {}).get("text", ""))
        STORE.save()
        return dict(res, ok=res.get("ok", False))

    if path.startswith("/api/talep/") and path.endswith("/octopus-ref") \
            and method == "POST":
        no = path.split("/")[3]
        t = STORE.get_talep(no)
        if not t:
            return {"ok": False, "error": "Talep yok."}
        ref = (body or {}).get("octopus_ref", "").strip()
        t["octopus_ref"] = ref
        talep_client().write_note(no, "Octopus deployment no: %s" % ref)
        STORE.log("TALEP", "%s talebine deployment no yazildi: %s" % (no, ref),
                  talep_no=no)
        STORE.save()
        return {"ok": True, "talep": t}

    if path.startswith("/api/talep/") and path.endswith("/script") \
            and method == "POST":
        no = path.split("/")[3]
        t = STORE.get_talep(no)
        if not t:
            return {"ok": False, "error": "Talep yok."}
        t["script"] = (body or {}).get("script", "")
        STORE.log("TALEP", "%s talebinin scripti degistirildi." % no,
                  talep_no=no)
        STORE.save()
        return {"ok": True, "talep": t}

    if path.startswith("/api/talep/") and path.endswith("/close") \
            and method == "POST":
        no = path.split("/")[3]
        res = talep_client().close_talep(no, (body or {}).get("result", "OK"))
        STORE.save()
        return dict(res, ok=res.get("ok", False))

    if path.startswith("/api/talep/") and method == "GET":
        no = path.split("/")[3]
        t = STORE.get_talep(no)
        if not t:
            return {"ok": False, "error": "Talep yok."}
        try:
            inv = inventory.analyze_inventory(t.get("script", ""),
                                              t.get("script_name", "x.sql"))
        except Exception as exc:                             # noqa: BLE001
            inv = {"error": str(exc)}
        return {"ok": True, "talep": t, "inventory": inv}

    # --------------------------------------------------- 4) PIPELINE
    if path == "/api/pipelines":
        return {"ok": True, "pipelines": pipeline.load_pipelines(),
                "capabilities": pipeline.capabilities()}

    if path == "/api/pipelines/save" and method == "POST":
        result = pipeline.save_definition((body or {}).get("pipeline") or {})
        if result.get("ok"):
            STORE.save()
        return result

    if path == "/api/pipelines/generate" and method == "POST":
        result = pipeline.generate_target_pipeline((body or {}).get("pipeline") or {})
        if result.get("ok"):
            STORE.save()
        return result

    if path.startswith("/api/pipelines/") and path.endswith("/delete") \
            and method == "POST":
        result = pipeline.delete_definition(path.split("/")[3])
        if result.get("ok"):
            STORE.save()
        return result

    if path == "/api/runs" and method == "GET":
        for r in STORE.runs.values():
            pipeline.evaluate(r)
        return {"ok": True, "runs": list(STORE.runs.values())}

    if path == "/api/runs" and method == "POST":
        b = body or {}
        res = pipeline.create_run(b.get("pipeline_id", ""),
                                  b.get("title", ""),
                                  b.get("reference_script", ""),
                                  b.get("owner") or b.get("_actor") or "RUNNER",
                                  b.get("selected_rule_ids",
                                        STORE.settings.get("selected_rule_ids")),
                                  b.get("script_name", "01-change.sql"))
        if (res.get("ok") and b.get("reference_script") and
                b.get("auto_prepare_requests",
                      res["run"].get("auto_prepare_requests"))):
            prepared = pipeline.prepare_requests(
                res["run"]["id"], b.get("reference_script", ""),
                b.get("script_name", "01-change.sql"),
                b.get("owner") or b.get("_actor") or "RUNNER")
            if not prepared.get("ok"):
                return prepared
            res["prepared_requests"] = prepared.get("talepler", [])
        STORE.save()
        return dict(res, ok=res.get("ok", False))

    if path.startswith("/api/runs/"):
        parts = path.split("/")
        run_id = parts[3] if len(parts) > 3 else ""
        action = parts[4] if len(parts) > 4 else ""

        if method == "GET" and not action:
            r = pipeline.get_run(run_id)
            if not r:
                return {"ok": False, "error": "Kosum yok."}
            pipeline.evaluate(r)
            return {"ok": True, "run": r,
                    "identity": pipeline.run_identity_report(run_id)}

        if action == "identity":
            return pipeline.run_identity_report(run_id)

        if method == "POST":
            b = body or {}
            sid = b.get("stage_id", "")
            if action == "attach":
                res = pipeline.attach_talep(run_id, sid, b.get("talep_no", ""))
            elif action == "validate":
                res = pipeline.run_validation(run_id, sid)
            elif action == "deploy":
                res = pipeline.create_deployment(run_id, sid, octopus_client())
            elif action == "db-deploy":
                res = pipeline.execute_database_deployment(
                    run_id, sid, database_service.DATABASES,
                    b.get("profile_id", ""), b.get("password", ""),
                    b.get("confirmation", ""),
                    b.get("transaction_mode", "SCRIPT"),
                    b.get("target_id", ""))
            elif action == "prepare":
                res = pipeline.prepare_requests(
                    run_id, b.get("script", ""),
                    b.get("script_name", "01-change.sql"),
                    b.get("owner") or b.get("_actor") or "RUNNER")
            elif action == "next":
                res = pipeline.next_action(run_id)
            elif action == "advance":
                res = pipeline.advance_run(
                    run_id, database_service.DATABASES, octopus_client(),
                    password=b.get("password", ""),
                    confirmation=b.get("confirmation", ""),
                    approver=b.get("approver", ""),
                    transaction_mode=b.get("transaction_mode", "SCRIPT"))
            elif action == "approve":
                res = pipeline.approve(run_id, sid, b.get("who", ""))
            elif action == "complete":
                res = pipeline.complete_stage(run_id, sid)
            elif action == "fail":
                res = pipeline.fail_stage(run_id, sid, b.get("reason", ""))
            else:
                return {"ok": False, "error": "Bilinmeyen eylem: %s" % action}
            STORE.save()
            return dict(res, ok=res.get("ok", False))

    # ------------------------------------------------- 5) DEPLOYMENTS
    if path == "/api/deployments" and method == "GET":
        return {"ok": True, "deployments": list(STORE.deployments.values())}

    if path.startswith("/api/deployments/") and path.endswith("/result") \
            and method == "POST":
        dep_id = path.split("/")[3]
        b = body or {}
        res = octopus_client().set_deployment_result(
            dep_id, bool(b.get("success")), b.get("detail", ""))
        for r in STORE.runs.values():
            pipeline.evaluate(r)
        STORE.save()
        return dict(res, ok=res.get("ok", False))

    # ----------------------------------------------- 6) ORACLE BAGLANTILARI
    if path == "/api/databases" and method == "GET":
        return {"ok": True,
                "profiles": database_service.DATABASES.list_profiles(),
                "actions": database_service.DATABASES.ACTIONS,
                "driver": database_service.DATABASES.driver_info(),
                "executions": STORE.db_executions[:100]}

    if path == "/api/databases" and method == "POST":
        return database_service.DATABASES.save_profile(body or {})

    if path.startswith("/api/databases/") and method == "POST":
        parts = path.split("/")
        profile_id = parts[3] if len(parts) > 3 else ""
        action = parts[4] if len(parts) > 4 else ""
        if action == "delete":
            return database_service.DATABASES.delete_profile(profile_id)
        if action == "action":
            return database_service.DATABASES.action(
                profile_id, (body or {}).get("action"), body or {})

    if path == "/api/targets" and method == "GET":
        return {"ok": True, "targets": database_service.DATABASES.list_targets()}

    if path == "/api/targets" and method == "POST":
        return database_service.DATABASES.save_target(body or {})

    if path == "/api/targets/seed" and method == "POST":
        return database_service.DATABASES.seed_environment_targets(
            (body or {}).get("database_profile_id", ""),
            (body or {}).get("prefix", "Örnek"))

    if path.startswith("/api/targets/") and path.endswith("/delete") \
            and method == "POST":
        return database_service.DATABASES.delete_target(path.split("/")[3])

    # ---------------------------------------------- 7) DIS SISTEM BAGLANTILARI
    if path == "/api/connectors/test" and method == "POST":
        which = (body or {}).get("which", "both")
        out = {}
        if which in ("both", "talep", "orkestra"):
            out["orkestra"] = orkestra_client().ping()
        if which in ("both", "octopus"):
            out["octopus"] = octopus_client().ping()
        STORE.log("BAGLANTI", "Baglanti testi: %s" % json.dumps(out)[:160])
        return {"ok": True, "result": out}

    return {"ok": False, "error": "Bilinmeyen uc: %s %s" % (method, path)}


# ================================================================ demo veri
DEMO_SCRIPT = """/*
 * TALEP NO  : {talep}
 * YAZAN     : burak.yalcin
 * TARIH     : 2026-08-12
 * AMAC      : Risk skoru kolonu ve indeksi
 * GERI ALMA : 99-rollback.sql
 * VERITABANI: {env}
 */
WHENEVER SQLERROR EXIT FAILURE ROLLBACK;
WHENEVER OSERROR EXIT FAILURE ROLLBACK;
SET DEFINE OFF;

CREATE TABLE BANKAPP.MUSTERI_RISK (
  MUSTERI_NO NUMBER        NOT NULL,
  SKOR       NUMBER(3)     DEFAULT 0,
  GUNCELLEME DATE          DEFAULT SYSDATE
) TABLESPACE TS_BANKAPP;

ALTER TABLE BANKAPP.MUSTERI_RISK
  ADD CONSTRAINT PK_MUSTERI_RISK PRIMARY KEY (MUSTERI_NO);

CREATE INDEX BANKAPP.IX_MUSTERI_RISK_SKOR
    ON BANKAPP.MUSTERI_RISK (SKOR) TABLESPACE TS_BANKAPP_IDX ONLINE;

COMMENT ON TABLE BANKAPP.MUSTERI_RISK IS 'Musteri risk skoru';
COMMENT ON COLUMN BANKAPP.MUSTERI_RISK.SKOR IS 'Risk skoru 0-100';

EXIT SUCCESS;
"""


def seed_demo(opts):
    """Create two realistic runs: promoted DDL and direct-to-PROD DML."""
    STORE.reset()
    examples = {item["id"]: item for item in load_examples()}
    ddl = examples.get("ddl-promoted") or {
        "script": DEMO_SCRIPT.format(talep="CHG-2026-0001", env="TESTDB01"),
        "script_name": "01-musteri_risk.sql"}
    dml = examples.get("dml-direct-prod") or ddl

    ddl_res = pipeline.create_run(
        "ddl_database_promoted", "Müşteri risk tablosu kontrollü yükseltme",
        "", "burak.yalcin")
    if not ddl_res.get("ok"):
        return ddl_res
    ddl_run = ddl_res["run"]
    test_request = STORE.create_talep(
        "TEST", "Müşteri risk tablosu", ddl["script"], ddl["script_name"],
        "burak.yalcin")
    pipeline.attach_talep(ddl_run["id"], "test_talep",
                          test_request["talep_no"])

    dml_res = pipeline.create_run(
        "dml_direct_prod", "Seçili müşteri risk skoru düzeltmesi",
        "", "burak.yalcin")
    if not dml_res.get("ok"):
        return dml_res
    dml_run = dml_res["run"]
    prod_request = STORE.create_talep(
        "PROD", "Risk skoru veri düzeltmesi", dml["script"],
        dml["script_name"], "burak.yalcin")
    pipeline.attach_talep(dml_run["id"], "prod_talep",
                          prod_request["talep_no"])
    STORE.save()
    return {"ok": True,
            "run_ids": [ddl_run["id"], dml_run["id"]],
            "talep_nos": [test_request["talep_no"],
                           prod_request["talep_no"]],
            "run_id": ddl_run["id"],
            "message": "DDL yükseltme ve doğrudan PROD DML demo koşumları oluşturuldu."}


# ================================================================ HTTP
class Handler(BaseHTTPRequestHandler):
    server_version = "OracleCICDPoc/1.0"

    def log_message(self, fmt, *args):        # sessiz
        pass

    def _send(self, code, payload, ctype="application/json; charset=utf-8",
              extra_headers=None):
        if isinstance(payload, (dict, list)):
            data = json.dumps(payload, ensure_ascii=False,
                              default=str).encode("utf-8")
        elif isinstance(payload, str):
            data = payload.encode("utf-8")
        else:
            data = payload
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        for key, value in (extra_headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _static(self, rel):
        fp = os.path.join(STATIC, rel)
        if not os.path.isfile(fp):
            self._send(404, "Bulunamadi: %s" % rel, "text/plain; charset=utf-8")
            return
        ctype = "text/html; charset=utf-8"
        if rel.endswith(".js"):
            ctype = "application/javascript; charset=utf-8"
        elif rel.endswith(".css"):
            ctype = "text/css; charset=utf-8"
        with open(fp, "rb") as f:
            self._send(200, f.read(), ctype)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ("/", "/index.html"):
            return self._static("index.html")
        if u.path.startswith("/static/"):
            return self._static(u.path[len("/static/"):])
        if u.path == "/api/auth/me":
            username = session_user(self.headers.get("Cookie", ""))
            return self._send(200 if username else 401,
                              {"ok": bool(username), "username": username,
                               "role": "ADMIN" if username else ""})
        if u.path.startswith("/api/"):
            if u.path != "/api/health" and not session_user(
                    self.headers.get("Cookie", "")):
                return self._send(401, {"ok": False,
                                        "error": "Oturum açmanız gerekiyor."})
            try:
                return self._send(200, api(u.path, "GET", None,
                                           parse_qs(u.query)))
            except Exception:                                # noqa: BLE001
                return self._send(500, {"ok": False,
                                        "error": traceback.format_exc()})
        return self._send(404, {"ok": False, "error": "Yok"})

    def do_POST(self):
        u = urlparse(self.path)
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b""
        try:
            body = json.loads(raw.decode("utf-8")) if raw else {}
        except Exception:                                    # noqa: BLE001
            body = {}
        if u.path == "/api/auth/login":
            username = str(body.get("username") or "")
            if not authenticate(username, body.get("password")):
                return self._send(401, {"ok": False,
                                        "error": "Kullanıcı adı veya parola hatalı."})
            token = create_session(username)
            return self._send(
                200, {"ok": True, "username": username, "role": "ADMIN"},
                extra_headers={
                    "Set-Cookie": "odc_session=%s; Path=/; HttpOnly; SameSite=Strict" %
                                  token})
        if u.path == "/api/auth/logout":
            delete_session(self.headers.get("Cookie", ""))
            return self._send(
                200, {"ok": True},
                extra_headers={"Set-Cookie":
                               "odc_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"})
        if not u.path.startswith("/api/"):
            return self._send(404, {"ok": False, "error": "Yok"})
        username = session_user(self.headers.get("Cookie", ""))
        if not username:
            return self._send(401, {"ok": False,
                                    "error": "Oturum açmanız gerekiyor."})
        body["_actor"] = username
        try:
            return self._send(200, api(u.path, "POST", body,
                                       parse_qs(u.query)))
        except Exception:                                    # noqa: BLE001
            return self._send(500, {"ok": False,
                                    "error": traceback.format_exc()})


def main():
    ap = argparse.ArgumentParser(description="Oracle CI/CD Pipeline POC")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--fresh", action="store_true",
                    help="Kayitli durumu yukleme, sifirdan basla")
    args = ap.parse_args()

    if not args.fresh:
        STORE.load()

    info = validator_api.engine_info()
    print("=" * 68)
    print(" Oracle DB CI/CD Pipeline POC")
    print("=" * 68)
    if info.get("ok"):
        print(" Validator motoru : %d kural (%d aktif)"
              % (info["rules_total"], info["rules_active"]))
    else:
        print(" Validator motoru : YUKLENEMEDI -> %s" % info.get("error"))
        print(" (Uygulama yine acilir; parse ekrani hata gosterir.)")
    print(" Pipeline sayisi  : %d" % len(pipeline.load_pipelines()))
    print(" Adres            : http://%s:%d" % (args.host, args.port))
    print("=" * 68)
    print(" Kapatmak icin Ctrl+C")
    srv = ThreadingHTTPServer((args.host, args.port), Handler)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nKapatiliyor...")
        STORE.save()
        srv.server_close()


if __name__ == "__main__":
    main()
