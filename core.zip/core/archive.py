# -*- coding: utf-8 -*-
"""ZIP arsiv guvenlik denetimi (ZIP-001..ZIP-025).

Arsiv TEK KEZ acilir; ad ve icerik ayni byte blob'u uzerinden analiz edilir
(ZIP-020, TOCTOU). Uye listesi, boyut, oran, sifreleme, path ve cakisma
kontrolleri parse baslamadan yapilir.
"""
# Karsilanan master kontroller: ZIP-014 ZIP-018 ZIP-019 ZIP-020 INP-002
from __future__ import annotations

import os
import re
import zipfile
from typing import Any, Dict, List, Tuple

DEFAULT_ZIP_LIMITS = {
    "max_members": 100,               # ZIP-001
    "max_member_bytes": 5 * 1024 * 1024,   # ZIP-002
    "max_total_bytes": 50 * 1024 * 1024,   # ZIP-002
    "max_ratio": 100,                 # ZIP-003 (zip bomb)
    "allow_nested_archive": False,    # ZIP-004
    "allow_directories": False,       # ZIP-011
}
ARCHIVE_EXT = (".zip", ".tar", ".gz", ".7z", ".rar", ".bz2", ".xz", ".jar", ".tgz")
HIDDEN_PATTERNS = (".ds_store", "thumbs.db", "__macosx", ".git", ".svn")
TEMP_PATTERNS = (".bak", ".tmp", ".swp", "~", ".orig", ".rej")


def inspect_archive(path: str, limits: Dict[str, Any] = None
                    ) -> Tuple[List[Tuple[str, str, str]], Dict[str, bytes]]:
    """(bulgular, {uye_adi: icerik}) dondurur. Fatal bulgu varsa icerik bostur."""
    lim = dict(DEFAULT_ZIP_LIMITS)
    lim.update(limits or {})
    issues: List[Tuple[str, str, str]] = []
    blobs: Dict[str, bytes] = {}

    try:
        zf = zipfile.ZipFile(path)
    except zipfile.BadZipFile as exc:
        return [("ZIP-007", "FAIL", "Arsiv okunamadi/bozuk: %s" % exc)], {}

    with zf:
        infos = zf.infolist()
        # ZIP-007: CRC ve merkezi dizin tutarliligi
        bad = zf.testzip()
        if bad:
            issues.append(("ZIP-007", "FAIL", "CRC hatasi: %s" % bad))
            return issues, {}

        real = [i for i in infos if not i.is_dir()]
        if len(real) > int(lim["max_members"]):
            issues.append(("ZIP-001", "FAIL",
                           "Uye sayisi %d; limit %d." % (len(real), lim["max_members"])))
            return issues, {}

        total = 0
        seen_lower = {}
        for info in infos:
            name = info.filename

            # ZIP-009: path traversal / mutlak yol / surucu harfi / UNC
            if name.startswith("/") or name.startswith("\\") or \
                    re.match(r"^[A-Za-z]:", name) or ".." in name.replace("\\", "/").split("/"):
                issues.append(("ZIP-009", "FAIL",
                               "Guvensiz yol: '%s' (path traversal)." % name))
                continue

            if info.is_dir():
                if not lim["allow_directories"]:
                    issues.append(("ZIP-011", "FAIL",
                                   "Arsivde dizin var: '%s' (duz yapi bekleniyor)." % name))
                continue

            # ZIP-010: symlink / ozel dosya (unix mode ust bitleri)
            mode = info.external_attr >> 16
            if mode and (mode & 0xF000) == 0xA000:
                issues.append(("ZIP-010", "FAIL",
                               "Arsivde symlink: '%s'." % name))
                continue

            # ZIP-005: sifreli uye
            if info.flag_bits & 0x1:
                issues.append(("ZIP-005", "FAIL",
                               "Sifreli arsiv uyesi: '%s'." % name))
                continue

            # ZIP-006: desteklenmeyen sikistirma
            if info.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
                issues.append(("ZIP-006", "FAIL",
                               "Desteklenmeyen sikistirma yontemi: '%s' (%d)."
                               % (name, info.compress_type)))
                continue

            # ZIP-008: buyuk/kucuk harf cakismasi
            low = os.path.basename(name).lower()
            if low in seen_lower:
                issues.append(("ZIP-008", "FAIL",
                               "Tekrarlanan/cakisan uye adi: '%s' ve '%s'."
                               % (seen_lower[low], name)))
            seen_lower[low] = name

            # ZIP-004: ic ice arsiv / polyglot
            if low.endswith(ARCHIVE_EXT):
                issues.append(("ZIP-004", "FAIL",
                               "Ic ice arsiv: '%s'." % name))
                continue

            # ZIP-013: gizli / gecici / editor dosyasi
            if any(h in low for h in HIDDEN_PATTERNS) or \
                    any(low.endswith(t) for t in TEMP_PATTERNS) or low.startswith("."):
                issues.append(("ZIP-013", "FAIL",
                               "Gizli/gecici dosya: '%s'." % name))
                continue

            # ZIP-002: uye boyutu
            if info.file_size > int(lim["max_member_bytes"]):
                issues.append(("ZIP-002", "FAIL",
                               "'%s' %d byte; uye limiti %d."
                               % (name, info.file_size, lim["max_member_bytes"])))
                continue

            # ZIP-003: sikistirma orani (zip bomb)
            if info.compress_size > 0:
                ratio = info.file_size / float(info.compress_size)
                if ratio > float(lim["max_ratio"]):
                    issues.append(("ZIP-003", "FAIL",
                                   "'%s' sikistirma orani %.0f:1; limit %d:1 "
                                   "(zip bomb)." % (name, ratio, lim["max_ratio"])))
                    continue

            total += info.file_size
            if total > int(lim["max_total_bytes"]):
                issues.append(("ZIP-002", "FAIL",
                               "Toplam acilmis boyut %d byte; limit %d."
                               % (total, lim["max_total_bytes"])))
                return issues, {}

            try:
                blobs[name] = zf.read(name)
            except Exception as exc:                 # noqa: BLE001
                issues.append(("ZIP-007", "FAIL",
                               "'%s' okunamadi: %s" % (name, exc)))

        # ZIP-021: arsiv yorumu boyutu
        if zf.comment and len(zf.comment) > 1024:
            issues.append(("ZIP-021", "WARN",
                           "Arsiv yorumu %d byte." % len(zf.comment)))

    if not blobs and not issues:
        issues.append(("ZIP-012", "FAIL", "Arsivde calistirilabilir uye yok."))
    return issues, blobs
