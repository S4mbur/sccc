# -*- coding: utf-8 -*-
"""Kural kesfi (auto-discovery) ve config uygulama.

rules/ klasorune bir .py dosyasi eklemek = kurali eklemek.
Dosyayi silmek = kurali kaldirmak. Baska hicbir yerde kayit gerekmez.
"""
# Karsilanan master kontroller: GATE-009 GATE-010 CUR-032 CUR-033 OBS-004
from __future__ import annotations

import importlib
import inspect
import os
import pkgutil
import sys
from typing import Any, Dict, List

from .model import BaseRule, Severity


class EngineError(Exception):
    """Fail-closed motor hatasi (GATE-010). Analiz sonucu KULLANILAMAZ."""

RULES_PACKAGE = "rules"


def discover_rules(rules_dir: str = None, config: Dict[str, Any] = None) -> List[BaseRule]:
    config = config or {}
    rule_cfg = config.get("rules") or {}

    base = rules_dir or os.path.join(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), RULES_PACKAGE)
    parent = os.path.dirname(base)
    if parent not in sys.path:
        sys.path.insert(0, parent)

    found: Dict[str, BaseRule] = {}
    errors: List[str] = []

    for mod_info in sorted(pkgutil.iter_modules([base]), key=lambda m: m.name):
        if mod_info.name.startswith("_"):
            continue
        try:
            module = importlib.import_module("%s.%s" % (RULES_PACKAGE, mod_info.name))
        except Exception as exc:                      # noqa: BLE001
            errors.append("%s yuklenemedi: %s" % (mod_info.name, exc))
            continue

        for _, obj in inspect.getmembers(module, inspect.isclass):
            if not issubclass(obj, BaseRule) or obj is BaseRule:
                continue
            if obj.__module__ != module.__name__:
                continue
            if not getattr(obj, "id", ""):
                continue
            rid = obj.id
            if rid in found:
                errors.append("Tekrarlanan kural id: %s" % rid)
                continue

            over = rule_cfg.get(rid) or {}
            if isinstance(over, bool):        # kisayol:  ORA001: false
                over = {"enabled": over}
            try:
                inst = obj(
                    severity=over.get("severity"),
                    enabled=over.get("enabled"),
                    params=over.get("params"),
                )
            except Exception as exc:          # noqa: BLE001
                errors.append("%s ornegi olusturulamadi: %s" % (rid, exc))
                continue
            found[rid] = inst

    # GATE-010 / CUR-033: import hatasi veya tekrarlanan ID fail-closed
    if errors:
        raise EngineError(
            "Kural seti yuklenemedi (%d hata):\n  - %s"
            % (len(errors), "\n  - ".join(errors)))

    rules = [found[k] for k in sorted(found)]
    verify_manifest(rules, config)
    return rules


def verify_manifest(rules, config):
    """GATE-009: beklenen kural ID manifesti + minimum aktif kural sayisi.

    manifest yoksa uretilir (ilk kurulum); varsa birebir dogrulanir.
    Boylece bir kural dosyasinin sessizce silinmesi/bozulmasi fark edilir.
    """
    import hashlib
    import json

    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    mpath = os.path.join(base, "rules_manifest.json")
    ids = sorted(r.id for r in rules)
    active = sorted(r.id for r in rules if r.enabled)

    src_hash = hashlib.sha256()
    rdir = os.path.join(base, RULES_PACKAGE)
    for fn in sorted(os.listdir(rdir)):
        if fn.endswith(".py"):
            with open(os.path.join(rdir, fn), "rb") as f:
                src_hash.update(f.read())
    digest = src_hash.hexdigest()

    if not os.path.exists(mpath):
        with open(mpath, "w", encoding="utf-8") as f:
            json.dump({"rule_ids": ids, "min_active": len(active),
                       "rules_sha256": digest}, f, ensure_ascii=False, indent=2)
        return {"rules_sha256": digest, "generated": True}

    with open(mpath, encoding="utf-8") as f:
        man = json.load(f)

    problems = []
    missing = sorted(set(man.get("rule_ids", [])) - set(ids))
    extra = sorted(set(ids) - set(man.get("rule_ids", [])))
    if missing:
        problems.append("Manifestte olup yuklenmeyen kural(lar): %s"
                        % ", ".join(missing))
    if extra and not man.get("allow_extra", True):
        problems.append("Manifestte olmayan kural(lar): %s" % ", ".join(extra))
    if len(active) < int(man.get("min_active", 0)):
        problems.append("Aktif kural sayisi %d; beklenen en az %d"
                        % (len(active), man.get("min_active")))
    if problems:
        raise EngineError("Kural manifesti dogrulanamadi:\n  - %s"
                          % "\n  - ".join(problems))
    return {"rules_sha256": digest, "manifest_sha256": man.get("rules_sha256", ""),
            "source_changed": digest != man.get("rules_sha256", "")}


def run_rules(rules: List[BaseRule], ctx) -> List:
    findings = []
    for rule in rules:
        if not rule.enabled:
            continue
        try:
            res = rule.check(ctx) or []
            for f in res:
                if f is not None:
                    findings.append(f)
        except Exception as exc:              # noqa: BLE001
            # GATE-010 / CUR-032: kural hatasi WARN'a cevrilmez, analiz durur.
            import traceback
            raise EngineError(
                "Kural %s (%s) calistirilirken hata: %s: %s\n%s"
                % (rule.id, rule.name, type(exc).__name__, exc,
                   traceback.format_exc(limit=3)))
    findings.sort(key=lambda f: f.sort_key())
    return findings
