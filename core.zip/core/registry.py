# -*- coding: utf-8 -*-
"""Kural kesfi (auto-discovery) ve config uygulama.

rules/ klasorune bir .py dosyasi eklemek = kurali eklemek.
Dosyayi silmek = kurali kaldirmak. Baska hicbir yerde kayit gerekmez.
"""
from __future__ import annotations

import importlib
import inspect
import os
import pkgutil
import sys
from typing import Any, Dict, List

from .model import BaseRule, Severity

RULES_PACKAGE = "rules"


def discover_rules(rules_dir: str = None, config: Dict[str, Any] = None) -> List[BaseRule]:
    config = config or {}
    rule_cfg = config.get("rules") or {}

    base = rules_dir or os.path.join(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), RULES_PACKAGE)
    parent = os.path.dirname(base)
    if parent not in sys.path:
        sys.path.insert(0, parent)

    found: Dict[str, BaseRule] = {}
    errors: List[str] = []

    for mod_info in sorted(pkgutil.iter_modules([base]), key=lambda m: m.name):
        if mod_info.name.startswith("_"):
            continue
        try:
            module = importlib.import_module("%s.%s" % (RULES_PACKAGE, mod_info.name))
        except Exception as exc:                      # noqa: BLE001
            errors.append("%s yuklenemedi: %s" % (mod_info.name, exc))
            continue

        for _, obj in inspect.getmembers(module, inspect.isclass):
            if not issubclass(obj, BaseRule) or obj is BaseRule:
                continue
            if obj.__module__ != module.__name__:
                continue
            if not getattr(obj, "id", ""):
                continue
            rid = obj.id
            if rid in found:
                errors.append("Tekrarlanan kural id: %s" % rid)
                continue

            over = rule_cfg.get(rid) or {}
            if isinstance(over, bool):        # kisayol:  ORA001: false
                over = {"enabled": over}
            try:
                inst = obj(
                    severity=over.get("severity"),
                    enabled=over.get("enabled"),
                    params=over.get("params"),
                )
            except Exception as exc:          # noqa: BLE001
                errors.append("%s ornegi olusturulamadi: %s" % (rid, exc))
                continue
            found[rid] = inst

    if errors:
        for e in errors:
            sys.stderr.write("[registry] UYARI: %s\n" % e)

    return [found[k] for k in sorted(found)]


def run_rules(rules: List[BaseRule], ctx) -> List:
    findings = []
    for rule in rules:
        if not rule.enabled:
            continue
        try:
            res = rule.check(ctx) or []
            for f in res:
                if f is not None:
                    findings.append(f)
        except Exception as exc:              # noqa: BLE001
            from .model import Finding
            findings.append(Finding(
                rule_id=rule.id, rule_name=rule.name, category="MOTOR",
                severity=Severity.WARN,
                message="Kural calistirilirken hata: %s: %s" % (type(exc).__name__, exc),
                line=0, suggestion="Kural dosyasini gozden gecirin.",
            ))
    findings.sort(key=lambda f: f.sort_key())
    return findings
