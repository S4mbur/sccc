# -*- coding: utf-8 -*-
"""Guvenli kaynak okuma: BOM, encoding, kontrol karakterleri, limitler, hash.

Master kontrol listesi karsiliklari:
  INP-001/002 byte limitleri            INP-008 hash-once-normalize-later
  INP-003/004 BOM tespiti/red           INP-009 U+2028/2029
  INP-005     decode hatasi FAIL        INP-010 NFC normalizasyon kontrolu
  INP-006     encoding belirsizligi     INP-018 satir limiti
  INP-007     NUL/C0/C1/bidi/zero-width GATE-007 SHA-256 artifact bagi
"""
# Karsilanan master kontroller: INP-002 INP-014 INP-015 INP-017 LEX-003
from __future__ import annotations

import hashlib
import io
import os
import re
import unicodedata
from typing import Any, Dict, List, Tuple

BOMS = [
    (b"\x00\x00\xfe\xff", "UTF-32BE", False),
    (b"\xff\xfe\x00\x00", "UTF-32LE", False),
    (b"\xef\xbb\xbf", "UTF-8-BOM", True),
    (b"\xfe\xff", "UTF-16BE", False),
    (b"\xff\xfe", "UTF-16LE", False),
]

# INP-007 / INP-009: kodda hicbir zaman bulunmamasi gereken karakterler
FORBIDDEN_CHARS = {
    "\x00": "NUL",
    "\x1b": "ANSI ESC",
    "​": "zero-width space",
    "‌": "zero-width non-joiner",
    "‍": "zero-width joiner",
    "⁠": "word joiner",
    "﻿": "BOM (metin ortasinda)",
    "‪": "bidi LRE", "‫": "bidi RLE", "‬": "bidi PDF",
    "‭": "bidi LRO", "‮": "bidi RLO",
    "⁦": "bidi LRI", "⁧": "bidi RLI", "⁨": "bidi FSI",
    "⁩": "bidi PDI",
    " ": "Unicode LINE SEPARATOR", " ": "Unicode PARAGRAPH SEPARATOR",
}

DEFAULT_LIMITS = {
    "max_file_bytes": 5 * 1024 * 1024,     # INP-001
    "max_line_chars": 2499,                # INP-018 (SQL*Plus siniri)
    "max_lines": 100000,
}


class SourceError(Exception):
    """Okuma asamasinda fail-closed hata (analiz baslamaz)."""


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def detect_bom(data: bytes) -> Tuple[str, int, bool]:
    """(bom_adi, byte_uzunlugu, desteklenir_mi)"""
    for sig, name, supported in BOMS:
        if data.startswith(sig):
            return name, len(sig), supported
    return "", 0, True


def read_source(path: str, declared_encoding: str = "utf-8",
                data: bytes = None, limits: Dict[str, Any] = None) -> Dict[str, Any]:
    """Kaynagi okur ve meta bilgisi ile birlikte dondurur.

    Donen sozluk:
      text, sha256, size, bom, encoding, issues[(kod, seviye, mesaj)],
      fatal (bool) -> True ise analiz yapilmamalidir.
    """
    lim = dict(DEFAULT_LIMITS)
    lim.update(limits or {})
    issues: List[Tuple[str, str, str]] = []

    if data is None:
        # INP-015: symlink / ozel dosya kaynak kabul edilmez
        real = path.split("!")[0]
        if os.path.islink(real):
            issues.append(("INP-015", "FAIL",
                           "Kaynak bir symlink: '%s'. Gercek dosya gonderilmeli."
                           % real))
            return {"path": path, "sha256": "", "size": 0, "bom": "",
                    "encoding": declared_encoding, "issues": issues,
                    "fatal": True, "text": ""}
        with io.open(real, "rb") as f:
            data = f.read()
        try:
            st = os.stat(real)
            meta_stat = {"mtime": st.st_mtime, "size": st.st_size}
        except OSError:
            meta_stat = {}
    else:
        meta_stat = {}

    meta: Dict[str, Any] = {
        "path": path,
        "sha256": sha256_bytes(data),        # GATE-007: normalizasyon ONCESI hash
        "size": len(data),
        "bom": "",
        "encoding": declared_encoding,
        "issues": issues,
        "fatal": False,
        "text": "",
        # INP-017: validation sonrasi degisim tespiti icin (TOCTOU)
        "stat": meta_stat,
    }

    # INP-014: MIME/magic ile uzanti uyusmazligi
    for sig, what in ((b"MZ", "Windows executable"), (b"PK\x03\x04", "ZIP arsivi"),
                      (b"\x7fELF", "ELF binary"), (b"%PDF", "PDF"),
                      (b"\xd0\xcf\x11\xe0", "MS Office/OLE"),
                      (b"\x1f\x8b", "gzip")):
        if data.startswith(sig):
            issues.append(("INP-014", "FAIL",
                           "Dosya icerigi %s gorunuyor; .sql/.txt bekleniyor."
                           % what))
            meta["fatal"] = True
            return meta

    # INP-001: boyut limiti
    if len(data) > int(lim["max_file_bytes"]):
        issues.append(("INP-001", "FAIL",
                       "Dosya %d byte; limit %d byte."
                       % (len(data), lim["max_file_bytes"])))
        meta["fatal"] = True
        return meta

    if not data.strip():
        issues.append(("INP-022", "FAIL", "Dosya bos veya yalniz bosluk iceriyor."))

    # INP-003/004: BOM
    bom, blen, supported = detect_bom(data)
    if bom:
        meta["bom"] = bom
        if not supported:
            issues.append(("INP-004", "FAIL",
                           "%s BOM destegi yok; dosya UTF-8 olarak gonderilmeli."
                           % bom))
            meta["fatal"] = True
            return meta
        # UTF-8 BOM: temizlenir ve raporlanir (CUR-001/002)
        issues.append(("INP-003", "FAIL",
                       "Dosya UTF-8 BOM ile basliyor; BOM ilk komutu gizleyerek "
                       "kontrolleri atlatabilir. BOM'suz kaydedin."))
        data = data[blen:]

    # INP-005/006: decode - errors=replace KULLANILMAZ
    try:
        text = data.decode(declared_encoding)
    except (UnicodeDecodeError, LookupError) as exc:
        issues.append(("INP-005", "FAIL",
                       "Dosya %s olarak cozulemedi: %s. Talep metadata'sindaki "
                       "encoding ile gonderin." % (declared_encoding, exc)))
        meta["fatal"] = True
        return meta

    if "�" in text:
        issues.append(("INP-005", "FAIL",
                       "Metinde replacement karakteri (U+FFFD) var; kaynak "
                       "encoding yanlis."))
        meta["fatal"] = True
        return meta

    # INP-007/009: yasak karakterler
    for ch, label in FORBIDDEN_CHARS.items():
        pos = text.find(ch)
        if pos >= 0:
            line = text.count("\n", 0, pos) + 1
            issues.append(("INP-007", "FAIL",
                           "Satir %d: yasak karakter %s (U+%04X)."
                           % (line, label, ord(ch))))
    # Diger C0/C1 kontrol karakterleri (TAB, LF, CR haric)
    for m in re.finditer(r"[\x01-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]", text):
        line = text.count("\n", 0, m.start()) + 1
        issues.append(("INP-007", "FAIL",
                       "Satir %d: kontrol karakteri U+%04X."
                       % (line, ord(m.group(0)))))
        break

    # INP-010: NFC normalizasyon farki
    if unicodedata.normalize("NFC", text) != text:
        issues.append(("INP-010", "WARN",
                       "Metin NFC normalize degil; obje adlarinda gorunmeyen "
                       "fark olusabilir."))

    # INP-008: satir sonu normalizasyonu (hash zaten alindi)
    crlf = text.count("\r\n")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    if crlf:
        issues.append(("INP-008", "INFO",
                       "%d CRLF satir sonu LF'e normalize edildi." % crlf))

    lines = text.split("\n")
    if len(lines) > int(lim["max_lines"]):
        issues.append(("INP-019", "FAIL",
                       "Satir sayisi %d; limit %d." % (len(lines), lim["max_lines"])))
    for i, ln in enumerate(lines, start=1):
        if len(ln) > int(lim["max_line_chars"]):
            issues.append(("INP-018", "FAIL",
                           "Satir %d uzunlugu %d; limit %d (SQL*Plus keser)."
                           % (i, len(ln), lim["max_line_chars"])))
            break

    meta["text"] = text
    return meta


# --------------------------------------------------------- dosya adi kontrolu
WINDOWS_RESERVED = {
    "CON", "PRN", "AUX", "NUL",
    *("COM%d" % i for i in range(1, 10)),
    *("LPT%d" % i for i in range(1, 10)),
}
SHELL_METACHARS = set(' \t\n\r"\'`$&|;<>()*?[]{}!#~^%')
ALLOWED_SCRIPT_EXT = (".sql", ".txt")


def check_filename(name: str) -> List[Tuple[str, str, str]]:
    """INP-012/013/023/024: dosya adi guvenligi."""
    out = []
    base = os.path.basename(name.replace("\\", "/"))

    if base != name.replace("\\", "/"):
        out.append(("ZIP-009", "FAIL",
                    "Dosya adinda dizin bileseni var: '%s' (path traversal riski)."
                    % name))
    if base in ("", ".", ".."):
        out.append(("ZIP-009", "FAIL", "Gecersiz dosya adi: '%s'" % name))
        return out

    stem = base.rsplit(".", 1)[0]
    if stem.upper() in WINDOWS_RESERVED:
        out.append(("INP-024", "FAIL",
                    "'%s' Windows rezerve cihaz adi." % base))
    if base != base.rstrip(". "):
        out.append(("INP-024", "FAIL",
                    "Dosya adi nokta/bosluk ile bitiyor: '%s'" % base))

    bad = sorted({c for c in base if c in SHELL_METACHARS or ord(c) < 32})
    if bad:
        out.append(("INP-023", "FAIL",
                    "Dosya adinda yasak karakter(ler): %s"
                    % " ".join(repr(c) for c in bad)))
    if re.search(r"[^\x00-\x7F]", base):
        out.append(("INP-023", "FAIL",
                    "Dosya adinda ASCII disi karakter: '%s'" % base))

    # INP-013: cift / gizli uzanti  (x.sql.exe, x.sql.bak, x.sql.)
    parts = base.lower().split(".")
    if len(parts) > 2:
        out.append(("INP-013", "FAIL",
                    "Cift uzanti: '%s' (yalniz tek .sql/.txt kabul edilir)." % base))
    elif len(parts) == 2 and ("." + parts[1]) not in ALLOWED_SCRIPT_EXT:
        out.append(("INP-012", "FAIL",
                    "Gecersiz uzanti: '.%s' (izinli: %s)"
                    % (parts[1], ", ".join(ALLOWED_SCRIPT_EXT))))
    elif len(parts) == 1:
        out.append(("INP-012", "FAIL", "Dosya uzantisi yok: '%s'" % base))
    return out
