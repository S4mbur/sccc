# -*- coding: utf-8 -*-
"""Temel veri modelleri: Severity, Finding, BaseRule."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Iterable, List, Optional


class Severity(str):
    """Kural siddet seviyesi. str tabanli, JSON'a dogrudan serilesir."""
    INFO = "INFO"
    WARN = "WARN"
    FAIL = "FAIL"

    ORDER = {"INFO": 0, "WARN": 1, "FAIL": 2}

    @classmethod
    def rank(cls, value: str) -> int:
        return cls.ORDER.get(str(value).upper(), 0)

    @classmethod
    def normalize(cls, value: str) -> str:
        v = str(value).upper().strip()
        if v in cls.ORDER:
            return v
        raise ValueError("Gecersiz severity: %r (INFO|WARN|FAIL olmali)" % value)

    @classmethod
    def max(cls, values: Iterable[str]) -> str:
        best = "INFO"
        for v in values:
            if cls.rank(v) > cls.rank(best):
                best = v
        return best


@dataclass
class Finding:
    """Tek bir kural ihlali."""
    rule_id: str
    rule_name: str
    category: str
    severity: str
    message: str
    line: int = 0
    column: int = 0
    snippet: str = ""
    suggestion: str = ""
    statement_index: Optional[int] = None
    object_name: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def sort_key(self):
        return (-Severity.rank(self.severity), self.line, self.rule_id)


class BaseRule(object):
    """Tum kurallarin turedigi taban sinif.

    Yeni kural eklemek icin: rules/ altina yeni bir .py dosyasi ac,
    BaseRule'dan turet, `id` ver ve `check()` yaz. Baska hicbir yeri
    degistirmeye gerek yok - registry otomatik bulur.
    """

    id: str = ""                      # ORA0xx  (benzersiz olmali)
    name: str = ""                    # Kisa Turkce baslik
    description: str = ""             # Ne kontrol ediyor
    rationale: str = ""               # Neden onemli (banka/operasyon gerekcesi)
    remediation: str = ""             # Nasil duzeltilir
    category: str = "GENEL"
    severity: str = Severity.WARN
    enabled: bool = True
    default_params: Dict[str, Any] = {}
    tags: List[str] = []

    def __init__(self, severity: Optional[str] = None,
                 enabled: Optional[bool] = None,
                 params: Optional[Dict[str, Any]] = None):
        if severity is not None:
            self.severity = Severity.normalize(severity)
        if enabled is not None:
            self.enabled = bool(enabled)
        self.params = dict(self.default_params or {})
        if params:
            self.params.update(params)

    # --- alt siniflarin implemente edecegi tek metod ---
    def check(self, ctx) -> Iterable[Finding]:
        raise NotImplementedError

    # --- yardimcilar ---
    def hit(self, ctx, offset: int = None, line: int = None, message: str = "",
            suggestion: str = None, severity: str = None,
            statement=None, object_name: str = "") -> Finding:
        if line is None:
            line = ctx.line_of(offset) if offset is not None else 0
        col = ctx.col_of(offset) if offset is not None else 0
        idx = statement.index if statement is not None else (
            ctx.statement_at(offset).index if offset is not None
            and ctx.statement_at(offset) else None)
        return Finding(
            rule_id=self.id,
            rule_name=self.name,
            category=self.category,
            severity=severity or self.severity,
            message=message or self.description,
            line=line,
            column=col,
            snippet=ctx.line_text(line),
            suggestion=suggestion if suggestion is not None else self.remediation,
            statement_index=idx,
            object_name=object_name,
        )

    def param(self, key, default=None):
        return self.params.get(key, default)

    def meta(self) -> Dict[str, Any]:
        return {
            "id": self.id, "name": self.name, "category": self.category,
            "severity": self.severity, "enabled": self.enabled,
            "description": self.description, "rationale": self.rationale,
            "remediation": self.remediation, "params": self.params,
            "tags": list(self.tags or []),
        }
