# -*- coding: utf-8 -*-
"""Rapor uretimi: konsol, JSON ve karar (PASS/WARN/FAIL)."""
from __future__ import annotations

import json
import os
from collections import Counter, OrderedDict
from typing import Any, Dict, List

from .model import Finding, Severity

EXIT_PASS, EXIT_WARN, EXIT_FAIL, EXIT_ERROR = 0, 1, 2, 3

_C = {
    "FAIL": "\033[1;31m", "WARN": "\033[1;33m", "INFO": "\033[1;36m",
    "PASS": "\033[1;32m", "DIM": "\033[2m", "B": "\033[1m", "R": "\033[0m",
}


def _c(key: str, use_color: bool) -> str:
    return _C.get(key, "") if use_color else ""


def verdict(findings: List[Finding]) -> str:
    if any(f.severity == Severity.FAIL for f in findings):
        return "FAIL"
    if any(f.severity == Severity.WARN for f in findings):
        return "WARN"
    return "PASS"


def exit_code(v: str) -> int:
    return {"PASS": EXIT_PASS, "WARN": EXIT_WARN, "FAIL": EXIT_FAIL}.get(v, EXIT_ERROR)


def build_report(ctx, findings: List[Finding], rules, duration_ms: float) -> Dict[str, Any]:
    v = verdict(findings)
    by_sev = Counter(f.severity for f in findings)
    by_cat = Counter(f.category for f in findings)
    by_rule = Counter(f.rule_id for f in findings)
    return OrderedDict([
        ("script", os.path.abspath(ctx.path)),
        ("verdict", v),
        ("exit_code", exit_code(v)),
        ("summary", OrderedDict([
            ("fail", by_sev.get("FAIL", 0)),
            ("warn", by_sev.get("WARN", 0)),
            ("info", by_sev.get("INFO", 0)),
            ("total", len(findings)),
            ("by_category", dict(by_cat)),
            ("by_rule", dict(by_rule)),
        ])),
        ("script_stats", OrderedDict([
            ("lines", len(ctx.lines)),
            ("statements", len(ctx.statements)),
            ("dml_statements", len(ctx.dml_statements)),
            ("ddl_statements", len(ctx.ddl_statements)),
        ])),
        ("rules_evaluated", len([r for r in rules if r.enabled])),
        ("rules_disabled", [r.id for r in rules if not r.enabled]),
        ("duration_ms", round(duration_ms, 1)),
        ("findings", [f.to_dict() for f in findings]),
    ])


def render_console(report: Dict[str, Any], findings: List[Finding],
                   use_color: bool = True, show_info: bool = True,
                   max_per_rule: int = 0) -> str:
    out = []
    w = 78
    v = report["verdict"]
    s = report["summary"]

    out.append("=" * w)
    out.append("ORACLE SCRIPT DOGRULAMA RAPORU")
    out.append("=" * w)
    out.append("Dosya      : %s" % report["script"])
    out.append("Satir/Ifade: %d satir, %d ifade (%d DML, %d DDL)" % (
        report["script_stats"]["lines"], report["script_stats"]["statements"],
        report["script_stats"]["dml_statements"], report["script_stats"]["ddl_statements"]))
    out.append("Kural      : %d aktif, %d kapali" % (
        report["rules_evaluated"], len(report["rules_disabled"])))
    out.append("Sonuc      : %s%s%s   (FAIL:%d  WARN:%d  INFO:%d)" % (
        _c(v, use_color), v, _c("R", use_color), s["fail"], s["warn"], s["info"]))
    out.append("=" * w)

    shown = Counter()
    groups = [("FAIL", "ENGELLEYICI BULGULAR"), ("WARN", "UYARILAR"),
              ("INFO", "BILGI")]
    for sev, title in groups:
        if sev == "INFO" and not show_info:
            continue
        items = [f for f in findings if f.severity == sev]
        if not items:
            continue
        out.append("")
        out.append("%s%s (%d)%s" % (_c(sev, use_color), title, len(items),
                                    _c("R", use_color)))
        out.append("-" * w)
        for f in items:
            if max_per_rule and shown[f.rule_id] >= max_per_rule:
                continue
            shown[f.rule_id] += 1
            out.append("[%s] satir %-5d %s | %s" % (
                f.rule_id, f.line, f.category, f.rule_name))
            out.append("    -> %s" % f.message)
            if f.snippet:
                snip = f.snippet if len(f.snippet) <= 100 else f.snippet[:97] + "..."
                out.append("    %s| %s%s" % (_c("DIM", use_color), snip,
                                             _c("R", use_color)))
            if f.suggestion:
                for i, ln in enumerate(str(f.suggestion).split("\n")):
                    out.append("    %s%s %s%s" % (_c("DIM", use_color),
                                                  "COZUM:" if i == 0 else "      ",
                                                  ln, _c("R", use_color)))
            out.append("")
        for rid, cnt in shown.items():
            pass

    if max_per_rule:
        total_by_rule = Counter(f.rule_id for f in findings)
        hidden = {r: total_by_rule[r] - shown[r] for r in shown
                  if total_by_rule[r] > shown[r]}
        if hidden:
            out.append("(%s kuralinda gizlenen ek bulgu var: %s)" % (
                len(hidden), ", ".join("%s +%d" % (k, v) for k, v in hidden.items())))

    out.append("=" * w)
    if s["by_category"]:
        out.append("KATEGORI OZETI")
        for cat, cnt in sorted(s["by_category"].items(), key=lambda x: -x[1]):
            out.append("  %-14s %d" % (cat, cnt))
        out.append("=" * w)
    out.append("KARAR: %s%s%s" % (_c(v, use_color), {
        "PASS": "PASS - script calistirilabilir.",
        "WARN": "WARN - uyarilar var, gozden gecirilip onaylanmali.",
        "FAIL": "FAIL - script calistirilmamali, duzeltme gerekli.",
    }[v], _c("R", use_color)))
    out.append("=" * w)
    return "\n".join(out)


def render_rule_list(rules) -> str:
    out = ["%-8s %-12s %-6s %-4s %s" % ("ID", "KATEGORI", "SEV", "AKTF", "AD"),
           "-" * 92]
    for r in rules:
        out.append("%-8s %-12s %-6s %-4s %s" % (
            r.id, r.category, r.severity, "E" if r.enabled else "H", r.name))
    out.append("-" * 92)
    out.append("Toplam %d kural (%d aktif)." % (
        len(rules), len([r for r in rules if r.enabled])))
    return "\n".join(out)


def write_json(report: Dict[str, Any], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
