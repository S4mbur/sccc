# -*- coding: utf-8 -*-
"""ScriptContext: kurallarin uzerinde calistigi tek nesne."""
from __future__ import annotations

import bisect
import re
from typing import Any, Dict, Iterator, List, Optional, Tuple

from .lexer import Statement, mask, split_statements


class Match(object):
    """Regex eslesmesi + satir/sutun bilgisi."""
    __slots__ = ("text", "start", "end", "line", "column", "groups", "m")

    def __init__(self, m, ctx):
        self.m = m
        self.text = m.group(0)
        self.start = m.start()
        self.end = m.end()
        self.line = ctx.line_of(m.start())
        self.column = ctx.col_of(m.start())
        self.groups = m.groups()

    def group(self, *a):
        return self.m.group(*a)


class ScriptContext(object):
    def __init__(self, path: str, text: str, settings: Optional[Dict[str, Any]] = None,
                 meta: Optional[Dict[str, Any]] = None):
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        self.path = path
        self.raw = text
        self.masked, self.regions = mask(text)
        self.lines = text.split("\n")
        self.masked_lines = self.masked.split("\n")
        self.settings = dict(settings or {})
        # reader.read_source() meta'si: sha256, bom, encoding, issues[...]
        self.meta = dict(meta or {})
        self._line_starts = [0] + [m.start() + 1 for m in re.finditer("\n", text)]
        self.statements: List[Statement] = split_statements(text, self.masked)
        self._cache: Dict[str, Any] = {}

    # ------------------------------------------------ konum yardimcilari
    def line_of(self, offset: int) -> int:
        if offset is None:
            return 0
        return bisect.bisect_right(self._line_starts, offset)

    def col_of(self, offset: int) -> int:
        if offset is None:
            return 0
        ln = self.line_of(offset)
        return offset - self._line_starts[ln - 1] + 1 if ln >= 1 else 1

    def offset_of_line(self, line: int) -> int:
        if 1 <= line <= len(self._line_starts):
            return self._line_starts[line - 1]
        return 0

    def line_text(self, line: int) -> str:
        if 1 <= line <= len(self.lines):
            return self.lines[line - 1].strip()
        return ""

    # ------------------------------------------------ arama yardimcilari
    def finditer(self, pattern: str, flags: int = re.I) -> Iterator[Match]:
        """Maskeli metin uzerinde arar (yorum/string icerigi haric)."""
        for m in re.finditer(pattern, self.masked, flags):
            yield Match(m, self)

    def findall_raw(self, pattern: str, flags: int = re.I) -> Iterator[Match]:
        """Ham metin uzerinde arar (yorumlar dahil)."""
        for m in re.finditer(pattern, self.raw, flags):
            yield Match(m, self)

    def search(self, pattern: str, flags: int = re.I) -> Optional[Match]:
        m = re.search(pattern, self.masked, flags)
        return Match(m, self) if m else None

    def statement_at(self, offset: int) -> Optional[Statement]:
        for st in self.statements:
            if st.start_offset <= offset < st.end_offset:
                return st
        return None

    def stmts(self, *first_words: str) -> List[Statement]:
        want = {w.upper() for w in first_words}
        return [s for s in self.statements if s.first_word in want]

    def stmts_matching(self, pattern: str, flags: int = re.I) -> List[Statement]:
        rx = re.compile(pattern, flags)
        return [s for s in self.statements if rx.search(s.masked)]

    # ------------------------------------------------ toplu ozellikler
    @property
    def all_statements(self) -> List[Statement]:
        """Ust seviye + PL/SQL govdesindeki ic ifadeler (LEX-014/015/016).

        DML/guvenlik kurallari bu listeyi kullanmalidir; aksi halde
        'BEGIN UPDATE t SET x=1; END; /' WHERE kontrolunu asar (CUR-003).
        """
        if "all_stmts" in self._cache:
            return self._cache["all_stmts"]
        out = []
        for s in self.statements:
            out.append(s)
            out.extend(getattr(s, "inner", []) or [])
        self._cache["all_stmts"] = out
        return out

    @property
    def top_dml_statements(self) -> List[Statement]:
        """SADECE ust seviye DML. Bir procedure govdesindeki DML, dosyanin
        sinifini (DDL/DML) degistirmez -> siniflandirma kurallari bunu kullanir."""
        return [s for s in self.statements if s.is_dml()]

    @property
    def top_ddl_statements(self) -> List[Statement]:
        return [s for s in self.statements if s.is_ddl() and s.kind != "sqlplus"]

    @property
    def dml_statements(self) -> List[Statement]:
        return [s for s in self.all_statements if s.is_dml()]

    @property
    def ddl_statements(self) -> List[Statement]:
        return [s for s in self.all_statements
                if s.is_ddl() and s.kind != "sqlplus"]

    @property
    def header_comment(self) -> str:
        """Ilk SQL ifadesinden onceki tum yorum blogu (ham metin)."""
        if "header" in self._cache:
            return self._cache["header"]
        limit = self.statements[0].start_offset if self.statements else len(self.raw)
        parts = [self.raw[r.start:r.end] for r in self.regions
                 if r.kind in ("line_comment", "block_comment") and r.end <= limit]
        head = "\n".join(parts)
        self._cache["header"] = head
        return head

    @property
    def all_comments(self) -> str:
        return "\n".join(self.raw[r.start:r.end] for r in self.regions
                         if r.kind in ("line_comment", "block_comment"))

    @property
    def filename(self) -> str:
        """Etkin dosya adi. ZIP icindeki girdilerde uye adini dondurur."""
        import os
        return os.path.basename(self.path.split("!")[-1])

    @property
    def in_archive(self) -> bool:
        return "!" in self.path and self.path.split("!")[0].lower().endswith(".zip")

    def setting(self, key: str, default=None):
        return self.settings.get(key, default)
