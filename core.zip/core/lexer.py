# -*- coding: utf-8 -*-
"""Oracle SQL / SQL*Plus script lexer.

Iki isi yapar:
  1) mask()            -> yorumlari ve string literalleri ayni uzunlukta bosluga
                          cevirir. Boylece kurallar regex ile calisirken
                          yorum satirindaki 'DROP TABLE' yanlis alarm uretmez,
                          ama satir/sutun numaralari birebir korunur.
  2) split_statements() -> scripti tek tek ifadelere boler; PL/SQL bloklarini,
                          SQL*Plus komutlarini ve '/' sonlandiricisini bilir.
"""
# Karsilanan master kontroller: LEX-004 LEX-009 LEX-012 LEX-014 LEX-015 LEX-016 LEX-018 LEX-023 GATE-016
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

# ---------------------------------------------------------------- maskeleme

_KEEP = "\n\r"


def _blank(buf: List[str], start: int, end: int, keep_quotes: bool = False):
    for k in range(start, end):
        if buf[k] not in _KEEP:
            buf[k] = " "


@dataclass
class Region:
    kind: str          # line_comment | block_comment | string | qstring
    start: int
    end: int


ALT_QUOTE_PAIRS = {"[": "]", "(": ")", "{": "}", "<": ">"}


def mask(text: str) -> Tuple[str, List[Region]]:
    """Yorum ve string iceriklerini bosluga cevirir; offsetler degismez."""
    buf = list(text)
    regions: List[Region] = []
    i, n = 0, len(text)

    while i < n:
        c = text[i]
        nx = text[i + 1] if i + 1 < n else ""

        # -- satir yorumu
        if c == "-" and nx == "-":
            j = text.find("\n", i)
            j = n if j == -1 else j
            _blank(buf, i, j)
            regions.append(Region("line_comment", i, j))
            i = j
            continue

        # /* blok yorumu */
        if c == "/" and nx == "*":
            j = text.find("*/", i + 2)
            j = n if j == -1 else j + 2
            _blank(buf, i, j)
            regions.append(Region("block_comment", i, j))
            i = j
            continue

        # REM / REMARK satiri (SQL*Plus yorumu)
        if (c in "rR") and re.match(r"(?i)rem(ark)?\b", text[i:i + 7]) and \
                (i == 0 or text[i - 1] == "\n"):
            j = text.find("\n", i)
            j = n if j == -1 else j
            _blank(buf, i, j)
            regions.append(Region("line_comment", i, j))
            i = j
            continue

        # q'[...]' alternatif tirnak
        if c in "qQ" and nx == "'" and i + 2 < n:
            delim = text[i + 2]
            close = ALT_QUOTE_PAIRS.get(delim, delim)
            j = text.find(close + "'", i + 3)
            j = n if j == -1 else j + 2
            _blank(buf, i + 3, max(i + 3, j - 2))
            regions.append(Region("qstring", i, j))
            i = j
            continue

        # 'normal string' ('' kacisli)
        if c == "'":
            j = i + 1
            while j < n:
                if text[j] == "'":
                    if j + 1 < n and text[j + 1] == "'":
                        j += 2
                        continue
                    j += 1
                    break
                j += 1
            else:
                j = n
            _blank(buf, i + 1, max(i + 1, j - 1))
            regions.append(Region("string", i, j))
            i = j
            continue

        # "quoted identifier" -> oldugu gibi birakilir (obje adi olabilir)
        if c == '"':
            j = text.find('"', i + 1)
            j = n if j == -1 else j + 1
            i = j
            continue

        i += 1

    return "".join(buf), regions


# ------------------------------------------------------------- ifade ayirma

SQLPLUS_COMMANDS = {
    "SET", "SPOOL", "WHENEVER", "PROMPT", "DEFINE", "UNDEFINE", "EXIT", "QUIT",
    "CONNECT", "CONN", "DISCONNECT", "HOST", "COLUMN", "COL", "TTITLE",
    "BTITLE", "SHOW", "START", "ACCEPT", "PAUSE", "CLEAR", "DESCRIBE", "DESC",
    "VARIABLE", "VAR", "TIMING", "STORE", "SAVE", "GET", "EDIT", "LIST",
    "REPFOOTER", "REPHEADER", "BREAK", "COMPUTE", "ARCHIVE", "RECOVER",
}

_RE_PLSQL_ANON = re.compile(r"^\s*(DECLARE|BEGIN)\b", re.I)
_RE_PLSQL_CREATE = re.compile(
    r"^\s*CREATE\s+(OR\s+REPLACE\s+)?"
    r"((NON)?EDITIONABLE\s+)?"
    r"(PROCEDURE|FUNCTION|PACKAGE|TRIGGER|TYPE|LIBRARY)\b", re.I)
_RE_SLASH_LINE = re.compile(r"^[ \t]*/[ \t]*$", re.M)


_RE_END_KW = re.compile(r"(?<![\w$#])END\s+(IF|LOOP|CASE)(?![\w$#])", re.I)
_RE_OPENERS = re.compile(r"(?<![\w$#])(BEGIN|CASE|IF|LOOP)(?![\w$#])", re.I)
_RE_CLOSERS = re.compile(r"(?<![\w$#])END(?![\w$#])", re.I)


def _plsql_block_end(masked: str, start: int) -> int:
    """'/' olmasa bile PL/SQL blogunun bittigi offseti bulur.

    BEGIN/IF/LOOP/CASE - END derinlik sayimi yapar. Boylece '/' unutulmus bir
    blok, dosyanin geri kalanini yutmaz ve sonraki ifadeler denetlenmeye devam
    eder (SQL*Plus'ta hata verir, ama linter kor kalmamalidir).
    """
    n = len(masked)
    head = masked[start:start + 200]
    # PACKAGE / PACKAGE BODY / TYPE BODY govdesi BEGIN'siz bir blok acar;
    # derinligi 1'den baslatmazsak paketteki ilk "END proc;" tum paketi kapatir.
    wrapper = 1 if re.search(r"(?<![\w$#])(PACKAGE|TYPE\s+BODY)(?![\w$#])",
                             head, re.I) else 0
    depth, seen = wrapper, bool(wrapper)
    i = start
    while i < n:
        j = masked.find("\n", i)
        j = n if j == -1 else j
        line = _RE_END_KW.sub("END", masked[i:j])
        opens = len(_RE_OPENERS.findall(line))
        closes = len(_RE_CLOSERS.findall(line))
        if opens or closes:
            seen = True
        depth += opens - closes
        if seen and depth <= 0:
            k = masked.find(";", i)
            return (k + 1) if (k != -1 and k < j) else j
        i = j + 1
    if not seen:
        # BEGIN/END icermeyen govde (ornegin CREATE TYPE ... AS OBJECT)
        k = masked.find(";", start)
        return (k + 1) if k != -1 else n
    return n


@dataclass
class Statement:
    index: int
    raw: str                 # orijinal metin
    masked: str              # yorum/string maskelenmis metin
    start_offset: int
    end_offset: int
    start_line: int
    end_line: int
    kind: str                # sql | plsql | sqlplus
    terminated: bool         # ; veya / ile duzgun bitmis mi
    inner: list = field(default_factory=list)   # PL/SQL govdesindeki ic ifadeler
    parent_index: int = None                    # ic ifade ise sarmalayan blogun index'i
    uncertain: bool = False                     # parse belirsizligi (LEX-023)

    @property
    def norm(self) -> str:
        """Tek satira indirgenmis, tek boslukli maskeli metin (buyuk harf degil)."""
        return re.sub(r"\s+", " ", self.masked).strip()

    @property
    def upper(self) -> str:
        return self.norm.upper()

    @property
    def first_word(self) -> str:
        m = re.match(r"[A-Za-z_@$#]+", self.norm)
        return m.group(0).upper() if m else ""

    @property
    def body(self) -> str:
        """Sonlandirici ve bos karakterler atilmis maskeli govde."""
        return self.masked.strip().rstrip(";/ \t\n\r")

    def is_dml(self) -> bool:
        return self.first_word in ("INSERT", "UPDATE", "DELETE", "MERGE")

    def is_ddl(self) -> bool:
        return self.first_word in ("CREATE", "ALTER", "DROP", "TRUNCATE",
                                   "RENAME", "COMMENT", "GRANT", "REVOKE",
                                   "ANALYZE", "AUDIT", "NOAUDIT", "PURGE",
                                   "FLASHBACK")


# --- PL/SQL govdesi icindeki gercek statement'lar (LEX-014/015/016) ----------
# Bir procedure/trigger/anonim blok govdesindeki UPDATE/DELETE/MERGE/COMMIT vb.
# ifadeler, ust seviye DML gibi denetlenmelidir. Aksi halde
#   BEGIN UPDATE t SET x=1; COMMIT; END; /
# gibi bir script WHERE kontrolunu tamamen asar (CUR-003).
INNER_VERBS = {
    "SELECT", "INSERT", "UPDATE", "DELETE", "MERGE", "COMMIT", "ROLLBACK",
    "SAVEPOINT", "LOCK", "SET", "EXECUTE", "CALL", "OPEN", "FETCH", "CLOSE",
    "FORALL", "RETURN", "RAISE", "NULL", "IF", "FOR", "WHILE", "LOOP", "CASE",
    "BEGIN", "END", "DECLARE", "EXIT", "CONTINUE", "GOTO", "PIPE",
}
_RE_PLSQL_HEADER = re.compile(
    r"^\s*(?:CREATE\s+(?:OR\s+REPLACE\s+)?(?:(?:NON)?EDITIONABLE\s+)?"
    r"(?:PROCEDURE|FUNCTION|PACKAGE(?:\s+BODY)?|TRIGGER|TYPE(?:\s+BODY)?)\b"
    r"[^;]*?)?(?:DECLARE\b|BEGIN\b)", re.I | re.S)


def _split_inner(masked: str, base_offset: int):
    """PL/SQL govdesini ';' sinirlarina bolup (parantez derinligi 0) parcalar."""
    parts, start, depth = [], 0, 0
    q = ""
    for i, ch in enumerate(masked):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        elif ch == ";" and depth == 0:
            parts.append((start, i + 1))
            start = i + 1
    if masked[start:].strip():
        parts.append((start, len(masked)))
    return parts


def _strip_structural(frag: str) -> int:
    """Fragmanin basindaki yapisal PL/SQL anahtar kelimelerini atlar.

    'BEGIN UPDATE ...' -> UPDATE'in offseti
    'IF x=1 THEN DELETE ...' -> DELETE'in offseti
    'FOR r IN (...) LOOP INSERT ...' -> INSERT'in offseti
    """
    pos = 0
    n = len(frag)
    guard = 0
    while pos < n and guard < 40:
        guard += 1
        m = re.match(r"\s*", frag[pos:])
        pos += m.end()
        if pos >= n:
            break
        # <<etiket>>
        lbl = re.match(r"<<[^>]*>>", frag[pos:])
        if lbl:
            pos += lbl.end()
            continue
        word_m = re.match(r"[A-Za-z_$#][\w$#]*", frag[pos:])
        if not word_m:
            break
        word = word_m.group(0).upper()
        if word in ("BEGIN", "DECLARE", "EXCEPTION", "ELSE", "LOOP",
                    "IS", "AS"):
            pos += word_m.end()
            continue
        # CREATE PROCEDURE/FUNCTION/... govdesi ve nested subprogram basligi:
        # govde BEGIN'e kadar bildirim alanidir, oradan devam edilir.
        if word in ("CREATE", "PROCEDURE", "FUNCTION", "PACKAGE", "TRIGGER",
                    "TYPE"):
            bg = re.search(r"(?<![\w$#])BEGIN(?![\w$#])", frag[pos:], re.I)
            if not bg:
                return -1
            pos += bg.end()
            continue
        if word == "END":
            tail = re.match(r"END(\s+(IF|LOOP|CASE))?\s*[\w$#\"]*\s*",
                            frag[pos:], re.I)
            pos += tail.end() if tail else word_m.end()
            continue
        if word in ("IF", "ELSIF", "WHEN"):
            th = re.search(r"(?<![\w$#])THEN(?![\w$#])", frag[pos:], re.I)
            if not th:
                return -1
            pos += th.end()
            continue
        if word in ("FOR", "WHILE"):
            lp = re.search(r"(?<![\w$#])LOOP(?![\w$#])", frag[pos:], re.I)
            if not lp:
                return -1
            pos += lp.end()
            continue
        return pos
    return -1


INNER_VERB_SET = {
    "SELECT", "INSERT", "UPDATE", "DELETE", "MERGE", "COMMIT", "ROLLBACK",
    "SAVEPOINT", "LOCK", "EXECUTE", "CALL", "OPEN", "FORALL", "SET",
}


def extract_inner_statements(st: "Statement", raw: str, masked: str,
                             line_starts) -> None:
    """st (kind='plsql') icindeki calistirilabilir ifadeleri st.inner'a doldurur."""
    body = st.masked
    idx = 0
    for a, b in _split_inner(body, st.start_offset):
        frag = body[a:b]
        if not frag.strip():
            continue
        rel = _strip_structural(frag)
        if rel < 0:
            continue
        word_m = re.match(r"[A-Za-z_$#][\w$#]*", frag[rel:])
        if not word_m:
            continue
        word = word_m.group(0).upper()
        if word not in INNER_VERB_SET:
            continue
        _append_inner(st, raw, masked, line_starts, a + rel, b, word, idx)
        idx += 1


def _append_inner(st, raw, masked, line_starts, rel_start, rel_end, word, idx):
    abs_start = st.start_offset + rel_start
    abs_end = st.start_offset + rel_end
    inner = Statement(
        index=-(1000 * (st.index + 1) + idx),      # negatif: ic ifade isareti
        raw=raw[abs_start:abs_end], masked=masked[abs_start:abs_end],
        start_offset=abs_start, end_offset=abs_end,
        start_line=_line_of(line_starts, abs_start),
        end_line=_line_of(line_starts, max(abs_start, abs_end - 1)),
        kind="plsql_inner", terminated=True,
    )
    inner.parent_index = st.index
    st.inner.append(inner)


def _classify(masked: str, pos: int) -> str:
    head = masked[pos:pos + 400]
    first = re.match(r"[A-Za-z_@$#]+", head.lstrip())
    word = first.group(0).upper() if first else ""
    if word in SQLPLUS_COMMANDS or head.lstrip()[:1] in ("@",):
        return "sqlplus"
    if _RE_PLSQL_ANON.match(head) or _RE_PLSQL_CREATE.match(head):
        return "plsql"
    return "sql"


def _line_index(text: str) -> List[int]:
    """Her satirin baslangic offseti (0-based liste, 1-based satir no)."""
    idx = [0]
    for m in re.finditer("\n", text):
        idx.append(m.start() + 1)
    return idx


def _line_of(line_starts: List[int], offset: int) -> int:
    import bisect
    return bisect.bisect_right(line_starts, offset)


def split_statements(raw: str, masked: str) -> List[Statement]:
    stmts: List[Statement] = []
    starts = _line_index(raw)
    n = len(masked)
    i = 0
    idx = 0

    def emit(s: int, e: int, kind: str, terminated: bool):
        nonlocal idx
        if not masked[s:e].strip(" \t\n\r;/"):
            return
        st = Statement(
            index=idx, raw=raw[s:e], masked=masked[s:e],
            start_offset=s, end_offset=e,
            start_line=_line_of(starts, s), end_line=_line_of(starts, max(s, e - 1)),
            kind=kind, terminated=terminated,
        )
        stmts.append(st)
        idx += 1

    while i < n:
        if masked[i].isspace():
            i += 1
            continue

        start = i
        kind = _classify(masked, i)

        if kind == "sqlplus":
            j = masked.find("\n", i)
            j = n if j == -1 else j
            emit(start, j, kind, True)
            i = j + 1
            continue

        if kind == "plsql":
            block_end = _plsql_block_end(masked, i)
            m = _RE_SLASH_LINE.search(masked, i)
            # '/' ancak blok sonundan hemen sonra geliyorsa gecerli sonlandiricidir
            if m and m.start() >= block_end - 1 and \
                    not masked[block_end:m.start()].strip():
                emit(start, m.end(), kind, True)
                i = m.end()
            else:
                emit(start, block_end, kind, False)
                i = block_end
            continue

        # duz SQL: ';' veya tek basina '/' satiri sonlandirir
        j = i
        terminated = False
        while j < n:
            c = masked[j]
            if c == ";":
                j += 1
                terminated = True
                break
            if c == "/":
                ls = masked.rfind("\n", 0, j) + 1
                le = masked.find("\n", j)
                le = n if le == -1 else le
                if masked[ls:le].strip() == "/":
                    j = le
                    terminated = True
                    break
            j += 1
        emit(start, j, kind, terminated)
        i = j

    for st in stmts:
        if st.kind == "plsql":
            try:
                extract_inner_statements(st, raw, masked, starts)
            except Exception:                     # noqa: BLE001
                st.uncertain = True               # LEX-023: belirsizlik isaretle
    return stmts
