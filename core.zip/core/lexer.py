# -*- coding: utf-8 -*-
"""Oracle SQL / SQL*Plus script lexer.

Iki isi yapar:
  1) mask()            -> yorumlari ve string literalleri ayni uzunlukta bosluga
                          cevirir. Boylece kurallar regex ile calisirken
                          yorum satirindaki 'DROP TABLE' yanlis alarm uretmez,
                          ama satir/sutun numaralari birebir korunur.
  2) split_statements() -> scripti tek tek ifadelere boler; PL/SQL bloklarini,
                          SQL*Plus komutlarini ve '/' sonlandiricisini bilir.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

# ---------------------------------------------------------------- maskeleme

_KEEP = "\n\r"


def _blank(buf: List[str], start: int, end: int, keep_quotes: bool = False):
    for k in range(start, end):
        if buf[k] not in _KEEP:
            buf[k] = " "


@dataclass
class Region:
    kind: str          # line_comment | block_comment | string | qstring
    start: int
    end: int


ALT_QUOTE_PAIRS = {"[": "]", "(": ")", "{": "}", "<": ">"}


def mask(text: str) -> Tuple[str, List[Region]]:
    """Yorum ve string iceriklerini bosluga cevirir; offsetler degismez."""
    buf = list(text)
    regions: List[Region] = []
    i, n = 0, len(text)

    while i < n:
        c = text[i]
        nx = text[i + 1] if i + 1 < n else ""

        # -- satir yorumu
        if c == "-" and nx == "-":
            j = text.find("\n", i)
            j = n if j == -1 else j
            _blank(buf, i, j)
            regions.append(Region("line_comment", i, j))
            i = j
            continue

        # /* blok yorumu */
        if c == "/" and nx == "*":
            j = text.find("*/", i + 2)
            j = n if j == -1 else j + 2
            _blank(buf, i, j)
            regions.append(Region("block_comment", i, j))
            i = j
            continue

        # REM / REMARK satiri (SQL*Plus yorumu)
        if (c in "rR") and re.match(r"(?i)rem(ark)?\b", text[i:i + 7]) and \
                (i == 0 or text[i - 1] == "\n"):
            j = text.find("\n", i)
            j = n if j == -1 else j
            _blank(buf, i, j)
            regions.append(Region("line_comment", i, j))
            i = j
            continue

        # q'[...]' alternatif tirnak
        if c in "qQ" and nx == "'" and i + 2 < n:
            delim = text[i + 2]
            close = ALT_QUOTE_PAIRS.get(delim, delim)
            j = text.find(close + "'", i + 3)
            j = n if j == -1 else j + 2
            _blank(buf, i + 3, max(i + 3, j - 2))
            regions.append(Region("qstring", i, j))
            i = j
            continue

        # 'normal string' ('' kacisli)
        if c == "'":
            j = i + 1
            while j < n:
                if text[j] == "'":
                    if j + 1 < n and text[j + 1] == "'":
                        j += 2
                        continue
                    j += 1
                    break
                j += 1
            else:
                j = n
            _blank(buf, i + 1, max(i + 1, j - 1))
            regions.append(Region("string", i, j))
            i = j
            continue

        # "quoted identifier" -> oldugu gibi birakilir (obje adi olabilir)
        if c == '"':
            j = text.find('"', i + 1)
            j = n if j == -1 else j + 1
            i = j
            continue

        i += 1

    return "".join(buf), regions


# ------------------------------------------------------------- ifade ayirma

SQLPLUS_COMMANDS = {
    "SET", "SPOOL", "WHENEVER", "PROMPT", "DEFINE", "UNDEFINE", "EXIT", "QUIT",
    "CONNECT", "CONN", "DISCONNECT", "HOST", "COLUMN", "COL", "TTITLE",
    "BTITLE", "SHOW", "START", "ACCEPT", "PAUSE", "CLEAR", "DESCRIBE", "DESC",
    "VARIABLE", "VAR", "TIMING", "STORE", "SAVE", "GET", "EDIT", "LIST",
    "REPFOOTER", "REPHEADER", "BREAK", "COMPUTE", "ARCHIVE", "RECOVER",
}

_RE_PLSQL_ANON = re.compile(r"^\s*(DECLARE|BEGIN)\b", re.I)
_RE_PLSQL_CREATE = re.compile(
    r"^\s*CREATE\s+(OR\s+REPLACE\s+)?"
    r"((NON)?EDITIONABLE\s+)?"
    r"(PROCEDURE|FUNCTION|PACKAGE|TRIGGER|TYPE|LIBRARY)\b", re.I)
_RE_SLASH_LINE = re.compile(r"^[ \t]*/[ \t]*$", re.M)


@dataclass
class Statement:
    index: int
    raw: str                 # orijinal metin
    masked: str              # yorum/string maskelenmis metin
    start_offset: int
    end_offset: int
    start_line: int
    end_line: int
    kind: str                # sql | plsql | sqlplus
    terminated: bool         # ; veya / ile duzgun bitmis mi

    @property
    def norm(self) -> str:
        """Tek satira indirgenmis, tek boslukli maskeli metin (buyuk harf degil)."""
        return re.sub(r"\s+", " ", self.masked).strip()

    @property
    def upper(self) -> str:
        return self.norm.upper()

    @property
    def first_word(self) -> str:
        m = re.match(r"[A-Za-z_@$#]+", self.norm)
        return m.group(0).upper() if m else ""

    @property
    def body(self) -> str:
        """Sonlandirici ve bos karakterler atilmis maskeli govde."""
        return self.masked.strip().rstrip(";/ \t\n\r")

    def is_dml(self) -> bool:
        return self.first_word in ("INSERT", "UPDATE", "DELETE", "MERGE")

    def is_ddl(self) -> bool:
        return self.first_word in ("CREATE", "ALTER", "DROP", "TRUNCATE",
                                   "RENAME", "COMMENT", "GRANT", "REVOKE",
                                   "ANALYZE", "AUDIT", "NOAUDIT", "PURGE",
                                   "FLASHBACK")


def _classify(masked: str, pos: int) -> str:
    head = masked[pos:pos + 400]
    first = re.match(r"[A-Za-z_@$#]+", head.lstrip())
    word = first.group(0).upper() if first else ""
    if word in SQLPLUS_COMMANDS or head.lstrip()[:1] in ("@",):
        return "sqlplus"
    if _RE_PLSQL_ANON.match(head) or _RE_PLSQL_CREATE.match(head):
        return "plsql"
    return "sql"


def _line_index(text: str) -> List[int]:
    """Her satirin baslangic offseti (0-based liste, 1-based satir no)."""
    idx = [0]
    for m in re.finditer("\n", text):
        idx.append(m.start() + 1)
    return idx


def _line_of(line_starts: List[int], offset: int) -> int:
    import bisect
    return bisect.bisect_right(line_starts, offset)


def split_statements(raw: str, masked: str) -> List[Statement]:
    stmts: List[Statement] = []
    starts = _line_index(raw)
    n = len(masked)
    i = 0
    idx = 0

    def emit(s: int, e: int, kind: str, terminated: bool):
        nonlocal idx
        if not masked[s:e].strip(" \t\n\r;/"):
            return
        st = Statement(
            index=idx, raw=raw[s:e], masked=masked[s:e],
            start_offset=s, end_offset=e,
            start_line=_line_of(starts, s), end_line=_line_of(starts, max(s, e - 1)),
            kind=kind, terminated=terminated,
        )
        stmts.append(st)
        idx += 1

    while i < n:
        if masked[i].isspace():
            i += 1
            continue

        start = i
        kind = _classify(masked, i)

        if kind == "sqlplus":
            j = masked.find("\n", i)
            j = n if j == -1 else j
            emit(start, j, kind, True)
            i = j + 1
            continue

        if kind == "plsql":
            m = _RE_SLASH_LINE.search(masked, i)
            if m:
                emit(start, m.end(), kind, True)
                i = m.end()
            else:
                emit(start, n, kind, False)
                i = n
            continue

        # duz SQL: ';' veya tek basina '/' satiri sonlandirir
        j = i
        terminated = False
        while j < n:
            c = masked[j]
            if c == ";":
                j += 1
                terminated = True
                break
            if c == "/":
                ls = masked.rfind("\n", 0, j) + 1
                le = masked.find("\n", j)
                le = n if le == -1 else le
                if masked[ls:le].strip() == "/":
                    j = le
                    terminated = True
                    break
            j += 1
        emit(start, j, kind, terminated)
        i = j

    return stmts
