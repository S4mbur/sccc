# -*- coding: utf-8 -*-
"""DB sozlugu (katalog) destegi - DB-005/006/011, CUR-030/034.

Katalog, hedef veritabanindan SALT-OKUNUR olarak alinan metadata'dir.
tools_build_catalog.sql ile uretilir ve --catalog ile verilir.

Format:
{
  "database": {"name": "PRODDB01", "db_unique_name": "...", "role": "PRIMARY",
               "version": "19.0.0.0.0", "generated_at": "..."},
  "objects": {"BANKAPP.HESAP": {"type": "TABLE", "status": "VALID"}},
  "columns": {"BANKAPP.HESAP": ["ID", "MUSTERI_ID", "BAKIYE"]},
  "constraints": {"BANKAPP.HESAP": [{"name":"PK_HESAP","type":"P","columns":["ID"]}]},
  "indexes":  {"BANKAPP.HESAP": [{"name":"IX_1","columns":["MUSTERI_ID"]}]},
  "tablespaces": ["TS_BANKAPP", "TS_BANKAPP_IDX"]
}
"""
# Karsilanan master kontroller: DB-001 DB-003 DB-004 DB-005 DB-006 DB-009 DB-030 MASTER-004
from __future__ import annotations

from typing import Any, Dict, List, Optional


class Catalog(object):
    def __init__(self, data: Optional[Dict[str, Any]] = None):
        data = data or {}
        self.raw = data
        self.database = data.get("database") or {}
        self.objects = {k.upper(): v for k, v in (data.get("objects") or {}).items()}
        self.columns = {k.upper(): [c.upper() for c in v]
                        for k, v in (data.get("columns") or {}).items()}
        self.constraints = {k.upper(): v
                            for k, v in (data.get("constraints") or {}).items()}
        self.indexes = {k.upper(): v for k, v in (data.get("indexes") or {}).items()}
        self.tablespaces = {t.upper() for t in (data.get("tablespaces") or [])}

    @property
    def loaded(self) -> bool:
        return bool(self.objects or self.columns)

    def has_object(self, fq: str) -> bool:
        return fq.upper() in self.objects

    def object_type(self, fq: str) -> str:
        return (self.objects.get(fq.upper()) or {}).get("type", "")

    def has_column(self, fq_table: str, column: str) -> Optional[bool]:
        cols = self.columns.get(fq_table.upper())
        if cols is None:
            return None                    # tablo katalogda yok -> bilinmiyor
        return column.upper() in cols

    def unique_keys(self, fq_table: str) -> List[List[str]]:
        out = []
        for c in self.constraints.get(fq_table.upper(), []):
            if c.get("type") in ("P", "U"):
                out.append([x.upper() for x in c.get("columns", [])])
        return out

    def index_prefixes(self, fq_table: str) -> List[List[str]]:
        return [[x.upper() for x in i.get("columns", [])]
                for i in self.indexes.get(fq_table.upper(), [])]

    def has_tablespace(self, name: str) -> bool:
        return name.upper() in self.tablespaces


def get_catalog(ctx) -> Catalog:
    """ScriptContext icinden katalogu alir (yoksa bos katalog)."""
    cached = getattr(ctx, "_catalog_obj", None)
    if cached is not None:
        return cached
    cat = Catalog(ctx.setting("catalog") or {})
    try:
        ctx._catalog_obj = cat
    except Exception:                                            # noqa: BLE001
        pass
    return cat
