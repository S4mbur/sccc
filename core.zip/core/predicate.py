# -*- coding: utf-8 -*-
"""Predicate (WHERE / MERGE ON) tautoloji analizi.

Master kontrol listesi DML-005/DML-006, CUR-011/012/013.

Temel kural: bir predicate'in HERHANGI bir OR dali her zaman dogruysa,
predicate'in tamami her zaman dogrudur -> tum tablo etkilenir.
"""
# Karsilanan master kontroller: DML-005 DML-006 TST-019
from __future__ import annotations

import re
from typing import List, Optional, Tuple

_ID = r'"?[A-Za-z_$#][\w$#]*"?(?:\s*\.\s*"?[A-Za-z_$#][\w$#]*"?)*'

# Her zaman dogru olan atomik kaliplar
TAUTOLOGY_PATTERNS = [
    (r"^\s*(\d+)\s*=\s*(\d+)\s*$", "sabit esitlik", "equal_numbers"),
    (r"^\s*'([^']*)'\s*=\s*'([^']*)'\s*$", "sabit string esitligi", "equal_strings"),
    (r"^\s*(\d+)\s*(<>|!=)\s*(\d+)\s*$", "sabit esitsizlik", "diff_numbers"),
    (r"^\s*NULL\s+IS\s+NULL\s*$", "NULL IS NULL", "null_is_null"),
    (r"^\s*ROWNUM\s*(>=\s*1|>\s*0)\s*$", "ROWNUM her zaman dogru", "rownum"),
    (r"^\s*1\s*=\s*1\s*$", "1=1", "one_eq_one"),
    (r"^\s*TRUE\s*$", "sabit TRUE", "true"),
]


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _strip_parens(text: str) -> str:
    t = text.strip()
    while t.startswith("(") and t.endswith(")"):
        depth = 0
        ok = True
        for i, ch in enumerate(t):
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0 and i != len(t) - 1:
                    ok = False
                    break
        if not ok:
            break
        t = t[1:-1].strip()
    return t


def split_top(text: str, keyword: str) -> List[str]:
    """Parantez derinligi 0'daki AND/OR'a gore boler."""
    parts, cur, depth, i = [], "", 0, 0
    n = len(text)
    kw = keyword.upper()
    klen = len(kw)
    while i < n:
        ch = text[i]
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        if depth == 0 and text[i:i + klen].upper() == kw:
            before_ok = i == 0 or not re.match(r"[\w$#]", text[i - 1])
            after = text[i + klen:i + klen + 1]
            after_ok = after == "" or not re.match(r"[\w$#]", after)
            if before_ok and after_ok:
                parts.append(cur)
                cur = ""
                i += klen
                continue
        cur += ch
        i += 1
    parts.append(cur)
    return [p for p in parts if p.strip()]


def is_always_true(pred: str) -> Optional[str]:
    """Atomik veya bilesik predicate her zaman dogru mu? Sebep metni veya None."""
    p = _strip_parens(_norm(pred))
    if not p:
        return None

    # OR dallari: biri her zaman dogruysa tamami dogrudur
    or_parts = split_top(p, "OR")
    if len(or_parts) > 1:
        for part in or_parts:
            why = is_always_true(part)
            if why:
                return "OR dalinda her zaman dogru kosul (%s)" % why
        # Tamamlayici dallar butun uzayi kapatiyor mu?
        #   X IS NULL OR X IS NOT NULL   -> her zaman dogru
        nulls, notnulls = {}, {}
        for part in or_parts:
            q = _strip_parens(_norm(part))
            m = re.match(r"^(%s)\s+IS\s+NOT\s+NULL$" % _ID, q, re.I)
            if m:
                notnulls[re.sub(r"\s+", "", m.group(1)).upper()] = q
                continue
            m = re.match(r"^(%s)\s+IS\s+NULL$" % _ID, q, re.I)
            if m:
                nulls[re.sub(r"\s+", "", m.group(1)).upper()] = q
        common = set(nulls) & set(notnulls)
        if common:
            col = sorted(common)[0]
            return ("tamamlayici kosullar tum satirlari kapsiyor "
                    "(%s IS NULL OR %s IS NOT NULL)" % (col, col))
        return None

    # AND dallari: HEPSI her zaman dogruysa tamami dogrudur
    and_parts = split_top(p, "AND")
    if len(and_parts) > 1:
        reasons = [is_always_true(x) for x in and_parts]
        if all(reasons):
            return "tum AND dallari her zaman dogru"
        return None

    for pat, label, _key in TAUTOLOGY_PATTERNS:
        m = re.match(pat, p, re.I)
        if not m:
            continue
        if _key == "equal_numbers":
            return label if m.group(1) == m.group(2) else None
        if _key == "equal_strings":
            return label if m.group(1) == m.group(2) else None
        if _key == "diff_numbers":
            return label if m.group(1) != m.group(3) else None
        return label

    # kolon = ayni kolon  (ID = ID, t.ID = t.ID)
    m = re.match(r"^(%s)\s*=\s*(%s)$" % (_ID, _ID), p, re.I)
    if m:
        a = re.sub(r"\s+", "", m.group(1)).upper().strip('"')
        b = re.sub(r"\s+", "", m.group(2)).upper().strip('"')
        if a == b:
            return "kolonun kendisiyle karsilastirilmasi (%s)" % m.group(1).strip()

    # X IS NULL OR X IS NOT NULL  -> OR dalinda yakalanmaz, ayrica kontrol
    m = re.match(r"^(%s)\s+IS\s+NULL\s+OR\s+\1\s+IS\s+NOT\s+NULL$" % _ID, p, re.I)
    if m:
        return "X IS NULL OR X IS NOT NULL"

    # EXISTS (SELECT ... FROM DUAL) / EXISTS (SELECT 1 FROM DUAL)
    if re.match(r"^EXISTS\s*\(\s*SELECT\s+[^)]*FROM\s+DUAL\s*\)$", p, re.I):
        return "her zaman dogru EXISTS (FROM DUAL)"
    if re.match(r"^\d+\s*(=|<=|>=)\s*\d+$", p):
        try:
            left, op, right = re.match(r"^(\d+)\s*(=|<=|>=)\s*(\d+)$", p).groups()
            if (op == "=" and left == right) or \
               (op == "<=" and int(left) <= int(right)) or \
               (op == ">=" and int(left) >= int(right)):
                return "sabit karsilastirma (%s)" % p
        except Exception:                      # noqa: BLE001
            pass
    return None


def find_tautologies(pred: str) -> List[Tuple[str, str]]:
    """Predicate icindeki tum tautoloji parcalarini dondurur: [(parca, sebep)]."""
    out = []
    for part in split_top(_strip_parens(_norm(pred)), "OR"):
        for sub in split_top(part, "AND"):
            why = is_always_true(sub)
            if why:
                out.append((_norm(sub), why))
    return out
