# -*- coding: utf-8 -*-
"""Paket (ZIP / coklu dosya) seviyesinde denetimler.

Tek bir dosyaya bakarak anlasilamayan kurallar burada calisir:
  - ORA240  pakette hem DDL hem DML dosyasi var (dokuman madde 6)
  - ORA241  pakette calistirilamayacak uzantida dosya var (dokuman madde 3)
  - ORA242  sira oneki eksik / hatali / tekrarli / atlamali (dokuman madde 8)
  - ORA243  rollback/forward/check dosya rolleri (ZIP-016)

Ilgili kontroller: ZIP-014 (sira TEK kaynaktan: dosya adi prefix'i; arsiv veya
dosya sistemi sirasi kullanilmaz), ZIP-015 (01'den baslar, bosluk/tekrar yok),
ZIP-016 (rol ayrimi), ZIP-017/018 (sinif politikasi ve coklu etiket),
ZIP-019 (bulgular aggregate JSON'a yazilir), INP-002 (toplam paket byte limiti).
"""
# Karsilanan master kontroller: ZIP-014 ZIP-015 ZIP-016 ZIP-017 ZIP-018 ZIP-019
from __future__ import annotations

import os
import re
from typing import Dict, List

from .model import Finding, Severity

ALLOWED_MEMBER_EXT = (".sql", ".txt")
RX_PREFIX = re.compile(r"^(\d{2})-")
RX_LOOSE_PREFIX = re.compile(r"^(\d+)\s*[-_ ]")


def _f(rule_id, name, severity, message, remediation, path=""):
    return Finding(
        rule_id=rule_id, rule_name=name, category="PAKET", severity=severity,
        message=message, line=0, column=0, snippet=path,
        suggestion=remediation, statement_index=None, object_name=path)


def check_package(entries: List[Dict], all_member_names: List[str] = None) -> List[Finding]:
    """entries: [{'name': '01-x.sql', 'kind': 'DDL'|'DML'|'SELECT'|'BOS'}]

    all_member_names: arsivdeki TUM girisler (uzanti kontrolu icin).
    """
    out: List[Finding] = []
    if not entries:
        return out
    names = [os.path.basename(e["name"]) for e in entries]

    # --- ORA241: calistirilamayacak uzanti ---
    for n in (all_member_names or []):
        base = os.path.basename(n)
        if not base or n.endswith("/"):
            continue
        if not base.lower().endswith(ALLOWED_MEMBER_EXT):
            out.append(_f(
                "ORA241", "Pakette calistirilamayacak dosya var", Severity.FAIL,
                "Arsivde '%s' var; sadece .sql ve .txt calistirilir, digerleri "
                "sessizce atlanir ve talep eksik uygulanir." % base,
                "Bu dosyayi arsivden cikarin veya .sql olarak yeniden gonderin.",
                base))

    # --- ORA240: pakette hem DDL hem DML ---
    ddl = [e["name"] for e in entries if e.get("kind") == "DDL"]
    dml = [e["name"] for e in entries if e.get("kind") == "DML"]
    if ddl and dml:
        out.append(_f(
            "ORA240", "Ayni pakette hem DDL hem DML dosyasi var", Severity.FAIL,
            "DDL dosyalari (%s) ile DML dosyalari (%s) ayni talepte gonderilmis."
            % (", ".join(os.path.basename(x) for x in ddl[:3]),
               ", ".join(os.path.basename(x) for x in dml[:3])),
            "DDL ve DML'i ayri talep/paket olarak gonderin (dokuman madde 6)."))

    # --- ORA242: sira oneki tutarliligi ---
    if len(names) > 1:
        good = {n: RX_PREFIX.match(n) for n in names}
        prefixed = [n for n, m in good.items() if m]
        if prefixed:                       # sirali calisma niyeti var
            for n in names:
                if good[n]:
                    continue
                loose = RX_LOOSE_PREFIX.match(n)
                detail = ("sira oneki iki haneli degil" if loose
                          else "sira oneki yok")
                out.append(_f(
                    "ORA242", "Sira oneki tutarsiz", Severity.FAIL,
                    "'%s' -> %s (paketteki diger dosyalar 01-, 02- formatinda)."
                    % (n, detail),
                    "Tum dosyalari iki haneli sira ile adlandirin: 01-, 02-, 03- ...",
                    n))
            nums = sorted(int(good[n].group(1)) for n in prefixed)
            dup = {x for x in nums if nums.count(x) > 1}
            if dup:
                out.append(_f(
                    "ORA242", "Sira numarasi tekrar ediyor", Severity.FAIL,
                    "Tekrar eden sira numarasi: %s - calisma sirasi belirsiz."
                    % ", ".join("%02d" % d for d in sorted(dup)),
                    "Her dosyaya benzersiz bir sira numarasi verin."))
            if nums and nums[0] != 1:
                out.append(_f(
                    "ORA242", "Sira 01 ile baslamiyor", Severity.WARN,
                    "Ilk sira numarasi %02d; paket eksik gonderilmis olabilir."
                    % nums[0],
                    "Sirayi 01'den baslatin veya eksik dosyayi ekleyin."))
            eksik = [i for i in range(1, (nums[-1] if nums else 0) + 1)
                     if i not in nums]
            if eksik:
                out.append(_f(
                    "ORA242", "Sira numarasinda bosluk var", Severity.WARN,
                    "Eksik sira numarasi: %s"
                    % ", ".join("%02d" % d for d in eksik),
                    "Eksik dosyalari ekleyin veya numaralari yeniden dizin."))

    # --- ORA243 / ZIP-016: dosya rolleri ---
    roles = {"rollback": [], "forward": [], "check": [], "other": []}
    for n in names:
        low = n.lower()
        if "rollback" in low or "geri" in low or "revert" in low or "undo" in low:
            roles["rollback"].append(n)
        elif "check" in low or "kontrol" in low or "verify" in low:
            roles["check"].append(n)
        elif re.match(r"^\d{2}-", n):
            roles["forward"].append(n)
        else:
            roles["other"].append(n)
    if roles["rollback"] and roles["forward"]:
        out.append(_f(
            "ORA243", "Rollback ve forward dosyalari ayni pakette", Severity.FAIL,
            "Ayni pakette hem ileri alma (%s) hem geri alma (%s) dosyasi var; "
            "yanlis faz otomatik calisabilir."
            % (", ".join(roles["forward"][:2]), ", ".join(roles["rollback"][:2])),
            "Geri alma scriptini ayri bir talep/pakette gonderin (ZIP-016)."))
    if roles["forward"] and not roles["rollback"]:
        out.append(_f(
            "ORA243", "Pakette geri alma dosyasi yok", Severity.WARN,
            "%d ileri alma dosyasi var, rollback dosyasi yok."
            % len(roles["forward"]),
            "Geri alma scriptini ayri artifact olarak hazirlayin (TX-017)."))

    # --- ZIP-018: bir dosyanin birden fazla sinifi varsa etiketler korunur ---
    for e in entries:
        kinds = e.get("kinds") or ([e["kind"]] if e.get("kind") else [])
        if len(kinds) > 1:
            out.append(_f(
                "ORA240", "Dosya birden fazla sinif iceriyor", Severity.FAIL,
                "'%s' hem %s iceriyor; tek sinif politikasi uygulanamaz."
                % (os.path.basename(e["name"]), " hem ".join(kinds)),
                "Dosyayi sinif basina ayirin (ZIP-018).", e["name"]))

    # --- dosya adinda bosluk / ASCII disi karakter ---
    for n in names:
        if " " in n or re.search(r"[^\x00-\x7F]", n):
            out.append(_f(
                "ORA242", "Dosya adinda bosluk veya ASCII disi karakter",
                Severity.FAIL,
                "'%s' - bosluk/Turkce karakter iceren dosya adlari arsivleme ve "
                "komut satirinda soruna yol acar." % n,
                "Dosya adinda sadece harf, rakam, '-' ve '_' kullanin.", n))
    return out


def classify_kinds(ctx) -> List[str]:
    """ZIP-018: bir dosyada birden fazla sinif olabilir; hepsi dondurulur."""
    kinds = []
    if ctx.top_ddl_statements:
        kinds.append("DDL")
    if ctx.top_dml_statements:
        kinds.append("DML")
    if any(s.first_word in ("SELECT", "WITH") for s in ctx.statements
           if s.kind != "sqlplus"):
        kinds.append("SELECT")
    if any(s.first_word in ("GRANT", "REVOKE") for s in ctx.statements):
        kinds.append("DCL")
    return kinds or ["BOS"]


def classify_script(ctx) -> str:
    """Bir scripti tek bir sinifa indirger (geriye donuk uyumluluk)."""
    return classify_kinds(ctx)[0]
