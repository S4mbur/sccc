# -*- coding: utf-8 -*-
"""Kurallarin ortak kullandigi kucuk yardimcilar."""
from __future__ import annotations

import re
from typing import Iterator, List, Optional, Tuple


def depth_map(text: str) -> List[int]:
    """Her karakter icin parantez derinligi."""
    out, d = [], 0
    for ch in text:
        if ch == "(":
            out.append(d)
            d += 1
        elif ch == ")":
            d = max(0, d - 1)
            out.append(d)
        else:
            out.append(d)
    return out


def find_top_level(text: str, pattern: str, flags: int = re.I) -> Optional[re.Match]:
    """Parantez derinligi 0 olan ilk eslesme (alt sorgulari atlar)."""
    dm = depth_map(text)
    for m in re.finditer(pattern, text, flags):
        if dm[m.start()] == 0:
            return m
    return None


def iter_top_level(text: str, pattern: str, flags: int = re.I) -> Iterator[re.Match]:
    dm = depth_map(text)
    for m in re.finditer(pattern, text, flags):
        if dm[m.start()] == 0:
            yield m


def paren_balance(text: str) -> int:
    return text.count("(") - text.count(")")


_WORD = r"[A-Za-z_$#][\w$#]*"
QUALIFIED = r'(?:"?%s"?\.)?"?%s"?' % (_WORD, _WORD)


def object_after(text: str, keyword_pattern: str) -> str:
    """Verilen anahtar kelimeden sonraki obje adini dondurur."""
    m = re.search(keyword_pattern + r"\s*(" + QUALIFIED + r")", text, re.I)
    return m.group(1).strip('"') if m else ""


def strip_hints(text: str) -> str:
    return re.sub(r"/\*\+.*?\*/", " ", text, flags=re.S)


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def kw(word: str) -> str:
    """Kelime siniri ile anahtar kelime regexi."""
    return r"(?<![\w$#])" + word + r"(?![\w$#])"
