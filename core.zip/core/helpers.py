# -*- coding: utf-8 -*-
"""Kurallarin ortak kullandigi kucuk yardimcilar."""
from __future__ import annotations

import re
from typing import Iterator, List, Optional, Tuple


def depth_map(text: str) -> List[int]:
    """Her karakter icin parantez derinligi."""
    out, d = [], 0
    for ch in text:
        if ch == "(":
            out.append(d)
            d += 1
        elif ch == ")":
            d = max(0, d - 1)
            out.append(d)
        else:
            out.append(d)
    return out


def find_top_level(text: str, pattern: str, flags: int = re.I) -> Optional[re.Match]:
    """Parantez derinligi 0 olan ilk eslesme (alt sorgulari atlar)."""
    dm = depth_map(text)
    for m in re.finditer(pattern, text, flags):
        if dm[m.start()] == 0:
            return m
    return None


def iter_top_level(text: str, pattern: str, flags: int = re.I) -> Iterator[re.Match]:
    dm = depth_map(text)
    for m in re.finditer(pattern, text, flags):
        if dm[m.start()] == 0:
            yield m


def paren_balance(text: str) -> int:
    return text.count("(") - text.count(")")


_WORD = r"[A-Za-z_$#][\w$#]*"
QUALIFIED = r'(?:"?%s"?\.)?"?%s"?' % (_WORD, _WORD)


def object_after(text: str, keyword_pattern: str) -> str:
    """Verilen anahtar kelimeden sonraki obje adini dondurur."""
    m = re.search(keyword_pattern + r"\s*(" + QUALIFIED + r")", text, re.I)
    return m.group(1).strip('"') if m else ""


def strip_hints(text: str) -> str:
    return re.sub(r"/\*\+.*?\*/", " ", text, flags=re.S)


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def kw(word: str) -> str:
    """Kelime siniri ile anahtar kelime regexi."""
    return r"(?<![\w$#])" + word + r"(?![\w$#])"


# --------------------------------------------------- PL/SQL blok tarayicisi
# Not: "ust seviye" tespiti girinti temellidir - kapanis END; satirinin
# sutun 0'da oldugu varsayilir (Oracle bicimlendirme standardi).
RE_BLOCK_CREATE = re.compile(
    r"^CREATE\s+(?:OR\s+REPLACE\s+)?(?:(?:NON)?EDITIONABLE\s+)?"
    r"(PROCEDURE|FUNCTION|PACKAGE(?:\s+BODY)?|TRIGGER|TYPE(?:\s+BODY)?|LIBRARY)\b",
    re.I)
RE_BLOCK_ANON = re.compile(r"^(DECLARE|BEGIN)\s*$|^(DECLARE|BEGIN)\b", re.I)
RE_BLOCK_END = re.compile(r"^END\s*[\w$#\"]*\s*;\s*$", re.I)
RE_BLOCK_END_SLASH = re.compile(r"^END\s*[\w$#\"]*\s*;\s*/\s*$", re.I)
RE_SLASH_ONLY = re.compile(r"^/\s*$")


RE_END_KEYWORD = re.compile(r"(?<![\w$#])END\s+(IF|LOOP|CASE)(?![\w$#])", re.I)
RE_OPENERS = re.compile(r"(?<![\w$#])(BEGIN|IF|LOOP|CASE)(?![\w$#])", re.I)
RE_CLOSERS = re.compile(r"(?<![\w$#])END(?![\w$#])", re.I)


class PlsqlUnit(object):
    """Ust seviye bir PL/SQL blogu ve onun '/' sonlandiricisi."""

    __slots__ = ("kind", "obj_type", "start", "end", "slash", "slash_gap",
                 "slash_same_line")

    def __init__(self, kind, obj_type, start, end):
        self.kind = kind              # 'create' | 'anon'
        self.obj_type = obj_type      # PROCEDURE / FUNCTION / BEGIN ...
        self.start = start            # 1-based
        self.end = end                # 1-based kapanis END; satiri (veya None)
        self.slash = None             # 1-based '/' satiri (veya None)
        self.slash_gap = 0            # END; ile '/' arasindaki bos satir sayisi
        self.slash_same_line = False  # END; / ayni satirda mi


def scan_plsql_units(masked_lines):
    """Dosyadaki ust seviye PL/SQL bloklarini ve '/' konumlarini cikarir.

    Blok sonu BEGIN/IF/LOOP/CASE - END derinlik sayimi ile bulunur; boylece
    procedure govdesindeki BEGIN, harici bir blok sanilmaz.
    """
    units = []
    n = len(masked_lines)
    i = 0
    while i < n:
        line = masked_lines[i]
        if not line.strip() or line[:1].isspace():
            i += 1
            continue
        m = RE_BLOCK_CREATE.match(line)
        if m:
            kind, otype = "create", re.sub(r"\s+", " ", m.group(1).upper())
        elif RE_BLOCK_ANON.match(line):
            kind, otype = "anon", line.strip().split()[0].upper()
        else:
            i += 1
            continue

        # PACKAGE / PACKAGE BODY / TYPE BODY govdesi kendisi bir blok acar:
        # "AS/IS ... END;" yapisinda BEGIN yoktur, bu yuzden derinlik 1'den baslar.
        # Aksi halde paket icindeki ilk "END proc;" tum paketi kapatmis sanilir.
        wrapper = 1 if re.search(r"(?<![\w$#])(PACKAGE|TYPE\s+BODY)(?![\w$#])",
                                 otype or "", re.I) else 0
        depth, seen, end_idx = wrapper, bool(wrapper), None
        j = i
        while j < n:
            txt = RE_END_KEYWORD.sub("END", masked_lines[j])
            opens = len(RE_OPENERS.findall(txt))
            closes = len(RE_CLOSERS.findall(txt))
            if opens or closes:
                seen = True
            depth += opens - closes
            if seen and depth <= 0:
                end_idx = j
                break
            j += 1

        unit = PlsqlUnit(kind, otype, i + 1, (end_idx + 1) if end_idx is not None else None)

        if end_idx is not None:
            if RE_BLOCK_END_SLASH.match(masked_lines[end_idx].strip()):
                unit.slash = end_idx + 1
                unit.slash_same_line = True
            else:
                k, blanks = end_idx + 1, 0
                while k < n and not masked_lines[k].strip():
                    blanks += 1
                    k += 1
                if k < n and RE_SLASH_ONLY.match(masked_lines[k].strip()):
                    unit.slash = k + 1
                    unit.slash_gap = blanks
            units.append(unit)
            i = (unit.slash or (end_idx + 1))
        else:
            units.append(unit)
            i = n
    return units


def top_level_blocks(masked_lines):
    """Geriye donuk uyumluluk: [(satir, kind, tip)] listesi."""
    return [(u.start, u.kind, u.obj_type) for u in scan_plsql_units(masked_lines)]


# --------------------------------------------------- literal / dinamik SQL
# q'[..]'  q'(..)'  q'{..}'  q'<..>'  ve q'X..X' bicimlerinin tamami (LEX-004)
_Q_PAIRS = {"[": "]", "(": ")", "{": "}", "<": ">"}
_RE_QSTART = re.compile(r"(?<![\w$#])[nN]?[qQ]'(.)", re.S)
_RE_PLAIN = re.compile(r"(?<![\w$#])[nN]?'((?:[^']|'')*)'", re.S)


def _find_qstring(text: str, start: int = 0):
    """Ilk q-quote literalini bulur -> (start, end, icerik) veya None."""
    m = _RE_QSTART.search(text, start)
    if not m:
        return None
    delim = m.group(1)
    close = _Q_PAIRS.get(delim, delim) + "'"
    idx = text.find(close, m.end())
    if idx == -1:
        return m.start(), len(text), text[m.end():]
    return m.start(), idx + 2, text[m.end():idx]


def iter_literals(text: str):
    """Metindeki tum string literalleri (normal, N'', q'[]') dondurur.

    yield (start, end, icerik)
    """
    pos, n = 0, len(text)
    while pos < n:
        q = _find_qstring(text, pos)
        p = _RE_PLAIN.search(text, pos)
        if q and (not p or q[0] <= p.start()):
            yield q
            pos = q[1]
        elif p:
            yield p.start(), p.end(), p.group(1).replace("''", "'")
            pos = p.end()
        else:
            return


def literal_at(text: str, pos: int):
    """pos'tan hemen sonra gelen ilk literali dondurur; araya kod girerse None."""
    m = re.match(r"[\s(]*", text[pos:])
    start = pos + m.end()
    q = _find_qstring(text, start)
    if q and q[0] == start:
        return q
    p = _RE_PLAIN.match(text, start)
    if p:
        return p.start(), p.end(), p.group(1).replace("''", "'")
    return None


def split_or_branches(text: str):
    """Predicate'i parantez derinligi 0'daki OR'lara gore boler."""
    parts, cur, depth, i = [], "", 0, 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        if depth == 0 and re.match(r"(?i)(?<![\w$#])OR(?![\w$#])", text[i:i + 3]):
            parts.append(cur)
            cur = ""
            i += 2
            continue
        cur += ch
        i += 1
    parts.append(cur)
    return [p for p in parts if p.strip()]
