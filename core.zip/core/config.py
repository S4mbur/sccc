# -*- coding: utf-8 -*-
"""Config yukleyici.

PyYAML kuruluysa onu kullanir; degilse dahili (bagimliliksiz) YAML alt-kumesi
cozumleyicisine duser. Amac: kilitli bir Python ortaminda ek paket gerekmemesi.
"""
# Karsilanan master kontroller: GATE-011 CUR-034 CUR-035
from __future__ import annotations

import io
import json
import os
import re
from typing import Any, Dict, List

DEFAULT_CONFIG: Dict[str, Any] = {
    "settings": {
        "max_statements": 200,
        "max_line_length": 300,
        "allowed_schemas": [],
        "object_prefixes": [],
        "required_header_fields": ["TALEP NO", "YAZAN", "TARIH", "AMAC"],
    },
    "rules": {},
}


def _coerce(v: str):
    s = v.strip()
    if s == "" or s in ("~", "null", "None"):
        return None
    low = s.lower()
    if low in ("true", "yes", "on"):
        return True
    if low in ("false", "no", "off"):
        return False
    if re.fullmatch(r"-?\d+", s):
        return int(s)
    if re.fullmatch(r"-?\d+\.\d+", s):
        return float(s)
    if s.startswith("[") and s.endswith("]"):
        inner = s[1:-1].strip()
        return [_coerce(x) for x in _split_inline(inner)] if inner else []
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "\"'":
        return s[1:-1]
    return s


def _split_inline(s: str) -> List[str]:
    out, cur, depth, q = [], "", 0, ""
    for ch in s:
        if q:
            cur += ch
            if ch == q:
                q = ""
            continue
        if ch in "\"'":
            q = ch
            cur += ch
        elif ch == "[":
            depth += 1
            cur += ch
        elif ch == "]":
            depth -= 1
            cur += ch
        elif ch == "," and depth == 0:
            out.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur)
    return out


def _strip_comment(line: str) -> str:
    out, q = [], ""
    for i, ch in enumerate(line):
        if q:
            out.append(ch)
            if ch == q:
                q = ""
            continue
        if ch in "\"'":
            q = ch
            out.append(ch)
            continue
        if ch == "#":
            break
        out.append(ch)
    return "".join(out)


def parse_simple_yaml(text: str) -> Dict[str, Any]:
    """Girinti tabanli, ic ice sozluk + blok liste destekleyen mini cozumleyici."""
    root: Dict[str, Any] = {}
    stack: List[list] = [[-1, root]]     # [indent, container]
    pending = None                       # [indent, parent, key]

    for rawline in text.split("\n"):
        line = _strip_comment(rawline).rstrip()
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip(" "))
        body = line.strip()

        if pending is not None:
            if indent > pending[0]:
                cont: Any = [] if body.startswith("- ") else {}
                pending[1][pending[2]] = cont
                stack.append([indent, cont])
            else:
                pending[1][pending[2]] = {}
            pending = None

        while len(stack) > 1 and indent < stack[-1][0]:
            stack.pop()
        container = stack[-1][1]

        if body.startswith("- "):
            if isinstance(container, list):
                container.append(_coerce(body[2:]))
            continue

        if ":" not in body:
            continue
        key, _, val = body.partition(":")
        key = key.strip().strip("\"'")
        val = val.strip()
        if not isinstance(container, dict):
            continue
        if val == "":
            pending = [indent, container, key]
        else:
            container[key] = _coerce(val)

    if pending is not None:
        pending[1][pending[2]] = {}
    return root


ALLOWED_TOP = {"settings", "rules", "profiles", "limits", "gate"}
ALLOWED_RULE_KEYS = {"enabled", "severity", "params"}
VALID_SEVERITY = {"INFO", "WARN", "FAIL"}


class ConfigError(Exception):
    """GATE-011: config semasi disi icerik fail-closed."""


def validate_config(cfg: Dict[str, Any], known_rule_ids=None) -> None:
    """Config'i semaya gore dogrular; hata varsa ConfigError firlatir."""
    problems = []
    for key in cfg:
        if key not in ALLOWED_TOP:
            problems.append("Bilinmeyen ust seviye anahtar: '%s' (izinli: %s)"
                            % (key, ", ".join(sorted(ALLOWED_TOP))))
    rules = cfg.get("rules") or {}
    if not isinstance(rules, dict):
        problems.append("'rules' bir sozluk olmali.")
        rules = {}
    for rid, val in rules.items():
        if known_rule_ids is not None and rid not in known_rule_ids:
            problems.append("Bilinmeyen kural ID: '%s'" % rid)
        if isinstance(val, bool) or val is None:
            continue
        if not isinstance(val, dict):
            problems.append("'%s' degeri sozluk olmali." % rid)
            continue
        for k in val:
            if k not in ALLOWED_RULE_KEYS:
                problems.append("'%s' icinde bilinmeyen anahtar: '%s'" % (rid, k))
        sev = val.get("severity")
        if sev is not None and str(sev).upper() not in VALID_SEVERITY:
            problems.append("'%s' icin gecersiz severity: '%s'" % (rid, sev))
        if "enabled" in val and not isinstance(val["enabled"], bool):
            problems.append("'%s'.enabled bool olmali." % rid)
    if problems:
        raise ConfigError("Config dogrulanamadi:\n  - %s" % "\n  - ".join(problems))


def load_config(path: str = None) -> Dict[str, Any]:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    if not path:
        return cfg
    if not os.path.exists(path):
        raise FileNotFoundError("Config bulunamadi: %s" % path)

    with io.open(path, "r", encoding="utf-8") as f:
        text = f.read()

    if path.lower().endswith(".json"):
        data = json.loads(text)
    else:
        try:
            import yaml  # type: ignore
            data = yaml.safe_load(text) or {}
        except ImportError:
            data = parse_simple_yaml(text)

    if not isinstance(data, dict):
        raise ValueError("Config kok seviyesi sozluk olmali.")

    for section in ("settings", "rules"):
        val = data.get(section)
        if isinstance(val, dict):
            cfg[section].update(val)
    return cfg
