# Kural Referansi

Toplam **60** kural. Bu dosya `tools_generate_rule_doc.py` ile uretilir.

| Seviye | Anlami |
|---|---|
| FAIL | Script calistirilmamali. Duzeltme zorunlu. |
| WARN | Gozden gecirilip onaylanmali. |
| INFO | Bilgilendirme. |

## Yikici / Geri Alinamaz Islemler (`YIKICI`)

| ID | Kural | Sev | Kontrol |
|---|---|---|---|
| `ORA001` | DROP ifadesi tespit edildi | FAIL | Script icinde obje silen DROP ifadesi var. |
| `ORA002` | TRUNCATE ifadesi tespit edildi | FAIL | TRUNCATE TABLE/CLUSTER kullanilmis. |
| `ORA003` | WHERE kosulu olmayan DELETE | FAIL | DELETE ifadesinde ust seviye WHERE kosulu yok. |
| `ORA004` | WHERE kosulu olmayan UPDATE | FAIL | UPDATE ifadesinde ust seviye WHERE kosulu yok. |
| `ORA005` | Instance seviyesinde mudahale | FAIL | ALTER SYSTEM / ALTER DATABASE / SHUTDOWN / STARTUP kullanilmis. |
| `ORA006` | Tablespace veya datafile operasyonu | FAIL | Tablespace/datafile olusturma, degistirme veya silme islemi var. |
| `ORA007` | Kolon / constraint / partition silme | FAIL | ALTER TABLE ile kolon, constraint veya partition siliniyor. |
| `ORA008` | Geri donus yolunu kapatan ifade (PURGE / FLASHBACK) | FAIL | PURGE, DROP ... PURGE veya FLASHBACK TABLE ifadesi var. |

### ORA001 - DROP ifadesi tespit edildi

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** Script icinde obje silen DROP ifadesi var.
- **Gerekce:** DROP geri alinamaz ve implicit commit uretir. Uretim veritabaninda veri/obje kaybina yol acar; degisiklik yonetimi onayi zorunludur.
- **Cozum:** Gercekten gerekliyse ayri bir 'drop' paketi olarak, yedek ve geri donus plani ile birlikte gonderin. Tercihen RENAME ... TO ..._YEDEK yontemi kullanin.
- **Parametreler:** `{'critical_objects': ['TABLE', 'USER', 'TABLESPACE', 'DATABASE', 'MATERIALIZED VIEW', 'DIRECTORY', 'ROLE', 'PROFILE']}`

### ORA002 - TRUNCATE ifadesi tespit edildi

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** TRUNCATE TABLE/CLUSTER kullanilmis.
- **Gerekce:** TRUNCATE DDL'dir: rollback edilemez, implicit commit uretir ve tabloyu aninda bosaltir. Flashback disinda geri donus yoktur.
- **Cozum:** Silinecek kayit sayisi kontrollu ise WHERE'li DELETE + COMMIT kullanin. TRUNCATE sart ise onceden CTAS ile yedek alin.

### ORA003 - WHERE kosulu olmayan DELETE

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** DELETE ifadesinde ust seviye WHERE kosulu yok.
- **Gerekce:** Tablonun tamamini siler. Buyuk tablolarda hem veri kaybi hem de UNDO tablespace dolmasi ve uzun sureli kilitlenme riski dogurur.
- **Cozum:** DELETE ifadesine daraltici bir WHERE kosulu ekleyin.

### ORA004 - WHERE kosulu olmayan UPDATE

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** UPDATE ifadesinde ust seviye WHERE kosulu yok.
- **Gerekce:** Tablodaki tum satirlari gunceller. Hesap/bakiye tablolarinda geri donusu maliyetli veri bozulmasina yol acar.
- **Cozum:** UPDATE ifadesine daraltici bir WHERE kosulu ekleyin.

### ORA005 - Instance seviyesinde mudahale

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** ALTER SYSTEM / ALTER DATABASE / SHUTDOWN / STARTUP kullanilmis.
- **Gerekce:** Bu komutlar tum instance'i etkiler; oturum kesilmesi, servis kesintisi ve SLA ihlali riski tasir. Uygulama scriptinde yeri yoktur.
- **Cozum:** Bu tur degisiklikleri uygulama scriptinden ayirip DBA operasyon penceresinde, degisiklik kaydi ile uygulayin.

### ORA006 - Tablespace veya datafile operasyonu

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** Tablespace/datafile olusturma, degistirme veya silme islemi var.
- **Gerekce:** Depolama katmani degisiklikleri kapasite planlamasi ve yedekleme politikasini etkiler; sadece DBA operasyon scriptlerinde olmalidir.
- **Cozum:** Storage islemlerini ayri bir DBA scriptine tasiyin.

### ORA007 - Kolon / constraint / partition silme

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** ALTER TABLE ile kolon, constraint veya partition siliniyor.
- **Gerekce:** Kolon silme geri alinamaz ve bagimli view/paket/rapor kirilmasina neden olur. Buyuk tablolarda uzun sureli exclusive lock alir.
- **Cozum:** Once SET UNUSED ile mantiksal olarak devre disi birakin, bagimlilik analizini yapin, ardindan bakim penceresinde DROP UNUSED COLUMNS calistirin.

### ORA008 - Geri donus yolunu kapatan ifade (PURGE / FLASHBACK)

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** PURGE, DROP ... PURGE veya FLASHBACK TABLE ifadesi var.
- **Gerekce:** PURGE recyclebin'i temizleyerek yanlislikla silinen objenin geri getirilmesini imkansiz kilar. FLASHBACK ise veriyi gecmise dondurur.
- **Cozum:** PURGE kullanmayin; silme oncesi export/CTAS yedegi alin.

## Guvenlik ve Yetkilendirme (`GUVENLIK`)

| ID | Kural | Sev | Kontrol |
|---|---|---|---|
| `ORA010` | PUBLIC rolune yetki verilmis | FAIL | GRANT ... TO PUBLIC ifadesi var. |
| `ORA011` | Genis kapsamli yetki verilmis | FAIL | ANY privilege, DBA rolu veya SYSDBA/SYSOPER yetkisi veriliyor. |
| `ORA012` | Script icinde acik kimlik bilgisi | FAIL | IDENTIFIED BY, CONNECT user/pass veya benzeri acik sifre var. |
| `ORA013` | Sistem semasi / sozluk objesine mudahale | FAIL | SYS, SYSTEM, SYSAUX, AUDSYS gibi sistem semalarina yazma islemi var. |
| `ORA014` | Dinamik SQL kullanimi | WARN | EXECUTE IMMEDIATE / DBMS_SQL ile dinamik SQL calistiriliyor. |
| `ORA015` | Riskli hazir paket kullanimi | WARN | Isletim sistemi, ag veya zamanlayici erisimi saglayan paketler. |
| `ORA016` | Kullanici, rol veya profil yonetimi | FAIL | CREATE/ALTER/DROP USER, ROLE veya PROFILE ifadesi var. |
| `ORA017` | Denetim izi veya trigger devre disi birakiliyor | FAIL | NOAUDIT, audit policy kapatma veya trigger DISABLE ifadesi var. |
| `ORA018` | Database link kullanimi | WARN | DB link olusturuluyor veya @link ile uzak veritabanina erisiliyor. |
| `ORA019` | Toplu veri disari cikarma sinyali | WARN | SPOOL, external table, CTAS veya directory ile veri disari aliniyor. |

### ORA010 - PUBLIC rolune yetki verilmis

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** GRANT ... TO PUBLIC ifadesi var.
- **Gerekce:** PUBLIC'e verilen yetki veritabanindaki her kullaniciya acilir. Musteri verisine yetkisiz erisim ve denetim bulgusu dogurur.
- **Cozum:** Yetkiyi ilgili role veya isimlendirilmis kullaniciya verin.

### ORA011 - Genis kapsamli yetki verilmis

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** ANY privilege, DBA rolu veya SYSDBA/SYSOPER yetkisi veriliyor.
- **Gerekce:** En az yetki (least privilege) ilkesini ihlal eder. Bu yetkiler gorev ayriligi (SoD) kontrollerini bypass eder ve denetimde bulgudur.
- **Cozum:** Yetkiyi obje bazinda (GRANT SELECT ON sema.tablo TO rol) verin. DBA/SYSDBA gereksinimini guvenlik ekibine onaylatın.
- **Parametreler:** `{'privileges': ['DBA', 'SYSDBA', 'SYSOPER', 'SYSBACKUP', 'SYSKM', 'SYSASM', 'IMP_FULL_DATABASE', 'EXP_FULL_DATABASE', 'GRANT ANY PRIVILEGE', 'ALTER SYSTEM', 'UNLIMITED TABLESPACE', 'BECOME USER']}`

### ORA012 - Script icinde acik kimlik bilgisi

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** IDENTIFIED BY, CONNECT user/pass veya benzeri acik sifre var.
- **Gerekce:** Sifre scriptte, versiyon kontrolunde ve log/spool ciktisinda duz metin kalir. KVKK ve bilgi guvenligi politikasi ihlalidir.
- **Cozum:** Sifreyi scriptten cikarin; wallet, degisken (&&pwd) veya vault kullanin. Zorunluysa IDENTIFIED BY VALUES yerine ayri kanal kullanin.

### ORA013 - Sistem semasi / sozluk objesine mudahale

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** SYS, SYSTEM, SYSAUX, AUDSYS gibi sistem semalarina yazma islemi var.
- **Gerekce:** Data dictionary uzerinde dogrudan degisiklik destek disi kalmaya ve veritabaninin tutarsiz hale gelmesine yol acar.
- **Cozum:** Islemi uygulama semasinda yapin; sistem semalarina dokunmayin.
- **Parametreler:** `{'schemas': ['SYS', 'SYSTEM', 'SYSAUX', 'AUDSYS', 'OUTLN', 'DBSNMP', 'XDB', 'WMSYS', 'CTXSYS', 'ORDSYS', 'MDSYS'], 'read_severity': 'INFO'}`

### ORA014 - Dinamik SQL kullanimi

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** EXECUTE IMMEDIATE / DBMS_SQL ile dinamik SQL calistiriliyor.
- **Gerekce:** Dinamik SQL statik olarak analiz edilemez; icerigi bu parser tarafindan denetlenemez ve SQL injection yuzeyi acar.
- **Cozum:** Mumkunse statik SQL kullanin. Zorunluysa bind degisken (USING) kullanin ve obje adlarini DBMS_ASSERT ile dogrulayin.

### ORA015 - Riskli hazir paket kullanimi

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** Isletim sistemi, ag veya zamanlayici erisimi saglayan paketler.
- **Gerekce:** Bu paketler veritabanindan disari veri cikarma (exfiltration), dosya sistemine erisim veya zamanlanmis gizli is olusturma imkani verir.
- **Cozum:** Kullanim gerekcesini degisiklik kaydina yazin ve guvenlik ekibi onayi alin. Alternatif olarak uygulama katmanini kullanin.
- **Parametreler:** `{'fail_packages': ['UTL_FILE', 'UTL_HTTP', 'UTL_TCP', 'UTL_SMTP', 'UTL_INADDR', 'DBMS_LOB.FILEOPEN', 'DBMS_BACKUP_RESTORE', 'DBMS_JAVA'], 'warn_packages': ['DBMS_SCHEDULER', 'DBMS_JOB', 'DBMS_LOCK', 'DBMS_PIPE', 'DBMS_AQ', 'DBMS_ALERT', 'DBMS_CRYPTO', 'DBMS_RANDOM', 'DBMS_SYSTEM', 'DBMS_UTILITY.EXEC_DDL_STATEMENT']}`

### ORA016 - Kullanici, rol veya profil yonetimi

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** CREATE/ALTER/DROP USER, ROLE veya PROFILE ifadesi var.
- **Gerekce:** Kimlik ve erisim yonetimi (IAM) ayri bir surectir; uygulama degisiklik scripti icinde hesap acilmasi gorev ayriligini ihlal eder.
- **Cozum:** Hesap/rol taleplerini IAM sureci uzerinden ayri script ile iletin.

### ORA017 - Denetim izi veya trigger devre disi birakiliyor

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** NOAUDIT, audit policy kapatma veya trigger DISABLE ifadesi var.
- **Gerekce:** Denetim izinin kapatilmasi log butunlugunu bozar; BDDK/ic denetim gereksinimlerini ihlal eder ve degisiklik izlenemez hale gelir.
- **Cozum:** Denetim kapatilmasi gerekiyorsa gerekcesini ve geri acma adimini degisiklik kaydina yazin, denetim ekibini bilgilendirin.

### ORA018 - Database link kullanimi

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** DB link olusturuluyor veya @link ile uzak veritabanina erisiliyor.
- **Gerekce:** DB link'ler veri sinirlarini asar; uzak sistemdeki veri sinifi ve yetki modeli farkli olabilir. Dagitik transaction riski de vardir.
- **Cozum:** Link kullanimini ve hedef sistemi degisiklik kaydinda belirtin; PUBLIC DATABASE LINK kullanmayin.

### ORA019 - Toplu veri disari cikarma sinyali

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** SPOOL, external table, CTAS veya directory ile veri disari aliniyor.
- **Gerekce:** Musteri verisinin dosyaya yazilmasi KVKK kapsaminda veri isleme faaliyetidir; maskeleme ve saklama kurallari uygulanmalidir.
- **Cozum:** Ciktiya kisisel veri gitmediginden emin olun, maskeleyin ve dosyayi islem sonrasi guvenli sekilde silin.

## Transaction Butunlugu (`TRANSACTION`)

| ID | Kural | Sev | Kontrol |
|---|---|---|---|
| `ORA020` | DML var ancak COMMIT yok | FAIL | Script veri degistiriyor fakat sonunda COMMIT bulunmuyor. |
| `ORA021` | Dongu icinde COMMIT | WARN | LOOP ... END LOOP blogu icinde COMMIT cagriliyor. |
| `ORA022` | Ayni scriptte DDL ve DML karisik | WARN | DDL implicit commit uretir; oncesindeki DML'i geri alamazsiniz. |
| `ORA023` | Birden fazla COMMIT | WARN | Script icinde birden cok COMMIT var; islem atomik degil. |
| `ORA024` | ROLLBACK / SAVEPOINT ifadesi | WARN | Script icinde ROLLBACK veya SAVEPOINT var. |
| `ORA025` | Otonom transaction kullanimi | WARN | PRAGMA AUTONOMOUS_TRANSACTION tanimlanmis. |
| `ORA026` | Acik tablo kilidi | WARN | LOCK TABLE veya SELECT ... FOR UPDATE kullanilmis. |
| `ORA027` | WHENEVER SQLERROR tanimlanmamis | FAIL | Script hata aninda durmuyor; sonraki ifadeler calismaya devam eder. |

### ORA020 - DML var ancak COMMIT yok

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** Script veri degistiriyor fakat sonunda COMMIT bulunmuyor.
- **Gerekce:** Commit edilmemis transaction, oturum kapaninca rollback olur ya da acik kalarak diger islemleri kilitler. Bloklama zinciri riskidir.
- **Cozum:** Scriptin sonuna acikca COMMIT; ekleyin.

### ORA021 - Dongu icinde COMMIT

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** LOOP ... END LOOP blogu icinde COMMIT cagriliyor.
- **Gerekce:** Dongu icindeki commit ORA-01555 (snapshot too old) hatasina ve islemin yarida kalmasi durumunda tutarsiz veriye yol acar.
- **Cozum:** Transaction sinirini dongu disina alin veya kontrollu batch commit (ornegin her 10.000 kayitta) + yeniden calistirilabilir tasarim kullanin.

### ORA022 - Ayni scriptte DDL ve DML karisik

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** DDL implicit commit uretir; oncesindeki DML'i geri alamazsiniz.
- **Gerekce:** DDL calistiginda bekleyen tum DML otomatik commit edilir. Hata durumunda kismi degisiklik kalici olur ve rollback plani calismaz.
- **Cozum:** DDL ve DML'i ayri scriptlere bolun (once yapisal degisiklik, sonra veri) ve her birini ayri adim olarak calistirin.

### ORA023 - Birden fazla COMMIT

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** Script icinde birden cok COMMIT var; islem atomik degil.
- **Gerekce:** Coklu commit, hata aninda scriptin yarisinin kalici olmasina yol acar. Geri donus (rollback) plani bu durumda gecersiz kalir.
- **Cozum:** Tek bir mantiksal islem icin tek COMMIT kullanin; zorunluysa her commit noktasi icin ayri bir geri alma adimi tanimlayin.
- **Parametreler:** `{'max_commits': 1}`

### ORA024 - ROLLBACK / SAVEPOINT ifadesi

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** Script icinde ROLLBACK veya SAVEPOINT var.
- **Gerekce:** Test sirasinda birakilmis ROLLBACK, degisikligin uretimde hic uygulanmamasina neden olur - sessiz basarisizliktir.
- **Cozum:** Test amacli ROLLBACK'leri temizleyin. Hata yakalama icin kullaniliyorsa EXCEPTION blogu icinde oldugunu dogrulayin.

### ORA025 - Otonom transaction kullanimi

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** PRAGMA AUTONOMOUS_TRANSACTION tanimlanmis.
- **Gerekce:** Otonom transaction ana islemden bagimsiz commit eder; ana islem rollback olsa bile yazdigi veri kalir. Tutarsizlik kaynagidir.
- **Cozum:** Sadece loglama gibi bilincli kullanimlarda birakin, is verisi yazan kodda kullanmayin.

### ORA026 - Acik tablo kilidi

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** LOCK TABLE veya SELECT ... FOR UPDATE kullanilmis.
- **Gerekce:** Exclusive kilit, mesai icinde calistirilirsa uygulama tarafinda bloklama ve zaman asimi zincirine yol acar.
- **Cozum:** Kilidi mumkun olan en dar kapsamda alin, NOWAIT / WAIT n ekleyin ve calistirmayi bakim penceresine planlayin.

### ORA027 - WHENEVER SQLERROR tanimlanmamis

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** Script hata aninda durmuyor; sonraki ifadeler calismaya devam eder.
- **Gerekce:** SQL*Plus varsayilan olarak hatayi yok sayip devam eder. Ilk adim basarisiz olsa bile sonraki DML/DDL calisir ve kismi degisiklik kalir.
- **Cozum:** Scriptin en basina su iki satiri ekleyin:   WHENEVER SQLERROR EXIT FAILURE ROLLBACK;   WHENEVER OSERROR EXIT FAILURE ROLLBACK;

## Sozdizimi ve Yapi (`SOZDIZIMI`)

| ID | Kural | Sev | Kontrol |
|---|---|---|---|
| `ORA030` | Sonlandirilmamis ifade | FAIL | Ifade ';' veya '/' ile bitirilmemis. |
| `ORA031` | BEGIN / END dengesizligi | FAIL | PL/SQL bloklarinda BEGIN ve END sayilari uyusmuyor. |
| `ORA032` | Parantez dengesizligi | FAIL | Ifade icinde acilan ve kapanan parantez sayisi esit degil. |
| `ORA033` | Kapanmamis string veya yorum | FAIL | Tek tirnak veya /* */ yorum blogu kapatilmamis. |
| `ORA034` | Bos script | FAIL | Scriptte calistirilabilir hicbir ifade yok. |
| `ORA035` | '&' iceren veri var ancak SET DEFINE OFF yok | FAIL | String icindeki '&' SQL*Plus tarafindan degisken olarak yorumlanir. |
| `ORA036` | PL/SQL blogu '/' ile kapatilmamis | FAIL | PL/SQL blogu kendi satirinda '/' ile sonlandirilmamis. |
| `ORA037` | Asiri uzun satir veya TAB karakteri | INFO | Cok uzun satirlar ve TAB karakteri okunabilirligi bozar. |
| `ORA038` | Kod icinde ASCII disi karakter | WARN | Obje adi / anahtar kelime bolgesinde Turkce veya ozel karakter var. |

### ORA030 - Sonlandirilmamis ifade

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** Ifade ';' veya '/' ile bitirilmemis.
- **Gerekce:** Sonlandirilmayan ifade SQL*Plus tarafindan calistirilmaz; script sessizce eksik calisir veya buffer'da bekleyip hata verir.
- **Cozum:** Ifadeyi ';' ile, PL/SQL blogunu ise ayri satirda '/' ile kapatin.

### ORA031 - BEGIN / END dengesizligi

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** PL/SQL bloklarinda BEGIN ve END sayilari uyusmuyor.
- **Gerekce:** Kapanmayan blok derleme hatasina yol acar; script yarim kalir. CASE/LOOP/IF yapilarinin da kapatilmasi gerekir.
- **Cozum:** Eksik END; ifadelerini tamamlayin.

### ORA032 - Parantez dengesizligi

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** Ifade icinde acilan ve kapanan parantez sayisi esit degil.
- **Gerekce:** Dengesiz parantez ORA-00907 gibi derleme/ayristirma hatasi uretir.
- **Cozum:** Eksik parantezi tamamlayin.

### ORA033 - Kapanmamis string veya yorum

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** Tek tirnak veya /* */ yorum blogu kapatilmamis.
- **Gerekce:** Kapanmayan tirnak scriptin geri kalanini string olarak yutar; beklenmeyen ifadeler calisir veya script asili kalir.
- **Cozum:** Eksik tirnagi/yorum kapanisini tamamlayin.

### ORA034 - Bos script

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** Scriptte calistirilabilir hicbir ifade yok.
- **Gerekce:** Bos script yanlislikla gonderilmis olabilir; degisiklik uygulanmaz.
- **Cozum:** Dogru dosyayi gonderdiginizden emin olun.

### ORA035 - '&' iceren veri var ancak SET DEFINE OFF yok

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** String icindeki '&' SQL*Plus tarafindan degisken olarak yorumlanir.
- **Gerekce:** SET DEFINE OFF verilmezse 'A&B' gibi bir deger sessizce bozulur veya script kullanicidan girdi bekleyerek asili kalir.
- **Cozum:** Scriptin basina SET DEFINE OFF; ekleyin.

### ORA036 - PL/SQL blogu '/' ile kapatilmamis

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** PL/SQL blogu kendi satirinda '/' ile sonlandirilmamis.
- **Gerekce:** SQL*Plus PL/SQL blogunu ancak tek basina '/' satirini gorunce calistirir. Eksikse blok hic calismaz.
- **Cozum:** Blogun END; satirindan sonra ayri bir satira / koyun.

### ORA037 - Asiri uzun satir veya TAB karakteri

- **Seviye:** INFO  |  **Varsayilan:** acik
- **Kontrol:** Cok uzun satirlar ve TAB karakteri okunabilirligi bozar.
- **Gerekce:** Bazi SQL*Plus surumlerinde 2499 karakterden uzun satirlar kesilir; TAB karakteri farkli editorlerde farkli goruntulenir.
- **Cozum:** Satirlari bolun, TAB yerine bosluk kullanin.
- **Parametreler:** `{'max_line_length': 300, 'flag_tabs': True}`

### ORA038 - Kod icinde ASCII disi karakter

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** Obje adi / anahtar kelime bolgesinde Turkce veya ozel karakter var.
- **Gerekce:** Client ile veritabani karakter seti (NLS_LANG) farkliysa bu karakterler bozulur; obje adlari ve veri hatali yazilir.
- **Cozum:** Obje ve kolon adlarinda Turkce karakter kullanmayin. Veri iceren stringler icin NLS_LANG ve dosya kodlamasini (UTF-8) dogrulayin.

## Sema, Obje ve Isimlendirme (`SEMA`)

| ID | Kural | Sev | Kontrol |
|---|---|---|---|
| `ORA040` | Sema oneki olmayan obje referansi | WARN | Tablo/view referansinda SEMA.OBJE formati kullanilmamis. |
| `ORA041` | Izin verilmeyen sema | FAIL | Script, izin verilen sema listesi disinda bir semaya dokunuyor. |
| `ORA042` | TABLESPACE belirtilmemis | WARN | CREATE TABLE / CREATE INDEX ifadesinde TABLESPACE yok. |
| `ORA043` | Obje isimlendirme standardina uymuyor | WARN | Yeni olusturulan obje adi kurum standardina uymuyor. |
| `ORA044` | Gecici veya test amacli obje adi | WARN | TEMP, TEST, YEDEK, BACKUP, _OLD gibi gecici adlar uretime gidiyor. |
| `ORA045` | Script tekrar calistirilabilir degil | WARN | CREATE / ALTER ADD ifadeleri var olan objede hata verir. |
| `ORA046` | Yeni tablo/kolon icin aciklama (COMMENT ON) yok | INFO | CREATE TABLE var ancak COMMENT ON TABLE/COLUMN tanimlanmamis. |

### ORA040 - Sema oneki olmayan obje referansi

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** Tablo/view referansinda SEMA.OBJE formati kullanilmamis.
- **Gerekce:** Sema oneki yoksa script hangi kullanici ile calistirildigina gore farkli semayi hedefler. Yanlis ortamda yanlis tabloyu degistirebilir.
- **Cozum:** Tum obje referanslarini SEMA.OBJE seklinde nitelendirin.
- **Parametreler:** `{'ignore_objects': ['DUAL', 'SYSDATE', 'SYSTIMESTAMP', 'USER', 'TABLE', 'SELECT', 'VALUES', 'LATERAL', 'ONLY', 'XMLTABLE', 'JSON_TABLE'], 'ignore_patterns': ['^(USER|ALL|DBA|CDB)_', '^V\\$', '^GV\\$', '^X\\$', '^(V_|L_|P_|G_|R_|C_)', '^SYS\\.']}`

### ORA041 - Izin verilmeyen sema

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** Script, izin verilen sema listesi disinda bir semaya dokunuyor.
- **Gerekce:** Her degisiklik talebi belirli bir uygulama semasi icin onaylanir. Kapsam disi sema, onaysiz degisiklik demektir.
- **Cozum:** config.yaml -> settings.allowed_schemas listesini guncelleyin ya da scripti sadece onayli semayi hedefleyecek sekilde duzeltin.
- **Parametreler:** `{'allowed_schemas': []}`

### ORA042 - TABLESPACE belirtilmemis

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** CREATE TABLE / CREATE INDEX ifadesinde TABLESPACE yok.
- **Gerekce:** Varsayilan tablespace'e dusen obje kapasite planlamasini bozar; yanlis diskte buyuyup uretim kesintisine yol acabilir.
- **Cozum:** Ifadeye acikca TABLESPACE <ad> ekleyin.

### ORA043 - Obje isimlendirme standardina uymuyor

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** Yeni olusturulan obje adi kurum standardina uymuyor.
- **Gerekce:** Standart disi isimler envanter, izleme ve otomatik bakim islerini bozar; obje sahipligi belirsizlesir.
- **Cozum:** Obje adini kurum isimlendirme standardina gore duzeltin.
- **Parametreler:** `{'max_length': 30, 'require_upper': True, 'prefixes': {'INDEX': ['IX_', 'IDX_', 'PK_', 'UK_'], 'TRIGGER': ['TRG_'], 'SEQUENCE': ['SEQ_'], 'VIEW': ['V_', 'VW_'], 'PACKAGE': ['PKG_']}}`

### ORA044 - Gecici veya test amacli obje adi

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** TEMP, TEST, YEDEK, BACKUP, _OLD gibi gecici adlar uretime gidiyor.
- **Gerekce:** Gecici objeler uretimde unutulur, disk doldurur ve envanterde sahipsiz kalir. Ayrica veri kopyalari KVKK acisindan risklidir.
- **Cozum:** Gecici obje gerekiyorsa temizleme adimini ayni degisiklik kaydinda planlayin ve son kullanma tarihi belirtin.
- **Parametreler:** `{'patterns': ['TEMP', 'TMP', 'TEST', 'DENEME', 'YEDEK', 'BACKUP', 'BKP', '_OLD', '_ESKI', '_NEW', '_YENI', 'COPY', 'KOPYA', '_BAK', '_1', '_2', 'XXX', 'ASDF', 'DELETEME', 'SILINECEK']}`

### ORA045 - Script tekrar calistirilabilir degil

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** CREATE / ALTER ADD ifadeleri var olan objede hata verir.
- **Gerekce:** Kesinti aninda script bastan calistirilir. Idempotent olmayan script ikinci calistirmada ORA-00955 verip yarida kalir.
- **Cozum:** Objeyi olusturmadan once USER_OBJECTS/USER_TAB_COLUMNS kontrolu yapan bir PL/SQL blogu kullanin ya da hata kodunu tolere edin.

### ORA046 - Yeni tablo/kolon icin aciklama (COMMENT ON) yok

- **Seviye:** INFO  |  **Varsayilan:** acik
- **Kontrol:** CREATE TABLE var ancak COMMENT ON TABLE/COLUMN tanimlanmamis.
- **Gerekce:** Veri sozlugu dokumantasyonu, veri yonetisimi ve KVKK envanteri icin gereklidir. Aciklamasiz kolonlar veri sinifi belirsiz kalir.
- **Cozum:** Her yeni tablo ve kolon icin COMMENT ON ... IS '...' ekleyin.

## Performans ve Kilitleme (`PERFORMANS`)

| ID | Kural | Sev | Kontrol |
|---|---|---|---|
| `ORA050` | SELECT * kullanimi | WARN | Kolon listesi yerine SELECT * kullanilmis. |
| `ORA051` | Index islemi ONLINE degil | WARN | CREATE INDEX / ALTER INDEX REBUILD icin ONLINE belirtilmemis. |
| `ORA052` | DEFAULT'suz NOT NULL kolon ekleniyor | FAIL | ALTER TABLE ADD ... NOT NULL ifadesinde DEFAULT deger yok. |
| `ORA053` | NOLOGGING / APPEND kullanimi | FAIL | NOLOGGING, UNRECOVERABLE veya /*+ APPEND */ kullanilmis. |
| `ORA054` | Optimizer hint / PARALLEL kullanimi | WARN | Sorgu hint'i veya yuksek dereceli PARALLEL tanimlanmis. |
| `ORA055` | Virgullu join / kartezyen carpim riski | WARN | FROM listesinde birden fazla tablo var, ANSI JOIN kullanilmamis. |
| `ORA056` | Kolon listesi olmayan INSERT | WARN | INSERT INTO tablo VALUES(...) seklinde, kolon adlari yazilmamis. |
| `ORA057` | Index kullanimini engelleyen kalip | INFO | WHERE kosulunda kolonu saran fonksiyon veya bastan joker (%) var. |

### ORA050 - SELECT * kullanimi

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** Kolon listesi yerine SELECT * kullanilmis.
- **Gerekce:** Tablo yapisi degistiginde kod sessizce bozulur, gereksiz kolonlar okunarak I/O artar ve gizli kolonlar (kisisel veri) disari sizabilir.
- **Cozum:** Ihtiyac duyulan kolonlari acikca yazin.

### ORA051 - Index islemi ONLINE degil

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** CREATE INDEX / ALTER INDEX REBUILD icin ONLINE belirtilmemis.
- **Gerekce:** ONLINE olmadan index olusturma tablo uzerinde DML'i bloke eder; buyuk tablolarda uygulama kesintisi anlamina gelir.
- **Cozum:** Ifadeye ONLINE (ve uygunsa PARALLEL + NOLOGGING sonrasi LOGGING) ekleyin.

### ORA052 - DEFAULT'suz NOT NULL kolon ekleniyor

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** ALTER TABLE ADD ... NOT NULL ifadesinde DEFAULT deger yok.
- **Gerekce:** Dolu bir tabloya DEFAULT'suz NOT NULL kolon eklenemez (ORA-01758). DEFAULT ile bile 11g oncesi surumlerde tum satirlar guncellenir ve uzun sureli kilit olusur.
- **Cozum:** Kolonu once NULL olarak ekleyin, veriyi batch halinde doldurun, ardindan NOT NULL constraint'i ENABLE NOVALIDATE ile ekleyin.

### ORA053 - NOLOGGING / APPEND kullanimi

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** NOLOGGING, UNRECOVERABLE veya /*+ APPEND */ kullanilmis.
- **Gerekce:** Redo uretilmedigi icin standby veritabani bozulur ve yedekten geri donus mumkun olmaz. Felaket kurtarma (DR) butunlugunu kirar.
- **Cozum:** Data Guard ortaminda NOLOGGING kullanmayin. Zorunluysa islem sonrasi FORCE LOGGING'e donun ve tam yedek alin.

### ORA054 - Optimizer hint / PARALLEL kullanimi

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** Sorgu hint'i veya yuksek dereceli PARALLEL tanimlanmis.
- **Gerekce:** Hint'ler optimizer'i sabitler; veri dagilimi degisince plan bozulur. Yuksek PARALLEL derecesi CPU ve PX server kaynagini tuketip diger islemleri yavaslatir.
- **Cozum:** Hint yerine guncel istatistik ve dogru index kullanin. PARALLEL derecesini kurum limitinde tutun ve islem sonrasi NOPARALLEL yapin.
- **Parametreler:** `{'max_parallel_degree': 8}`

### ORA055 - Virgullu join / kartezyen carpim riski

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** FROM listesinde birden fazla tablo var, ANSI JOIN kullanilmamis.
- **Gerekce:** Join kosulu unutulursa kartezyen carpim olusur; milyonlarca satir uretip UNDO/TEMP alanini doldurur ve veritabanini kilitler.
- **Cozum:** ANSI JOIN ... ON sozdizimi kullanin.

### ORA056 - Kolon listesi olmayan INSERT

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** INSERT INTO tablo VALUES(...) seklinde, kolon adlari yazilmamis.
- **Gerekce:** Tabloya kolon eklenirse veya sira degisirse INSERT sessizce yanlis kolona yazar ya da hata verir. Veri butunlugu riskidir.
- **Cozum:** INSERT INTO sema.tablo (kolon1, kolon2, ...) VALUES (...) yazin.

### ORA057 - Index kullanimini engelleyen kalip

- **Seviye:** INFO  |  **Varsayilan:** acik
- **Kontrol:** WHERE kosulunda kolonu saran fonksiyon veya bastan joker (%) var.
- **Gerekce:** Bu kaliplar index'i devre disi birakip tam tablo taramasina zorlar; buyuk hesap/hareket tablolarinda islem suresi katlanir.
- **Cozum:** Fonksiyonu sabit tarafa alin, function-based index tanimlayin veya LIKE '%...' yerine daraltici kosul kullanin.

## Kurumsal Standart ve Izlenebilirlik (`STANDART`)

| ID | Kural | Sev | Kontrol |
|---|---|---|---|
| `ORA060` | Zorunlu baslik blogu eksik | FAIL | Scriptin basinda talep no, yazan, tarih, amac bilgileri yok. |
| `ORA061` | Geri alma plani referansi yok | FAIL | Kalici degisiklik yapan scriptte geri alma adimi belirtilmemis. |
| `ORA062` | Calisma logu alinmiyor | WARN | Script ciktisi SPOOL ile dosyaya yazilmiyor. |
| `ORA063` | Script cok fazla ifade iceriyor | WARN | Tek scriptte cok sayida ifade var. |
| `ORA064` | Script EXIT ile bitmiyor | WARN | Scriptin sonunda EXIT yok; oturum acik kalir. |
| `ORA065` | Format maskesi olmayan tarih donusumu | FAIL | TO_DATE / TO_CHAR tek parametre ile cagrilmis ya da tarih stringi var. |
| `ORA066` | Ortama ozel referans | FAIL | Script icinde DEV/TEST/UAT ortamina ait isim, IP veya sunucu var. |
| `ORA067` | DBMS_OUTPUT var ama SERVEROUTPUT acik degil | WARN | DBMS_OUTPUT.PUT_LINE kullanilmis fakat SET SERVEROUTPUT ON yok. |
| `ORA068` | Degisiklik sonrasi istatistik toplanmamis | WARN | Index/tablo olusturulmus ancak DBMS_STATS cagrisi yok. |

### ORA060 - Zorunlu baslik blogu eksik

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** Scriptin basinda talep no, yazan, tarih, amac bilgileri yok.
- **Gerekce:** Degisiklik izlenebilirligi (change traceability) icin zorunludur. Denetimde 'bu degisikligi kim, hangi talep ile yapti' sorusunun cevabidir.
- **Cozum:** Scriptin en basina asagidaki gibi bir yorum blogu ekleyin:   /*    * TALEP NO : CHG-2026-0001    * YAZAN    : Ad Soyad    * TARIH    : 2026-08-10    * AMAC     : ...    * GERI ALMA: rollback_CHG-2026-0001.sql    */
- **Parametreler:** `{'required_fields': ['TALEP', 'YAZAN', 'TARIH', 'AMAC'], 'aliases': {'TALEP': ['TALEP NO', 'TALEP', 'CHANGE', 'CHG', 'TICKET', 'JIRA', 'ISTEK'], 'YAZAN': ['YAZAN', 'AUTHOR', 'HAZIRLAYAN', 'GELISTIRICI', 'OWNER'], 'TARIH': ['TARIH', 'DATE', 'OLUSTURMA'], 'AMAC': ['AMAC', 'ACIKLAMA', 'PURPOSE', 'DESCRIPTION', 'KONU']}}`

### ORA061 - Geri alma plani referansi yok

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** Kalici degisiklik yapan scriptte geri alma adimi belirtilmemis.
- **Gerekce:** Uretim degisikliginin geri alinabilir olmasi zorunludur. Rollback scripti olmadan hata durumunda kesinti suresi ongorulemez.
- **Cozum:** Baslik blogunda 'GERI ALMA: <dosya adi>' satiri ekleyin ve ilgili rollback scriptini pakete dahil edin.
- **Parametreler:** `{'keywords': ['GERI ALMA', 'GERI DONUS', 'ROLLBACK PLAN', 'ROLLBACK SCRIPT', 'GERIALMA', 'UNDO SCRIPT', 'REVERT']}`

### ORA062 - Calisma logu alinmiyor

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** Script ciktisi SPOOL ile dosyaya yazilmiyor.
- **Gerekce:** Kanit (evidence) olmadan degisikligin basariyla uygulandigi denetimde gosterilemez; hata analizi de mumkun olmaz.
- **Cozum:** Basa SPOOL <talep_no>_<ortam>.log, sona SPOOL OFF ekleyin.

### ORA063 - Script cok fazla ifade iceriyor

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** Tek scriptte cok sayida ifade var.
- **Gerekce:** Buyuk scriptler gozden gecirilmesi zor, hata aninda hangi adimda kalindigini tespit etmek gucdur. Kismi basarisizlik riski artar.
- **Cozum:** Scripti mantiksal adimlara bolun (01_yapi.sql, 02_veri.sql ...).
- **Parametreler:** `{'max_statements': 200}`

### ORA064 - Script EXIT ile bitmiyor

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** Scriptin sonunda EXIT yok; oturum acik kalir.
- **Gerekce:** Otomasyondan calistirilan scriptte EXIT yoksa oturum kapanmaz, is beklemeye girer ve kilit tutmaya devam eder.
- **Cozum:** Scriptin sonuna EXIT SUCCESS; (veya EXIT;) ekleyin.

### ORA065 - Format maskesi olmayan tarih donusumu

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** TO_DATE / TO_CHAR tek parametre ile cagrilmis ya da tarih stringi var.
- **Gerekce:** Format maskesi verilmezse sonuc NLS_DATE_FORMAT'a baglidir. Ayni script farkli oturumda farkli tarih uretir - finansal hesaplamada kritik.
- **Cozum:** TO_DATE('01.01.2026','DD.MM.YYYY') gibi acik format maskesi kullanin veya DATE '2026-01-01' ANSI literalini tercih edin.

### ORA066 - Ortama ozel referans

- **Seviye:** FAIL  |  **Varsayilan:** acik
- **Kontrol:** Script icinde DEV/TEST/UAT ortamina ait isim, IP veya sunucu var.
- **Gerekce:** Uretime giden scriptte test ortami referansi kalirsa islem yanlis sisteme baglanir veya hata verir. Sik gorulen dagitim hatasidir.
- **Cozum:** Ortama ozel degerleri degisken (&&ortam) veya ayri config dosyasi ile disariya alin.
- **Parametreler:** `{'tokens': ['DEV', 'TEST', 'UAT', 'SIT', 'PREPROD', 'STAGING', 'LOCALHOST', 'SANDBOX', 'DENEME'], 'flag_ip': True}`

### ORA067 - DBMS_OUTPUT var ama SERVEROUTPUT acik degil

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** DBMS_OUTPUT.PUT_LINE kullanilmis fakat SET SERVEROUTPUT ON yok.
- **Gerekce:** SERVEROUTPUT kapaliyken mesajlar hicbir yere yazilmaz; scriptin ilerleme ve dogrulama ciktilari kaybolur.
- **Cozum:** Scriptin basina SET SERVEROUTPUT ON SIZE UNLIMITED; ekleyin.

### ORA068 - Degisiklik sonrasi istatistik toplanmamis

- **Seviye:** WARN  |  **Varsayilan:** acik
- **Kontrol:** Index/tablo olusturulmus ancak DBMS_STATS cagrisi yok.
- **Gerekce:** Guncel olmayan istatistik optimizer'in yanlis plan secmesine ve sorgu surelerinin aniden artmasina yol acar.
- **Cozum:** Islem sonuna DBMS_STATS.GATHER_TABLE_STATS('SEMA','TABLO', cascade=>TRUE) ekleyin.

## Kuruma Ozel (sablon) (`KURUM`)

| ID | Kural | Sev | Kontrol |
|---|---|---|---|
| `ORA900` | Ornek sablon kural | INFO | Yasakli kelime listesindeki ifadeleri arar. |

### ORA900 - Ornek sablon kural

- **Seviye:** INFO  |  **Varsayilan:** kapali
- **Kontrol:** Yasakli kelime listesindeki ifadeleri arar.
- **Gerekce:** Kurumunuza ozel yasakli kaliplari burada tanimlayabilirsiniz.
- **Cozum:** Ilgili ifadeyi kaldirin veya istisna onayi alin.
- **Parametreler:** `{'yasakli_kelimeler': ['SILINECEK_KELIME']}`
