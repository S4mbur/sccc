# Oracle Script Doğrulayıcı (Parser)

Oracle SQL/PL-SQL script'lerini **çalıştırmadan önce** kural bazlı denetleyen statik analiz aracı.
Veritabanına bağlanmaz, hiçbir şey çalıştırmaz — sadece parse eder ve rapor üretir.

- **59 aktif kural**, 7 kategori (+1 şablon)
- **Sıfır bağımlılık** — sadece standart kütüphane (PyYAML varsa kullanılır, yoksa dahili parser devreye girer)
- **Her kural ayrı dosya** — dosya ekle = kural ekle, dosya sil = kural sil
- PASS / WARN / FAIL kararı + exit code ile otomasyona bağlanır

---

## Hızlı başlangıç

```bash
python validate_script.py degisiklik.sql
python validate_script.py *.sql --json rapor.json
python validate_script.py --list-rules
python validate_script.py --rule-info ORA003
```

Örnek çıktı:

```
==============================================================================
ORACLE SCRIPT DOGRULAMA RAPORU
==============================================================================
Dosya      : /opt/scripts/CHG-2026-0417.sql
Satir/Ifade: 42 satir, 12 ifade (1 DML, 1 DDL)
Kural      : 59 aktif, 0 kapali
Sonuc      : FAIL   (FAIL:16  WARN:16  INFO:1)
==============================================================================

ENGELLEYICI BULGULAR (16)
------------------------------------------------------------------------------
[ORA004] satir 14    YIKICI | WHERE kosulu olmayan UPDATE
    -> WHERE'siz UPDATE: bankapp.hesap (tum satirlar guncellenir)
    | UPDATE bankapp.hesap SET durum = 'P';
    COZUM: UPDATE ifadesine daraltici bir WHERE kosulu ekleyin.
```

### Exit code'lar

| Kod | Anlamı |
|---|---|
| 0 | PASS — bulgu yok (veya sadece INFO) |
| 1 | WARN — uyarı var, onaya sunulmalı |
| 2 | FAIL — engelleyici bulgu, çalıştırılmamalı |
| 3 | Hata — dosya okunamadı / config bozuk |

Otomasyona bağlamak için:

```bash
python validate_script.py "$SCRIPT" --format quiet --json "$SCRIPT.json"
if [ $? -ge 2 ]; then echo "Script reddedildi"; exit 1; fi
```

---

## Dizin yapısı

```
ora_script_validator/
├── validate_script.py          # CLI giriş noktası
├── config.yaml                 # kural aç/kapa, severity, parametreler
├── KURALLAR.md                 # kural referansı (otomatik üretilir)
├── tools_generate_rule_doc.py  # KURALLAR.md üreticisi
├── core/
│   ├── lexer.py       yorum/string maskeleme + ifade ayrıştırma
│   ├── context.py     ScriptContext — kuralların çalıştığı nesne
│   ├── model.py       BaseRule / Finding / Severity
│   ├── registry.py    rules/ klasöründen otomatik kural keşfi
│   ├── config.py      YAML yükleyici (bağımlılıksız fallback dahil)
│   ├── helpers.py     ortak regex yardımcıları
│   └── reporter.py    konsol + JSON rapor, PASS/WARN/FAIL kararı
├── rules/             HER KURAL AYRI DOSYA (ORA001_*.py ... ORA900_*.py)
└── samples/           iyi_ornek.sql, kotu_ornek.sql
```

### Parsing neden güvenilir

`core/lexer.py` önce **yorumları ve string içeriklerini aynı uzunlukta boşluğa çevirir**.
Böylece:

- `-- DROP TABLE x;` yorumu **alarm üretmez**
- `WHERE ad = 'DELETE FROM x'` string'i **alarm üretmez**
- satır/sütun numaraları **birebir korunur** (offset kayması yok)

Ardından script ifadelere bölünür; anonim PL/SQL blokları, `CREATE PROCEDURE/PACKAGE/TRIGGER`
gövdeleri, SQL\*Plus komutları (`SET`, `SPOOL`, `WHENEVER`, `@`) ve `/` sonlandırıcısı ayrı ayrı tanınır.
Böylece PL/SQL bloğu içindeki `;` karakterleri ifadeyi yanlışlıkla bölmez.

---

## Kural kategorileri

| Kategori | Aralık | Kapsam |
|---|---|---|
| `YIKICI` | ORA001–008 | DROP, TRUNCATE, WHERE'siz DML, ALTER SYSTEM, kolon silme, PURGE |
| `GUVENLIK` | ORA010–019 | GRANT TO PUBLIC, ANY/DBA yetkisi, açık şifre, sistem şeması, dinamik SQL, riskli paketler, audit kapatma, DB link |
| `TRANSACTION` | ORA020–027 | COMMIT eksikliği, döngü içi COMMIT, DDL+DML karışımı, çoklu COMMIT, otonom transaction, kilitleme, WHENEVER SQLERROR |
| `SOZDIZIMI` | ORA030–038 | sonlandırıcı, BEGIN/END dengesi, parantez, kapanmamış string, boş script, SET DEFINE OFF, `/` eksikliği, ASCII dışı karakter |
| `SEMA` | ORA040–046 | şema öneki, şema allowlist, TABLESPACE, isimlendirme standardı, geçici obje adları, idempotency, COMMENT ON |
| `PERFORMANS` | ORA050–057 | SELECT \*, ONLINE index, NOT NULL kolon ekleme, NOLOGGING, hint/PARALLEL, kartezyen çarpım, kolonsuz INSERT |
| `STANDART` | ORA060–068 | başlık bloğu, geri alma planı, SPOOL logu, ifade sayısı, EXIT, tarih format maskesi, DEV/TEST sızıntısı, SERVEROUTPUT, DBMS_STATS |

Tam liste, gerekçe ve çözüm önerileri: **[KURALLAR.md](KURALLAR.md)**

---

## Kural EKLEMEK

`rules/` klasörüne yeni bir `.py` dosyası koyun. Başka hiçbir yeri değiştirmeyin — registry otomatik bulur.

```python
# rules/ORA101_yasak_tablo.py
import re
from core.model import BaseRule, Severity


class YasakTabloRule(BaseRule):
    id = "ORA101"
    name = "Kritik tabloya dogrudan DML"
    category = "KURUM"
    severity = Severity.FAIL
    description = "Mutabakat tablolarina script ile DML yapilamaz."
    rationale = "Bu tablolar gunsonu surecinde otomatik beslenir."
    remediation = "Degisikligi gunsonu ekibi uzerinden talep edin."
    default_params = {"tablolar": ["MUTABAKAT", "GUNSONU_BAKIYE"]}

    def check(self, ctx):
        for st in ctx.dml_statements:
            for t in self.param("tablolar", []):
                if re.search(r"(?<![\w$#])%s(?![\w$#])" % t, st.masked, re.I):
                    yield self.hit(ctx, offset=st.start_offset, statement=st,
                                   object_name=t,
                                   message="Kritik tabloya DML: %s" % t)
```

Çalışan bir şablon `rules/ORA900_ornek_sablon.py` içinde — `ScriptContext` API'sinin tamamı orada dokümante edilmiş.

## Kural SİLMEK

Üç yoldan biri:

1. `rules/ORA0xx_*.py` dosyasını silin
2. `config.yaml` içinde `ORA0xx: {enabled: false}`
3. Tek seferlik: `--skip ORA050,ORA057`

## Kural AYARLAMAK

```yaml
rules:
  ORA023:
    severity: FAIL          # WARN yerine engelleyici yap
    params:
      max_commits: 3        # kuralın kendi parametresi

  ORA050:
    enabled: false          # SELECT * kuralını kapat

settings:
  allowed_schemas: [BANKAPP, CORE, RAPOR]   # ORA041 bu listeyi kullanır
  max_statements: 150
```

---

## Faydalı CLI seçenekleri

| Seçenek | Açıklama |
|---|---|
| `--only ORA001,ORA003` | sadece belirli kuralları çalıştır |
| `--skip ORA040` | belirli kuralları atla |
| `--category YIKICI,GUVENLIK` | sadece bu kategoriler |
| `--min-severity WARN` | INFO bulgularını gizle |
| `--fail-on WARN` | uyarıları da engelleyici say (exit 2) |
| `--max-per-rule 3` | kural başına en fazla 3 bulgu göster |
| `--format json\|console\|both\|quiet` | çıktı biçimi |
| `--json rapor.json` | JSON raporu dosyaya yaz |
| `--encoding cp1254` | Türkçe legacy dosyalar için |
| `--no-color` | ANSI renklerini kapat (log dosyası için) |

---

## Önerilen kurulum akışı

1. `config.yaml` içinde `settings.allowed_schemas` listesini kendi uygulama şemalarınızla doldurun (ORA041 böylece aktifleşir).
2. `ORA043` (isimlendirme) parametrelerini kurum standardınıza göre ayarlayın.
3. Mevcut onaylı script'lerinizden 20-30 tanesini araçtan geçirin; çıkan yanlış pozitifleri kural parametreleriyle kısın.
4. Aracı script kabul sürecine zorunlu adım olarak koyun (exit code ≥ 2 → red).
5. Kuruma özel kuralları `ORA1xx` aralığında ekleyin; `ORA0xx` aralığını çekirdek kurallara bırakın.

## Sınırlar

Bu araç **statik** bir denetleyicidir; veritabanına bağlanmaz. Dolayısıyla:

- Tablonun gerçekten dolu olup olmadığını, satır sayısını veya index varlığını bilemez
- `EXECUTE IMMEDIATE` içindeki dinamik SQL'i çözemez (bu yüzden ORA014 uyarı üretir)
- Nesnelerin gerçekten var olup olmadığını doğrulayamaz

Bu kontroller için ayrı bir "dry-run / dictionary doğrulama" adımı gerekir — bu araç o adımdan **önce** çalışacak kapıdır.
