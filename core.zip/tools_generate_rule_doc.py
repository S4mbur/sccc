#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Kural metadatasindan KURALLAR.md dosyasini uretir."""
import io
import os
import sys
from collections import OrderedDict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from core.config import load_config          # noqa: E402
from core.registry import discover_rules     # noqa: E402

CAT_ORDER = ["YIKICI", "GUVENLIK", "TRANSACTION", "SOZDIZIMI", "SEMA",
             "PERFORMANS", "STANDART", "KURUM"]
CAT_TITLE = {
    "YIKICI": "Yikici / Geri Alinamaz Islemler",
    "GUVENLIK": "Guvenlik ve Yetkilendirme",
    "TRANSACTION": "Transaction Butunlugu",
    "SOZDIZIMI": "Sozdizimi ve Yapi",
    "SEMA": "Sema, Obje ve Isimlendirme",
    "PERFORMANS": "Performans ve Kilitleme",
    "STANDART": "Kurumsal Standart ve Izlenebilirlik",
    "KURUM": "Kuruma Ozel (sablon)",
}


def main():
    cfg_path = os.path.join(HERE, "config.yaml")
    rules = discover_rules(config=load_config(cfg_path if os.path.exists(cfg_path) else None))
    groups = OrderedDict((c, []) for c in CAT_ORDER)
    for r in rules:
        groups.setdefault(r.category, []).append(r)

    out = ["# Kural Referansi", "",
           "Toplam **%d** kural. Bu dosya `tools_generate_rule_doc.py` ile uretilir.",
           "", "| Seviye | Anlami |", "|---|---|",
           "| FAIL | Script calistirilmamali. Duzeltme zorunlu. |",
           "| WARN | Gozden gecirilip onaylanmali. |",
           "| INFO | Bilgilendirme. |", ""]
    out[2] = out[2] % len(rules)

    for cat in groups:
        rs = groups[cat]
        if not rs:
            continue
        out.append("## %s (`%s`)" % (CAT_TITLE.get(cat, cat), cat))
        out.append("")
        out.append("| ID | Kural | Sev | Kontrol |")
        out.append("|---|---|---|---|")
        for r in rs:
            out.append("| `%s` | %s | %s | %s |" % (
                r.id, r.name, r.severity, r.description.replace("|", "/")))
        out.append("")
        for r in rs:
            out.append("### %s - %s" % (r.id, r.name))
            out.append("")
            out.append("- **Seviye:** %s  |  **Varsayilan:** %s" % (
                r.severity, "acik" if r.enabled else "kapali"))
            out.append("- **Kontrol:** %s" % r.description)
            out.append("- **Gerekce:** %s" % r.rationale)
            out.append("- **Cozum:** %s" % str(r.remediation).replace("\n", " "))
            if r.params:
                out.append("- **Parametreler:** `%s`" % r.params)
            out.append("")
    with io.open(os.path.join(HERE, "KURALLAR.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(out))
    print("KURALLAR.md uretildi (%d kural)." % len(rules))


if __name__ == "__main__":
    main()
