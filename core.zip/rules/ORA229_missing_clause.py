# -*- coding: utf-8 -*-
"""ORA229 - Zorunlu yan tumce eksik."""
import re
from core.model import BaseRule, Severity
from core.helpers import find_top_level, kw


class MissingClauseRule(BaseRule):
    id = "ORA229"
    name = "Zorunlu yan tumce eksik"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = "UPDATE'te SET, MERGE'te USING/ON, INSERT'te VALUES/SELECT yok."
    rationale = ("Eksik yan tumce ORA-00971 / ORA-00905 gibi hatalar uretir. "
                 "Script durur, degisiklik kismi uygulanmis olur.")
    remediation = "Eksik yan tumceyi tamamlayin."
    tags = ['syntax', 'dml', 'LEX-020', 'DML-003']

    REQUIRED = {
        "UPDATE": [("SET", "SET")],
        "MERGE": [("USING", "USING"), ("ON", "ON")],
        "INSERT": [(r"VALUES|SELECT|WITH", "VALUES veya SELECT")],
        "DELETE": [("FROM", "FROM")],
    }

    def check(self, ctx):
        for st in ctx.all_statements:
            if st.kind not in ("sql", "plsql_inner"):
                continue
            reqs = self.REQUIRED.get(st.first_word)
            if not reqs:
                continue
            for pat, label in reqs:
                if find_top_level(st.body, kw("(?:%s)" % pat)):
                    continue
                if st.first_word == "DELETE" and re.match(
                        r"\s*DELETE\s+(?!FROM)[\w$#\".]+\s", st.body, re.I):
                    # DELETE tablo ... (FROM opsiyoneldir) -> uyari yeterli
                    yield self.hit(ctx, offset=st.start_offset, statement=st,
                                   severity=Severity.INFO,
                                   message="DELETE ifadesinde FROM yazilmamis "
                                           "(gecerli ama okunabilirlik icin ekleyin).")
                    continue
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               message="%s ifadesinde %s yan tumcesi yok: %s"
                                       % (st.first_word, label, st.norm[:60]))
