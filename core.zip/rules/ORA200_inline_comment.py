# -*- coding: utf-8 -*-
"""KULLANIM DISI DOSYA - silinebilir.

Bu dosyanin icerdigi kontrol, ayni ID ile zaten mevcut olan DBRUNNER
kural setine tasinmistir (ORA200-ORA209). Kural sinifi tanimlamadigi icin
registry tarafindan yok sayilir. Guvenle silebilirsiniz.
"""
