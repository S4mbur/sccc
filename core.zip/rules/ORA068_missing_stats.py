# -*- coding: utf-8 -*-
"""ORA068 - Buyuk yapisal degisiklik sonrasi istatistik toplanmamis."""
import re
from core.model import BaseRule, Severity


class MissingStatsRule(BaseRule):
    id = "ORA068"
    name = "Degisiklik sonrasi istatistik toplanmamis"
    category = "STANDART"
    severity = Severity.WARN
    description = "Index/tablo olusturulmus ancak DBMS_STATS cagrisi yok."
    rationale = ("Guncel olmayan istatistik optimizer'in yanlis plan secmesine ve "
                 "sorgu surelerinin aniden artmasina yol acar.")
    remediation = ("Islem sonuna DBMS_STATS.GATHER_TABLE_STATS('SEMA','TABLO', "
                   "cascade=>TRUE) ekleyin.")
    tags = ["performance", "standard"]

    def check(self, ctx):
        triggers = list(ctx.finditer(
            r"CREATE\s+(UNIQUE\s+|BITMAP\s+)*INDEX\b|CREATE\s+TABLE\b|"
            r"ALTER\s+TABLE\b[^;]*\b(MOVE|ADD)\b"))
        if not triggers:
            return
        if re.search(r"DBMS_STATS\s*\.\s*GATHER", ctx.masked, re.I):
            return
        yield self.hit(ctx, offset=triggers[0].start,
                       message="%d yapisal degisiklik var, DBMS_STATS.GATHER_* "
                               "cagrisi bulunamadi." % len(triggers))
