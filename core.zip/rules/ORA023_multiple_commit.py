# -*- coding: utf-8 -*-
"""ORA023 - Birden fazla COMMIT."""
import re
from core.model import BaseRule, Severity


class MultipleCommitRule(BaseRule):
    id = "ORA023"
    name = "Birden fazla COMMIT"
    category = "TRANSACTION"
    severity = Severity.WARN
    description = "Script icinde birden cok COMMIT var; islem atomik degil."
    rationale = ("Coklu commit, hata aninda scriptin yarisinin kalici olmasina yol "
                 "acar. Geri donus (rollback) plani bu durumda gecersiz kalir.")
    remediation = ("Tek bir mantiksal islem icin tek COMMIT kullanin; zorunluysa her "
                   "commit noktasi icin ayri bir geri alma adimi tanimlayin.")
    tags = ['transaction', 'TX-004']
    default_params = {"max_commits": 1}

    def check(self, ctx):
        hits = list(ctx.finditer(r"(?<![\w$#])COMMIT(?![\w$#])"))
        limit = int(self.param("max_commits", 1))
        if len(hits) <= limit:
            return
        for m in hits[limit:]:
            yield self.hit(ctx, offset=m.start,
                           message="Fazladan COMMIT (toplam %d, limit %d)."
                                   % (len(hits), limit))
