# -*- coding: utf-8 -*-
"""ORA281 - DDL obje tipi taniyici / allowlist (DDL-001..DDL-013, MASTER-001)."""
import re
from core.model import BaseRule, Severity

# Deployment'ta gorulmesi normal, kural setinin tanidigi obje tipleri
KNOWN_TYPES = {
    "TABLE", "INDEX", "VIEW", "MATERIALIZED VIEW", "MATERIALIZED VIEW LOG",
    "SEQUENCE", "SYNONYM", "PUBLIC SYNONYM", "TRIGGER", "PROCEDURE", "FUNCTION",
    "PACKAGE", "PACKAGE BODY", "TYPE", "TYPE BODY", "CONSTRAINT", "COMMENT",
}
# Uygulama deployment'inda YERI OLMAYAN, instance/guvenlik seviyesi tipler
BLOCKED_TYPES = {
    "TABLESPACE": "DDL-013", "DATAFILE": "DDL-013", "TEMPFILE": "DDL-013",
    "PLUGGABLE DATABASE": "DDL-013", "DATABASE": "DDL-013",
    "CONTROLFILE": "DDL-013", "RESTORE POINT": "DDL-013", "DISKGROUP": "DDL-013",
    "USER": "DDL-008", "ROLE": "DDL-008", "PROFILE": "DDL-008",
    "CREDENTIAL": "DDL-008", "CONTEXT": "DDL-008",
    "DIRECTORY": "DDL-006", "LIBRARY": "DDL-006", "JAVA": "DDL-006",
    "JAVA SOURCE": "DDL-006", "JAVA CLASS": "DDL-006",
    "DATABASE LINK": "DDL-007", "PUBLIC DATABASE LINK": "DDL-007",
    "AUDIT POLICY": "DDL-009", "OPERATOR": "DDL-010", "INDEXTYPE": "DDL-010",
    "CLUSTER": "DDL-011", "DIMENSION": "DDL-011", "EDITION": "DDL-012",
    "OUTLINE": "DDL-010", "PFILE": "DDL-013", "SPFILE": "DDL-013",
    "FLASHBACK ARCHIVE": "DDL-013", "ROLLBACK SEGMENT": "DDL-013",
    "LOCKDOWN PROFILE": "DDL-008", "ANALYTIC VIEW": "DDL-011",
    "ATTRIBUTE DIMENSION": "DDL-011", "HIERARCHY": "DDL-011",
    "PROPERTY GRAPH": "DDL-011", "MINING MODEL": "DDL-011",
}

_HEAD = re.compile(
    r"^\s*(CREATE|ALTER|DROP)\s+"
    r"(?:OR\s+REPLACE\s+)?(?:(?:NON)?EDITIONABLE\s+)?"
    r"(?:GLOBAL\s+TEMPORARY\s+|PRIVATE\s+TEMPORARY\s+|UNIQUE\s+|BITMAP\s+|"
    r"MULTIDIMENSIONAL\s+|FORCE\s+|NOFORCE\s+|SHARDED\s+|DUPLICATED\s+|"
    r"IMMUTABLE\s+|BLOCKCHAIN\s+|SHARED\s+|PUBLIC\s+|MATERIALIZED\s+|"
    r"EDITIONING\s+|BIGFILE\s+|SMALLFILE\s+|TEMPORARY\s+|UNDO\s+)*"
    r"([A-Z]+(?:\s+(?:BODY|VIEW|LOG|LINK|POLICY|DATABASE|SOURCE|CLASS|"
    r"SEGMENT|POINT|ARCHIVE|PROFILE|MODEL|DIMENSION|GRAPH))?)", re.I)


class ObjectTypeAllowlistRule(BaseRule):
    id = "ORA281"
    name = "Obje tipi allowlist / taninmayan DDL"
    category = "SEMA"
    severity = Severity.FAIL
    description = ("DDL'in hedef obje tipi ya uygulama deployment'inda yasak ya da "
                   "kural seti tarafindan taninmiyor.")
    rationale = ("Master kontrol listesi DDL-001..DDL-013 ve MASTER-001. Politika "
                 "allowlist'tir: 'bilinmiyor ama gecsin' karari verilmez. Instance, "
                 "depolama, kimlik ve dosya sistemi seviyesindeki obje tipleri "
                 "uygulama scriptinde yer alamaz.")
    remediation = ("Bu obje tipini ayri bir DBA talebine tasiyin. Yeni bir Oracle "
                   "obje tipi kullaniyorsaniz once kural setine tanitilmalidir.")
    tags = ['schema', 'DDL-001', 'DDL-013', 'MASTER-001', 'allowlist', 'DDL-002', 'DDL-003', 'DDL-004', 'DDL-005', 'DDL-006', 'DDL-007', 'DDL-008', 'DDL-009', 'DDL-010', 'DDL-011', 'DDL-012']
    default_params = {"extra_allowed": []}

    def check(self, ctx):
        allowed = set(KNOWN_TYPES) | {a.upper() for a in self.param("extra_allowed", [])}
        for st in ctx.statements:
            if st.kind == "sqlplus" or st.first_word not in ("CREATE", "ALTER", "DROP"):
                continue
            m = _HEAD.match(st.masked)
            if not m:
                continue
            raw_type = re.sub(r"\s+", " ", m.group(2).upper()).strip()
            head = re.sub(r"\s+", " ", st.masked[:80].upper())

            blocked = None
            for name, code in BLOCKED_TYPES.items():
                if re.search(r"(?<![\w$#])%s(?![\w$#])" % name.replace(" ", r"\s+"),
                             head):
                    blocked = (name, code)
                    break
            if blocked:
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               message="[%s] '%s %s' uygulama deployment'inda "
                                       "yasak obje tipi."
                                       % (blocked[1], st.first_word, blocked[0]))
                continue
            if raw_type in ("SESSION", "SYSTEM"):
                continue                      # ORA005 / ORA282 kapsaminda
            if raw_type not in allowed:
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               message="[MASTER-001] Taninmayan DDL obje tipi: "
                                       "'%s %s'. Allowlist disi tipler reddedilir."
                                       % (st.first_word, raw_type))
