# -*- coding: utf-8 -*-
"""ORA018 - Database link kullanimi."""
import re
from core.model import BaseRule, Severity


class DbLinkRule(BaseRule):
    id = "ORA018"
    name = "Database link kullanimi"
    category = "GUVENLIK"
    severity = Severity.WARN
    description = "DB link olusturuluyor veya @link ile uzak veritabanina erisiliyor."
    rationale = ("DB link'ler veri sinirlarini asar; uzak sistemdeki veri sinifi ve "
                 "yetki modeli farkli olabilir. Dagitik transaction riski de vardir.")
    remediation = ("Link kullanimini ve hedef sistemi degisiklik kaydinda belirtin; "
                   "PUBLIC DATABASE LINK kullanmayin.")
    tags = ["security", "network"]

    def check(self, ctx):
        for m in ctx.finditer(r"\bCREATE\s+(PUBLIC\s+)?(SHARED\s+)?DATABASE\s+LINK\b"):
            sev = Severity.FAIL if "PUBLIC" in m.text.upper() else self.severity
            yield self.hit(ctx, offset=m.start, severity=sev,
                           message="DB link olusturuluyor: %s" % " ".join(m.text.split()))
        for m in ctx.finditer(r"[\w$#\"]+\s*@\s*[\w$#\.]+"):
            st = ctx.statement_at(m.start)
            if st is not None and st.kind == "sqlplus":
                continue
            yield self.hit(ctx, offset=m.start,
                           message="Uzak obje referansi: %s" % m.text.replace(" ", ""))
