# -*- coding: utf-8 -*-
"""ORA273 - Parse/transaction davranisini degistiren SET komutlari (CLI-025..027)."""
import re
from core.model import BaseRule, Severity

BLOCKED_SET = {
    "SQLTERMINATOR": ("Ifade sonlandiricisini degistirir; parser ile calistirma "
                      "motoru farkli bolebilir", "CLI-025", "FAIL"),
    "BLOCKTERMINATOR": ("PL/SQL blok sonlandiricisini degistirir", "CLI-025", "FAIL"),
    "CMDSEP": ("Komut ayiricisini degistirir", "CLI-025", "FAIL"),
    "SQLPREFIX": ("Komut on ekini degistirir", "CLI-025", "FAIL"),
    "SQLBLANKLINES": ("Bos satir davranisini degistirir", "CLI-025", "FAIL"),
    "AUTOCOMMIT": ("Transaction politikasi runner'a aittir", "CLI-026", "FAIL"),
    "ERRORLOGGING": ("Basari kriterini degistirir", "CLI-027", "FAIL"),
    "DEFINE": ("Substitution karakterini degistirir", "CLI-020", "WARN"),
    "SCAN": ("Substitution taramasini degistirir", "CLI-020", "WARN"),
    "ESCAPE": ("Kacis karakterini degistirir", "CLI-020", "WARN"),
    "CONCAT": ("Birlestirme karakterini degistirir", "CLI-020", "WARN"),
    "ROLE": ("Session yetkisini genisletir", "CLI-008", "FAIL"),
}


class SetStateRule(BaseRule):
    id = "ORA273"
    name = "Parse veya transaction durumunu degistiren SET komutu"
    category = "ISTEMCI"
    severity = Severity.FAIL
    description = "SET SQLTERMINATOR/AUTOCOMMIT/ROLE gibi davranis degistiren komut."
    rationale = ("Master kontrol listesi CLI-008/020/025/026/027. Bu ayarlar "
                 "scriptin statik analizde gorundugunden farkli bolunmesine veya "
                 "farkli transaction semantigiyle calismasina yol acar.")
    remediation = "Bu SET komutlarini scriptten cikarin; ayarlar runner tarafindan sabitlenir."
    tags = ['client', 'CLI', 'parser', 'CLI-008', 'CLI-020', 'CLI-025', 'CLI-026', 'CLI-027']

    def check(self, ctx):
        for m in ctx.finditer(r"(?<![\w$#])SET\s+([A-Z]+)\s*([^\n;]*)"):
            name = m.group(1).upper()
            info = BLOCKED_SET.get(name)
            if not info:
                continue
            why, code, sev = info
            if name == "DEFINE" and re.match(r"(?i)\s*(OFF|ON)\s*$", m.group(2) or ""):
                continue          # SET DEFINE OFF/ON kabul edilir
            yield self.hit(ctx, offset=m.start, severity=sev,
                           message="[%s] SET %s %s - %s."
                                   % (code, name, " ".join((m.group(2) or "").split())[:20],
                                      why))
        # SET ROLE ALL (SQL komutu olarak da gelebilir)
        for m in ctx.finditer(r"(?<![\w$#])SET\s+ROLE\b"):
            yield self.hit(ctx, offset=m.start,
                           message="[CLI-008] SET ROLE ile session yetkisi genisletiliyor.")
