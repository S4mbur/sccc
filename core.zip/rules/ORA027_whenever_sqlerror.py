# -*- coding: utf-8 -*-
"""ORA027 - WHENEVER SQLERROR tanimlanmamis."""
import re
from core.model import BaseRule, Severity


class WheneverSqlerrorRule(BaseRule):
    id = "ORA027"
    name = "WHENEVER SQLERROR tanimlanmamis"
    category = "TRANSACTION"
    severity = Severity.FAIL
    description = "Script hata aninda durmuyor; sonraki ifadeler calismaya devam eder."
    rationale = ("SQL*Plus varsayilan olarak hatayi yok sayip devam eder. Ilk adim "
                 "basarisiz olsa bile sonraki DML/DDL calisir ve kismi degisiklik kalir.")
    remediation = ("Scriptin en basina su iki satiri ekleyin:\n"
                   "  WHENEVER SQLERROR EXIT FAILURE ROLLBACK;\n"
                   "  WHENEVER OSERROR EXIT FAILURE ROLLBACK;")
    tags = ['transaction', 'sqlplus', 'errorhandling', 'CLI-017']

    def check(self, ctx):
        if not ctx.statements:
            return
        sql = ctx.search(r"WHENEVER\s+SQLERROR\s+EXIT")
        if sql is None:
            yield self.hit(ctx, line=1,
                           message="WHENEVER SQLERROR EXIT ... tanimi bulunamadi.")
            return
        if not re.search(r"WHENEVER\s+SQLERROR\s+EXIT[^\n]*ROLLBACK", ctx.masked, re.I):
            yield self.hit(ctx, offset=sql.start, severity=Severity.WARN,
                           message="WHENEVER SQLERROR var ama ROLLBACK belirtilmemis.")
        if not ctx.search(r"WHENEVER\s+OSERROR\s+EXIT"):
            yield self.hit(ctx, offset=sql.start, severity=Severity.WARN,
                           message="WHENEVER OSERROR EXIT ... tanimlanmamis.")
