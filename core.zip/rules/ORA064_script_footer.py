# -*- coding: utf-8 -*-
"""ORA064 - Script sonu (EXIT) tanimlanmamis."""
import re
from core.model import BaseRule, Severity


class ScriptFooterRule(BaseRule):
    id = "ORA064"
    name = "Script EXIT ile bitmiyor"
    category = "STANDART"
    severity = Severity.WARN
    description = "Scriptin sonunda EXIT yok; oturum acik kalir."
    rationale = ("Otomasyondan calistirilan scriptte EXIT yoksa oturum kapanmaz, "
                 "is beklemeye girer ve kilit tutmaya devam eder.")
    remediation = "Scriptin sonuna EXIT SUCCESS; (veya EXIT;) ekleyin."
    tags = ['standard', 'sqlplus', 'automation', 'CLI-018']

    def check(self, ctx):
        if not ctx.statements:
            return
        if not re.search(r"^\s*EXIT\b", ctx.masked, re.I | re.M):
            yield self.hit(ctx, line=len(ctx.lines),
                           message="Script sonunda EXIT tanimlanmamis.")
