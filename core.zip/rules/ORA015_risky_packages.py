# -*- coding: utf-8 -*-
"""ORA015 - Riskli hazir paket kullanimi."""
import re
from core.model import BaseRule, Severity


class RiskyPackageRule(BaseRule):
    id = "ORA015"
    name = "Riskli hazir paket kullanimi"
    category = "GUVENLIK"
    severity = Severity.WARN
    description = "Isletim sistemi, ag veya zamanlayici erisimi saglayan paketler."
    rationale = ("Bu paketler veritabanindan disari veri cikarma (exfiltration), "
                 "dosya sistemine erisim veya zamanlanmis gizli is olusturma imkani verir.")
    remediation = ("Kullanim gerekcesini degisiklik kaydina yazin ve guvenlik ekibi "
                   "onayi alin. Alternatif olarak uygulama katmanini kullanin.")
    tags = ["security", "package"]
    default_params = {
        "fail_packages": ["UTL_FILE", "UTL_HTTP", "UTL_TCP", "UTL_SMTP", "UTL_INADDR",
                          "DBMS_LOB.FILEOPEN", "DBMS_BACKUP_RESTORE", "DBMS_JAVA"],
        "warn_packages": ["DBMS_SCHEDULER", "DBMS_JOB", "DBMS_LOCK", "DBMS_PIPE",
                          "DBMS_AQ", "DBMS_ALERT", "DBMS_CRYPTO", "DBMS_RANDOM",
                          "DBMS_SYSTEM", "DBMS_UTILITY.EXEC_DDL_STATEMENT"],
    }

    def check(self, ctx):
        groups = [(self.param("fail_packages", []), Severity.FAIL),
                  (self.param("warn_packages", []), Severity.WARN)]
        for names, sev in groups:
            for name in names:
                pat = r"(?<![\w$#])" + re.escape(name).replace(r"\.", r"\s*\.\s*") + r"(?![\w$#])"
                for m in ctx.finditer(pat):
                    yield self.hit(ctx, offset=m.start, severity=sev,
                                   object_name=name,
                                   message="Riskli paket cagrisi: %s" % m.text)
