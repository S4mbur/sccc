# -*- coding: utf-8 -*-
"""ORA015 - Riskli hazir paket kullanimi."""
import re
from core.model import BaseRule, Severity


class RiskyPackageRule(BaseRule):
    id = "ORA015"
    name = "Riskli hazir paket kullanimi"
    category = "GUVENLIK"
    severity = Severity.WARN
    description = "Isletim sistemi, ag veya zamanlayici erisimi saglayan paketler."
    rationale = ("Bu paketler veritabanindan disari veri cikarma (exfiltration), "
                 "dosya sistemine erisim veya zamanlanmis gizli is olusturma imkani verir.")
    remediation = ("Kullanim gerekcesini degisiklik kaydina yazin ve guvenlik ekibi "
                   "onayi alin. Alternatif olarak uygulama katmanini kullanin.")
    tags = ['security', 'package', 'SEC-019', 'SEC-020', 'SEC-021', 'SEC-022', 'SEC-023', 'SEC-024', 'SEC-027', 'SEC-028', 'SEC-029', 'SEC-030', 'SEC-031', 'PLS-026', 'PLS-027']
    default_params = {
        # SEC-019/020/021/026..030 - ag, dosya, is/zamanlayici ve instance yuzeyi
        "fail_packages": ["UTL_FILE", "UTL_HTTP", "UTL_TCP", "UTL_SMTP", "UTL_INADDR",
                          "UTL_MAIL", "UTL_URL", "UTL_DBWS", "UTL_NLA",
                          "DBMS_LDAP", "DBMS_CLOUD", "APEX_WEB_SERVICE",
                          "HTTPURITYPE", "DBMS_NETWORK_ACL_ADMIN",
                          "DBMS_LOB.FILEOPEN", "DBMS_FILE_TRANSFER",
                          "DBMS_BACKUP_RESTORE", "DBMS_JAVA", "DBMS_JAVA_TEST",
                          "DBMS_SCHEDULER.CREATE_JOB", "DBMS_CREDENTIAL",
                          "DBMS_RLS", "DBMS_FGA", "DBMS_REDACT", "DBMS_AUDIT_MGMT",
                          "DBMS_MACADM", "DBMS_SQL_FIREWALL",
                          "DBMS_SYSTEM", "DBMS_SERVICE", "DBMS_RESOURCE_MANAGER",
                          "DBMS_SHARED_POOL", "DBMS_WORKLOAD_REPOSITORY",
                          "DBMS_FLASHBACK", "DBMS_REPAIR", "DBMS_LOGMNR",
                          "DBMS_SPM", "DBMS_SQLDIAG", "DBMS_SQLTUNE",
                          "DBMS_XSLPROCESSOR", "DBMS_DATAPUMP"],
        "warn_packages": ["DBMS_SCHEDULER", "DBMS_JOB", "DBMS_LOCK", "DBMS_PIPE",
                          "DBMS_AQ", "DBMS_ALERT", "DBMS_CRYPTO", "DBMS_RANDOM",
                          "DBMS_SYSTEM", "DBMS_UTILITY.EXEC_DDL_STATEMENT"],
    }

    def check(self, ctx):
        groups = [(self.param("fail_packages", []), Severity.FAIL),
                  (self.param("warn_packages", []), Severity.WARN)]
        for names, sev in groups:
            for name in names:
                pat = r"(?<![\w$#])" + re.escape(name).replace(r"\.", r"\s*\.\s*") + r"(?![\w$#])"
                for m in ctx.finditer(pat):
                    yield self.hit(ctx, offset=m.start, severity=sev,
                                   object_name=name,
                                   message="Riskli paket cagrisi: %s" % m.text)
