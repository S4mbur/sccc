# -*- coding: utf-8 -*-
"""ORA222 - PROCEDURE / FUNCTION tanimda IS veya AS eksik."""
import re
from core.model import BaseRule, Severity


class MissingIsAsRule(BaseRule):
    id = "ORA222"
    name = "PROCEDURE / FUNCTION tanimda IS veya AS eksik"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = "CREATE PROCEDURE/FUNCTION basligi ile BEGIN arasinda IS/AS yok."
    rationale = ("Oracle PLS-00103 verir ve obje derlenmez. Uygulama bu objeyi "
                 "cagirdiginda ORA-06550 alir; degisiklik yarim kalir.")
    remediation = "Baslik sonuna IS (veya AS) ekleyin."
    tags = ['syntax', 'plsql', 'LEX-017']

    RX = re.compile(r"\s*CREATE\s+(OR\s+REPLACE\s+)?((NON)?EDITIONABLE\s+)?"
                    r"(PROCEDURE|FUNCTION)\b", re.I)

    def check(self, ctx):
        for st in ctx.statements:
            if st.kind != "plsql" or not self.RX.match(st.masked):
                continue
            bm = re.search(r"(?<![\w$#])BEGIN(?![\w$#])", st.masked, re.I)
            head = st.masked[:bm.start()] if bm else st.masked
            if re.search(r"(?<![\w$#])(IS|AS)(?![\w$#])", head, re.I):
                continue
            yield self.hit(ctx, offset=st.start_offset, statement=st,
                           message="'%s...' tanimda IS/AS yok (PLS-00103)."
                                   % st.norm[:50])
