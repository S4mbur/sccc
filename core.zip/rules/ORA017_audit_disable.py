# -*- coding: utf-8 -*-
"""ORA017 - Denetim (audit) veya trigger devre disi birakma."""
import re
from core.model import BaseRule, Severity


class AuditDisableRule(BaseRule):
    id = "ORA017"
    name = "Denetim izi veya trigger devre disi birakiliyor"
    category = "GUVENLIK"
    severity = Severity.FAIL
    description = "NOAUDIT, audit policy kapatma veya trigger DISABLE ifadesi var."
    rationale = ("Denetim izinin kapatilmasi log butunlugunu bozar; BDDK/ic denetim "
                 "gereksinimlerini ihlal eder ve degisiklik izlenemez hale gelir.")
    remediation = ("Denetim kapatilmasi gerekiyorsa gerekcesini ve geri acma adimini "
                   "degisiklik kaydina yazin, denetim ekibini bilgilendirin.")
    tags = ['security', 'audit', 'compliance', 'SEC-025', 'SEC-026', 'DDL-009']

    PATTERNS = [
        (r"\bNOAUDIT\b", "NOAUDIT"),
        (r"\bAUDIT\s+POLICY\b[^;]*\bDISABLE\b", "AUDIT POLICY DISABLE"),
        (r"\bALTER\s+TRIGGER\b[^;]*\bDISABLE\b", "ALTER TRIGGER DISABLE"),
        (r"\bDISABLE\s+ALL\s+TRIGGERS\b", "DISABLE ALL TRIGGERS"),
        (r"\bALTER\s+TABLE\b[^;]*\bDISABLE\s+CONSTRAINT\b", "DISABLE CONSTRAINT"),
        (r"\bALTER\s+SESSION\s+SET\s+SQL_TRACE\s*=\s*FALSE", "SQL_TRACE kapatma"),
    ]

    def check(self, ctx):
        for pat, label in self.PATTERNS:
            for m in ctx.finditer(pat, re.I | re.S):
                yield self.hit(ctx, offset=m.start,
                               message="%s tespit edildi." % label)
