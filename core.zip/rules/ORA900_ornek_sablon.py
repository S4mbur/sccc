# -*- coding: utf-8 -*-
"""ORA900 - YENI KURAL SABLONU.

Bu dosya calisir bir ornektir ve varsayilan olarak KAPALIDIR (enabled = False).

YENI KURAL EKLEMEK ICIN:
  1. Bu dosyayi kopyalayin: rules/ORA101_kendi_kuralim.py
  2. `id`, `name`, `category`, `severity` alanlarini doldurun.
  3. check() icinde bulgu urettikce `yield self.hit(...)` cagirin.
  4. enabled = True yapin (veya config.yaml'da acin).
  Baska hicbir dosyayi degistirmeniz gerekmez - kural otomatik bulunur.

KURALI KALDIRMAK ICIN:
  - Dosyayi silin,  VEYA
  - config.yaml -> rules -> ORA900: {enabled: false}

CTX (ScriptContext) UZERINDE KULLANABILECEKLERINIZ:
  ctx.raw                 ham metin
  ctx.masked              yorum/string icerigi bosluga cevrilmis metin (regex icin)
  ctx.lines               ham satirlar (liste)
  ctx.statements          Statement listesi (.first_word .kind .masked .body .norm
                          .start_line .terminated .is_dml() .is_ddl())
  ctx.dml_statements / ctx.ddl_statements
  ctx.finditer(pattern)   maskeli metinde arama -> .start .text .line .group()
  ctx.findall_raw(pat)    ham metinde arama (yorum ve string icerigi dahil)
  ctx.search(pattern)     ilk eslesme veya None
  ctx.stmts("UPDATE")     ilk kelimesi eslesen ifadeler
  ctx.statement_at(off)   offsetin dustugu ifade
  ctx.header_comment      dosya basindaki yorum blogu
  ctx.setting("anahtar")  config.yaml -> settings degeri
  self.param("anahtar")   bu kuralin parametresi (default_params + config override)
"""
import re

from core.model import BaseRule, Severity


class OrnekSablonRule(BaseRule):
    id = "ORA900"                       # benzersiz olmali
    name = "Ornek sablon kural"
    category = "KURUM"                  # rapor gruplamasi icin
    severity = Severity.INFO            # INFO | WARN | FAIL
    enabled = False                     # sablon oldugu icin kapali
    description = "Yasakli kelime listesindeki ifadeleri arar."
    rationale = "Kurumunuza ozel yasakli kaliplari burada tanimlayabilirsiniz."
    remediation = "Ilgili ifadeyi kaldirin veya istisna onayi alin."
    tags = ["ornek"]
    default_params = {"yasakli_kelimeler": ["SILINECEK_KELIME"]}

    def check(self, ctx):
        for kelime in self.param("yasakli_kelimeler", []):
            pat = r"(?<![\w$#])%s(?![\w$#])" % re.escape(kelime)
            for m in ctx.finditer(pat):
                yield self.hit(
                    ctx,
                    offset=m.start,
                    message="Yasakli ifade bulundu: %s" % m.text,
                )
