# -*- coding: utf-8 -*-
"""ORA005 - Instance/veritabani seviyesi mudahale."""
import re
from core.model import BaseRule, Severity
from core.helpers import kw


class AlterSystemRule(BaseRule):
    id = "ORA005"
    name = "Instance seviyesinde mudahale"
    category = "YIKICI"
    severity = Severity.FAIL
    description = "ALTER SYSTEM / ALTER DATABASE / SHUTDOWN / STARTUP kullanilmis."
    rationale = ("Bu komutlar tum instance'i etkiler; oturum kesilmesi, servis "
                 "kesintisi ve SLA ihlali riski tasir. Uygulama scriptinde yeri yoktur.")
    remediation = ("Bu tur degisiklikleri uygulama scriptinden ayirip DBA operasyon "
                   "penceresinde, degisiklik kaydi ile uygulayin.")
    tags = ['destructive', 'instance', 'DDL-013', 'SEC-009']

    PATTERNS = [
        (r"ALTER\s+SYSTEM\b", "ALTER SYSTEM"),
        (r"ALTER\s+DATABASE\b", "ALTER DATABASE"),
        (kw("SHUTDOWN"), "SHUTDOWN"),
        (r"^\s*STARTUP\b", "STARTUP"),
        (r"ALTER\s+PLUGGABLE\s+DATABASE\b", "ALTER PLUGGABLE DATABASE"),
    ]

    def check(self, ctx):
        for pat, label in self.PATTERNS:
            for m in ctx.finditer(pat, re.I | re.M):
                yield self.hit(ctx, offset=m.start,
                               message="%s ifadesi kullanilmis." % label)
