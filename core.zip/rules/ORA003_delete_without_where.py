# -*- coding: utf-8 -*-
"""ORA003 - WHERE'siz DELETE."""
import re
from core.model import BaseRule, Severity
from core.helpers import find_top_level, object_after, kw


class DeleteWithoutWhereRule(BaseRule):
    id = "ORA003"
    name = "WHERE kosulu olmayan DELETE"
    category = "YIKICI"
    severity = Severity.FAIL
    description = "DELETE ifadesinde ust seviye WHERE kosulu yok."
    rationale = ("Tablonun tamamini siler. Buyuk tablolarda hem veri kaybi hem de "
                 "UNDO tablespace dolmasi ve uzun sureli kilitlenme riski dogurur.")
    remediation = "DELETE ifadesine daraltici bir WHERE kosulu ekleyin."
    tags = ['destructive', 'dml', 'DML-001']

    def check(self, ctx):
        for st in ctx.all_statements:
            if st.first_word != "DELETE":
                continue
            body = st.body
            if find_top_level(body, kw("WHERE")):
                continue
            name = object_after(body, r"DELETE\s+(?:FROM\s+)?")
            yield self.hit(ctx, offset=st.start_offset, statement=st, object_name=name,
                           message="WHERE'siz DELETE: %s (tum satirlar silinir)" % name)
