# -*- coding: utf-8 -*-
"""ORA013 - Sistem semalarina mudahale."""
import re
from core.model import BaseRule, Severity


class SystemSchemaRule(BaseRule):
    id = "ORA013"
    name = "Sistem semasi / sozluk objesine mudahale"
    category = "GUVENLIK"
    severity = Severity.FAIL
    description = "SYS, SYSTEM, SYSAUX, AUDSYS gibi sistem semalarina yazma islemi var."
    rationale = ("Data dictionary uzerinde dogrudan degisiklik destek disi kalmaya "
                 "ve veritabaninin tutarsiz hale gelmesine yol acar.")
    remediation = "Islemi uygulama semasinda yapin; sistem semalarina dokunmayin."
    tags = ["security", "dictionary"]
    default_params = {
        "schemas": ["SYS", "SYSTEM", "SYSAUX", "AUDSYS", "OUTLN", "DBSNMP",
                    "XDB", "WMSYS", "CTXSYS", "ORDSYS", "MDSYS"],
        # sadece okuma yapilan ifadeler icin severity dusurulur
        "read_severity": "INFO",
    }

    WRITE_WORDS = ("INSERT", "UPDATE", "DELETE", "MERGE", "DROP", "ALTER",
                   "TRUNCATE", "CREATE", "GRANT", "REVOKE")

    def check(self, ctx):
        schemas = [s.upper() for s in self.param("schemas", [])]
        if not schemas:
            return
        pat = r"(?<![\w$#])(%s)\s*\.\s*[\w$#\"]+" % "|".join(schemas)
        for m in ctx.finditer(pat):
            st = ctx.statement_at(m.start)
            is_write = st is not None and st.first_word in self.WRITE_WORDS
            sev = self.severity if is_write else self.param("read_severity", Severity.INFO)
            yield self.hit(ctx, offset=m.start, severity=sev, statement=st,
                           object_name=m.text,
                           message="Sistem semasi referansi: %s (%s)" % (
                               m.text, "yazma" if is_write else "okuma"))
