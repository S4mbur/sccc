# -*- coding: utf-8 -*-
"""ORA226 - Cikti alinan SELECT scriptinde kolon listesi yok."""
import re
from core.model import BaseRule, Severity


class SelectStarExportRule(BaseRule):
    id = "ORA226"
    name = "Cikti scriptinde SELECT * kullanilmis"
    category = "GUVENLIK"
    severity = Severity.FAIL
    description = ("Dosya bir rapor/cikti scripti (yalnizca SELECT iceriyor) ve "
                   "kolon listesi yerine * kullanilmis.")
    rationale = ("Excel/CSV olarak disari cikacak veride hangi kolonlarin yer "
                 "aldigi belirsiz kalir. Tabloya sonradan eklenen kisisel veri "
                 "kolonlari da otomatik olarak ciktiya girer - KVKK ihlali riski.")
    remediation = ("Ciktida yer almasi gereken kolonlari acikca yazin ve kisisel "
                   "veri iceren kolonlari maskeleyin.")
    tags = ['security', 'kvkk', 'dlp', 'dokuman-m9', 'SEC-035', 'SEC-036']

    def check(self, ctx):
        stmts = [s for s in ctx.statements if s.kind != "sqlplus"]
        if not stmts:
            return
        if any(s.first_word not in ("SELECT", "WITH") for s in stmts):
            return                       # rapor scripti degil -> ORA050 (WARN) yeterli
        for st in stmts:
            for m in re.finditer(r"\bSELECT\s+(?:/\*\+.*?\*/\s*)?\*", st.masked, re.I):
                if re.search(r"COUNT\s*\(\s*\*\s*\)",
                             st.masked[m.start():m.start() + 60], re.I):
                    continue
                yield self.hit(ctx, offset=st.start_offset + m.start(), statement=st,
                               message="Rapor ciktisinda SELECT * - disari cikan "
                                       "kolonlar belirsiz.")
