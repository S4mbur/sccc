# -*- coding: utf-8 -*-
"""ORA270 - SQL*Plus / SQLcl istemci komutu allowlist (CLI-001..CLI-012).

Politika: deny-by-default. Deployment icin gerekli olmayan her istemci komutu
engellenir. Blacklist degil allowlist kullanilir; bilinmeyen komut da reddedilir
(MASTER-001).
"""
import re
from core.model import BaseRule, Severity

# Deployment icin gerekli ve zararsiz komutlar
ALLOWED = {
    "SET", "WHENEVER", "SPOOL", "PROMPT", "EXIT", "QUIT", "REM", "REMARK",
    "DEFINE", "UNDEFINE", "SHOW", "TIMING", "CLEAR", "COLUMN", "COL",
}

# Acikca tehlikeli komutlar ve gerekceleri
BLOCKED = {
    "CONNECT": ("Kimlik/hedef degistirir ve bekleyen transaction'i COMMIT eder", "CLI-001"),
    "CONN": ("Kimlik/hedef degistirir ve bekleyen transaction'i COMMIT eder", "CLI-001"),
    "DISCONNECT": ("Oturum yonetimi runner'a aittir", "CLI-001"),
    "HOST": ("Isletim sistemi komutu calistirir", "CLI-002"),
    "START": ("Harici script dahil eder (local/UNC/HTTP/FTP)", "CLI-003"),
    "GET": ("Dosya sisteminden buffer'a icerik okur", "CLI-004"),
    "SAVE": ("Dosya sistemine yazar", "CLI-004"),
    "STORE": ("Dosya sistemine yazar", "CLI-004"),
    "EDIT": ("Harici editor/dosya erisimi", "CLI-004"),
    "RUN": ("SQL buffer'ini yeniden calistirir (mukerrer islem)", "CLI-005"),
    "ACCEPT": ("Interaktif girdi bekler; otomasyonu sonsuza kadar bloke eder", "CLI-007"),
    "PAUSE": ("Interaktif bekleme; otomasyonu bloke eder", "CLI-007"),
    "PASSWORD": ("Parola degistirir", "CLI-009"),
    "ARCHIVE": ("Instance/recovery islemi", "CLI-010"),
    "RECOVER": ("Instance/recovery islemi", "CLI-010"),
    "STARTUP": ("Instance islemi", "CLI-010"),
    "SHUTDOWN": ("Instance islemi", "CLI-010"),
    "COPY": ("Uzak veritabanina veri kopyalar", "CLI-011"),
    "PRINT": ("Cikti/bind degiskeni yazdirir", "CLI-012"),
    "ATTRIBUTE": ("Cikti bicimlendirme; deployment icin gerekli degil", "CLI-012"),
    "REPFOOTER": ("Rapor bicimlendirme", "CLI-012"),
    "REPHEADER": ("Rapor bicimlendirme", "CLI-012"),
    # SQLcl
    "SCRIPT": ("SQLcl JavaScript calistirir", "CLI-032"),
    "LOAD": ("SQLcl dosya yukler", "CLI-032"),
    "LB": ("SQLcl Liquibase", "CLI-032"),
    "LIQUIBASE": ("SQLcl Liquibase", "CLI-032"),
    "CD": ("SQLcl dizin degistirir", "CLI-032"),
    "OCI": ("SQLcl bulut komutu", "CLI-032"),
    "APEX": ("SQLcl APEX komutu", "CLI-032"),
    "REST": ("SQLcl REST komutu", "CLI-032"),
}


class ClientCommandRule(BaseRule):
    id = "ORA270"
    name = "Izinsiz SQL*Plus / SQLcl istemci komutu"
    category = "ISTEMCI"
    severity = Severity.FAIL
    description = "Deployment icin izin verilmeyen istemci komutu kullanilmis."
    rationale = ("Master kontrol listesi CLI-001..CLI-012. Bu komutlar kimlik "
                 "degistirme, isletim sistemi erisimi, harici script dahil etme, "
                 "interaktif bekleme ve mukerrer calistirma yollari acar. Politika "
                 "allowlist'tir: listede olmayan komut da reddedilir (MASTER-001).")
    remediation = ("Komutu scriptten cikarin. Baglanti, spool dizini ve exit "
                   "protokolu runner tarafindan yonetilir.")
    tags = ['client', 'CLI', 'security', 'CLI-001', 'CLI-002', 'CLI-003', 'CLI-004', 'CLI-005', 'CLI-007', 'CLI-009', 'CLI-010', 'CLI-011', 'CLI-012', 'CLI-032', 'CLI-034']
    default_params = {"extra_allowed": []}

    def check(self, ctx):
        allowed = set(ALLOWED) | {a.upper() for a in self.param("extra_allowed", [])}
        for st in ctx.statements:
            if st.kind != "sqlplus":
                continue
            head = st.norm.lstrip()
            # @ ve @@ ile script dahil etme (CLI-003)
            if head.startswith("@"):
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               message="[CLI-003] Harici script dahil etme: '%s' "
                                       "(local/UNC/HTTP/FTP kaynak calistirilabilir)."
                                       % head[:60])
                continue
            word = st.first_word
            if word in BLOCKED:
                why, code = BLOCKED[word]
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               message="[%s] %s komutu yasak: %s." % (code, word, why))
            elif word and word not in allowed:
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               message="[MASTER-001] Taninmayan istemci komutu: '%s'. "
                                       "Allowlist disindaki komutlar reddedilir." % word)

        # '!' shell kisayolu (CLI-002)
        for i, line in enumerate(ctx.lines, start=1):
            if re.match(r"^\s*!", line):
                yield self.hit(ctx, line=i,
                               message="[CLI-002] '!' ile shell komutu calistiriliyor.")
