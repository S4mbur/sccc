# -*- coding: utf-8 -*-
"""ORA232 - Ifade ortasinda blok yorum."""
import re
from core.model import BaseRule, Severity


class BlockCommentMidStatementRule(BaseRule):
    id = "ORA232"
    name = "Ifade ortasinda blok yorum (/* ... */)"
    category = "DBRUNNER"
    severity = Severity.FAIL
    description = "Blok yorum bir sorgunun icine, ifadelerin arasina yerlestirilmis."
    rationale = ("Deployment dokumani madde 10 yorumlarin sorgu icine "
                 "yerlestirilmesini yasaklar. Ifadeleri satir satir isleyen "
                 "calistirma motoru sorguyu yanlis parcalayabilir.")
    remediation = "Yorumu sorgunun ustune veya altina, ayri bir satira alin."
    tags = ['dbrunner', 'dokuman-m10', 'comment', 'LEX-008']
    default_params = {"allow_in_plsql_block": True}

    def check(self, ctx):
        for r in ctx.regions:
            if r.kind != "block_comment":
                continue
            if ctx.raw[r.start:r.start + 3] == "/*+":      # optimizer hint
                continue
            st = ctx.statement_at(r.start)
            if st is None:
                continue                                   # ifadeler arasinda -> serbest
            if self.param("allow_in_plsql_block", True) and st.kind == "plsql":
                continue
            before = ctx.masked[st.start_offset:r.start]
            after = ctx.masked[r.end:st.end_offset]
            if before.strip() and after.strip():
                yield self.hit(ctx, offset=r.start, statement=st,
                               message="Sorgu ortasinda blok yorum: %s"
                                       % " ".join(ctx.raw[r.start:r.end].split())[:50])
