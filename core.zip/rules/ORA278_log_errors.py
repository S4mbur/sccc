# -*- coding: utf-8 -*-
"""ORA278 - LOG ERRORS ile satir hatalarinin sessizce kabulu (CUR-027, DML-014)."""
import re
from core.model import BaseRule, Severity


class LogErrorsRule(BaseRule):
    id = "ORA278"
    name = "LOG ERRORS ile hata yutma"
    category = "BUTUNLUK"
    severity = Severity.FAIL
    description = "DML'de LOG ERRORS / REJECT LIMIT kullanilmis."
    rationale = ("Master kontrol listesi DML-014/015 ve CUR-027. LOG ERRORS, "
                 "basarisiz satirlari hata tablosuna yazip islemi 'basarili' "
                 "bitirir. REJECT LIMIT UNLIMITED ile tum satirlar reddedilse "
                 "bile deployment basarili gorunur.")
    remediation = ("LOG ERRORS kullanmayin. Zorunluysa REJECT LIMIT 0 verin ve "
                   "hata tablosunda satir olusursa deployment'i basarisiz sayin.")
    tags = ['integrity', 'DML-014', 'errorhandling', 'DML-015']

    def check(self, ctx):
        for m in ctx.finditer(r"(?<![\w$#])LOG\s+ERRORS(?![\w$#])[^;]{0,200}"):
            txt = " ".join(m.text.split())
            unlimited = re.search(r"REJECT\s+LIMIT\s+UNLIMITED", txt, re.I)
            yield self.hit(ctx, offset=m.start,
                           message="[DML-014] %s%s"
                                   % (txt[:70],
                                      " -> TUM satirlar reddedilse bile basarili "
                                      "gorunur." if unlimited else ""))
