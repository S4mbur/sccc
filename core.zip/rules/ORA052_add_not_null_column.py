# -*- coding: utf-8 -*-
"""ORA052 - NOT NULL kolon eklerken DEFAULT yok."""
import re
from core.model import BaseRule, Severity


class AddNotNullRule(BaseRule):
    id = "ORA052"
    name = "DEFAULT'suz NOT NULL kolon ekleniyor"
    category = "PERFORMANS"
    severity = Severity.FAIL
    description = "ALTER TABLE ADD ... NOT NULL ifadesinde DEFAULT deger yok."
    rationale = ("Dolu bir tabloya DEFAULT'suz NOT NULL kolon eklenemez (ORA-01758). "
                 "DEFAULT ile bile 11g oncesi surumlerde tum satirlar guncellenir ve "
                 "uzun sureli kilit olusur.")
    remediation = ("Kolonu once NULL olarak ekleyin, veriyi batch halinde doldurun, "
                   "ardindan NOT NULL constraint'i ENABLE NOVALIDATE ile ekleyin.")
    tags = ['performance', 'locking', 'ddl', 'DDL-021']

    def check(self, ctx):
        for st in ctx.statements:
            if not re.match(r"\s*ALTER\s+TABLE\b", st.masked, re.I):
                continue
            for m in re.finditer(r"\bADD\b(.{0,200}?)(?=;|$)", st.body, re.I | re.S):
                frag = m.group(1)
                if not re.search(r"(?<![\w$#])NOT\s+NULL(?![\w$#])", frag, re.I):
                    continue
                if re.search(r"(?<![\w$#])DEFAULT(?![\w$#])", frag, re.I):
                    yield self.hit(ctx, offset=st.start_offset + m.start(),
                                   statement=st, severity=Severity.WARN,
                                   message="NOT NULL + DEFAULT kolon ekleniyor; "
                                           "12c oncesi surumlerde tablo yeniden yazilir.")
                else:
                    yield self.hit(ctx, offset=st.start_offset + m.start(), statement=st,
                                   message="DEFAULT'suz NOT NULL kolon ekleniyor "
                                           "(dolu tabloda ORA-01758).")
