# -*- coding: utf-8 -*-
"""ORA207 - END; sonrasi '/' konumu (kurum kurali 11)."""
from core.model import BaseRule, Severity
from core.helpers import scan_plsql_units


class SlashPositionRule(BaseRule):
    id = "ORA207"
    name = "END; sonrasina '/' eklenmemis veya yanlis konumda"
    category = "DBRUNNER"
    severity = Severity.FAIL
    description = ("BEGIN ... END; komutunun bir sonraki satirina, kendi basina "
                   "'/' isareti eklenmelidir.")
    rationale = ("'/' yoksa veya yanlis konumdaysa sorgu calisiyor gorunur; fakat "
                 "veritabaninda o session inactive kalir ve islem basariyla "
                 "tamamlanmaz. Sonraki bloklar da calistirilmaz.")
    remediation = ("END;\n"
                   "/            <- END; satirinin hemen altinda, tek basina.")
    default_params = {"gap_severity": "FAIL"}
    tags = ['dbrunner', 'plsql', 'sozdizimi', 'LEX-011']

    def check(self, ctx):
        for u in scan_plsql_units(ctx.masked_lines):
            if u.end is None:
                yield self.hit(ctx, line=u.start,
                               message="%s blogu (satir %d) END; ile kapatilmamis."
                                       % (u.obj_type, u.start))
                continue
            if u.slash_same_line:
                yield self.hit(ctx, line=u.end,
                               message="'/' isareti END; ile ayni satirda; bir alt "
                                       "satira tek basina alinmalidir.")
            elif u.slash is None:
                nxt = ctx.line_text(u.end + 1)
                yield self.hit(ctx, line=u.end,
                               message="END; (satir %d) sonrasinda '/' yok%s"
                                       % (u.end, ("; sonraki icerik: '%s'" % nxt[:50])
                                          if nxt else " (dosya sonu)."))
            elif u.slash_gap:
                yield self.hit(ctx, line=u.slash,
                               severity=self.param("gap_severity", Severity.FAIL),
                               message="'/' isareti END; satirindan %d bos satir sonra "
                                       "geliyor; hemen altinda olmalidir." % u.slash_gap)
