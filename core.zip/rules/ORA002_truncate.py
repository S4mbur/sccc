# -*- coding: utf-8 -*-
"""ORA002 - TRUNCATE ifadesi."""
import re
from core.model import BaseRule, Severity
from core.helpers import object_after


class TruncateRule(BaseRule):
    id = "ORA002"
    name = "TRUNCATE ifadesi tespit edildi"
    category = "YIKICI"
    severity = Severity.FAIL
    description = "TRUNCATE TABLE/CLUSTER kullanilmis."
    rationale = ("TRUNCATE DDL'dir: rollback edilemez, implicit commit uretir ve "
                 "tabloyu aninda bosaltir. Flashback disinda geri donus yoktur.")
    remediation = ("Silinecek kayit sayisi kontrollu ise WHERE'li DELETE + COMMIT "
                   "kullanin. TRUNCATE sart ise onceden CTAS ile yedek alin.")
    tags = ['destructive', 'ddl', 'DDL-018']

    def check(self, ctx):
        for st in ctx.statements:
            if st.first_word != "TRUNCATE":
                continue
            name = object_after(st.masked, r"TRUNCATE\s+(?:TABLE|CLUSTER)")
            yield self.hit(ctx, offset=st.start_offset, statement=st, object_name=name,
                           message="TRUNCATE ifadesi: %s" % (name or "(ad cozulemedi)"))
