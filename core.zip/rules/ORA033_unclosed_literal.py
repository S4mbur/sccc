# -*- coding: utf-8 -*-
"""ORA033 - Kapanmamis string literal veya blok yorum."""
import re
from core.model import BaseRule, Severity


class UnclosedLiteralRule(BaseRule):
    id = "ORA033"
    name = "Kapanmamis string veya yorum"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = "Tek tirnak veya /* */ yorum blogu kapatilmamis."
    rationale = ("Kapanmayan tirnak scriptin geri kalanini string olarak yutar; "
                 "beklenmeyen ifadeler calisir veya script asili kalir.")
    remediation = "Eksik tirnagi/yorum kapanisini tamamlayin."
    tags = ['syntax', 'LEX-005', 'LEX-006']

    def check(self, ctx):
        for r in ctx.regions:
            frag = ctx.raw[r.start:r.end]
            if r.kind == "string" and not (len(frag) >= 2 and frag.endswith("'")):
                yield self.hit(ctx, offset=r.start,
                               message="Kapanmamis string literal.")
            if r.kind == "block_comment" and not frag.endswith("*/"):
                yield self.hit(ctx, offset=r.start,
                               message="Kapanmamis /* ... */ yorum blogu.")
            if r.kind == "qstring" and not frag.endswith("'"):
                yield self.hit(ctx, offset=r.start,
                               message="Kapanmamis q'[...]' literali.")
