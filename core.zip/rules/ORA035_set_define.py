# -*- coding: utf-8 -*-
"""ORA035 - SET DEFINE OFF eksik."""
import re
from core.model import BaseRule, Severity


class SetDefineRule(BaseRule):
    id = "ORA035"
    name = "'&' iceren veri var ancak SET DEFINE OFF yok"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = "String icindeki '&' SQL*Plus tarafindan degisken olarak yorumlanir."
    rationale = ("SET DEFINE OFF verilmezse 'A&B' gibi bir deger sessizce bozulur "
                 "veya script kullanicidan girdi bekleyerek asili kalir.")
    remediation = "Scriptin basina SET DEFINE OFF; ekleyin."
    tags = ['syntax', 'sqlplus', 'dataintegrity', 'CLI-020']

    def check(self, ctx):
        amp_positions = []
        for r in ctx.regions:
            if r.kind not in ("string", "qstring"):
                continue
            frag = ctx.raw[r.start:r.end]
            for m in re.finditer(r"&", frag):
                amp_positions.append(r.start + m.start())
        if not amp_positions:
            return
        if re.search(r"\bSET\s+DEFINE\s+(OFF|\S)\b", ctx.masked, re.I):
            return
        for pos in amp_positions[:20]:
            yield self.hit(ctx, offset=pos,
                           message="String icinde '&' var, SET DEFINE OFF tanimlanmamis.")
