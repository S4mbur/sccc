# -*- coding: utf-8 -*-
"""ORA036 - PL/SQL blogu sonrasi '/' eksik."""
import re
from core.model import BaseRule, Severity


class MissingSlashRule(BaseRule):
    id = "ORA036"
    name = "PL/SQL blogu '/' ile kapatilmamis"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = "PL/SQL blogu kendi satirinda '/' ile sonlandirilmamis."
    rationale = ("SQL*Plus PL/SQL blogunu ancak tek basina '/' satirini gorunce "
                 "calistirir. Eksikse blok hic calismaz.")
    remediation = "Blogun END; satirindan sonra ayri bir satira / koyun."
    tags = ["syntax", "plsql", "sqlplus"]

    def check(self, ctx):
        for st in ctx.statements:
            if st.kind != "plsql":
                continue
            tail = st.masked.rstrip()
            if not re.search(r"\n[ \t]*/[ \t]*$", tail):
                yield self.hit(ctx, line=st.end_line, statement=st,
                               message="PL/SQL blogu (satir %d-%d) '/' ile kapatilmamis."
                                       % (st.start_line, st.end_line))
