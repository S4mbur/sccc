# -*- coding: utf-8 -*-
"""ORA202 - DML ve DDL ayri dosyalarda olmali (kurum kurali 6)."""
from core.model import BaseRule, Severity


class DmlDdlSeparateFilesRule(BaseRule):
    id = "ORA202"
    name = "DML ve DDL ayni dosyada"
    category = "DBRUNNER"
    severity = Severity.FAIL
    description = "Bir dosya hem DML hem DDL iceremez; ayri dosyalar halinde gonderilmelidir."
    rationale = ("Deployment araci dosyayi DML mi DDL mi diye siniflandirip farkli "
                 "kural setleri uygular. Karisik dosya yanlis siniflandirilir, ayrica "
                 "DDL'in urettigi implicit commit DML'in geri alinmasini engeller.")
    remediation = ("Dosyayi ikiye bolun: 01-ddl_degisiklikleri.sql ve "
                   "02-dml_degisiklikleri.sql")
    tags = ["dbrunner", "dosya", "transaction"]
    default_params = {
        # Bu ifadeler DDL sayilmaz (yalnizca yetki/aciklama islemleri)
        "ignore_ddl_words": ["GRANT", "REVOKE", "COMMENT"],
    }

    def check(self, ctx):
        ignore = {w.upper() for w in self.param("ignore_ddl_words", [])}
        dml = ctx.top_dml_statements
        ddl = [s for s in ctx.top_ddl_statements if s.first_word not in ignore]
        if not dml or not ddl:
            return
        yield self.hit(
            ctx, offset=ddl[0].start_offset, statement=ddl[0],
            message="Dosyada %d DML (ilk satir %d) ve %d DDL (ilk satir %d) birlikte var."
                    % (len(dml), dml[0].start_line, len(ddl), ddl[0].start_line))
