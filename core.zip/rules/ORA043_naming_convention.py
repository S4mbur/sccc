# -*- coding: utf-8 -*-
"""ORA043 - Obje isimlendirme standardi."""
import re
from core.model import BaseRule, Severity


class NamingConventionRule(BaseRule):
    id = "ORA043"
    name = "Obje isimlendirme standardina uymuyor"
    category = "SEMA"
    severity = Severity.WARN
    description = "Yeni olusturulan obje adi kurum standardina uymuyor."
    rationale = ("Standart disi isimler envanter, izleme ve otomatik bakim "
                 "islerini bozar; obje sahipligi belirsizlesir.")
    remediation = "Obje adini kurum isimlendirme standardina gore duzeltin."
    tags = ["naming", "standard"]
    default_params = {
        "max_length": 30,
        "require_upper": True,
        "prefixes": {           # obje tipi -> zorunlu on ek listesi ([] = kontrol yok)
            "INDEX": ["IX_", "IDX_", "PK_", "UK_"],
            "TRIGGER": ["TRG_"],
            "SEQUENCE": ["SEQ_"],
            "VIEW": ["V_", "VW_"],
            "PACKAGE": ["PKG_"],
        },
    }

    PATTERN = (r"CREATE\s+(?:OR\s+REPLACE\s+)?(?:GLOBAL\s+TEMPORARY\s+|UNIQUE\s+|"
               r"BITMAP\s+|MATERIALIZED\s+|PUBLIC\s+)*"
               r"(TABLE|INDEX|VIEW|SEQUENCE|TRIGGER|PACKAGE|PROCEDURE|FUNCTION|SYNONYM)"
               r"\s+(?:(\"?[\w$#]+\"?)\s*\.\s*)?(\"?[\w$#]+\"?)")

    def check(self, ctx):
        prefixes = self.param("prefixes", {}) or {}
        maxlen = int(self.param("max_length", 30))
        for m in ctx.finditer(self.PATTERN):
            otype = m.group(1).upper()
            name = (m.group(3) or "").strip('"')
            if not name:
                continue
            if len(name) > maxlen:
                yield self.hit(ctx, offset=m.start, object_name=name,
                               message="Obje adi %d karakter (limit %d): %s"
                                       % (len(name), maxlen, name))
            if self.param("require_upper", True) and name != name.upper():
                yield self.hit(ctx, offset=m.start, object_name=name,
                               message="Obje adi buyuk harf olmali: %s" % name)
            if not re.match(r"^[A-Za-z][\w$#]*$", name):
                yield self.hit(ctx, offset=m.start, object_name=name,
                               message="Obje adi harfle baslamali / gecersiz karakter: %s"
                                       % name)
            want = prefixes.get(otype) or []
            if want and not any(name.upper().startswith(p.upper()) for p in want):
                yield self.hit(ctx, offset=m.start, object_name=name,
                               message="%s adi %s on eklerinden biri ile baslamali: %s"
                                       % (otype, "/".join(want), name))
