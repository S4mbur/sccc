# -*- coding: utf-8 -*-
"""ORA044 - Gecici / test amacli obje adlari."""
import re
from core.model import BaseRule, Severity


class SuspiciousNameRule(BaseRule):
    id = "ORA044"
    name = "Gecici veya test amacli obje adi"
    category = "SEMA"
    severity = Severity.WARN
    description = "TEMP, TEST, YEDEK, BACKUP, _OLD gibi gecici adlar uretime gidiyor."
    rationale = ("Gecici objeler uretimde unutulur, disk doldurur ve envanterde "
                 "sahipsiz kalir. Ayrica veri kopyalari KVKK acisindan risklidir.")
    remediation = ("Gecici obje gerekiyorsa temizleme adimini ayni degisiklik "
                   "kaydinda planlayin ve son kullanma tarihi belirtin.")
    tags = ["naming", "housekeeping"]
    default_params = {
        "patterns": ["TEMP", "TMP", "TEST", "DENEME", "YEDEK", "BACKUP", "BKP",
                     "_OLD", "_ESKI", "_NEW", "_YENI", "COPY", "KOPYA", "_BAK",
                     "_1", "_2", "XXX", "ASDF", "DELETEME", "SILINECEK"],
    }

    PATTERN = (r"CREATE\s+(?:OR\s+REPLACE\s+)?(?:GLOBAL\s+TEMPORARY\s+|UNIQUE\s+|"
               r"BITMAP\s+|MATERIALIZED\s+|PUBLIC\s+)*"
               r"(TABLE|INDEX|VIEW|SEQUENCE|SYNONYM)\s+"
               r"(?:\"?[\w$#]+\"?\s*\.\s*)?(\"?[\w$#]+\"?)")

    def check(self, ctx):
        pats = [p.upper() for p in self.param("patterns", [])]
        for m in ctx.finditer(self.PATTERN):
            name = (m.group(2) or "").strip('"').upper()
            for p in pats:
                if p in name:
                    yield self.hit(ctx, offset=m.start, object_name=name,
                                   message="Supheli obje adi '%s' ('%s' iceriyor)."
                                           % (name, p))
                    break
