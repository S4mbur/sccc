# -*- coding: utf-8 -*-
"""ORA030 - Sonlandirilmamis ifade."""
import re
from core.model import BaseRule, Severity


class UnterminatedStatementRule(BaseRule):
    id = "ORA030"
    name = "Sonlandirilmamis ifade"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = "Ifade ';' veya '/' ile bitirilmemis."
    rationale = ("Sonlandirilmayan ifade SQL*Plus tarafindan calistirilmaz; script "
                 "sessizce eksik calisir veya buffer'da bekleyip hata verir.")
    remediation = "Ifadeyi ';' ile, PL/SQL blogunu ise ayri satirda '/' ile kapatin."
    tags = ["syntax"]

    def check(self, ctx):
        for st in ctx.statements:
            if st.terminated or st.kind == "sqlplus":
                continue
            yield self.hit(ctx, offset=st.start_offset, statement=st,
                           message="'%s ...' ifadesi sonlandirilmamis."
                                   % st.norm[:60])
