# -*- coding: utf-8 -*-
"""ORA065 - Format maskesiz tarih donusumu."""
import re
from core.model import BaseRule, Severity


class DateLiteralRule(BaseRule):
    id = "ORA065"
    name = "Format maskesi olmayan tarih donusumu"
    category = "STANDART"
    severity = Severity.FAIL
    description = "TO_DATE / TO_CHAR tek parametre ile cagrilmis ya da tarih stringi var."
    rationale = ("Format maskesi verilmezse sonuc NLS_DATE_FORMAT'a baglidir. Ayni "
                 "script farkli oturumda farkli tarih uretir - finansal hesaplamada kritik.")
    remediation = ("TO_DATE('01.01.2026','DD.MM.YYYY') gibi acik format maskesi kullanin "
                   "veya DATE '2026-01-01' ANSI literalini tercih edin.")
    tags = ["standard", "correctness", "nls"]

    def check(self, ctx):
        for m in ctx.findall_raw(r"(?<![\w$#])TO_DATE\s*\(\s*'[^']*'\s*\)"):
            yield self.hit(ctx, offset=m.start,
                           message="Format maskesiz TO_DATE: %s" % m.text)
        for m in ctx.findall_raw(r"(?<![\w$#])TO_CHAR\s*\(\s*[\w$#.]+\s*\)"):
            yield self.hit(ctx, offset=m.start, severity=Severity.WARN,
                           message="Format maskesiz TO_CHAR: %s" % m.text)
        for m in ctx.findall_raw(r"(?<![\w$#])TO_NUMBER\s*\(\s*'[^']*'\s*\)"):
            yield self.hit(ctx, offset=m.start, severity=Severity.WARN,
                           message="Format maskesiz TO_NUMBER: %s" % m.text)
        for m in ctx.finditer(r"ALTER\s+SESSION\s+SET\s+NLS_"):
            yield self.hit(ctx, offset=m.start, severity=Severity.INFO,
                           message="NLS ayari degistiriliyor - oturum bagimliligi olusur.")
