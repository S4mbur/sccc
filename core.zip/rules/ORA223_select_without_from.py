# -*- coding: utf-8 -*-
"""ORA223 - FROM icermeyen SELECT."""
import re
from core.model import BaseRule, Severity
from core.helpers import find_top_level, kw


class SelectWithoutFromRule(BaseRule):
    id = "ORA223"
    name = "FROM icermeyen SELECT"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = "SELECT ifadesinde FROM yan tumcesi yok."
    rationale = ("Oracle'da FROM zorunludur (sabit ifadeler icin FROM DUAL). "
                 "Eksikse ORA-00923 alinir ve script durur.")
    remediation = "Kaynak tabloyu ekleyin; sabit deger okunuyorsa FROM DUAL yazin."
    tags = ['syntax', 'sql', 'LEX-020']

    def check(self, ctx):
        for st in ctx.statements:
            if st.kind != "sql" or st.first_word != "SELECT":
                continue
            if find_top_level(st.body, kw("FROM")):
                continue
            yield self.hit(ctx, offset=st.start_offset, statement=st,
                           message="SELECT ifadesinde FROM yok (ORA-00923): %s"
                                   % st.norm[:60])
