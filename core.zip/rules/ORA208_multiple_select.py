# -*- coding: utf-8 -*-
"""ORA208 - Ciktisi istenen SELECT sorgulari ayri dosyalarda olmali (kurum kurali 9)."""
import re
from core.model import BaseRule, Severity


class MultipleSelectRule(BaseRule):
    id = "ORA208"
    name = "Bir dosyada birden fazla SELECT"
    category = "DBRUNNER"
    severity = Severity.WARN
    description = ("Excel / CSV / HTML ciktisi istenen SELECT sorgularinin her biri "
                   "ayri dosyada gonderilmelidir.")
    rationale = ("Tek dosyada birden fazla SELECT varsa cikti istenen formatta degil, "
                 "log dosyasi formatinda uretilir.")
    remediation = "Her SELECT sorgusunu ayri bir .sql dosyasina alin."
    tags = ['dbrunner', 'dosya', 'cikti', 'ZIP-017']

    def check(self, ctx):
        selects = [s for s in ctx.statements
                   if s.kind != "sqlplus" and s.first_word in ("SELECT", "WITH")]
        others = [s for s in ctx.statements
                  if s.kind != "sqlplus" and s.first_word not in ("SELECT", "WITH")]
        if not selects:
            return
        if others:
            # Cikti alinacak SELECT, DML/DDL ile ayni dosyada olmamalidir.
            yield self.hit(ctx, offset=selects[0].start_offset, statement=selects[0],
                           message="Cikti sorgusu (SELECT) ile %d adet diger ifade "
                                   "(%s) ayni dosyada." % (
                                       len(others),
                                       ", ".join(sorted({o.first_word for o in others}))))
            return
        if len(selects) < 2:
            return
        for st in selects[1:]:
            yield self.hit(ctx, offset=st.start_offset, statement=st,
                           message="Dosyada %d adet SELECT var; her biri ayri dosyada "
                                   "gonderilmelidir." % len(selects))
