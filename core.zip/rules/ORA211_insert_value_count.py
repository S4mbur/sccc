# -*- coding: utf-8 -*-
"""ORA211 - INSERT kolon/deger sayisi uyumsuz."""
import re
from core.model import BaseRule, Severity


def _split_top(text):
    parts, cur, depth, q = [], "", 0, ""
    for ch in text:
        if q:
            cur += ch
            if ch == q:
                q = ""
            continue
        if ch in "\"'":
            q = ch
            cur += ch
        elif ch == "(":
            depth += 1
            cur += ch
        elif ch == ")":
            depth -= 1
            cur += ch
        elif ch == "," and depth == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        parts.append(cur)
    return [p for p in parts if p.strip()]


def _balanced(text, start):
    """start konumundaki '(' ile eslesen ')' arasini dondurur."""
    depth, q = 0, ""
    for i in range(start, len(text)):
        ch = text[i]
        if q:
            if ch == q:
                q = ""
            continue
        if ch in "\"'":
            q = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                return text[start + 1:i], i
    return None, -1


class InsertValueCountRule(BaseRule):
    id = "ORA211"
    name = "INSERT kolon ve deger sayisi uyumsuz"
    category = "BUTUNLUK"
    severity = Severity.FAIL
    description = "INSERT ifadesindeki kolon sayisi ile VALUES listesindeki deger sayisi farkli."
    rationale = ("Calistirma sirasinda ORA-00947 / ORA-00913 hatasi alinir ve script "
                 "yarida kalir. Onceki adimlar commit edilmisse veri tutarsiz kalir.")
    remediation = "Kolon listesi ile deger listesini birebir eslestirin."
    tags = ['integrity', 'dml', 'syntax', 'DML-017']

    def check(self, ctx):
        for st in ctx.all_statements:
            if st.first_word != "INSERT":
                continue
            body = st.body
            m = re.search(r"INSERT\s+(?:/\*.*?\*/\s*)?INTO\s+"
                          r"((?:\"?[\w$#]+\"?\s*\.\s*)?\"?[\w$#]+\"?)\s*\(",
                          body, re.I | re.S)
            if not m:
                continue
            cols_txt, close = _balanced(body, m.end() - 1)
            if cols_txt is None:
                continue
            tail = body[close + 1:]
            vm = re.search(r"^\s*VALUES\s*\(", tail, re.I)
            if not vm:
                continue                     # INSERT ... SELECT -> statik sayilamaz
            vals_txt, _ = _balanced(tail, vm.end() - 1)
            if vals_txt is None:
                continue
            nc, nv = len(_split_top(cols_txt)), len(_split_top(vals_txt))
            if nc != nv:
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               object_name=m.group(1).strip(),
                               message="%s -> %d kolon, %d deger (ORA-00947 alinir)."
                                       % (m.group(1).strip(), nc, nv))
