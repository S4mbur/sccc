# -*- coding: utf-8 -*-
"""ORA063 - Script boyutu / ifade sayisi limiti."""
from core.model import BaseRule, Severity


class StatementCountRule(BaseRule):
    id = "ORA063"
    name = "Script cok fazla ifade iceriyor"
    category = "STANDART"
    severity = Severity.WARN
    description = "Tek scriptte cok sayida ifade var."
    rationale = ("Buyuk scriptler gozden gecirilmesi zor, hata aninda hangi adimda "
                 "kalindigini tespit etmek gucdur. Kismi basarisizlik riski artar.")
    remediation = "Scripti mantiksal adimlara bolun (01_yapi.sql, 02_veri.sql ...)."
    tags = ["standard", "reviewability"]
    default_params = {"max_statements": 200}

    def check(self, ctx):
        limit = int(ctx.setting("max_statements", self.param("max_statements", 200)))
        n = len([s for s in ctx.statements if s.kind != "sqlplus"])
        if n > limit:
            yield self.hit(ctx, line=1,
                           message="%d ifade var, limit %d." % (n, limit))
