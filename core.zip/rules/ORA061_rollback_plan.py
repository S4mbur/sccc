# -*- coding: utf-8 -*-
"""ORA061 - Geri alma (rollback) plani referansi."""
import re
from core.model import BaseRule, Severity


class RollbackPlanRule(BaseRule):
    id = "ORA061"
    name = "Geri alma plani referansi yok"
    category = "STANDART"
    severity = Severity.FAIL
    description = "Kalici degisiklik yapan scriptte geri alma adimi belirtilmemis."
    rationale = ("Uretim degisikliginin geri alinabilir olmasi zorunludur. Rollback "
                 "scripti olmadan hata durumunda kesinti suresi ongorulemez.")
    remediation = ("Baslik blogunda 'GERI ALMA: <dosya adi>' satiri ekleyin ve ilgili "
                   "rollback scriptini pakete dahil edin.")
    tags = ["standard", "operations", "governance"]
    default_params = {
        "keywords": ["GERI ALMA", "GERI DONUS", "ROLLBACK PLAN", "ROLLBACK SCRIPT",
                     "GERIALMA", "UNDO SCRIPT", "REVERT"],
    }

    def check(self, ctx):
        changes = ctx.ddl_statements + ctx.dml_statements
        if not changes:
            return
        text = ctx.all_comments.upper()
        if any(k.upper() in text for k in self.param("keywords", [])):
            return
        yield self.hit(ctx, line=1,
                       message="%d adet kalici degisiklik var, geri alma plani "
                               "referansi bulunamadi." % len(changes))
