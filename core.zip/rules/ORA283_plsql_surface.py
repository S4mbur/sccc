# -*- coding: utf-8 -*-
"""ORA283 - PL/SQL yuzeyi: trigger, AUTHID, wrapped kod, kosullu derleme.

PLS-013/015/016/017/019/023/024/025.
"""
import re
from core.model import BaseRule, Severity


class PlsqlSurfaceRule(BaseRule):
    id = "ORA283"
    name = "Riskli PL/SQL yuzeyi"
    category = "DINAMIK"
    severity = Severity.FAIL
    description = ("Sistem trigger'i, AUTHID CURRENT_USER, wrapped kod, kosullu "
                   "derleme veya Java/external procedure.")
    rationale = ("Master kontrol listesi PLS-013..PLS-025. Wrapped kod statik "
                 "analiz edilemez; database/logon/DDL trigger'lari her oturumu "
                 "etkiler; kosullu derleme ($IF) analiz edilen kod ile calisan "
                 "kodun farkli olmasina yol acar.")
    remediation = ("Wrapped kod yerine kaynak kodu gonderin; sistem trigger'lari "
                   "ve external procedure'lari ayri guvenlik onayina tabi tutun.")
    tags = ['plsql', 'PLS-016', 'PLS-024', 'security', 'PLS-013', 'PLS-015', 'PLS-017', 'PLS-019', 'PLS-023', 'PLS-025', 'LEX-017']

    PATTERNS = [
        (r"CREATE\s+(OR\s+REPLACE\s+)?TRIGGER\b[^;]{0,300}?"
         r"(AFTER|BEFORE)\s+(LOGON|LOGOFF|STARTUP|SHUTDOWN|SERVERERROR|"
         r"CREATE|ALTER|DROP|GRANT|REVOKE|DDL)\b",
         "Sistem/DDL trigger'i (tum oturumlari etkiler)", "PLS-016", "FAIL"),
        (r"\bON\s+(DATABASE|SCHEMA)\b", "DATABASE/SCHEMA seviyesinde trigger",
         "PLS-016", "FAIL"),
        (r"(?<![\w$#])WRAPPED(?![\w$#])", "Wrapped PL/SQL - kaynak analiz edilemez",
         "PLS-024", "FAIL"),
        (r"AUTHID\s+CURRENT_USER", "AUTHID CURRENT_USER (invoker rights)",
         "PLS-017", "WARN"),
        (r"AUTHID\s+DEFINER", "AUTHID DEFINER (privilege escalation yuzeyi)",
         "PLS-017", "WARN"),
        (r"\$IF\b|\$\$[\w$#]+", "Kosullu derleme ($IF/$$flag)", "PLS-023", "FAIL"),
        (r"(?<![\w$#])LANGUAGE\s+JAVA(?![\w$#])", "Java call spec", "PLS-025", "FAIL"),
        (r"(?<![\w$#])AS\s+LANGUAGE\s+C(?![\w$#])", "External C procedure",
         "PLS-025", "FAIL"),
        (r"CREATE\s+(OR\s+REPLACE\s+)?(AND\s+\w+\s+)?JAVA\s+(SOURCE|CLASS|RESOURCE)",
         "Java stored source", "PLS-025", "FAIL"),
        (r"ACCESSIBLE\s+BY", "ACCESSIBLE BY (bagimlilik kisiti degisiyor)",
         "PLS-019", "WARN"),
        (r"COMPOUND\s+TRIGGER", "Compound trigger", "LEX-017", "WARN"),
    ]

    def check(self, ctx):
        for pat, label, code, sev in self.PATTERNS:
            for m in ctx.finditer(pat, re.I | re.S):
                yield self.hit(ctx, offset=m.start, severity=sev,
                               message="[%s] %s" % (code, label))
