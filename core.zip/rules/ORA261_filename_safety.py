# -*- coding: utf-8 -*-
"""ORA261 - Dosya adi guvenligi (INP-012/013/023/024, ZIP-009)."""
from core.model import BaseRule, Severity
from core.reader import check_filename


class FilenameSafetyRule(BaseRule):
    id = "ORA261"
    name = "Dosya adi guvenligi"
    category = "GIRDI"
    severity = Severity.FAIL
    description = ("Dosya adinda yasak karakter, cift uzanti, rezerve ad veya "
                   "dizin bileseni var.")
    rationale = ("Master kontrol listesi INP-012/013/023/024 ve ZIP-009. "
                 "'rapor.sql.exe' gibi cift uzantilar, bosluk/shell metakarakter "
                 "iceren adlar ve '../' bilesenleri arsiv acma ve komut satiri "
                 "katmaninda kod calistirma veya yanlis dosya yazma riskidir.")
    remediation = ("Dosya adinda yalnizca harf, rakam, '-' ve '_' kullanin; "
                   "tek bir .sql veya .txt uzantisi olsun.")
    tags = ['input', 'INP', 'ZIP', 'dosya', 'INP-012', 'INP-013', 'INP-023', 'INP-024', 'INP-025', 'ZIP-009']

    def check(self, ctx):
        name = ctx.meta.get("member_name") or ctx.filename
        for code, sev, msg in check_filename(name):
            yield self.hit(ctx, line=1, severity=sev,
                           message="[%s] %s" % (code, msg))
