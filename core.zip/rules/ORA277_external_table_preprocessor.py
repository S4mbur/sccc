# -*- coding: utf-8 -*-
"""ORA277 - External table / PREPROCESSOR ile OS erisimi (CUR-024, DDL-029)."""
import re
from core.model import BaseRule, Severity


class ExternalTablePreprocessorRule(BaseRule):
    id = "ORA277"
    name = "External table PREPROCESSOR / OS erisimi"
    category = "GUVENLIK"
    severity = Severity.FAIL
    description = "ORGANIZATION EXTERNAL ve PREPROCESSOR ile isletim sistemi programi cagriliyor."
    rationale = ("Master kontrol listesi DDL-029 / CUR-024. PREPROCESSOR, veritabani "
                 "sunucusunda keyfi bir executable calistirir; bu, DB uzerinden "
                 "isletim sistemi ele gecirme yoludur.")
    remediation = ("PREPROCESSOR kullanmayin. Veri yukleme icin SQL*Loader veya "
                   "kontrollu bir ETL sureci kullanin.")
    tags = ['security', 'DDL-029', 'os', 'SEC-020']

    def check(self, ctx):
        for m in ctx.finditer(r"(?<![\w$#])PREPROCESSOR(?![\w$#])"):
            yield self.hit(ctx, offset=m.start,
                           message="[DDL-029] PREPROCESSOR - DB sunucusunda OS "
                                   "programi calistiriliyor.")
        for m in ctx.finditer(r"ORGANIZATION\s+EXTERNAL"):
            yield self.hit(ctx, offset=m.start, severity=Severity.FAIL,
                           message="[DDL-029] External table olusturuluyor; "
                                   "dosya sistemi/directory erisimi denetlenmeli.")
        for m in ctx.finditer(r"(?<![\w$#])(BFILENAME|DBMS_FILE_TRANSFER|"
                              r"DBMS_XSLPROCESSOR|DBMS_LOB\s*\.\s*LOADFROMFILE)"):
            yield self.hit(ctx, offset=m.start,
                           message="[SEC-020] Dosya sistemi erisimi: %s" % m.text)
