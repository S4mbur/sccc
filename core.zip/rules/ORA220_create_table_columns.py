# -*- coding: utf-8 -*-
"""ORA220 - CREATE TABLE kolon listesi hatalari."""
import re
from core.model import BaseRule, Severity
from core.helpers import object_after

RESERVED = {
    "ACCESS", "ADD", "ALL", "ALTER", "AND", "ANY", "AS", "ASC", "AUDIT", "BETWEEN",
    "BY", "CHAR", "CHECK", "CLUSTER", "COLUMN", "COMMENT", "COMPRESS", "CONNECT",
    "CREATE", "CURRENT", "DATE", "DECIMAL", "DEFAULT", "DELETE", "DESC", "DISTINCT",
    "DROP", "ELSE", "EXCLUSIVE", "EXISTS", "FILE", "FLOAT", "FOR", "FROM", "GRANT",
    "GROUP", "HAVING", "IDENTIFIED", "IMMEDIATE", "IN", "INCREMENT", "INDEX",
    "INITIAL", "INSERT", "INTEGER", "INTERSECT", "INTO", "IS", "LEVEL", "LIKE",
    "LOCK", "LONG", "MAXEXTENTS", "MINUS", "MLSLABEL", "MODE", "MODIFY", "NOAUDIT",
    "NOCOMPRESS", "NOT", "NOWAIT", "NULL", "NUMBER", "OF", "OFFLINE", "ON",
    "ONLINE", "OPTION", "OR", "ORDER", "PCTFREE", "PRIOR", "PUBLIC", "RAW",
    "RENAME", "RESOURCE", "REVOKE", "ROW", "ROWID", "ROWNUM", "ROWS", "SELECT",
    "SESSION", "SET", "SHARE", "SIZE", "SMALLINT", "START", "SUCCESSFUL",
    "SYNONYM", "SYSDATE", "TABLE", "THEN", "TO", "TRIGGER", "UID", "UNION",
    "UNIQUE", "UPDATE", "USER", "VALIDATE", "VALUES", "VARCHAR", "VARCHAR2",
    "VIEW", "WHENEVER", "WHERE", "WITH",
}
NON_COLUMN = {"CONSTRAINT", "PRIMARY", "UNIQUE", "FOREIGN", "CHECK", "SUPPLEMENTAL",
              "PARTITION", "SUBPARTITION", "PERIOD", "LIKE"}


def _balanced(text, start):
    depth, q = 0, ""
    for i in range(start, len(text)):
        ch = text[i]
        if q:
            if ch == q:
                q = ""
            continue
        if ch in "\"'":
            q = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                return text[start + 1:i], i
    return None, -1


def _split_top(text):
    parts, cur, depth, q = [], "", 0, ""
    for ch in text:
        if q:
            cur += ch
            if ch == q:
                q = ""
            continue
        if ch in "\"'":
            q = ch
            cur += ch
        elif ch == "(":
            depth += 1
            cur += ch
        elif ch == ")":
            depth -= 1
            cur += ch
        elif ch == "," and depth == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    parts.append(cur)
    return parts


class CreateTableColumnsRule(BaseRule):
    id = "ORA220"
    name = "CREATE TABLE kolon listesi hatali"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = ("Kolon listesinde fazladan virgul, tekrar eden kolon adi veya "
                   "rezerve kelime kullanimi var.")
    rationale = ("Bu hatalar calistirma aninda ORA-00904 / ORA-00957 / ORA-00936 "
                 "uretir. Script yarida kalir; onceki adimlar commit edildiyse "
                 "veritabani yarim yapida kalir.")
    remediation = ("Fazladan virgulu silin, tekrar eden kolonu yeniden adlandirin, "
                   "rezerve kelimeleri kolon adi olarak kullanmayin.")
    tags = ['syntax', 'ddl', 'LEX-019', 'DML-017']
    default_params = {"check_reserved": True, "check_duplicate": True,
                      "check_trailing_comma": True}

    def check(self, ctx):
        for st in ctx.statements:
            m = re.match(r"\s*CREATE\s+(GLOBAL\s+TEMPORARY\s+)?TABLE\b", st.masked, re.I)
            if not m:
                continue
            table = object_after(st.masked, r"TABLE")
            po = st.masked.find("(", m.end())
            if po == -1:
                continue
            body, _ = _balanced(st.masked, po)
            if body is None:
                continue

            if self.param("check_trailing_comma", True) and re.search(r",\s*$", body):
                yield self.hit(ctx, offset=st.start_offset + po, statement=st,
                               object_name=table,
                               message="%s -> kolon listesi fazladan virgulle bitiyor "
                                       "(ORA-00904)." % table)

            seen, dups = {}, set()
            for part in _split_top(body):
                tok = re.match(r"\s*(\"?[\w$#]+\"?)", part)
                if not tok:
                    continue
                name = tok.group(1).strip('"')
                up = name.upper()
                if up in NON_COLUMN:
                    continue
                if self.param("check_reserved", True) and up in RESERVED:
                    yield self.hit(ctx, offset=st.start_offset + po, statement=st,
                                   object_name=table,
                                   message="%s -> '%s' Oracle rezerve kelimesi, "
                                           "kolon adi olarak kullanilamaz." % (table, name))
                if self.param("check_duplicate", True):
                    if up in seen and up not in dups:
                        dups.add(up)
                        yield self.hit(ctx, offset=st.start_offset + po, statement=st,
                                       object_name=table,
                                       message="%s -> '%s' kolonu birden fazla "
                                               "tanimlanmis (ORA-00957)." % (table, name))
                    seen[up] = True
