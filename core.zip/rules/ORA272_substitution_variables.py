# -*- coding: utf-8 -*-
"""ORA272 - Substitution degiskenleri (CLI-020..CLI-024)."""
import re
from core.model import BaseRule, Severity


class SubstitutionVariableRule(BaseRule):
    id = "ORA272"
    name = "Cozulmemis substitution degiskeni"
    category = "ISTEMCI"
    severity = Severity.FAIL
    description = "&ad / &&ad / &1 kullanilmis ama DEFINE ile tanimlanmamis."
    rationale = ("Master kontrol listesi CLI-021/CLI-022. Tanimsiz degisken "
                 "SQL*Plus'ta interaktif prompt uretir; otomasyon sonsuza kadar "
                 "bekler veya bos deger ile yanlis SQL calisir.")
    remediation = ("Degiskeni scriptin basinda DEFINE ile tanimlayin ya da "
                   "SET DEFINE OFF ile '&' karakterini duz metin yapin.")
    tags = ['client', 'CLI', 'automation', 'CLI-021', 'CLI-022', 'CLI-023', 'CLI-024']

    def check(self, ctx):
        # SET DEFINE OFF etkin mi (basit durum takibi)
        define_off_at = None
        m = ctx.search(r"SET\s+DEFINE\s+OFF")
        if m:
            define_off_at = m.start
        defined = {d.group(1).upper() for d in
                   re.finditer(r"(?<![\w$#])DEFINE\s+([\w$#]+)\s*=", ctx.masked, re.I)}

        for mm in re.finditer(r"&{1,2}([\w$#]+|\d+)", ctx.raw):
            pos = mm.start()
            if define_off_at is not None and pos > define_off_at:
                continue                      # DEFINE OFF sonrasi duz metin
            name = mm.group(1).upper()
            if name in defined:
                continue
            yield self.hit(ctx, offset=pos,
                           message="[CLI-022] Tanimsiz substitution degiskeni: "
                                   "'%s' (interaktif prompt uretir)." % mm.group(0))

        # CLI-024: SQL sonucundan komut/dosya adi uretme
        for mm in ctx.finditer(r"COLUMN\s+\S+\s+NEW_VALUE|COLUMN\s+\S+\s+OLD_VALUE"):
            yield self.hit(ctx, offset=mm.start,
                           message="[CLI-024] COLUMN ... NEW_VALUE ile sorgu "
                                   "sonucundan degisken uretiliyor.")
