# -*- coding: utf-8 -*-
"""ORA038 - Kod icinde ASCII disi karakter."""
import re
from core.model import BaseRule, Severity


class NonAsciiRule(BaseRule):
    id = "ORA038"
    name = "Kod icinde ASCII disi karakter"
    category = "SOZDIZIMI"
    severity = Severity.WARN
    description = "Obje adi / anahtar kelime bolgesinde Turkce veya ozel karakter var."
    rationale = ("Client ile veritabani karakter seti (NLS_LANG) farkliysa bu "
                 "karakterler bozulur; obje adlari ve veri hatali yazilir.")
    remediation = ("Obje ve kolon adlarinda Turkce karakter kullanmayin. Veri "
                   "iceren stringler icin NLS_LANG ve dosya kodlamasini (UTF-8) dogrulayin.")
    tags = ["encoding", "style"]

    def check(self, ctx):
        # Maskeli metinde string/yorum icerigi zaten yok -> sadece kod bolgesi kalir
        for m in re.finditer(r"[^\x00-\x7F]", ctx.masked):
            yield self.hit(ctx, offset=m.start(),
                           message="Kod bolgesinde ASCII disi karakter: %r"
                                   % m.group(0))
