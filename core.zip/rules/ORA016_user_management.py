# -*- coding: utf-8 -*-
"""ORA016 - Kullanici / rol / profil yonetimi."""
import re
from core.model import BaseRule, Severity
from core.helpers import object_after


class UserManagementRule(BaseRule):
    id = "ORA016"
    name = "Kullanici, rol veya profil yonetimi"
    category = "GUVENLIK"
    severity = Severity.FAIL
    description = "CREATE/ALTER/DROP USER, ROLE veya PROFILE ifadesi var."
    rationale = ("Kimlik ve erisim yonetimi (IAM) ayri bir surectir; uygulama "
                 "degisiklik scripti icinde hesap acilmasi gorev ayriligini ihlal eder.")
    remediation = "Hesap/rol taleplerini IAM sureci uzerinden ayri script ile iletin."
    tags = ["security", "iam", "sod"]

    PATTERN = (r"\b(CREATE|ALTER|DROP)\s+(USER|ROLE|PROFILE)\b")

    def check(self, ctx):
        for m in ctx.finditer(self.PATTERN):
            st = ctx.statement_at(m.start)
            name = object_after(ctx.masked[m.start:m.start + 200], m.text)
            yield self.hit(ctx, offset=m.start, statement=st, object_name=name,
                           message="%s -> %s" % (" ".join(m.text.split()), name))
        for m in ctx.finditer(r"\b(ACCOUNT\s+UNLOCK|PASSWORD\s+EXPIRE|"
                              r"PASSWORD_LIFE_TIME|FAILED_LOGIN_ATTEMPTS)\b"):
            yield self.hit(ctx, offset=m.start, severity=Severity.WARN,
                           message="Hesap politikasi degisikligi: %s" % m.text)
