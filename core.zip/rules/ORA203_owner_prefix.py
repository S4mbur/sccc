# -*- coding: utf-8 -*-
"""ORA203 - DDL obje isminde owner oneki yok (kurum kurali 7)."""
import re
from core.model import BaseRule, Severity

WORD = r"[A-Za-z_$#][\w$#]*"


class OwnerPrefixRule(BaseRule):
    id = "ORA203"
    name = "DDL obje isminde owner oneki yok"
    category = "DBRUNNER"
    severity = Severity.FAIL
    description = "CREATE / ALTER / DROP ifadelerinde obje adi OWNER.OBJE seklinde olmali."
    rationale = ("DDL scriptleri obje ismine gore versiyonlanip saklanir. Owner oneki "
                 "yoksa sorgu dbrunner semasi altinda calisir ve hata alir; ayrica "
                 "versiyon kaydi yanlis objeye baglanir.")
    remediation = "Obje adinin basina sema/owner ekleyin: CREATE TABLE BANKAPP.HESAP ..."
    tags = ['dbrunner', 'schema', 'DDL-014']
    default_params = {
        # Owner beklenmeyen obje tipleri (oturum/sistem seviyesi)
        "skip_types": ["SESSION", "SYSTEM", "DATABASE", "TABLESPACE", "USER", "ROLE",
                       "PROFILE", "DIRECTORY", "PLUGGABLE"],
    }

    HEAD = (r"^\s*(CREATE|ALTER|DROP)\s+"
            r"(?:OR\s+REPLACE\s+)?(?:(?:NON)?EDITIONABLE\s+)?"
            r"(?:GLOBAL\s+TEMPORARY\s+|UNIQUE\s+|BITMAP\s+|MATERIALIZED\s+|"
            r"PUBLIC\s+|SHARED\s+|FORCE\s+)*"
            r"(TABLE|INDEX|VIEW|SEQUENCE|TRIGGER|PACKAGE(?:\s+BODY)?|PROCEDURE|"
            r"FUNCTION|SYNONYM|TYPE(?:\s+BODY)?|CONSTRAINT|TABLESPACE|USER|ROLE|"
            r"PROFILE|DIRECTORY|SESSION|SYSTEM|DATABASE|PLUGGABLE)\s+"
            r"(?!IF\s)(\"?%s\"?)\s*(\.)?" % WORD)

    def check(self, ctx):
        skip = {t.upper() for t in self.param("skip_types", [])}
        for st in ctx.statements:
            if st.kind == "sqlplus":
                continue
            m = re.match(self.HEAD, st.masked, re.I)
            if not m:
                continue
            otype = re.sub(r"\s+", " ", m.group(2).upper())
            if otype.split()[0] in skip:
                continue
            if m.group(4) == ".":          # OWNER.OBJE -> uygun
                continue
            name = m.group(3).strip('"')
            yield self.hit(ctx, offset=st.start_offset + m.start(3), statement=st,
                           object_name=name,
                           message="%s %s -> owner oneki yok (OWNER.%s bekleniyor)."
                                   % (m.group(1).upper(), otype, name))

        # CREATE INDEX ... ON <tablo> hedefinde de owner zorunlu
        for st in ctx.statements:
            m = re.search(r"CREATE\s+(?:UNIQUE\s+|BITMAP\s+)*INDEX\s+"
                          r"(?:\"?%s\"?\s*\.\s*)?\"?%s\"?\s+ON\s+"
                          r"(\"?%s\"?)\s*(\.)?" % (WORD, WORD, WORD),
                          st.masked, re.I)
            if not m or m.group(2) == ".":
                continue
            tbl = m.group(1).strip('"')
            yield self.hit(ctx, offset=st.start_offset + m.start(1), statement=st,
                           object_name=tbl,
                           message="CREATE INDEX ... ON %s -> owner oneki yok "
                                   "(OWNER.%s bekleniyor)." % (tbl, tbl))

        # COMMENT ON ve GRANT ... ON icin de owner zorunlu
        for m in ctx.finditer(r"\b(COMMENT\s+ON\s+(?:TABLE|COLUMN)|ON)\s+(\"?%s\"?)\s*(\.)?"
                              % WORD):
            if m.group(3) == ".":
                continue
            st = ctx.statement_at(m.start)
            if st is None or st.first_word not in ("COMMENT", "GRANT", "REVOKE"):
                continue
            yield self.hit(ctx, offset=m.start, statement=st,
                           object_name=m.group(2),
                           message="%s ifadesinde owner oneki yok: %s"
                                   % (st.first_word, m.group(2)))
