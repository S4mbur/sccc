# -*- coding: utf-8 -*-
"""ORA201 - Dosya adi ve sira oneki (Dokuman madde 8)."""
import re
from core.model import BaseRule, Severity


class FileSequencePrefixRule(BaseRule):
    id = "ORA201"
    name = "Dosya sira oneki / adi hatali"
    category = "DBRUNNER"
    severity = Severity.FAIL
    description = ("Sirali calisacak dosyalar iki haneli rakamla baslamalidir "
                   "(01-dosyaadi.sql). Dosya adinda bosluk/ozel karakter olmamalidir.")
    rationale = ("Deployment dokumani madde 8. Yanlis onek calisma sirasini bozar; "
                 "bagimli scriptler yanlis sirada calisirsa veri tutarsiz kalir. "
                 "Bosluk iceren adlar arsivleme ve komut satirinda hataya yol acar.")
    remediation = ("Dosyayi 01-, 02-, 03- ... seklinde adlandirin. Ad icinde sadece "
                   "harf, rakam, '-' ve '_' kullanin.")
    tags = ["dbrunner", "dokuman-m8", "dosya"]
    default_params = {
        # True yapilirsa onek olmayan her dosya da FAIL uretir.
        "require_prefix": False,
        "pattern": r"^\d{2}-",
        "forbid_space": True,
        "forbid_non_ascii": True,
        "sep_chars": "-",        # "-_" yapilirsa 001_ad.sql de denetlenir
    }

    def check(self, ctx):
        base = ctx.filename
        pat = self.param("pattern", r"^\d{2}-")

        if self.param("forbid_space", True) and " " in base:
            yield self.hit(ctx, line=1,
                           message="Dosya adinda bosluk var: '%s'" % base)
        if self.param("forbid_non_ascii", True) and re.search(r"[^\x00-\x7F]", base):
            yield self.hit(ctx, line=1,
                           message="Dosya adinda ASCII disi karakter var: '%s'" % base)

        if re.match(pat, base):
            return

        # Onek denemesi var ama iki haneli degil -> kesin hata.
        # Sadece '-' ayraci sira onegi sayilir (dokuman ornegi: 01-dosyaadi.sql).
        # '001_ad.sql' gibi alt cizgili adlandirmalar farkli bir konvansiyondur,
        # varsayilan olarak flaglenmez (sep_chars parametresi ile degistirilebilir).
        seps = self.param("sep_chars", "-")
        loose = re.match(r"^(\d+)[%s]" % re.escape(seps), base)
        if loose:
            yield self.hit(ctx, line=1,
                           message="Sira oneki iki haneli olmali: '%s' -> '%02d-...'"
                                   % (base, int(loose.group(1))))
        elif self.param("require_prefix", False):
            yield self.hit(ctx, line=1,
                           message="Dosya adinda iki haneli sira oneki yok: %s" % base)
