# -*- coding: utf-8 -*-
"""ORA204 - Stored obje create scripti '/' ile sonlandirilmamis (kurum kurali 5)."""
from core.model import BaseRule, Severity
from core.helpers import scan_plsql_units


class StoredObjectSlashRule(BaseRule):
    id = "ORA204"
    name = "Stored obje create sonrasi '/' eksik"
    category = "DBRUNNER"
    severity = Severity.FAIL
    description = ("PROCEDURE / FUNCTION / PACKAGE / TRIGGER / TYPE create scriptinin "
                   "sonuna mutlaka '/' isareti eklenmelidir.")
    rationale = ("'/' olmadan obje derlenmez. Deployment araci sorguyu gondermis gibi "
                 "gorunur, fakat session inactive kalir ve talep basarisiz tamamlanir. "
                 "Ayrica sonraki bloklar bu blogun parcasi sayilarak bozulur.")
    remediation = "Create ifadesinin kapanis END; satirindan sonra ayri satira / koyun."
    tags = ['dbrunner', 'plsql', 'LEX-011']

    def check(self, ctx):
        for u in scan_plsql_units(ctx.masked_lines):
            if u.kind != "create" or u.slash:
                continue
            if u.end is None:
                yield self.hit(ctx, line=u.start,
                               message="CREATE %s blogu (satir %d) kapanmamis; "
                                       "END; ve '/' eksik." % (u.obj_type, u.start))
            else:
                yield self.hit(ctx, line=u.end,
                               message="CREATE %s (satir %d-%d) sonrasinda '/' yok."
                                       % (u.obj_type, u.start, u.end))
