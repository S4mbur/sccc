# -*- coding: utf-8 -*-
"""ORA021 - Dongu icinde COMMIT."""
import re
from core.model import BaseRule, Severity


class CommitInLoopRule(BaseRule):
    id = "ORA021"
    name = "Dongu icinde COMMIT"
    category = "TRANSACTION"
    severity = Severity.WARN
    description = "LOOP ... END LOOP blogu icinde COMMIT cagriliyor."
    rationale = ("Dongu icindeki commit ORA-01555 (snapshot too old) hatasina ve "
                 "islemin yarida kalmasi durumunda tutarsiz veriye yol acar.")
    remediation = ("Transaction sinirini dongu disina alin veya kontrollu batch "
                   "commit (ornegin her 10.000 kayitta) + yeniden calistirilabilir "
                   "tasarim kullanin.")
    tags = ["transaction", "plsql"]

    def check(self, ctx):
        text = ctx.masked
        for lm in re.finditer(r"(?<![\w$#])LOOP(?![\w$#])", text, re.I):
            em = re.search(r"(?<![\w$#])END\s+LOOP(?![\w$#])", text[lm.end():], re.I)
            if not em:
                continue
            block = text[lm.end():lm.end() + em.start()]
            for cm in re.finditer(r"(?<![\w$#])(COMMIT|ROLLBACK)(?![\w$#])", block, re.I):
                yield self.hit(ctx, offset=lm.end() + cm.start(),
                               message="Dongu icinde %s cagrisi."
                                       % cm.group(0).upper())
