# -*- coding: utf-8 -*-
"""ORA215 - Isimlendirilmemis constraint."""
import re
from core.model import BaseRule, Severity
from core.helpers import object_after


class UnnamedConstraintRule(BaseRule):
    id = "ORA215"
    name = "Constraint isimlendirilmemis"
    category = "BUTUNLUK"
    severity = Severity.WARN
    description = "PRIMARY KEY / UNIQUE / FOREIGN KEY / CHECK icin CONSTRAINT adi verilmemis."
    rationale = ("Oracle SYS_C0012345 gibi rastgele bir ad uretir. Bu ad ortamlar "
                 "arasinda farkli olur; rollback scripti ve karsilastirma araclari "
                 "constraint'i bulamaz, hata mesajlari da anlasilmaz hale gelir.")
    remediation = ("Constraint'i acikca isimlendirin:\n"
                   "  CONSTRAINT PK_HESAP PRIMARY KEY (ID)")
    tags = ['integrity', 'naming', 'ddl', 'DDL-022']

    KINDS = r"(PRIMARY\s+KEY|UNIQUE|FOREIGN\s+KEY|CHECK)"

    def check(self, ctx):
        for st in ctx.statements:
            if st.first_word not in ("CREATE", "ALTER"):
                continue
            if not re.match(r"\s*(CREATE\s+(GLOBAL\s+TEMPORARY\s+)?TABLE|ALTER\s+TABLE)\b",
                            st.masked, re.I):
                continue
            table = object_after(st.masked, r"TABLE")
            for m in re.finditer(self.KINDS, st.masked, re.I):
                before = st.masked[max(0, m.start() - 120):m.start()]
                if re.search(r"CONSTRAINT\s+[\w$#\"]+\s*$", before, re.I):
                    continue
                if re.search(r"(?<![\w$#])(ADD|MODIFY|DROP)\s*\(?\s*$", before, re.I) or \
                        re.search(r"[,(]\s*$", before) or \
                        re.search(r"[\w$#\")\]]\s+$", before):
                    yield self.hit(ctx, offset=st.start_offset + m.start(),
                                   statement=st, object_name=table,
                                   message="Isimsiz %s (SYS_C... adi uretilir) -> %s"
                                           % (" ".join(m.group(0).split()).upper(), table))
