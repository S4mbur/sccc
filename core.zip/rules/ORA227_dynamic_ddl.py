# -*- coding: utf-8 -*-
"""ORA227 - Dinamik SQL calistirma (CUR-006..010, PLS-001..005, MASTER-002).

Politika: dinamik SQL varsayilan olarak BLOCK.
  * Literal ise icerigi cozulup gercek fiil raporlanir.
  * Literal degilse (degisken, birlestirme, CHR/UNISTR, fonksiyon donusu)
    statik olarak cozulemez -> MASTER-002 geregi otomatik calistirilmaz.
"""
import re
from core.model import BaseRule, Severity
from core.helpers import literal_at

DDL_VERBS = r"(CREATE|ALTER|DROP|TRUNCATE|RENAME|GRANT|REVOKE|COMMENT|PURGE|FLASHBACK|AUDIT|NOAUDIT)"
DML_VERBS = r"(INSERT|UPDATE|DELETE|MERGE|LOCK)"

WRAPPERS = [
    (r"EXECUTE\s+IMMEDIATE", "EXECUTE IMMEDIATE", "PLS-001"),
    (r"DBMS_SQL\s*\.\s*PARSE", "DBMS_SQL.PARSE", "PLS-003"),
    (r"DBMS_UTILITY\s*\.\s*EXEC_DDL_STATEMENT", "DBMS_UTILITY.EXEC_DDL_STATEMENT", "PLS-004"),
    (r"DBMS_DDL\s*\.\s*\w+", "DBMS_DDL", "PLS-004"),
    (r"DBMS_METADATA\s*\.\s*\w+", "DBMS_METADATA", "PLS-004"),
    (r"OPEN\s+[\w$#.]+\s+FOR\s+(?![Ss][Ee][Ll][Ee][Cc][Tt])", "OPEN ... FOR <dinamik>", "PLS-003"),
]


class DynamicSqlExecutionRule(BaseRule):
    id = "ORA227"
    name = "Dinamik SQL calistirma"
    category = "DINAMIK"
    severity = Severity.FAIL
    description = ("EXECUTE IMMEDIATE / DBMS_SQL / DBMS_UTILITY ile dinamik SQL "
                   "calistiriliyor.")
    rationale = ("Master kontrol listesi PLS-001..005 ve MASTER-002. Dinamik SQL "
                 "tum statik denetimleri (owner oneki, WHERE zorunlulugu, DDL/DML "
                 "ayrimi, versiyonlama) devre disi birakir. Icerik statik olarak "
                 "cozulemiyorsa ne calisacagi bilinemez.")
    remediation = ("SQL'i dogrudan, string icine almadan yazin. Kosullu calistirma "
                   "gerekiyorsa dosyayi bolun ve on kontrolu ayri adim yapin.")
    tags = ["dynamic", "PLS", "MASTER-002", "security"]

    def check(self, ctx):
        # Anahtar kelime MASKELI metinde aranir (yorum/string icindeki
        # "EXECUTE IMMEDIATE" yazisi alarm uretmesin); literal icerigi ise
        # HAM metinden okunur - maskeleme offsetleri korudugu icin guvenlidir.
        raw, masked = ctx.raw, ctx.masked
        for pat, label, code in WRAPPERS:
            for m in re.finditer(pat, masked, re.I):
                tail_pos = m.end()
                lit = literal_at(raw, tail_pos)
                if lit:
                    _, _, content = lit
                    body = " ".join(content.split())
                    vm = re.match(r"\s*%s\b" % DDL_VERBS, content, re.I)
                    dm = re.match(r"\s*%s\b" % DML_VERBS, content, re.I)
                    if vm:
                        kind = "DDL (%s)" % vm.group(1).upper()
                    elif dm:
                        kind = "DML (%s)" % dm.group(1).upper()
                    else:
                        kind = "SQL"
                    yield self.hit(
                        ctx, offset=m.start(),
                        message="[%s] %s ile dinamik %s: \"%s\"%s"
                                % (code, label, kind, body[:70],
                                   "..." if len(body) > 70 else ""))
                else:
                    # Literal degil -> statik cozulemez (MASTER-002)
                    snippet = " ".join(raw[tail_pos:tail_pos + 70].split())
                    yield self.hit(
                        ctx, offset=m.start(),
                        message="[MASTER-002] %s icerigi statik olarak cozulemiyor "
                                "(degisken/birlestirme/fonksiyon): %s"
                                % (label, snippet[:60]))

        # CHR()/UNISTR() ile karakter kacirma (PLS-002)
        for m in re.finditer(r"(?<![\w$#])(CHR|UNISTR|TRANSLATE|REPLACE)\s*\(",
                             masked, re.I):
            window = masked[max(0, m.start() - 200):m.start()].upper()
            if re.search(r"EXECUTE\s+IMMEDIATE|DBMS_SQL|EXEC_DDL", window):
                yield self.hit(ctx, offset=m.start(),
                               message="[PLS-002] Dinamik SQL metni %s() ile "
                                       "uretiliyor; icerik gizlenmis olabilir."
                                       % m.group(1).upper())
