# -*- coding: utf-8 -*-
"""ORA224 - DDL dosyasinda transaction komutu."""
import re
from core.model import BaseRule, Severity


class TransactionInDdlFileRule(BaseRule):
    id = "ORA224"
    name = "DDL dosyasinda COMMIT / ROLLBACK var"
    category = "DBRUNNER"
    severity = Severity.FAIL
    description = "Dosya sadece DDL iceriyor fakat COMMIT/ROLLBACK komutu da var."
    rationale = ("Her DDL zaten implicit commit uretir; buradaki COMMIT islevsizdir. "
                 "Ayrica deployment araci dosyayi DDL olarak siniflandirdiginda "
                 "transaction komutu beklemez ve kural ihlali olarak degerlendirir.")
    remediation = "DDL dosyasindan COMMIT/ROLLBACK satirlarini kaldirin."
    tags = ['dbrunner', 'transaction', 'ddl', 'TX-008']

    def check(self, ctx):
        ddl = ctx.top_ddl_statements
        if not ddl or ctx.top_dml_statements:
            return
        for st in ctx.statements:
            if st.kind == "sqlplus":
                continue
            if st.first_word in ("COMMIT", "ROLLBACK", "SAVEPOINT"):
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               message="Sadece DDL iceren dosyada %s komutu var."
                                       % st.first_word)
