# -*- coding: utf-8 -*-
"""ORA230 - UPDATE SET listesi hatali."""
import re
from core.model import BaseRule, Severity
from core.helpers import find_top_level, kw


def _split_top(text):
    parts, cur, depth, q = [], "", 0, ""
    for ch in text:
        if q:
            cur += ch
            if ch == q:
                q = ""
            continue
        if ch in "\"'":
            q = ch
            cur += ch
        elif ch == "(":
            depth += 1
            cur += ch
        elif ch == ")":
            depth -= 1
            cur += ch
        elif ch == "," and depth == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    parts.append(cur)
    return parts


class UpdateSetListRule(BaseRule):
    id = "ORA230"
    name = "UPDATE SET listesinde gecersiz oge"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = "SET listesindeki her oge 'kolon = deger' bicimde olmalidir."
    rationale = ("Ondalik ayirici olarak virgul yazmak (10,00) veya eksik atama, "
                 "SET listesini bozar. Oracle ORA-00971/ORA-00904 verir ya da daha "
                 "kotusu yanlis kolonu gunceller.")
    remediation = ("Ondalik ayirici olarak nokta kullanin (10.00) ve her atamayi "
                   "'kolon = deger' seklinde yazin.")
    tags = ['syntax', 'dml', 'dataintegrity', 'DML-025']

    def check(self, ctx):
        for st in ctx.all_statements:
            if st.kind not in ("sql", "plsql_inner") or st.first_word != "UPDATE":
                continue
            sm = find_top_level(st.body, kw("SET"))
            if not sm:
                continue
            tail = st.body[sm.end():]
            wm = find_top_level(tail, kw("(?:WHERE|RETURNING)"))
            clause = tail[:wm.start()] if wm else tail
            for part in _split_top(clause):
                if not part.strip():
                    continue
                if "=" in part:
                    continue
                if re.match(r"^\s*\(", part):        # (a,b) = (SELECT ...) bicimi
                    continue
                yield self.hit(ctx, offset=st.start_offset + sm.end(), statement=st,
                               message="SET listesinde atama olmayan oge: '%s'"
                                       % part.strip()[:40])
