# -*- coding: utf-8 -*-
"""ORA213 - Foreign key kolonunda index yok."""
import re
from core.model import BaseRule, Severity
from core.helpers import object_after


class FkWithoutIndexRule(BaseRule):
    id = "ORA213"
    name = "Foreign key kolonunda index olusturulmamis"
    category = "BUTUNLUK"
    severity = Severity.WARN
    description = "FOREIGN KEY tanimlanmis fakat ayni scriptte o kolon icin index yok."
    rationale = ("Indexsiz FK, ana tabloda DELETE/UPDATE yapildiginda cocuk tablo "
                 "uzerinde tam tablo kilidi (share lock) alinmasina yol acar. "
                 "Yogun saatte uygulama genelinde bloklama zinciri olusturur.")
    remediation = ("FK kolonu icin index olusturun:\n"
                   "  CREATE INDEX OWNER.IX_TABLO_KOLON ON OWNER.TABLO (KOLON) ONLINE;")
    tags = ['integrity', 'locking', 'ddl', 'DDL-023']

    RX_FK = re.compile(r"FOREIGN\s+KEY\s*\(([^)]*)\)", re.I)

    def check(self, ctx):
        # scriptte olusturulan indexlerin (tablo, kolonlar) kaydi
        indexed = []
        for st in ctx.statements:
            m = re.search(r"CREATE\s+(?:UNIQUE\s+|BITMAP\s+)*INDEX\s+\S+\s+ON\s+"
                          r"((?:\"?[\w$#]+\"?\s*\.\s*)?\"?[\w$#]+\"?)\s*\(([^)]*)\)",
                          st.masked, re.I)
            if m:
                cols = [c.strip().strip('"').upper() for c in m.group(2).split(",")]
                indexed.append((m.group(1).split(".")[-1].strip('"').upper(), cols))

        for st in ctx.statements:
            if st.first_word not in ("ALTER", "CREATE"):
                continue
            if re.match(r"\s*ALTER\s+TABLE\b", st.masked, re.I):
                table = object_after(st.masked, r"ALTER\s+TABLE")
            elif re.match(r"\s*CREATE\s+(GLOBAL\s+TEMPORARY\s+)?TABLE\b", st.masked, re.I):
                table = object_after(st.masked, r"TABLE")
            else:
                continue
            short = table.split(".")[-1].strip('"').upper()
            for m in self.RX_FK.finditer(st.masked):
                cols = [c.strip().strip('"').upper() for c in m.group(1).split(",")]
                if not cols or not cols[0]:
                    continue
                covered = any(t == short and ic[:len(cols)] == cols
                              for t, ic in indexed)
                if covered:
                    continue
                yield self.hit(ctx, offset=st.start_offset + m.start(), statement=st,
                               object_name=table,
                               message="%s(%s) uzerinde FK var, index yok "
                                       "(ana tabloda DELETE cocuk tabloyu kilitler)."
                                       % (table, ", ".join(cols)))
