# -*- coding: utf-8 -*-
"""ORA057 - Index kullanimini engelleyen kaliplar."""
import re
from core.model import BaseRule, Severity


class SargabilityRule(BaseRule):
    id = "ORA057"
    name = "Index kullanimini engelleyen kalip"
    category = "PERFORMANS"
    severity = Severity.WARN
    description = "WHERE kosulunda kolonu saran fonksiyon veya bastan joker (%) var."
    rationale = ("Bu kaliplar index'i devre disi birakip tam tablo taramasina zorlar; "
                 "buyuk hesap/hareket tablolarinda islem suresi katlanir.")
    remediation = ("Fonksiyonu sabit tarafa alin, function-based index tanimlayin veya "
                   "LIKE '%...' yerine daraltici kosul kullanin.")
    tags = ["performance", "sql"]

    PATTERNS = [
        (r"WHERE[^;]{0,300}?(?<![\w$#])(UPPER|LOWER|TRIM|SUBSTR|TO_CHAR|NVL|"
         r"TRUNC)\s*\(\s*[\w$#.]+\s*\)\s*(=|<|>|LIKE|IN)", "Kolonu saran fonksiyon"),
        (r"(?<![\w$#])LIKE\s+'%", "Bastan joker karakterli LIKE"),
        (r"(?<![\w$#])(!=|<>)\s*", "Esitsizlik operatoru (index kullanilmayabilir)"),
    ]

    def check(self, ctx):
        for pat, label in self.PATTERNS[:1]:
            for m in ctx.finditer(pat, re.I | re.S):
                yield self.hit(ctx, offset=m.start,
                               message="%s: %s" % (label, " ".join(m.text.split())[-60:]))
        # LIKE '%...' maskeleme nedeniyle ham metinde aranir
        for m in ctx.findall_raw(r"(?<![\w$#])LIKE\s+'%"):
            yield self.hit(ctx, offset=m.start,
                           message="Bastan joker karakterli LIKE - full table scan.")
