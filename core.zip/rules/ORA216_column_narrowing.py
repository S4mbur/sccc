# -*- coding: utf-8 -*-
"""ORA216 - Kolon tipi/uzunlugu degistiriliyor (veri kaybi riski)."""
import re
from core.model import BaseRule, Severity
from core.helpers import object_after


class ColumnNarrowingRule(BaseRule):
    id = "ORA216"
    name = "Kolon tipi veya uzunlugu degistiriliyor"
    category = "BUTUNLUK"
    severity = Severity.WARN
    description = "ALTER TABLE ... MODIFY ile kolon tipi/uzunlugu degistiriliyor."
    rationale = ("Mevcut veri yeni tanima sigmazsa ORA-01441/ORA-01439 alinir ya da "
                 "donusum sirasinda deger kaybi/yuvarlanma olur. Statik analiz mevcut "
                 "veriyi goremedigi icin bu degisiklik mutlaka on kontrol ister.")
    remediation = ("Uygulamadan once dogrulayin:\n"
                   "  SELECT MAX(LENGTH(KOLON)) FROM OWNER.TABLO;\n"
                   "Daraltma gerekiyorsa once veriyi donusturun, sonra MODIFY calistirin.")
    tags = ['integrity', 'ddl', 'dataloss', 'DDL-020']

    RX = re.compile(r"\bMODIFY\s*\(?\s*([\w$#\"]+)\s+"
                    r"([A-Z][\w$#]*(?:\s*\(\s*[\d,\s*]+\s*\))?)", re.I)

    def check(self, ctx):
        for st in ctx.statements:
            if not re.match(r"\s*ALTER\s+TABLE\b", st.masked, re.I):
                continue
            table = object_after(st.masked, r"ALTER\s+TABLE")
            for m in self.RX.finditer(st.masked):
                col, typ = m.group(1).strip('"'), " ".join(m.group(2).split())
                if typ.upper() in ("NOT", "NULL", "DEFAULT", "CONSTRAINT"):
                    continue
                yield self.hit(ctx, offset=st.start_offset + m.start(), statement=st,
                               object_name="%s.%s" % (table, col),
                               message="%s.%s -> %s (mevcut veri uzunlugu "
                                       "dogrulanmali)." % (table, col, typ))
