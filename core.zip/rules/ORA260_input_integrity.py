# -*- coding: utf-8 -*-
"""ORA260 - Girdi butunlugu ve kodlama kontrolleri.

core/reader.py tarafindan uretilen bulgular (INP-001..INP-024) rapora
tasinir. Boylece BOM, encoding, kontrol karakteri ve limit ihlalleri
diger kural bulgulariyla ayni formatta gorunur.
"""
from core.model import BaseRule, Severity

CONTROL_TEXT = {
    "INP-001": ("Dosya boyutu limiti asildi",
                "Scripti mantiksal adimlara bolun."),
    "INP-003": ("Dosya UTF-8 BOM ile basliyor",
                "Editorunuzde 'UTF-8 (BOM'suz)' olarak kaydedin. BOM, ilk "
                "komutun basina gorunmez karakter koyarak WHERE/DROP gibi "
                "kontrollerin atlanmasina yol acabilir."),
    "INP-004": ("Desteklenmeyen BOM / kodlama",
                "Dosyayi UTF-8 (BOM'suz) olarak yeniden kaydedin."),
    "INP-005": ("Karakter kodlama hatasi",
                "Talepte belirtilen encoding ile kaydedin; bozuk karakter "
                "iceren dosya calistirilmaz."),
    "INP-007": ("Yasak/gorunmez karakter",
                "NUL, ESC, bidi ve zero-width karakterleri temizleyin. Bu "
                "karakterler kodun goründugunden farkli calismasina yol acar."),
    "INP-008": ("Satir sonu normalizasyonu", "Bilgi amaclidir."),
    "INP-010": ("Unicode normalizasyon farki",
                "Obje adlarini ASCII karakterlerle yazin."),
    "INP-018": ("Satir uzunlugu limiti",
                "Satiri bolun; SQL*Plus uzun satirlari kesebilir."),
    "INP-019": ("Satir sayisi limiti", "Scripti bolun."),
    "INP-022": ("Bos dosya", "Dogru dosyayi gonderdiginizden emin olun."),
}


class InputIntegrityRule(BaseRule):
    id = "ORA260"
    name = "Girdi butunlugu / kodlama"
    category = "GIRDI"
    severity = Severity.FAIL
    description = "Dosya baytlari, BOM, kodlama ve karakter guvenligi kontrolu."
    rationale = ("Master kontrol listesi INP-001..INP-024. BOM veya gorunmez "
                 "karakterler statik analizi atlatabilir (CUR-001/CUR-002); "
                 "bozuk kodlama veriyi sessizce degistirir.")
    remediation = "Dosyayi UTF-8 (BOM'suz), kontrol karakteri icermeyen halde gonderin."
    tags = ['input', 'INP', 'encoding', 'INP-001', 'INP-003', 'INP-004', 'INP-005', 'INP-006', 'INP-007', 'INP-008', 'INP-009', 'INP-010', 'INP-018', 'INP-019', 'INP-022', 'LEX-003', 'GATE-007']

    def check(self, ctx):
        for item in (ctx.meta.get("issues") or []):
            code, sev, msg = item
            title, fix = CONTROL_TEXT.get(code, (code, self.remediation))
            yield self.hit(ctx, line=1, severity=sev,
                           message="[%s] %s: %s" % (code, title, msg),
                           suggestion=fix)
