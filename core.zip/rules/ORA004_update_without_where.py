# -*- coding: utf-8 -*-
"""ORA004 - WHERE'siz UPDATE."""
import re
from core.model import BaseRule, Severity
from core.helpers import find_top_level, object_after, kw


class UpdateWithoutWhereRule(BaseRule):
    id = "ORA004"
    name = "WHERE kosulu olmayan UPDATE"
    category = "YIKICI"
    severity = Severity.FAIL
    description = "UPDATE ifadesinde ust seviye WHERE kosulu yok."
    rationale = ("Tablodaki tum satirlari gunceller. Hesap/bakiye tablolarinda "
                 "geri donusu maliyetli veri bozulmasina yol acar.")
    remediation = "UPDATE ifadesine daraltici bir WHERE kosulu ekleyin."
    tags = ['destructive', 'dml', 'DML-001']

    def check(self, ctx):
        for st in ctx.all_statements:
            if st.first_word != "UPDATE":
                continue
            body = st.body
            if find_top_level(body, kw("WHERE")):
                continue
            name = object_after(body, r"UPDATE")
            yield self.hit(ctx, offset=st.start_offset, statement=st, object_name=name,
                           message="WHERE'siz UPDATE: %s (tum satirlar guncellenir)" % name)
