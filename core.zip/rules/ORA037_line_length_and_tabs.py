# -*- coding: utf-8 -*-
"""ORA037 - Satir uzunlugu ve tab karakteri."""
import re
from core.model import BaseRule, Severity


class LineLengthRule(BaseRule):
    id = "ORA037"
    name = "Asiri uzun satir veya TAB karakteri"
    category = "SOZDIZIMI"
    severity = Severity.INFO
    description = "Cok uzun satirlar ve TAB karakteri okunabilirligi bozar."
    rationale = ("Bazi SQL*Plus surumlerinde 2499 karakterden uzun satirlar kesilir; "
                 "TAB karakteri farkli editorlerde farkli goruntulenir.")
    remediation = "Satirlari bolun, TAB yerine bosluk kullanin."
    tags = ["style"]
    default_params = {"max_line_length": 300, "flag_tabs": True}

    def check(self, ctx):
        limit = int(ctx.setting("max_line_length", self.param("max_line_length", 300)))
        for i, line in enumerate(ctx.lines, start=1):
            if len(line) > limit:
                yield self.hit(ctx, line=i,
                               message="Satir uzunlugu %d (limit %d)." % (len(line), limit))
            if self.param("flag_tabs", True) and "\t" in line:
                yield self.hit(ctx, line=i, message="Satirda TAB karakteri var.")
