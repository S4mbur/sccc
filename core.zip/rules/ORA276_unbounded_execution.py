# -*- coding: utf-8 -*-
"""ORA276 - Sinirsiz calisma / bekleme (PLS-010/012, CUR-026, PERF-008)."""
import re
from core.model import BaseRule, Severity


class UnboundedExecutionRule(BaseRule):
    id = "ORA276"
    name = "Sinirsiz dongu veya bekleme"
    category = "DINAMIK"
    severity = Severity.FAIL
    description = "Cikis kosulu olmayan LOOP, SLEEP veya bloklayan bekleme cagrisi."
    rationale = ("Master kontrol listesi PLS-010/PLS-012 ve CUR-026. Sonsuz dongu "
                 "veya uzun SLEEP, deployment penceresini tuketir, kilitleri tutar "
                 "ve calistirma motorunu sureli olarak bloke eder.")
    remediation = ("Dongulere kesin bir cikis kosulu (EXIT WHEN) ve maksimum "
                   "iterasyon sayaci ekleyin; SLEEP kullanmayin.")
    tags = ['plsql', 'PLS-010', 'dos', 'PLS-012']
    default_params = {"max_sleep_seconds": 5}

    def check(self, ctx):
        masked = ctx.masked
        # Sinirsiz LOOP: LOOP ... END LOOP arasinda EXIT/RETURN yok
        for m in re.finditer(r"(?<![\w$#])LOOP(?![\w$#])", masked, re.I):
            before = masked[max(0, m.start() - 80):m.start()].upper()
            if re.search(r"(?<![\w$#])(FOR|WHILE)(?![\w$#])", before):
                continue                       # sinirli dongu
            end = re.search(r"(?<![\w$#])END\s+LOOP(?![\w$#])", masked[m.end():], re.I)
            body = masked[m.end():m.end() + end.start()] if end else masked[m.end():]
            if not re.search(r"(?<![\w$#])(EXIT|RETURN|RAISE|GOTO)(?![\w$#])",
                             body, re.I):
                yield self.hit(ctx, offset=m.start(),
                               message="[PLS-010] Cikis kosulu olmayan LOOP "
                                       "(sonsuz dongu riski).")
        for m in re.finditer(r"(?<![\w$#])WHILE\s+TRUE(?![\w$#])", masked, re.I):
            yield self.hit(ctx, offset=m.start(),
                           message="[PLS-010] WHILE TRUE - sonsuz dongu.")

        limit = float(self.param("max_sleep_seconds", 5))
        for m in re.finditer(r"(DBMS_LOCK|DBMS_SESSION)\s*\.\s*SLEEP\s*\(\s*([\d.]+)?",
                             masked, re.I):
            secs = float(m.group(2)) if m.group(2) else None
            if secs is None or secs > limit:
                yield self.hit(ctx, offset=m.start(),
                               message="[PLS-012] %s.SLEEP(%s) - bloklayan bekleme "
                                       "(limit %.0f sn)."
                                       % (m.group(1).upper(),
                                          m.group(2) or "?", limit))
        for m in re.finditer(r"(DBMS_PIPE\s*\.\s*RECEIVE_MESSAGE|"
                             r"DBMS_ALERT\s*\.\s*WAITONE|DBMS_AQ\s*\.\s*DEQUEUE)",
                             masked, re.I):
            yield self.hit(ctx, offset=m.start(),
                           message="[PLS-012] Bloklayan bekleme cagrisi: %s"
                                   % m.group(0))
