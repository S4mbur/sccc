# -*- coding: utf-8 -*-
"""ORA252 - FK parent anahtari ve child index kontrolu (DDL-023, PERF-015)."""
import re
from core.model import BaseRule, Severity
from core.catalog import get_catalog
from core.helpers import object_after

WORD = r'"?[A-Za-z_$#][\w$#]*"?'


class CatalogFkRule(BaseRule):
    id = "ORA252"
    name = "FK parent anahtari / child index katalog kontrolu"
    category = "PREFLIGHT"
    severity = Severity.FAIL
    description = ("REFERENCES hedefinde PK/UK yok ya da FK kolonunda uygun "
                   "index bulunmuyor (katalogdan dogrulanir).")
    rationale = ("Master kontrol listesi DDL-023 ve PERF-015. Parent tabloda "
                 "unique anahtar yoksa FK olusturulamaz (ORA-02270). Child "
                 "tabloda soldan-prefix index yoksa parent DELETE'i child'i "
                 "kilitler - ayni scriptte CREATE INDEX aramak yeterli degildir.")
    remediation = ("Parent tabloda PK/UK oldugundan emin olun; child kolonlar icin "
                   "soldan-prefix uyumlu bir index olusturun.")
    tags = ['preflight', 'DDL-023', 'PERF-015', 'catalog', 'DDL-024']

    RX_FK = re.compile(
        r"FOREIGN\s+KEY\s*\(([^)]*)\)\s*REFERENCES\s+"
        r"((?:%s\s*\.\s*)?%s)\s*(?:\(([^)]*)\))?" % (WORD, WORD), re.I)

    def check(self, ctx):
        cat = get_catalog(ctx)
        if not cat.loaded:
            return
        for st in ctx.all_statements:
            if st.first_word not in ("ALTER", "CREATE"):
                continue
            child = object_after(st.masked, r"(?:ALTER\s+TABLE|CREATE\s+TABLE)")
            child_fq = re.sub(r"[\s\"]", "", child or "").upper()
            for m in self.RX_FK.finditer(st.masked):
                cols = [c.strip().strip('"').upper() for c in m.group(1).split(",")]
                parent = re.sub(r"[\s\"]", "", m.group(2)).upper()
                pcols = [c.strip().strip('"').upper()
                         for c in (m.group(3) or "").split(",") if c.strip()]

                if not cat.has_object(parent):
                    yield self.hit(ctx, offset=st.start_offset + m.start(),
                                   statement=st, object_name=parent,
                                   message="[DDL-023] FK parent tablosu '%s' "
                                           "katalogda yok." % parent)
                    continue
                uks = cat.unique_keys(parent)
                if pcols:
                    ok = any(uk == pcols for uk in uks)
                else:
                    ok = bool(uks)
                if not ok:
                    yield self.hit(ctx, offset=st.start_offset + m.start(),
                                   statement=st, object_name=parent,
                                   message="[DDL-023] '%s' uzerinde uygun PK/UK yok "
                                           "(ORA-02270). Katalogdaki anahtarlar: %s"
                                           % (parent, uks or "yok"))
                # PERF-015: child index gercek metadata'dan
                if child_fq:
                    have = cat.index_prefixes(child_fq)
                    covered = any(ix[:len(cols)] == cols for ix in have)
                    if not covered:
                        yield self.hit(ctx, offset=st.start_offset + m.start(),
                                       statement=st, object_name=child_fq,
                                       severity=Severity.WARN,
                                       message="[PERF-015] %s(%s) icin katalogda "
                                               "soldan-prefix index yok; parent "
                                               "DELETE child tabloyu kilitler."
                                               % (child_fq, ", ".join(cols)))
