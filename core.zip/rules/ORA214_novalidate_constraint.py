# -*- coding: utf-8 -*-
"""ORA214 - Constraint mevcut veriyi dogrulamadan devreye aliniyor."""
import re
from core.model import BaseRule, Severity


class NovalidateConstraintRule(BaseRule):
    id = "ORA214"
    name = "Constraint NOVALIDATE ile devreye aliniyor"
    category = "BUTUNLUK"
    severity = Severity.WARN
    description = "ENABLE NOVALIDATE / DISABLE VALIDATE / NOVALIDATE kullanilmis."
    rationale = ("NOVALIDATE, mevcut satirlarin kurala uygunlugunu kontrol etmez. "
                 "Tabloda kurala aykiri eski kayitlar kalir; raporlama ve mutabakat "
                 "bu kaydi 'gecerli' sanarak isler.")
    remediation = ("Once aykiri kayitlari tespit edip duzeltin, ardindan "
                   "ENABLE VALIDATE ile devreye alin. NOVALIDATE zorunluysa "
                   "aykiri kayit sayisini degisiklik kaydina yazin.")
    tags = ['integrity', 'constraint', 'DDL-022']

    PATTERNS = [
        (r"\bENABLE\s+NOVALIDATE\b", "ENABLE NOVALIDATE"),
        (r"\bDISABLE\s+VALIDATE\b", "DISABLE VALIDATE"),
        (r"(?<!ENABLE\s)(?<!DISABLE\s)\bNOVALIDATE\b", "NOVALIDATE"),
        (r"\bDISABLE\s+CONSTRAINT\b", "DISABLE CONSTRAINT"),
        (r"\bNORELY\b|\bRELY\b", "RELY / NORELY"),
    ]

    def check(self, ctx):
        seen = set()
        for pat, label in self.PATTERNS:
            for m in ctx.finditer(pat):
                if m.start in seen:
                    continue
                seen.add(m.start)
                yield self.hit(ctx, offset=m.start,
                               message="%s - mevcut veri dogrulanmiyor." % label)
