# -*- coding: utf-8 -*-
"""ORA200 - Dosya uzantisi (kurum deployment kurali 3)."""
import os
from core.model import BaseRule, Severity


class FileExtensionRule(BaseRule):
    id = "ORA200"
    name = "Gecersiz dosya uzantisi"
    category = "DBRUNNER"
    severity = Severity.FAIL
    description = "Calistirilacak sorgu dosyasinin uzantisi .sql, .txt veya .zip olmalidir."
    rationale = ("Deployment araci sadece izinli uzantilari isler. Diger dosya turleri "
                 "dikkate alinmaz; talep sessizce eksik calisir.")
    remediation = "Dosyayi .sql uzantisi ile yeniden gonderin (Nexus icin .zip)."
    tags = ["dbrunner", "dosya"]
    default_params = {"allowed": [".sql", ".txt", ".zip"]}

    def check(self, ctx):
        allowed = [e.lower() for e in self.param("allowed", [])]
        ext = os.path.splitext(ctx.filename)[1].lower()
        if ext not in allowed:
            yield self.hit(ctx, line=1,
                           message="Dosya uzantisi '%s' izinli degil (izinli: %s)."
                                   % (ext or "(yok)", ", ".join(allowed)))
