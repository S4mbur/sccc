# -*- coding: utf-8 -*-
"""ORA206 - Sorgunun devamina eklenmis satir yorumu (kurum kurali 10)."""
import re
from core.model import BaseRule, Severity


class InlineCommentRule(BaseRule):
    id = "ORA206"
    name = "Sorgunun devamina yorum eklenmis"
    category = "DBRUNNER"
    severity = Severity.FAIL
    description = ("Tek satirlik yorum (--) bir sorgunun devamina eklenemez; "
                   "yorum sorgunun ustune veya altina, kendi satirina yazilmalidir.")
    rationale = ("Deployment araci sorguyu satir bazli ayristirdigi icin satir sonundaki "
                 "yorum sorgunun parcasi sayilir ve calistirma sirasinda hata alinir.")
    remediation = ("YANLIS : UPDATE x SET y=z WHERE a=b; -- yorum satiri\n"
                   "DOGRU  : -- yorum satiri\n"
                   "         UPDATE x SET y=z WHERE a=b;")
    tags = ['dbrunner', 'yorum', 'sozdizimi', 'LEX-010']
    default_params = {
        # DDL create sorgularinda begin..end arasi bu kuraldan muaftir.
        "allow_in_plsql_block": True,
    }

    def check(self, ctx):
        allow_plsql = self.param("allow_in_plsql_block", True)
        for r in ctx.regions:
            if r.kind != "line_comment":
                continue
            line_start = ctx.raw.rfind("\n", 0, r.start) + 1
            before = ctx.raw[line_start:r.start]
            if not before.strip():
                continue                       # kendi satirinda -> dogru kullanim
            st = ctx.statement_at(r.start)
            if allow_plsql and st is not None and st.kind == "plsql":
                continue                       # begin..end arasi muaf
            yield self.hit(ctx, offset=r.start, statement=st,
                           message="Satir sonuna yorum eklenmis: %s"
                                   % ctx.raw[r.start:r.end].strip()[:60])
