# -*- coding: utf-8 -*-
"""ORA045 - Tekrar calistirilabilirlik (idempotency)."""
import re
from core.model import BaseRule, Severity


class RerunSafetyRule(BaseRule):
    id = "ORA045"
    name = "Script tekrar calistirilabilir degil"
    category = "SEMA"
    severity = Severity.WARN
    description = "CREATE / ALTER ADD ifadeleri var olan objede hata verir."
    rationale = ("Kesinti aninda script bastan calistirilir. Idempotent olmayan "
                 "script ikinci calistirmada ORA-00955 verip yarida kalir.")
    remediation = ("Kesinti aninda scripti bastan degil kaldigi adimdan calistirin; "
                   "ya da 'zaten var' hatasini (ORA-00955/ORA-01430) kabul edilebilir "
                   "sayin ve talep notuna yazin.\n"
                   "DIKKAT: EXECUTE IMMEDIATE ile kosullu DDL yazmayin - dinamik DDL "
                   "deployment aracinin obje tespitini ve versiyonlamasini bozar "
                   "(bkz. ORA227).")
    tags = ['idempotency', 'operations', 'TX-015']

    GUARD = r"(USER_OBJECTS|ALL_OBJECTS|USER_TAB_COLUMNS|ALL_TAB_COLUMNS|" \
            r"USER_TABLES|ALL_TABLES|USER_INDEXES|ALL_CONSTRAINTS|OR\s+REPLACE)"

    def check(self, ctx):
        guarded = bool(re.search(self.GUARD, ctx.masked, re.I))
        for st in ctx.statements:
            if st.first_word == "CREATE":
                if re.search(r"CREATE\s+OR\s+REPLACE", st.masked, re.I):
                    continue
                if guarded:
                    continue
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               message="'%s...' tekrar calistirilirsa ORA-00955 verir."
                                       % st.norm[:50])
            elif st.first_word == "ALTER" and re.search(
                    r"ALTER\s+TABLE\b[^;]*\bADD\b", st.masked, re.I) and not guarded:
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               message="'%s...' tekrar calistirilirsa ORA-01430 verir."
                                       % st.norm[:50])
