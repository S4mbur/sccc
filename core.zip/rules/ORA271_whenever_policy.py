# -*- coding: utf-8 -*-
"""ORA271 - WHENEVER / EXIT politikasi (CLI-013..CLI-018)."""
import re
from core.model import BaseRule, Severity


class WheneverPolicyRule(BaseRule):
    id = "ORA271"
    name = "WHENEVER / EXIT politikasi ihlali"
    category = "ISTEMCI"
    severity = Severity.FAIL
    description = ("WHENEVER SQLERROR CONTINUE, EXIT SUCCESS/0, hata yolunda COMMIT "
                   "veya gec tanimlanmis WHENEVER.")
    rationale = ("Master kontrol listesi CLI-013..CLI-018. Bu kaliplar hatayi "
                 "yutarak basarisiz bir deployment'i basarili gosterir; kismi "
                 "uygulanmis degisiklik uretimde kalir.")
    remediation = ("Scriptin ilk calistirilabilir komutundan ONCE:\n"
                   "  WHENEVER SQLERROR EXIT FAILURE ROLLBACK;\n"
                   "  WHENEVER OSERROR EXIT FAILURE ROLLBACK;")
    tags = ['client', 'CLI', 'errorhandling', 'CLI-013', 'CLI-014', 'CLI-015', 'CLI-016', 'CLI-017', 'CLI-018']

    def check(self, ctx):
        for m in ctx.finditer(r"WHENEVER\s+(SQLERROR|OSERROR)\s+([^\n;]*)"):
            kind, action = m.group(1).upper(), " ".join(m.group(2).split()).upper()
            if "CONTINUE" in action:
                yield self.hit(ctx, offset=m.start,
                               message="[CLI-013] WHENEVER %s CONTINUE - hata "
                                       "yok sayilir." % kind)
            if re.search(r"EXIT\s+(SUCCESS|0)\b", action):
                yield self.hit(ctx, offset=m.start,
                               message="[CLI-014] WHENEVER %s EXIT SUCCESS - "
                                       "hata basarili gorunur." % kind)
            if "COMMIT" in action:
                yield self.hit(ctx, offset=m.start,
                               message="[CLI-015] WHENEVER %s ... COMMIT - hata "
                                       "yolunda ROLLBACK olmali." % kind)

        # CLI-016: ilk calistirilabilir komuttan once tanimlanmali
        exec_sts = [s for s in ctx.statements if s.kind != "sqlplus"]
        wm = ctx.search(r"WHENEVER\s+SQLERROR")
        if exec_sts and wm and wm.start > exec_sts[0].start_offset:
            yield self.hit(ctx, offset=wm.start,
                           message="[CLI-016] WHENEVER SQLERROR ilk calistirilabilir "
                                   "komuttan (satir %d) SONRA tanimlanmis."
                                   % exec_sts[0].start_line)

        # CLI-018: EXIT son komut olmali ve SUCCESS/COMMIT olmamali
        for st in ctx.statements:
            if st.first_word not in ("EXIT", "QUIT"):
                continue
            up = st.upper
            if re.search(r"\b(SUCCESS|0)\b", up) and "FAILURE" not in up:
                # sonda ve kosulsuz EXIT SUCCESS kabul edilir, ama COMMIT olmamali
                pass
            if "COMMIT" in up:
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               message="[CLI-018] EXIT ... COMMIT - transaction "
                                       "karari runner'a aittir.")
            later = [x for x in ctx.statements
                     if x.start_offset > st.end_offset and x.norm.strip()]
            if later:
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               severity=Severity.WARN,
                               message="[CLI-018] EXIT son komut degil; sonrasinda "
                                       "%d ifade var." % len(later))
