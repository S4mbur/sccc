# -*- coding: utf-8 -*-
"""ORA051 - CREATE/REBUILD INDEX ONLINE degil."""
import re
from core.model import BaseRule, Severity
from core.helpers import object_after


class IndexOnlineRule(BaseRule):
    id = "ORA051"
    name = "Index islemi ONLINE degil"
    category = "PERFORMANS"
    severity = Severity.WARN
    description = "CREATE INDEX / ALTER INDEX REBUILD icin ONLINE belirtilmemis."
    rationale = ("ONLINE olmadan index olusturma tablo uzerinde DML'i bloke eder; "
                 "buyuk tablolarda uygulama kesintisi anlamina gelir.")
    remediation = "Ifadeye ONLINE (ve uygunsa PARALLEL + NOLOGGING sonrasi LOGGING) ekleyin."
    tags = ['performance', 'locking', 'ddl', 'DDL-035', 'PERF-019']

    def check(self, ctx):
        for st in ctx.statements:
            body = st.masked
            is_create = re.match(r"\s*CREATE\s+(UNIQUE\s+|BITMAP\s+)*INDEX\b", body, re.I)
            is_rebuild = re.search(r"ALTER\s+INDEX\b[^;]*\bREBUILD\b", body, re.I)
            if not (is_create or is_rebuild):
                continue
            if re.search(r"(?<![\w$#])ONLINE(?![\w$#])", body, re.I):
                continue
            name = object_after(body, r"INDEX")
            yield self.hit(ctx, offset=st.start_offset, statement=st, object_name=name,
                           message="%s icin ONLINE belirtilmemis (DML bloklanir)."
                                   % ("CREATE INDEX" if is_create else "REBUILD INDEX"))
        for st in ctx.statements:
            if re.search(r"ALTER\s+TABLE\b[^;]*\bMOVE\b", st.masked, re.I) and \
                    not re.search(r"(?<![\w$#])ONLINE(?![\w$#])", st.masked, re.I):
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               message="ALTER TABLE ... MOVE ONLINE degil.")
