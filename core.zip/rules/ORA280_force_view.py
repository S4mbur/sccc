# -*- coding: utf-8 -*-
"""ORA280 - FORCE VIEW ve gecersiz obje birakma (CUR-030, DDL-031)."""
import re
from core.model import BaseRule, Severity


class ForceViewRule(BaseRule):
    id = "ORA280"
    name = "FORCE VIEW / gecersiz obje birakma riski"
    category = "SEMA"
    severity = Severity.FAIL
    description = "CREATE FORCE VIEW veya ALTER ... COMPILE kullanilmis."
    rationale = ("Master kontrol listesi DDL-031 ve CUR-030. FORCE VIEW, bagimli "
                 "objeler olmasa bile view'i olusturur ve obje INVALID kalir. "
                 "Uygulama bu view'i cagirinca calisma zamaninda hata alir; "
                 "statik analiz bunu goremez, DB preflight gerekir.")
    remediation = ("FORCE kullanmayin. Bagimliliklari once olusturun ve deployment "
                   "sonrasi USER_OBJECTS.STATUS='VALID' kontrolu yapin.")
    tags = ['schema', 'DDL-031', 'preflight']

    def check(self, ctx):
        for m in ctx.finditer(r"CREATE\s+(OR\s+REPLACE\s+)?FORCE\s+"
                              r"(EDITIONING\s+)?VIEW\b"):
            yield self.hit(ctx, offset=m.start,
                           message="[DDL-031] FORCE VIEW - obje INVALID kalabilir.")
        for m in ctx.finditer(r"ALTER\s+\w+\s+[\w$#.\"]+\s+COMPILE\b"):
            yield self.hit(ctx, offset=m.start, severity=Severity.WARN,
                           message="[DDL-031] ALTER ... COMPILE - derleme sonucu "
                                   "DB preflight ile dogrulanmali.")
