# -*- coding: utf-8 -*-
"""ORA026 - Acik kilitleme."""
import re
from core.model import BaseRule, Severity


class LockTableRule(BaseRule):
    id = "ORA026"
    name = "Acik tablo kilidi"
    category = "TRANSACTION"
    severity = Severity.WARN
    description = "LOCK TABLE veya SELECT ... FOR UPDATE kullanilmis."
    rationale = ("Exclusive kilit, mesai icinde calistirilirsa uygulama tarafinda "
                 "bloklama ve zaman asimi zincirine yol acar.")
    remediation = ("Kilidi mumkun olan en dar kapsamda alin, NOWAIT / WAIT n ekleyin "
                   "ve calistirmayi bakim penceresine planlayin.")
    tags = ['transaction', 'locking', 'DDL-033']

    def check(self, ctx):
        for m in ctx.finditer(r"\bLOCK\s+TABLE\b"):
            tail = ctx.masked[m.start:m.start + 200].upper()
            has_wait = "NOWAIT" in tail or re.search(r"\bWAIT\s+\d+", tail)
            sev = Severity.WARN if has_wait else Severity.FAIL
            yield self.hit(ctx, offset=m.start, severity=sev,
                           message="LOCK TABLE%s" % ("" if has_wait
                                                     else " (NOWAIT/WAIT belirtilmemis)"))
        for m in ctx.finditer(r"\bFOR\s+UPDATE\b"):
            tail = ctx.masked[m.start:m.start + 120].upper()
            if "NOWAIT" in tail or re.search(r"\bWAIT\s+\d+", tail):
                continue
            yield self.hit(ctx, offset=m.start,
                           message="SELECT ... FOR UPDATE (NOWAIT/WAIT yok).")
