# -*- coding: utf-8 -*-
"""ORA250 - Katalogda olmayan obje referansi (DB-005, CUR-030)."""
import re
from core.model import BaseRule, Severity
from core.catalog import get_catalog

WORD = r'"?[A-Za-z_$#][\w$#]*"?'
ANCHORS = r"(?:FROM|JOIN|UPDATE|INSERT\s+INTO|DELETE\s+FROM|MERGE\s+INTO|" \
          r"ALTER\s+TABLE|COMMENT\s+ON\s+TABLE|REFERENCES)"


class CatalogObjectExistsRule(BaseRule):
    id = "ORA250"
    name = "Hedef obje veritabaninda yok"
    category = "PREFLIGHT"
    severity = Severity.FAIL
    description = "Script'in referans verdigi obje DB katalogunda bulunamadi."
    rationale = ("Master kontrol listesi DB-005. Statik analiz tek basina objenin "
                 "varligini dogrulayamaz; katalog verildiginde ORA-00942 riski "
                 "calistirmadan once tespit edilir.")
    remediation = ("Obje adini/owner'ini duzeltin veya objeyi olusturan scripti "
                   "ayni pakete, daha once calisacak sirayla ekleyin.")
    tags = ['preflight', 'DB-005', 'catalog', 'DB-006', 'DB-008', 'DB-021']

    def check(self, ctx):
        cat = get_catalog(ctx)
        if not cat.loaded:
            return                      # katalog yoksa kural sessizdir
        created = set()
        for st in ctx.all_statements:
            m = re.match(r"\s*CREATE\s+(?:OR\s+REPLACE\s+)?\w+[\w\s]*?"
                         r"((?:%s\s*\.\s*)?%s)" % (WORD, WORD), st.masked, re.I)
            if m:
                created.add(re.sub(r"[\s\"]", "", m.group(1)).upper())

        seen = set()
        for st in ctx.all_statements:
            if st.kind == "sqlplus":
                continue
            for m in re.finditer(r"(?<![\w$#.])%s\s+((?:%s\s*\.\s*)%s)"
                                 % (ANCHORS, WORD, WORD), st.masked, re.I):
                ref = re.sub(r"[\s\"]", "", m.group(1)).upper()
                if ref in seen or ref in created:
                    continue
                seen.add(ref)
                if ref.split(".")[0] in ("DUAL",):
                    continue
                if cat.has_object(ref):
                    obj = cat.objects[ref]
                    if obj.get("status") and obj["status"] != "VALID":
                        yield self.hit(ctx, offset=st.start_offset + m.start(1),
                                       statement=st, object_name=ref,
                                       severity=Severity.WARN,
                                       message="[DB-008] %s katalogda %s durumda."
                                               % (ref, obj["status"]))
                    continue
                yield self.hit(ctx, offset=st.start_offset + m.start(1),
                               statement=st, object_name=ref,
                               message="[DB-005] '%s' hedef veritabaninda yok "
                                       "(ORA-00942 alinir)." % ref)
