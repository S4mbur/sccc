# -*- coding: utf-8 -*-
"""ORA279 - Partition / kolon seviyesinde veri kaybi (CUR-028/029, DDL-018/019)."""
import re
from core.model import BaseRule, Severity


class PartitionDataLossRule(BaseRule):
    id = "ORA279"
    name = "Partition veya kolon seviyesinde veri kaybi riski"
    category = "YIKICI"
    severity = Severity.FAIL
    description = ("EXCHANGE/DROP/TRUNCATE/MERGE/SPLIT PARTITION, SET UNUSED, "
                   "DROP UNUSED COLUMNS veya RENAME islemi.")
    rationale = ("Master kontrol listesi DDL-016/018/019 ve CUR-028/029. "
                 "EXCHANGE PARTITION ... WITHOUT VALIDATION veri setini dogrulamadan "
                 "degistirir; SET UNUSED kolonu erisilemez yapar; RENAME bagimli "
                 "tum objeleri kirar. Hicbiri kolayca geri alinamaz.")
    remediation = ("Islemi ayri bir talep olarak, yedek kaniti ve bagimlilik "
                   "analizi ile gonderin.")
    tags = ['destructive', 'DDL-018', 'DDL-019', 'DDL-016']

    PATTERNS = [
        (r"EXCHANGE\s+PARTITION\b[^;]{0,200}?WITHOUT\s+VALIDATION",
         "EXCHANGE PARTITION ... WITHOUT VALIDATION (veri dogrulanmiyor)", "DDL-019"),
        (r"EXCHANGE\s+PARTITION\b", "EXCHANGE PARTITION", "DDL-018"),
        (r"DROP\s+PARTITION\b", "DROP PARTITION", "DDL-018"),
        (r"TRUNCATE\s+PARTITION\b", "TRUNCATE PARTITION", "DDL-018"),
        (r"MERGE\s+PARTITIONS?\b", "MERGE PARTITION", "DDL-018"),
        (r"SPLIT\s+PARTITION\b", "SPLIT PARTITION", "DDL-018"),
        (r"SET\s+UNUSED\b", "SET UNUSED (kolon erisilemez olur)", "DDL-018"),
        (r"DROP\s+UNUSED\s+COLUMNS\b", "DROP UNUSED COLUMNS", "DDL-018"),
        (r"^\s*RENAME\s+", "RENAME (bagimli objeler kirilir)", "DDL-016"),
        (r"ALTER\s+TABLE\b[^;]{0,200}?\bRENAME\s+(TO|COLUMN)\b",
         "ALTER TABLE ... RENAME", "DDL-016"),
        (r"INCLUDING\s+INDEXES|EXCLUDING\s+INDEXES",
         "INCLUDING/EXCLUDING INDEXES", "DDL-019"),
    ]

    def check(self, ctx):
        seen = set()
        for pat, label, code in self.PATTERNS:
            for m in ctx.finditer(pat, re.I | re.M | re.S):
                key = (m.line, label)
                if key in seen:
                    continue
                seen.add(key)
                yield self.hit(ctx, offset=m.start,
                               message="[%s] %s" % (code, label))
