# -*- coding: utf-8 -*-
"""ORA020 - DML var, COMMIT yok."""
import re
from core.model import BaseRule, Severity


class MissingCommitRule(BaseRule):
    id = "ORA020"
    name = "DML var ancak COMMIT yok"
    category = "TRANSACTION"
    severity = Severity.FAIL
    description = "Script veri degistiriyor fakat sonunda COMMIT bulunmuyor."
    rationale = ("Commit edilmemis transaction, oturum kapaninca rollback olur ya da "
                 "acik kalarak diger islemleri kilitler. Bloklama zinciri riskidir.")
    remediation = "Scriptin sonuna acikca COMMIT; ekleyin."
    tags = ["transaction"]

    def check(self, ctx):
        dml = ctx.dml_statements
        if not dml:
            return
        has_commit = any(re.match(r"\s*COMMIT\b", s.masked, re.I) for s in ctx.statements)
        has_commit = has_commit or bool(re.search(r"(?<![\w$#])COMMIT(?![\w$#])",
                                                  ctx.masked, re.I))
        if has_commit:
            return
        last = dml[-1]
        yield self.hit(ctx, offset=last.start_offset, statement=last,
                       message="%d adet DML var fakat script icinde COMMIT yok."
                               % len(dml))
