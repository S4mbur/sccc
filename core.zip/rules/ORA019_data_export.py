# -*- coding: utf-8 -*-
"""ORA019 - Toplu veri disari cikarma sinyalleri."""
import re
from core.model import BaseRule, Severity


class DataExportRule(BaseRule):
    id = "ORA019"
    name = "Toplu veri disari cikarma sinyali"
    category = "GUVENLIK"
    severity = Severity.WARN
    description = "SPOOL, external table, CTAS veya directory ile veri disari aliniyor."
    rationale = ("Musteri verisinin dosyaya yazilmasi KVKK kapsaminda veri isleme "
                 "faaliyetidir; maskeleme ve saklama kurallari uygulanmalidir.")
    remediation = ("Ciktiya kisisel veri gitmediginden emin olun, maskeleyin ve "
                   "dosyayi islem sonrasi guvenli sekilde silin.")
    tags = ['security', 'kvkk', 'dlp', 'DDL-030', 'SEC-021']

    PATTERNS = [
        (r"\bORGANIZATION\s+EXTERNAL\b", "External table"),
        (r"\bCREATE\s+(OR\s+REPLACE\s+)?DIRECTORY\b", "CREATE DIRECTORY"),
        (r"\bDBMS_LOB\s*\.\s*(WRITEAPPEND|FILEOPEN)", "DBMS_LOB dosya islemi"),
    ]

    def check(self, ctx):
        for pat, label in self.PATTERNS:
            for m in ctx.finditer(pat, re.I | re.M):
                yield self.hit(ctx, offset=m.start,
                               message="%s: %s" % (label, " ".join(m.text.split())))
