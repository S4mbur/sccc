# -*- coding: utf-8 -*-
"""ORA032 - Parantez dengesizligi."""
from core.model import BaseRule, Severity
from core.helpers import paren_balance


class ParenBalanceRule(BaseRule):
    id = "ORA032"
    name = "Parantez dengesizligi"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = "Ifade icinde acilan ve kapanan parantez sayisi esit degil."
    rationale = "Dengesiz parantez ORA-00907 gibi derleme/ayristirma hatasi uretir."
    remediation = "Eksik parantezi tamamlayin."
    tags = ["syntax"]

    def check(self, ctx):
        for st in ctx.statements:
            bal = paren_balance(st.masked)
            if bal != 0:
                yield self.hit(
                    ctx, offset=st.start_offset, statement=st,
                    message="Parantez dengesizligi: %+d (%s)"
                            % (bal, "fazla acilis" if bal > 0 else "fazla kapanis"))
