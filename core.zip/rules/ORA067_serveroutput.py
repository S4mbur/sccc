# -*- coding: utf-8 -*-
"""ORA067 - DBMS_OUTPUT kullanimi icin SERVEROUTPUT ayari."""
import re
from core.model import BaseRule, Severity


class ServerOutputRule(BaseRule):
    id = "ORA067"
    name = "DBMS_OUTPUT var ama SERVEROUTPUT acik degil"
    category = "STANDART"
    severity = Severity.WARN
    description = "DBMS_OUTPUT.PUT_LINE kullanilmis fakat SET SERVEROUTPUT ON yok."
    rationale = ("SERVEROUTPUT kapaliyken mesajlar hicbir yere yazilmaz; scriptin "
                 "ilerleme ve dogrulama ciktilari kaybolur."
                 )
    remediation = "Scriptin basina SET SERVEROUTPUT ON SIZE UNLIMITED; ekleyin."
    tags = ["standard", "sqlplus", "observability"]

    def check(self, ctx):
        uses = list(ctx.finditer(r"DBMS_OUTPUT\s*\.\s*PUT_LINE"))
        if not uses:
            return
        if re.search(r"\bSET\s+SERVEROUT(PUT)?\s+ON\b", ctx.masked, re.I):
            return
        yield self.hit(ctx, offset=uses[0].start,
                       message="%d adet DBMS_OUTPUT cagrisi var, "
                               "SET SERVEROUTPUT ON tanimlanmamis." % len(uses))
