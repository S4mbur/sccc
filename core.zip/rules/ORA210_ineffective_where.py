# -*- coding: utf-8 -*-
"""ORA210 - Etkisiz (her zaman dogru) WHERE / ON kosulu.

CUR-011/012/013, DML-003/005/006.
"""
import re
from core.model import BaseRule, Severity
from core.helpers import find_top_level, kw
from core.predicate import is_always_true, find_tautologies


class IneffectiveWhereRule(BaseRule):
    id = "ORA210"
    name = "Etkisiz WHERE / ON kosulu (her zaman dogru)"
    category = "BUTUNLUK"
    severity = Severity.FAIL
    description = ("UPDATE/DELETE/MERGE kosulu hicbir satiri elemiyor ya da bir OR "
                   "dalinda her zaman dogru bir ifade var.")
    rationale = ("Master kontrol listesi DML-005/DML-006. 'WHERE 1=1', 'WHERE ID=ID', "
                 "'WHERE X IS NULL OR X IS NOT NULL' veya 'WHERE ID=42 OR 1=1' "
                 "kaliplari, WHERE zorunlulugu kuralini sozde saglar ama pratikte "
                 "tablonun tamamini etkiler. MERGE icin daraltici ON zorunludur.")
    remediation = ("Kosulu gercekten daraltici hale getirin. Tum tabloyu etkilemek "
                   "gerekiyorsa gerekcesini ve beklenen satir sayisini talebe yazip "
                   "ayrica onaylatin.")
    tags = ["integrity", "DML-005", "DML-006", "bypass"]

    def check(self, ctx):
        for st in ctx.all_statements:
            if st.first_word not in ("UPDATE", "DELETE", "MERGE"):
                continue
            body = st.body

            # --- MERGE: ON kosulu (DML-003) ---
            if st.first_word == "MERGE":
                om = re.search(r"(?<![\w$#])ON\s*\(", body, re.I)
                if om:
                    depth, end = 0, len(body)
                    for i in range(om.end() - 1, len(body)):
                        if body[i] == "(":
                            depth += 1
                        elif body[i] == ")":
                            depth -= 1
                            if depth == 0:
                                end = i
                                break
                    pred = body[om.end():end]
                    why = is_always_true(pred)
                    if why:
                        yield self.hit(ctx, offset=st.start_offset + om.start(),
                                       statement=st,
                                       message="[DML-003] MERGE ON kosulu her zaman "
                                               "dogru (%s): tum hedef satirlar "
                                               "eslesir." % why)
                continue

            wm = find_top_level(body, kw("WHERE"))
            if not wm:
                continue                       # ORA003/ORA004 yakalar
            clause = body[wm.end():]
            cut = re.search(r"(?<![\w$#])(RETURNING|ORDER\s+BY|GROUP\s+BY)(?![\w$#])",
                            clause, re.I)
            if cut:
                clause = clause[:cut.start()]

            why = is_always_true(clause)
            if why:
                yield self.hit(ctx, offset=st.start_offset + wm.end(), statement=st,
                               message="[DML-006] %s kosulu HER ZAMAN DOGRU (%s) - "
                                       "tum tablo etkilenir: WHERE %s"
                                       % (st.first_word, why,
                                          " ".join(clause.split())[:60]))
                continue

            for frag, reason in find_tautologies(clause):
                yield self.hit(ctx, offset=st.start_offset + wm.end(), statement=st,
                               severity=Severity.WARN,
                               message="[DML-005] Kosulun bir parcasi her zaman "
                                       "dogru (%s): '%s'" % (reason, frag[:50]))
