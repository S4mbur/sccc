# -*- coding: utf-8 -*-
"""ORA050 - SELECT * kullanimi."""
import re
from core.model import BaseRule, Severity


class SelectStarRule(BaseRule):
    id = "ORA050"
    name = "SELECT * kullanimi"
    category = "PERFORMANS"
    severity = Severity.WARN
    description = "Kolon listesi yerine SELECT * kullanilmis."
    rationale = ("Tablo yapisi degistiginde kod sessizce bozulur, gereksiz kolonlar "
                 "okunarak I/O artar ve gizli kolonlar (kisisel veri) disari sizabilir.")
    remediation = "Ihtiyac duyulan kolonlari acikca yazin."
    tags = ["performance", "maintainability"]

    def check(self, ctx):
        for m in ctx.finditer(r"\bSELECT\s+(?:/\*\+.*?\*/\s*)?\*"):
            tail = ctx.masked[m.start:m.start + 200]
            if re.search(r"COUNT\s*\(\s*\*\s*\)", tail, re.I):
                continue
            yield self.hit(ctx, offset=m.start, message="SELECT * kullanilmis.")
