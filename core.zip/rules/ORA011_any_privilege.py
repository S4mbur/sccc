# -*- coding: utf-8 -*-
"""ORA011 - Genis kapsamli yetki (ANY / DBA / SYSDBA)."""
import re
from core.model import BaseRule, Severity


class AnyPrivilegeRule(BaseRule):
    id = "ORA011"
    name = "Genis kapsamli yetki verilmis"
    category = "GUVENLIK"
    severity = Severity.FAIL
    description = "ANY privilege, DBA rolu veya SYSDBA/SYSOPER yetkisi veriliyor."
    rationale = ("En az yetki (least privilege) ilkesini ihlal eder. Bu yetkiler "
                 "gorev ayriligi (SoD) kontrollerini bypass eder ve denetimde bulgudur.")
    remediation = ("Yetkiyi obje bazinda (GRANT SELECT ON sema.tablo TO rol) verin. "
                   "DBA/SYSDBA gereksinimini guvenlik ekibine onaylatın.")
    tags = ["security", "privilege", "sod"]
    default_params = {
        "privileges": ["DBA", "SYSDBA", "SYSOPER", "SYSBACKUP", "SYSKM", "SYSASM",
                       "IMP_FULL_DATABASE", "EXP_FULL_DATABASE", "GRANT ANY PRIVILEGE",
                       "ALTER SYSTEM", "UNLIMITED TABLESPACE", "BECOME USER"],
    }

    def check(self, ctx):
        for st in ctx.statements:
            if st.first_word not in ("GRANT", "REVOKE"):
                continue
            up = st.upper
            for m in re.finditer(
                    r"\b(SELECT|INSERT|UPDATE|DELETE|EXECUTE|CREATE|ALTER|DROP|READ|"
                    r"WRITE|MANAGE|LOCK|FLASHBACK|DEBUG|UNDER|GRANT)\s+ANY\s+"
                    r"[A-Z]+(?:\s+VIEW)?", up):
                yield self.hit(ctx, offset=st.start_offset + m.start(), statement=st,
                               message="ANY yetkisi: %s" % " ".join(m.group(0).split()))
            for priv in self.param("privileges", []):
                pat = r"(?<![\w$#])" + priv.replace(" ", r"\s+") + r"(?![\w$#])"
                for m in re.finditer(pat, up):
                    yield self.hit(ctx, offset=st.start_offset + m.start(), statement=st,
                                   message="Yuksek yetki: %s" % priv)
            if re.search(r"\bWITH\s+ADMIN\s+OPTION\b", up):
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               message="WITH ADMIN OPTION - yetki devredilebilir hale geliyor.")
            if re.search(r"\bWITH\s+GRANT\s+OPTION\b", up):
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               severity=Severity.WARN,
                               message="WITH GRANT OPTION - yetki zinciri olusuyor.")
