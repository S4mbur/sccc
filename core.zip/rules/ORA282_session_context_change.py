# -*- coding: utf-8 -*-
"""ORA282 - Oturum baglami degisikligi (SEC-032, SEC-033)."""
import re
from core.model import BaseRule, Severity


class SessionContextRule(BaseRule):
    id = "ORA282"
    name = "Oturum baglami degistiriliyor"
    category = "GUVENLIK"
    severity = Severity.FAIL
    description = ("ALTER SESSION SET CURRENT_SCHEMA / CONTAINER / EDITION veya "
                   "gizli parametre/event ayari.")
    rationale = ("Master kontrol listesi SEC-032/SEC-033. CURRENT_SCHEMA "
                 "degistirildiginde owner oneksiz tum ifadeler BASKA bir semada "
                 "calisir; statik analizde gorunen hedef ile gercek hedef ayrisir. "
                 "Oturum baglami runner tarafindan sabitlenmelidir.")
    remediation = ("Bu komutu kaldirin ve tum objeleri OWNER.OBJE seklinde "
                   "nitelendirin.")
    tags = ['security', 'SEC-032', 'session', 'SEC-033', 'PLS-022']

    PATTERNS = [
        (r"ALTER\s+SESSION\s+SET\s+CURRENT_SCHEMA", "CURRENT_SCHEMA", "SEC-032"),
        (r"ALTER\s+SESSION\s+SET\s+CONTAINER", "CONTAINER (PDB degisimi)", "SEC-032"),
        (r"ALTER\s+SESSION\s+SET\s+EDITION", "EDITION", "SEC-032"),
        (r"ALTER\s+SESSION\s+SET\s+\"?_[\w$#]+", "gizli parametre", "SEC-032"),
        (r"ALTER\s+SESSION\s+SET\s+EVENTS", "EVENTS", "SEC-032"),
        (r"ALTER\s+SESSION\s+SET\s+PLSQL_(WARNINGS|OPTIMIZE_LEVEL|CODE_TYPE|CCFLAGS)",
         "PL/SQL derleme ayari", "PLS-022"),
        (r"DBMS_SESSION\s*\.\s*SET_(CONTEXT|IDENTIFIER|ROLE)", "DBMS_SESSION", "SEC-032"),
    ]

    def check(self, ctx):
        for pat, label, code in self.PATTERNS:
            for m in ctx.finditer(pat):
                yield self.hit(ctx, offset=m.start,
                               message="[%s] Oturum baglami degisikligi: %s"
                                       % (code, label))
