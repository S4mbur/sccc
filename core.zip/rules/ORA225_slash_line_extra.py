# -*- coding: utf-8 -*-
"""ORA225 - '/' sonlandirici satirinda fazladan karakter."""
import re
from core.model import BaseRule, Severity


class SlashLineExtraRule(BaseRule):
    id = "ORA225"
    name = "'/' satirinda fazladan karakter veya yorum var"
    category = "DBRUNNER"
    severity = Severity.FAIL
    description = "PL/SQL sonlandiricisi '/' tek basina bir satirda olmalidir."
    rationale = ("SQL*Plus '/' karakterini yalnizca satirda tek basina oldugunda "
                 "calistirma komutu olarak kabul eder. '/ -- yorum' seklinde "
                 "yazildiginda blok calistirilmaz ve session INACTIVE kalir.")
    remediation = "Yorumu ayri satira alin; '/' satirinda baska hicbir sey olmasin."
    tags = ['dbrunner', 'dokuman-m11', 'plsql', 'LEX-012', 'CLI-034']

    def check(self, ctx):
        for i, line in enumerate(ctx.lines, start=1):
            stripped = line.strip()
            if not stripped.startswith("/") or stripped.startswith("/*"):
                continue
            if stripped == "/":
                continue
            yield self.hit(ctx, line=i,
                           message="'/' satirinda fazladan icerik: %s" % stripped[:60])
