# -*- coding: utf-8 -*-
"""ORA040 - Sema oneki olmayan obje referansi."""
import re
from core.model import BaseRule, Severity

WORD = r"[A-Za-z_$#][\w$#]*"
QUALIFIED = r'(?:"?%s"?\s*\.\s*)?"?%s"?' % (WORD, WORD)


class UnqualifiedObjectRule(BaseRule):
    id = "ORA040"
    name = "Sema oneki olmayan obje referansi"
    category = "SEMA"
    severity = Severity.WARN
    description = "Tablo/view referansinda SEMA.OBJE formati kullanilmamis."
    rationale = ("Sema oneki yoksa script hangi kullanici ile calistirildigina gore "
                 "farkli semayi hedefler. Yanlis ortamda yanlis tabloyu degistirebilir.")
    remediation = "Tum obje referanslarini SEMA.OBJE seklinde nitelendirin."
    tags = ['schema', 'portability', 'DDL-014']
    default_params = {
        "ignore_objects": ["DUAL", "SYSDATE", "SYSTIMESTAMP", "USER", "TABLE",
                           "SELECT", "VALUES", "LATERAL", "ONLY", "XMLTABLE", "JSON_TABLE"],
        # Veri sozlugu view'leri ve gecici tablolar haric tutulur
        "ignore_patterns": [r"^(USER|ALL|DBA|CDB)_", r"^V\$", r"^GV\$", r"^X\$",
                            r"^(V_|L_|P_|G_|R_|C_)", r"^SYS\."],
    }

    ANCHORS = r"(?:FROM|JOIN|UPDATE|INSERT\s+INTO|DELETE\s+FROM|MERGE\s+INTO)"

    def check(self, ctx):
        ignore = {o.upper() for o in self.param("ignore_objects", [])}
        pats = [re.compile(p, re.I) for p in self.param("ignore_patterns", [])]
        for st in ctx.all_statements:
            if st.kind == "sqlplus":
                continue
            body = st.masked
            ctes = {m.group(1).upper() for m in
                    re.finditer(r"(?:WITH|,)\s*(%s)\s+AS\s*\(" % WORD, body, re.I)}
            locals_ = {m.group(1).upper() for m in
                       re.finditer(r"(?:CURSOR|TYPE)\s+(%s)" % WORD, body, re.I)}
            seen = set()
            for m in re.finditer(r"(?<![\w$#.])%s\s+(%s)" % (self.ANCHORS, QUALIFIED),
                                 body, re.I):
                ref = m.group(1).strip()
                if "." in ref:                       # zaten nitelendirilmis
                    continue
                name = ref.strip('"')
                up = name.upper()
                if up in ignore or up in ctes or up in locals_ or up in seen:
                    continue
                if any(p.match(up) for p in pats):
                    continue
                seen.add(up)
                yield self.hit(ctx, offset=st.start_offset + m.start(1), statement=st,
                               object_name=name,
                               message="Sema oneki yok: %s (SEMA.%s bekleniyor)"
                                       % (name, name))
