# -*- coding: utf-8 -*-
"""ORA251 - Katalogda olmayan kolon (DB-005, DML-017)."""
import re
from core.model import BaseRule, Severity
from core.catalog import get_catalog

WORD = r'"?[A-Za-z_$#][\w$#]*"?'


class CatalogColumnExistsRule(BaseRule):
    id = "ORA251"
    name = "Hedef kolon veritabaninda yok"
    category = "PREFLIGHT"
    severity = Severity.FAIL
    description = "INSERT kolon listesi veya UPDATE SET hedefi katalogda bulunamadi."
    rationale = ("Master kontrol listesi DB-005/DML-017. Yanlis kolon adi "
                 "ORA-00904 verir; script yarida kalir ve onceki adimlar "
                 "commit edilmisse veri tutarsiz kalir.")
    remediation = "Kolon adini duzeltin veya kolonu ekleyen DDL'i once calistirin."
    tags = ['preflight', 'DB-005', 'catalog', 'DML-017']

    def check(self, ctx):
        cat = get_catalog(ctx)
        if not cat.loaded:
            return
        for st in ctx.all_statements:
            if st.first_word == "INSERT":
                m = re.match(r"\s*INSERT\s+INTO\s+((?:%s\s*\.\s*)?%s)\s*\(([^)]*)\)"
                             % (WORD, WORD), st.masked, re.I | re.S)
                if not m:
                    continue
                table = re.sub(r"[\s\"]", "", m.group(1)).upper()
                for col in m.group(2).split(","):
                    name = col.strip().strip('"')
                    if not re.match(r"^[A-Za-z_$#][\w$#]*$", name):
                        continue
                    if cat.has_column(table, name) is False:
                        yield self.hit(ctx, offset=st.start_offset + m.start(2),
                                       statement=st, object_name="%s.%s" % (table, name),
                                       message="[DB-005] %s tablosunda '%s' kolonu "
                                               "yok (ORA-00904)." % (table, name))
            elif st.first_word == "UPDATE":
                m = re.match(r"\s*UPDATE\s+((?:%s\s*\.\s*)?%s)\s+SET\s+(.*)"
                             % (WORD, WORD), st.body, re.I | re.S)
                if not m:
                    continue
                table = re.sub(r"[\s\"]", "", m.group(1)).upper()
                clause = re.split(r"(?i)(?<![\w$#])WHERE(?![\w$#])", m.group(2))[0]
                for assign in clause.split(","):
                    cm = re.match(r"\s*([A-Za-z_$#][\w$#]*)\s*=", assign)
                    if not cm:
                        continue
                    if cat.has_column(table, cm.group(1)) is False:
                        yield self.hit(ctx, offset=st.start_offset, statement=st,
                                       object_name="%s.%s" % (table, cm.group(1)),
                                       message="[DB-005] %s tablosunda '%s' kolonu "
                                               "yok (ORA-00904)."
                                               % (table, cm.group(1)))
