# -*- coding: utf-8 -*-
"""ORA054 - Optimizer hint ve PARALLEL kullanimi."""
import re
from core.model import BaseRule, Severity


class HintParallelRule(BaseRule):
    id = "ORA054"
    name = "Optimizer hint / PARALLEL kullanimi"
    category = "PERFORMANS"
    severity = Severity.WARN
    description = "Sorgu hint'i veya yuksek dereceli PARALLEL tanimlanmis."
    rationale = ("Hint'ler optimizer'i sabitler; veri dagilimi degisince plan bozulur. "
                 "Yuksek PARALLEL derecesi CPU ve PX server kaynagini tuketip diger "
                 "islemleri yavaslatir.")
    remediation = ("Hint yerine guncel istatistik ve dogru index kullanin. PARALLEL "
                   "derecesini kurum limitinde tutun ve islem sonrasi NOPARALLEL yapin.")
    tags = ["performance", "optimizer"]
    default_params = {"max_parallel_degree": 8}

    def check(self, ctx):
        limit = int(self.param("max_parallel_degree", 8))
        for m in ctx.findall_raw(r"/\*\+(.{0,200}?)\*/", re.S):
            yield self.hit(ctx, offset=m.start, severity=Severity.INFO,
                           message="Optimizer hint: %s" % " ".join(m.text.split())[:100])
        for m in ctx.findall_raw(r"(?<![\w$#])PARALLEL\s*\(?\s*(\d+)"):
            deg = int(m.group(1))
            if deg > limit:
                yield self.hit(ctx, offset=m.start,
                               message="PARALLEL %d, kurum limiti %d." % (deg, limit))
        for m in ctx.findall_raw(r"/\*\+[^*]*\bFULL\s*\("):
            yield self.hit(ctx, offset=m.start,
                           message="FULL hint - tam tablo taramasi zorlaniyor.")
