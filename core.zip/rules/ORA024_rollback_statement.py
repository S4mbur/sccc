# -*- coding: utf-8 -*-
"""ORA024 - Script icinde ROLLBACK / SAVEPOINT."""
import re
from core.model import BaseRule, Severity


class RollbackStatementRule(BaseRule):
    id = "ORA024"
    name = "ROLLBACK / SAVEPOINT ifadesi"
    category = "TRANSACTION"
    severity = Severity.WARN
    description = "Script icinde ROLLBACK veya SAVEPOINT var."
    rationale = ("Test sirasinda birakilmis ROLLBACK, degisikligin uretimde hic "
                 "uygulanmamasina neden olur - sessiz basarisizliktir.")
    remediation = ("Test amacli ROLLBACK'leri temizleyin. Hata yakalama icin "
                   "kullaniliyorsa EXCEPTION blogu icinde oldugunu dogrulayin.")
    tags = ["transaction"]

    def check(self, ctx):
        for m in ctx.finditer(r"(?<![\w$#])ROLLBACK(?![\w$#])"):
            st = ctx.statement_at(m.start)
            # WHENEVER SQLERROR EXIT FAILURE ROLLBACK dogru kullanimdir, atlanir.
            if st is not None and st.first_word == "WHENEVER":
                continue
            yield self.hit(ctx, offset=m.start, statement=st,
                           message="ROLLBACK ifadesi - test artigi olabilir.")
        for m in ctx.finditer(r"(?<![\w$#])SAVEPOINT(?![\w$#])"):
            yield self.hit(ctx, offset=m.start, severity=Severity.INFO,
                           message="SAVEPOINT kullanilmis.")
