# -*- coding: utf-8 -*-
"""ORA066 - Ortama ozel (DEV/TEST) referanslar."""
import re
from core.model import BaseRule, Severity


class EnvironmentLeakRule(BaseRule):
    id = "ORA066"
    name = "Ortama ozel referans"
    category = "STANDART"
    severity = Severity.FAIL
    description = "Script icinde DEV/TEST/UAT ortamina ait isim, IP veya sunucu var."
    rationale = ("Uretime giden scriptte test ortami referansi kalirsa islem yanlis "
                 "sisteme baglanir veya hata verir. Sik gorulen dagitim hatasidir.")
    remediation = ("Ortama ozel degerleri degisken (&&ortam) veya ayri config dosyasi "
                   "ile disariya alin.")
    tags = ['standard', 'deployment', 'OPS-002']
    default_params = {
        "tokens": ["DEV", "TEST", "UAT", "SIT", "PREPROD", "STAGING", "LOCALHOST",
                   "SANDBOX", "DENEME"],
        "flag_ip": True,
    }

    def check(self, ctx):
        tokens = [t.upper() for t in self.param("tokens", [])]
        if tokens:
            pat = r"(?<![\w$#])(%s)[_\.\-]?[\w$#]*" % "|".join(re.escape(t) for t in tokens)
            seen = set()
            for m in ctx.finditer(pat):
                key = m.text.upper()
                if key in seen:
                    continue
                seen.add(key)
                yield self.hit(ctx, offset=m.start,
                               message="Ortam referansi olabilir: %s" % m.text)
        if self.param("flag_ip", True):
            for m in ctx.findall_raw(r"(?<![\w.])\d{1,3}(?:\.\d{1,3}){3}(?![\w.])"):
                yield self.hit(ctx, offset=m.start, severity=Severity.WARN,
                               message="Script icinde IP adresi: %s" % m.text)
