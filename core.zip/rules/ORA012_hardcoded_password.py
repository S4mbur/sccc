# -*- coding: utf-8 -*-
"""ORA012 - Script icinde acik sifre / kimlik bilgisi."""
import re
from core.model import BaseRule, Severity


class HardcodedCredentialRule(BaseRule):
    id = "ORA012"
    name = "Script icinde acik kimlik bilgisi"
    category = "GUVENLIK"
    severity = Severity.FAIL
    description = "IDENTIFIED BY, CONNECT user/pass veya benzeri acik sifre var."
    rationale = ("Sifre scriptte, versiyon kontrolunde ve log/spool ciktisinda "
                 "duz metin kalir. KVKK ve bilgi guvenligi politikasi ihlalidir.")
    remediation = ("Sifreyi scriptten cikarin; wallet, degisken (&&pwd) veya vault "
                   "kullanin. Zorunluysa IDENTIFIED BY VALUES yerine ayri kanal kullanin.")
    tags = ["security", "credential", "kvkk"]

    # Ham metinde de aranir; yorum satirinda sifre birakmak da ihlaldir.
    PATTERNS = [
        (r"\bIDENTIFIED\s+BY\s+(?!VALUES)[\w\"'#$]+", "IDENTIFIED BY"),
        (r"\bIDENTIFIED\s+BY\s+VALUES\b", "IDENTIFIED BY VALUES (hash)"),
        (r"^\s*(CONNECT|CONN)\s+[\w$#]+\s*/\s*\S+", "CONNECT kullanici/sifre"),
        (r"\b(PASSWORD|PASSWD|PWD|SIFRE|PAROLA)\s*[:=]\s*['\"]?\S+", "Acik parola atamasi"),
        (r"\bUSING\s+'[^']*'", "DB LINK USING/parola ifadesi"),
    ]

    def check(self, ctx):
        for pat, label in self.PATTERNS:
            for m in ctx.findall_raw(pat, re.I | re.M):
                yield self.hit(ctx, offset=m.start,
                               message="%s tespit edildi (satir maskelenmeli)." % label)
