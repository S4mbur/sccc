# -*- coding: utf-8 -*-
"""ORA022 - Ayni scriptte DDL ve DML karisik."""
import re
from core.model import BaseRule, Severity


class DdlDmlMixedRule(BaseRule):
    id = "ORA022"
    name = "Ayni scriptte DDL ve DML karisik"
    category = "TRANSACTION"
    severity = Severity.WARN
    description = "DDL implicit commit uretir; oncesindeki DML'i geri alamazsiniz."
    rationale = ("DDL calistiginda bekleyen tum DML otomatik commit edilir. Hata "
                 "durumunda kismi degisiklik kalici olur ve rollback plani calismaz.")
    remediation = ("DDL ve DML'i ayri scriptlere bolun (once yapisal degisiklik, "
                   "sonra veri) ve her birini ayri adim olarak calistirin.")
    tags = ["transaction", "ddl"]

    def check(self, ctx):
        dml = ctx.dml_statements
        ddl = [s for s in ctx.ddl_statements
               if s.first_word not in ("GRANT", "REVOKE", "COMMENT")]
        if not dml or not ddl:
            return
        first_dml = dml[0]
        after = [d for d in ddl if d.start_offset > first_dml.start_offset]
        if not after:
            return
        d = after[0]
        yield self.hit(ctx, offset=d.start_offset, statement=d,
                       message="DML (satir %d) sonrasi DDL (%s) implicit commit uretir."
                               % (first_dml.start_line, d.first_word))
