# -*- coding: utf-8 -*-
"""ORA031 - BEGIN/END dengesizligi."""
import re
from core.model import BaseRule, Severity


class BlockBalanceRule(BaseRule):
    id = "ORA031"
    name = "BEGIN / END dengesizligi"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = "PL/SQL bloklarinda BEGIN ve END sayilari uyusmuyor."
    rationale = ("Kapanmayan blok derleme hatasina yol acar; script yarim kalir."
                 " CASE/LOOP/IF yapilarinin da kapatilmasi gerekir.")
    remediation = "Eksik END; ifadelerini tamamlayin."
    tags = ['syntax', 'plsql', 'LEX-018']

    def check(self, ctx):
        for st in ctx.statements:
            if st.kind != "plsql":
                continue
            body = st.masked
            # "END IF/LOOP/CASE" ifadelerini tek bir END'e indirge ki
            # icindeki IF/LOOP/CASE kelimeleri acilis sayilmasin.
            body = re.sub(r"(?<![\w$#])END\s+(IF|LOOP|CASE)(?![\w$#])", "END",
                          body, flags=re.I)
            opens = len(re.findall(r"(?<![\w$#])(BEGIN|CASE|IF|LOOP)(?![\w$#])",
                                   body, re.I))
            # PACKAGE / PACKAGE BODY / TYPE BODY govdesi BEGIN'siz blok acar
            if re.match(r"\s*CREATE\b[^;]{0,120}?(?<![\w$#])"
                        r"(PACKAGE|TYPE\s+BODY)(?![\w$#])", body, re.I):
                opens += 1
            closes = len(re.findall(r"(?<![\w$#])END(?![\w$#])", body, re.I))
            if opens != closes:
                yield self.hit(
                    ctx, offset=st.start_offset, statement=st,
                    message="Blok dengesizligi: acilis %d (BEGIN/IF/LOOP/CASE) - "
                            "kapanis %d (END)." % (opens, closes))
