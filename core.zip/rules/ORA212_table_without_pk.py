# -*- coding: utf-8 -*-
"""ORA212 - Yeni tabloda birincil anahtar yok."""
import re
from core.model import BaseRule, Severity
from core.helpers import object_after


class TableWithoutPkRule(BaseRule):
    id = "ORA212"
    name = "Yeni tabloda PRIMARY KEY tanimlanmamis"
    category = "BUTUNLUK"
    severity = Severity.WARN
    description = "CREATE TABLE ifadesinde ve scriptin devaminda PK tanimi bulunamadi."
    rationale = ("Birincil anahtari olmayan tabloda tekrarli kayit olusabilir; "
                 "replikasyon, mutabakat ve satir bazli guncelleme guvenilir calismaz.")
    remediation = ("Tabloya PRIMARY KEY ekleyin:\n"
                   "  ALTER TABLE OWNER.TABLO ADD CONSTRAINT PK_TABLO PRIMARY KEY (ID);")
    tags = ['integrity', 'ddl', 'DDL-024']

    def check(self, ctx):
        for st in ctx.statements:
            if not re.match(r"\s*CREATE\s+(GLOBAL\s+TEMPORARY\s+)?TABLE\b",
                            st.masked, re.I):
                continue
            name = object_after(st.masked, r"TABLE")
            short = name.split(".")[-1].strip('"').upper() if name else ""
            if re.search(r"(?<![\w$#])PRIMARY\s+KEY(?![\w$#])", st.masked, re.I):
                continue
            # scriptin devaminda ALTER TABLE ... ADD ... PRIMARY KEY var mi
            later = False
            for other in ctx.statements:
                if other.start_offset <= st.start_offset:
                    continue
                if not re.match(r"\s*ALTER\s+TABLE\b", other.masked, re.I):
                    continue
                if short and short not in other.upper:
                    continue
                if re.search(r"(?<![\w$#])PRIMARY\s+KEY(?![\w$#])", other.masked, re.I):
                    later = True
                    break
            if later:
                continue
            # Tablo uzerinde UNIQUE INDEX varsa islevsel olarak yakindir ->
            # bulgu INFO'ya duser ama constraint yine de beyan edilmelidir.
            uniq = False
            for other in ctx.statements:
                if re.search(r"CREATE\s+UNIQUE\s+INDEX\b", other.masked, re.I) and \
                        short and short in other.upper:
                    uniq = True
                    break
            if uniq:
                yield self.hit(ctx, offset=st.start_offset, statement=st,
                               object_name=name, severity=Severity.INFO,
                               message="%s icin UNIQUE INDEX var ama PRIMARY KEY "
                                       "constraint'i beyan edilmemis (FK referansi ve "
                                       "metadata icin gerekli)." % name)
                continue
            yield self.hit(ctx, offset=st.start_offset, statement=st, object_name=name,
                           message="%s tablosu icin PRIMARY KEY tanimlanmamis." % name)
