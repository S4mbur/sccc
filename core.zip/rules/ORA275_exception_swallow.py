# -*- coding: utf-8 -*-
"""ORA275 - Hata yutan exception handler (PLS-006..009, CUR-025)."""
import re
from core.model import BaseRule, Severity


class ExceptionSwallowRule(BaseRule):
    id = "ORA275"
    name = "Hatayi yutan exception handler"
    category = "DINAMIK"
    severity = Severity.FAIL
    description = "WHEN OTHERS blogu hatayi yeniden firlatmiyor."
    rationale = ("Master kontrol listesi PLS-006..009. 'WHEN OTHERS THEN NULL' "
                 "veya sadece loglayan handler, basarisiz bir deployment'i "
                 "basarili gosterir; kismi uygulanmis degisiklik uretimde kalir "
                 "ve kimse fark etmez.")
    remediation = ("Handler icinde RAISE veya RAISE_APPLICATION_ERROR ile hatayi "
                   "yeniden firlatin:\n"
                   "  WHEN OTHERS THEN\n"
                   "    ROLLBACK;\n"
                   "    RAISE;")
    tags = ['plsql', 'PLS-006', 'errorhandling', 'PLS-007', 'PLS-008', 'PLS-009']

    def check(self, ctx):
        masked = ctx.masked
        for m in re.finditer(r"(?<![\w$#])WHEN\s+OTHERS\s+THEN", masked, re.I):
            # handler govdesi: bir sonraki WHEN veya END'e kadar
            rest = masked[m.end():]
            stop = re.search(r"(?<![\w$#])(WHEN\s+|END\s*;|END\s+[\w$#]+\s*;)",
                             rest, re.I)
            body = rest[:stop.start()] if stop else rest
            norm = " ".join(body.split()).upper()

            if re.match(r"^NULL\s*;?$", norm):
                yield self.hit(ctx, offset=m.start(),
                               message="[PLS-006] WHEN OTHERS THEN NULL - hata "
                                       "tamamen yutuluyor.")
                continue
            if not re.search(r"(?<![\w$#])(RAISE|RAISE_APPLICATION_ERROR)(?![\w$#])",
                             body, re.I):
                yield self.hit(ctx, offset=m.start(),
                               message="[PLS-007] WHEN OTHERS handler'i hatayi "
                                       "yeniden firlatmiyor: '%s'" % norm[:60])
            if re.search(r"(?<![\w$#])COMMIT(?![\w$#])", body, re.I):
                yield self.hit(ctx, offset=m.start(),
                               message="[PLS-008] Exception handler icinde COMMIT - "
                                       "hatali durum kalici hale geliyor.")
