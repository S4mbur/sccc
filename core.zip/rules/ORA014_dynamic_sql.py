# -*- coding: utf-8 -*-
"""ORA014 - Dinamik SQL / string birlestirme."""
import re
from core.model import BaseRule, Severity


class DynamicSqlRule(BaseRule):
    id = "ORA014"
    name = "Dinamik SQL kullanimi"
    category = "GUVENLIK"
    severity = Severity.WARN
    description = "EXECUTE IMMEDIATE / DBMS_SQL ile dinamik SQL calistiriliyor."
    rationale = ("Dinamik SQL statik olarak analiz edilemez; icerigi bu parser "
                 "tarafindan denetlenemez ve SQL injection yuzeyi acar.")
    remediation = ("Mumkunse statik SQL kullanin. Zorunluysa bind degisken (USING) "
                   "kullanin ve obje adlarini DBMS_ASSERT ile dogrulayin.")
    tags = ["security", "plsql"]

    def check(self, ctx):
        for m in ctx.finditer(r"\bEXECUTE\s+IMMEDIATE\b"):
            st = ctx.statement_at(m.start)
            tail = ctx.masked[m.start:m.start + 400]
            concat = "||" in tail.split(";")[0]
            sev = Severity.FAIL if concat else self.severity
            msg = "EXECUTE IMMEDIATE" + (" + string birlestirme (||) - injection riski"
                                         if concat else "")
            yield self.hit(ctx, offset=m.start, severity=sev, statement=st, message=msg)
        for m in ctx.finditer(r"\bDBMS_SQL\s*\.\s*\w+"):
            yield self.hit(ctx, offset=m.start,
                           message="DBMS_SQL kullanimi: %s" % m.text)
