# -*- coding: utf-8 -*-
"""ORA221 - Taninmayan / yanlis yazilmis SQL komutu."""
import difflib
import re
from core.model import BaseRule, Severity

KNOWN = {
    "SELECT", "INSERT", "UPDATE", "DELETE", "MERGE", "CREATE", "ALTER", "DROP",
    "TRUNCATE", "GRANT", "REVOKE", "COMMENT", "RENAME", "COMMIT", "ROLLBACK",
    "SAVEPOINT", "SET", "LOCK", "EXPLAIN", "ANALYZE", "AUDIT", "NOAUDIT", "PURGE",
    "FLASHBACK", "CALL", "EXEC", "EXECUTE", "BEGIN", "DECLARE", "WITH",
    "ASSOCIATE", "DISASSOCIATE", "ADMINISTER", "ALTERING", "MOVE",
}


class UnknownCommandRule(BaseRule):
    id = "ORA221"
    name = "Taninmayan SQL komutu (yazim hatasi)"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = "Ifade bilinen bir SQL komutu ile baslamiyor."
    rationale = ("Yazim hatasi (UPDTE, DELET, SLECT gibi) calistirma aninda "
                 "ORA-00900 verir. Onceki adimlar calismissa script yarida kalir "
                 "ve degisiklik kismi uygulanmis olur.")
    remediation = "Komutu duzeltin veya ifadeyi kaldirin."
    tags = ['syntax', 'typo', 'LEX-019', 'MASTER-001', 'GATE-015']

    def check(self, ctx):
        for st in ctx.statements:
            if st.kind != "sql":
                continue
            word = st.first_word
            if not word or word in KNOWN:
                continue
            near = difflib.get_close_matches(word, sorted(KNOWN), n=1, cutoff=0.6)
            hint = (" Bunu mu demek istediniz: %s?" % near[0]) if near else ""
            yield self.hit(ctx, offset=st.start_offset, statement=st,
                           message="Taninmayan komut: '%s' (ORA-00900).%s"
                                   % (word, hint))
