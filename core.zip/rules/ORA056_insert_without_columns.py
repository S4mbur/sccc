# -*- coding: utf-8 -*-
"""ORA056 - Kolon listesi olmayan INSERT."""
import re
from core.model import BaseRule, Severity
from core.helpers import object_after


class InsertWithoutColumnsRule(BaseRule):
    id = "ORA056"
    name = "Kolon listesi olmayan INSERT"
    category = "PERFORMANS"
    severity = Severity.WARN
    description = "INSERT INTO tablo VALUES(...) seklinde, kolon adlari yazilmamis."
    rationale = ("Tabloya kolon eklenirse veya sira degisirse INSERT sessizce yanlis "
                 "kolona yazar ya da hata verir. Veri butunlugu riskidir.")
    remediation = "INSERT INTO sema.tablo (kolon1, kolon2, ...) VALUES (...) yazin."
    tags = ['dataintegrity', 'maintainability', 'DML-016']

    def check(self, ctx):
        for st in ctx.all_statements:
            if st.first_word != "INSERT":
                continue
            m = re.match(r"\s*INSERT\s+(?:/\*.*?\*/\s*)?INTO\s+"
                         r"((?:\"?[\w$#]+\"?\s*\.\s*)?\"?[\w$#]+\"?)\s*(\(|VALUES|SELECT|WITH)",
                         st.masked, re.I | re.S)
            if not m:
                continue
            if m.group(2) == "(":
                continue
            yield self.hit(ctx, offset=st.start_offset, statement=st,
                           object_name=m.group(1),
                           message="INSERT icin kolon listesi belirtilmemis: %s"
                                   % m.group(1).strip())
