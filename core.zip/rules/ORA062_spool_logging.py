# -*- coding: utf-8 -*-
"""ORA062 - Calisma logu (SPOOL) alinmamis."""
import re
from core.model import BaseRule, Severity


class SpoolLoggingRule(BaseRule):
    id = "ORA062"
    name = "Calisma logu alinmiyor"
    category = "STANDART"
    severity = Severity.WARN
    description = "Script ciktisi SPOOL ile dosyaya yazilmiyor."
    rationale = ("Kanit (evidence) olmadan degisikligin basariyla uygulandigi "
                 "denetimde gosterilemez; hata analizi de mumkun olmaz.")
    remediation = ("Basa SPOOL <talep_no>_<ortam>.log, sona SPOOL OFF ekleyin.")
    tags = ['standard', 'operations', 'audit', 'OBS-018']

    def check(self, ctx):
        has_on = ctx.search(r"^\s*SPOOL\s+\S+", re.I | re.M)
        has_off = ctx.search(r"^\s*SPOOL\s+OFF\b", re.I | re.M)
        if not has_on:
            yield self.hit(ctx, line=1, message="SPOOL <dosya> tanimlanmamis.")
        elif not has_off:
            yield self.hit(ctx, offset=has_on.start,
                           message="SPOOL acilmis ama SPOOL OFF yok.")
