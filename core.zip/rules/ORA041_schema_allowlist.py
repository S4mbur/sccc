# -*- coding: utf-8 -*-
"""ORA041 - Izin verilmeyen sema kullanimi."""
import re
from core.model import BaseRule, Severity


class SchemaAllowlistRule(BaseRule):
    id = "ORA041"
    name = "Izin verilmeyen sema"
    category = "SEMA"
    severity = Severity.FAIL
    description = "Script, izin verilen sema listesi disinda bir semaya dokunuyor."
    rationale = ("Her degisiklik talebi belirli bir uygulama semasi icin onaylanir. "
                 "Kapsam disi sema, onaysiz degisiklik demektir.")
    remediation = ("config.yaml -> settings.allowed_schemas listesini guncelleyin ya da "
                   "scripti sadece onayli semayi hedefleyecek sekilde duzeltin.")
    tags = ["schema", "scope"]
    default_params = {"allowed_schemas": []}

    def check(self, ctx):
        allowed = [s.upper() for s in
                   (ctx.setting("allowed_schemas") or self.param("allowed_schemas") or [])]
        if not allowed:
            return   # liste bos ise kural sessizdir
        seen = {}
        for m in ctx.finditer(r"(?<![\w$#.])([A-Za-z_$#][\w$#]*)\s*\.\s*[A-Za-z_$#][\w$#]*"):
            schema = m.group(1).upper()
            if schema in allowed:
                continue
            if schema in ("DUAL", "SYSDATE"):
                continue
            # paket cagrilari (DBMS_*) bu kuralin kapsaminda degil
            if schema.startswith("DBMS_") or schema.startswith("UTL_"):
                continue
            if schema in seen:
                continue
            seen[schema] = True
            yield self.hit(ctx, offset=m.start, object_name=schema,
                           message="Kapsam disi sema: %s (izinli: %s)"
                                   % (schema, ", ".join(allowed)))
