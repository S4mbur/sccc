# -*- coding: utf-8 -*-
"""ORA055 - Eski usul (virgullu) join / kartezyen riski."""
import re
from core.model import BaseRule, Severity
from core.helpers import find_top_level, kw


class ImplicitJoinRule(BaseRule):
    id = "ORA055"
    name = "Virgullu join / kartezyen carpim riski"
    category = "PERFORMANS"
    severity = Severity.WARN
    description = "FROM listesinde birden fazla tablo var, ANSI JOIN kullanilmamis."
    rationale = ("Join kosulu unutulursa kartezyen carpim olusur; milyonlarca satir "
                 "uretip UNDO/TEMP alanini doldurur ve veritabanini kilitler.")
    remediation = "ANSI JOIN ... ON sozdizimi kullanin."
    tags = ['performance', 'correctness', 'PERF-007']

    def check(self, ctx):
        for st in ctx.all_statements:
            if st.first_word not in ("SELECT", "UPDATE", "DELETE", "INSERT", "WITH"):
                continue
            body = st.masked
            for fm in re.finditer(r"(?<![\w$#])FROM(?![\w$#])(.*?)"
                                  r"(?=(?<![\w$#])(WHERE|GROUP|ORDER|HAVING|CONNECT|"
                                  r"START|UNION|MINUS|INTERSECT|FETCH)(?![\w$#])|$)",
                                  body, re.I | re.S):
                frag = fm.group(1)
                if re.search(r"(?<![\w$#])JOIN(?![\w$#])", frag, re.I):
                    continue
                depth, commas = 0, 0
                for ch in frag:
                    if ch == "(":
                        depth += 1
                    elif ch == ")":
                        depth = max(0, depth - 1)
                    elif ch == "," and depth == 0:
                        commas += 1
                if commas == 0:
                    continue
                has_where = bool(find_top_level(body[fm.end():fm.end() + 4000],
                                                kw("WHERE")))
                sev = Severity.WARN if has_where else Severity.FAIL
                msg = ("FROM listesinde %d+ tablo virgul ile birlestirilmis" % (commas + 1))
                if not has_where:
                    msg += " ve WHERE yok -> kartezyen carpim."
                yield self.hit(ctx, offset=st.start_offset + fm.start(), statement=st,
                               severity=sev, message=msg)
