# -*- coding: utf-8 -*-
"""ORA001 - DROP ifadesi."""
import re
from core.model import BaseRule, Severity
from core.helpers import object_after


class DropObjectRule(BaseRule):
    id = "ORA001"
    name = "DROP ifadesi tespit edildi"
    category = "YIKICI"
    severity = Severity.FAIL
    description = "Script icinde obje silen DROP ifadesi var."
    rationale = ("DROP geri alinamaz ve implicit commit uretir. Uretim veritabaninda "
                 "veri/obje kaybina yol acar; degisiklik yonetimi onayi zorunludur.")
    remediation = ("Gercekten gerekliyse ayri bir 'drop' paketi olarak, yedek ve "
                   "geri donus plani ile birlikte gonderin. Tercihen RENAME ... TO "
                   "..._YEDEK yontemi kullanin.")
    tags = ['destructive', 'ddl', 'DDL-017', 'DDL-016']
    default_params = {
        # Bu objelerde severity FAIL, digerlerinde WARN
        "critical_objects": ["TABLE", "USER", "TABLESPACE", "DATABASE",
                             "MATERIALIZED VIEW", "DIRECTORY", "ROLE", "PROFILE"],
    }

    def check(self, ctx):
        crit = {c.upper() for c in self.param("critical_objects", [])}
        for st in ctx.statements:
            if st.first_word != "DROP":
                continue
            m = re.match(r"\s*DROP\s+(MATERIALIZED\s+VIEW|PUBLIC\s+SYNONYM|[A-Z]+)",
                         st.masked, re.I)
            obj_type = re.sub(r"\s+", " ", m.group(1).upper()) if m else "?"
            name = object_after(st.masked, r"DROP\s+(?:%s)" % obj_type.replace(" ", r"\s+"))
            # DDL-017 / CUR-029: tum DROP tipleri kritiktir. crit listesi yalniz
            # mesaji zenginlestirmek icin kullanilir; severity her zaman FAIL.
            sev = Severity.FAIL
            yield self.hit(
                ctx, offset=st.start_offset, statement=st, severity=sev,
                object_name=name,
                message="[DDL-017] DROP %s ifadesi: %s%s"
                        % (obj_type, name or "(ad cozulemedi)",
                           " (kritik obje tipi)" if obj_type in crit else ""),
            )
