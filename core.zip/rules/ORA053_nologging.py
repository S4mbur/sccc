# -*- coding: utf-8 -*-
"""ORA053 - NOLOGGING / APPEND kullanimi."""
import re
from core.model import BaseRule, Severity


class NologgingRule(BaseRule):
    id = "ORA053"
    name = "NOLOGGING / APPEND kullanimi"
    category = "PERFORMANS"
    severity = Severity.FAIL
    description = "NOLOGGING, UNRECOVERABLE veya /*+ APPEND */ kullanilmis."
    rationale = ("Redo uretilmedigi icin standby veritabani bozulur ve yedekten "
                 "geri donus mumkun olmaz. Felaket kurtarma (DR) butunlugunu kirar.")
    remediation = ("Data Guard ortaminda NOLOGGING kullanmayin. Zorunluysa islem "
                   "sonrasi FORCE LOGGING'e donun ve tam yedek alin.")
    tags = ['performance', 'dr', 'recovery', 'DDL-027', 'HA-004']

    PATTERNS = [
        (r"(?<![\w$#])NOLOGGING(?![\w$#])", "NOLOGGING"),
        (r"(?<![\w$#])UNRECOVERABLE(?![\w$#])", "UNRECOVERABLE"),
        (r"/\*\+[^*]*\bAPPEND\b[^*]*\*/", "APPEND hint"),
    ]

    def check(self, ctx):
        for pat, label in self.PATTERNS:
            # hint'ler maskeleme sirasinda yorum sayildigi icin ham metinde araniyor
            source = ctx.findall_raw if "APPEND" in label else ctx.finditer
            for m in source(pat):
                yield self.hit(ctx, offset=m.start,
                               message="%s kullanilmis (redo uretilmez)." % label)
