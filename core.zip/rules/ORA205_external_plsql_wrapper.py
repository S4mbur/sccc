# -*- coding: utf-8 -*-
"""ORA205 - Create scriptine harici anonim PL/SQL blogu eklenmis (kurum kurali 5)."""
from core.model import BaseRule, Severity
from core.helpers import scan_plsql_units


class ExternalPlsqlWrapperRule(BaseRule):
    id = "ORA205"
    name = "Create scriptine harici BEGIN ... END; eklenmis"
    category = "DBRUNNER"
    severity = Severity.FAIL
    description = ("PROCEDURE / FUNCTION / PACKAGE create scripti iceren dosyaya ayrica "
                   "harici anonim BEGIN ... END; blogu yazilmamalidir.")
    rationale = ("Harici PL/SQL blogu create ifadesinin ayristirilmasini bozar; obje "
                 "derlenmez ya da blok icinde calistirilmaya calisilarak hata alinir.")
    remediation = ("Anonim BEGIN ... END; blogunu kaldirin. Calistirilmasi gereken "
                   "PL/SQL varsa ayri bir dosya olarak gonderin.")
    tags = ['dbrunner', 'plsql', 'LEX-014']

    def check(self, ctx):
        units = scan_plsql_units(ctx.masked_lines)
        creates = [u for u in units if u.kind == "create"]
        anons = [u for u in units if u.kind == "anon"]
        if not creates or not anons:
            return
        first = creates[0]
        for u in anons:
            yield self.hit(ctx, line=u.start,
                           message="Dosyada CREATE %s scripti (satir %d) varken harici "
                                   "%s blogu da yazilmis (satir %d)."
                                   % (first.obj_type, first.start, u.obj_type, u.start))
