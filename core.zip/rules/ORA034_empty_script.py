# -*- coding: utf-8 -*-
"""ORA034 - Bos veya calistirilabilir ifadesi olmayan script."""
from core.model import BaseRule, Severity


class EmptyScriptRule(BaseRule):
    id = "ORA034"
    name = "Bos script"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = "Scriptte calistirilabilir hicbir ifade yok."
    rationale = "Bos script yanlislikla gonderilmis olabilir; degisiklik uygulanmaz."
    remediation = "Dogru dosyayi gonderdiginizden emin olun."
    tags = ["syntax"]

    def check(self, ctx):
        exec_stmts = [s for s in ctx.statements if s.kind != "sqlplus"]
        if not exec_stmts:
            yield self.hit(ctx, line=1,
                           message="Script icinde SQL/PLSQL ifadesi bulunamadi "
                                   "(%d SQL*Plus komutu var)." % len(ctx.statements))
