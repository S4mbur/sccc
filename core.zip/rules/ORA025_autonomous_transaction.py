# -*- coding: utf-8 -*-
"""ORA025 - PRAGMA AUTONOMOUS_TRANSACTION."""
import re
from core.model import BaseRule, Severity


class AutonomousTransactionRule(BaseRule):
    id = "ORA025"
    name = "Otonom transaction kullanimi"
    category = "TRANSACTION"
    severity = Severity.WARN
    description = "PRAGMA AUTONOMOUS_TRANSACTION tanimlanmis."
    rationale = ("Otonom transaction ana islemden bagimsiz commit eder; ana islem "
                 "rollback olsa bile yazdigi veri kalir. Tutarsizlik kaynagidir.")
    remediation = ("Sadece loglama gibi bilincli kullanimlarda birakin, is verisi "
                   "yazan kodda kullanmayin.")
    tags = ['transaction', 'plsql', 'TX-010', 'PLS-013']

    def check(self, ctx):
        for m in ctx.finditer(r"PRAGMA\s+AUTONOMOUS_TRANSACTION"):
            yield self.hit(ctx, offset=m.start,
                           message="PRAGMA AUTONOMOUS_TRANSACTION tanimli.")
