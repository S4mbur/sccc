# -*- coding: utf-8 -*-
"""ORA007 - Kolon veya constraint silme."""
import re
from core.model import BaseRule, Severity
from core.helpers import object_after


class DropColumnRule(BaseRule):
    id = "ORA007"
    name = "Kolon / constraint / partition silme"
    category = "YIKICI"
    severity = Severity.FAIL
    description = "ALTER TABLE ile kolon, constraint veya partition siliniyor."
    rationale = ("Kolon silme geri alinamaz ve bagimli view/paket/rapor kirilmasina "
                 "neden olur. Buyuk tablolarda uzun sureli exclusive lock alir.")
    remediation = ("Once SET UNUSED ile mantiksal olarak devre disi birakin, bagimlilik "
                   "analizini yapin, ardindan bakim penceresinde DROP UNUSED COLUMNS calistirin.")
    tags = ['destructive', 'ddl', 'DDL-018', 'DDL-022']

    PATTERNS = [
        (r"\bDROP\s+(COLUMN\s+)?\(?\s*[\w$#\"]+\s*\)?(?=\s|$|,|;)", "DROP COLUMN"),
        (r"\bDROP\s+CONSTRAINT\b", "DROP CONSTRAINT"),
        (r"\bDROP\s+PARTITION\b", "DROP PARTITION"),
        (r"\bDROP\s+PRIMARY\s+KEY\b", "DROP PRIMARY KEY"),
        (r"\bTRUNCATE\s+PARTITION\b", "TRUNCATE PARTITION"),
    ]

    def check(self, ctx):
        for st in ctx.statements:
            if st.first_word != "ALTER":
                continue
            if not re.match(r"\s*ALTER\s+TABLE\b", st.masked, re.I):
                continue
            table = object_after(st.masked, r"ALTER\s+TABLE")
            for pat, label in self.PATTERNS:
                for m in re.finditer(pat, st.body, re.I):
                    yield self.hit(ctx, offset=st.start_offset + m.start(),
                                   statement=st, object_name=table,
                                   message="%s -> %s (%s)" % (
                                       label, table, " ".join(m.group(0).split())))
