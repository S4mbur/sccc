# -*- coding: utf-8 -*-
"""ORA042 - CREATE TABLE/INDEX icin TABLESPACE belirtilmemis."""
import re
from core.model import BaseRule, Severity
from core.helpers import object_after


class MissingTablespaceRule(BaseRule):
    id = "ORA042"
    name = "TABLESPACE belirtilmemis"
    category = "SEMA"
    severity = Severity.WARN
    description = "CREATE TABLE / CREATE INDEX ifadesinde TABLESPACE yok."
    rationale = ("Varsayilan tablespace'e dusen obje kapasite planlamasini bozar; "
                 "yanlis diskte buyuyup uretim kesintisine yol acabilir.")
    remediation = "Ifadeye acikca TABLESPACE <ad> ekleyin."
    tags = ['schema', 'storage', 'DDL-025']

    def check(self, ctx):
        for st in ctx.statements:
            m = re.match(r"\s*CREATE\s+(GLOBAL\s+TEMPORARY\s+|UNIQUE\s+|BITMAP\s+)*"
                         r"(TABLE|INDEX)\b", st.masked, re.I)
            if not m:
                continue
            kind = m.group(2).upper()
            if kind == "TABLE" and re.search(r"GLOBAL\s+TEMPORARY", st.masked, re.I):
                continue
            if re.search(r"(?<![\w$#])TABLESPACE(?![\w$#])", st.masked, re.I):
                continue
            name = object_after(st.masked, r"(?:TABLE|INDEX)")
            yield self.hit(ctx, offset=st.start_offset, statement=st, object_name=name,
                           message="CREATE %s %s icin TABLESPACE belirtilmemis."
                                   % (kind, name))
