# -*- coding: utf-8 -*-
# Bu dosya kullanim disidir; icerigi rules/ORA900_ornek_sablon.py dosyasina tasindi.
