# -*- coding: utf-8 -*-
"""ORA008 - PURGE / FLASHBACK / geri donus yolunu kapatan ifadeler."""
import re
from core.model import BaseRule, Severity


class PurgeFlashbackRule(BaseRule):
    id = "ORA008"
    name = "Geri donus yolunu kapatan ifade (PURGE / FLASHBACK)"
    category = "YIKICI"
    severity = Severity.FAIL
    description = "PURGE, DROP ... PURGE veya FLASHBACK TABLE ifadesi var."
    rationale = ("PURGE recyclebin'i temizleyerek yanlislikla silinen objenin geri "
                 "getirilmesini imkansiz kilar. FLASHBACK ise veriyi gecmise dondurur.")
    remediation = "PURGE kullanmayin; silme oncesi export/CTAS yedegi alin."
    tags = ['destructive', 'recovery', 'DDL-017']

    PATTERNS = [
        (r"\bPURGE\s+(RECYCLEBIN|DBA_RECYCLEBIN|TABLE|INDEX|TABLESPACE)\b", "PURGE"),
        (r"\bDROP\s+TABLE\b[^;]*\bPURGE\b", "DROP TABLE ... PURGE"),
        (r"\bFLASHBACK\s+(TABLE|DATABASE)\b", "FLASHBACK"),
    ]

    def check(self, ctx):
        for pat, label in self.PATTERNS:
            for m in ctx.finditer(pat, re.I | re.S):
                yield self.hit(ctx, offset=m.start,
                               message="%s ifadesi tespit edildi." % label)
