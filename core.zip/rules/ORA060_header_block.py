# -*- coding: utf-8 -*-
"""ORA060 - Zorunlu baslik blogu."""
import re
from core.model import BaseRule, Severity


class HeaderBlockRule(BaseRule):
    id = "ORA060"
    name = "Zorunlu baslik blogu eksik"
    category = "STANDART"
    severity = Severity.FAIL
    description = "Scriptin basinda talep no, yazan, tarih, amac bilgileri yok."
    rationale = ("Degisiklik izlenebilirligi (change traceability) icin zorunludur. "
                 "Denetimde 'bu degisikligi kim, hangi talep ile yapti' sorusunun cevabidir.")
    remediation = ("Scriptin en basina asagidaki gibi bir yorum blogu ekleyin:\n"
                   "  /*\n   * TALEP NO : CHG-2026-0001\n   * YAZAN    : Ad Soyad\n"
                   "   * TARIH    : 2026-08-10\n   * AMAC     : ...\n"
                   "   * GERI ALMA: rollback_CHG-2026-0001.sql\n   */")
    tags = ["standard", "governance", "audit"]
    default_params = {
        "required_fields": ["TALEP", "YAZAN", "TARIH", "AMAC"],
        "aliases": {
            "TALEP": ["TALEP NO", "TALEP", "CHANGE", "CHG", "TICKET", "JIRA", "ISTEK"],
            "YAZAN": ["YAZAN", "AUTHOR", "HAZIRLAYAN", "GELISTIRICI", "OWNER"],
            "TARIH": ["TARIH", "DATE", "OLUSTURMA"],
            "AMAC": ["AMAC", "ACIKLAMA", "PURPOSE", "DESCRIPTION", "KONU"],
        },
    }

    def check(self, ctx):
        header = ctx.header_comment.upper()
        fields = ctx.setting("required_header_fields") or self.param("required_fields", [])
        aliases = self.param("aliases", {})
        if not header.strip():
            yield self.hit(ctx, line=1,
                           message="Scriptin basinda hicbir aciklama blogu yok.")
            return
        missing = []
        for field in fields:
            key = str(field).upper().split()[0]
            names = [a.upper() for a in aliases.get(key, [field])]
            if not any(n in header for n in names):
                missing.append(str(field))
        if missing:
            yield self.hit(ctx, line=1,
                           message="Baslik blogunda eksik alan(lar): %s"
                                   % ", ".join(missing))
