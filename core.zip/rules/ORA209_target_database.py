# -*- coding: utf-8 -*-
"""ORA209 - Hedef veritabani adi belirtilmemis (kurum kurali 2)."""
from core.model import BaseRule, Severity


class TargetDatabaseRule(BaseRule):
    id = "ORA209"
    name = "Hedef veritabani adi belirtilmemis"
    category = "DBRUNNER"
    severity = Severity.WARN
    description = ("Script basligi izinli veritabani adlarindan biriyle tam eslesmelidir.")
    rationale = ("Talep basligi/icerigi ile veritabani adi eslesmezse talep dikkate "
                 "alinmaz. Baslikta belirtilmesi yanlis ortama gonderimi de onler.")
    remediation = ("Baslik blogunda 'VERITABANI: <ad>' satiri ekleyin ve config.yaml -> "
                   "ORA209.params.database_names listesini doldurun.")
    tags = ['dbrunner', 'governance', 'DB-001', 'OPS-002']
    default_params = {"database_names": []}     # bos ise kural sessizdir

    def check(self, ctx):
        names = [n.upper() for n in self.param("database_names", [])]
        if not names:
            return
        header = ctx.header_comment.upper()
        if any(n in header for n in names):
            return
        yield self.hit(ctx, line=1,
                       message="Baslik blogunda izinli veritabani adi bulunamadi "
                               "(izinli: %s)." % ", ".join(names))
