# -*- coding: utf-8 -*-
"""ORA231 - Gecersiz tarih / zaman literali."""
import re
from core.model import BaseRule, Severity


class InvalidLiteralRule(BaseRule):
    id = "ORA231"
    name = "Gecersiz tarih veya zaman literali"
    category = "SOZDIZIMI"
    severity = Severity.FAIL
    description = "ANSI DATE / TIMESTAMP literali gecerli bir tarih degil."
    rationale = ("DATE '2024-31-12' gibi bir deger ORA-01847 verir. Finansal "
                 "scriptlerde tarih hatasi yanlis doneme kayit atilmasina da yol acar.")
    remediation = "DATE literalini YYYY-MM-DD formatinda ve gecerli bir tarih olarak yazin."
    tags = ['syntax', 'correctness', 'DML-023']

    def check(self, ctx):
        import datetime
        for m in re.finditer(r"(?<![\w$#])(DATE|TIMESTAMP)\s*'([^']*)'",
                             ctx.raw, re.I):
            kind, val = m.group(1).upper(), m.group(2).strip()
            ok = True
            try:
                if kind == "DATE":
                    datetime.datetime.strptime(val, "%Y-%m-%d")
                else:
                    datetime.datetime.strptime(val[:19].replace("T", " "),
                                               "%Y-%m-%d %H:%M:%S")
            except ValueError:
                ok = False
            if not ok:
                yield self.hit(ctx, offset=m.start(),
                               message="Gecersiz %s literali: '%s' "
                                       "(beklenen format YYYY-MM-DD)." % (kind, val))
