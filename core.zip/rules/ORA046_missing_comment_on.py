# -*- coding: utf-8 -*-
"""ORA046 - Yeni obje icin COMMENT ON eksik."""
import re
from core.model import BaseRule, Severity


class MissingCommentOnRule(BaseRule):
    id = "ORA046"
    name = "Yeni tablo/kolon icin aciklama (COMMENT ON) yok"
    category = "SEMA"
    severity = Severity.INFO
    description = "CREATE TABLE var ancak COMMENT ON TABLE/COLUMN tanimlanmamis."
    rationale = ("Veri sozlugu dokumantasyonu, veri yonetisimi ve KVKK envanteri "
                 "icin gereklidir. Aciklamasiz kolonlar veri sinifi belirsiz kalir.")
    remediation = "Her yeni tablo ve kolon icin COMMENT ON ... IS '...' ekleyin."
    tags = ['documentation', 'governance', 'DDL-039']

    def check(self, ctx):
        created = [s for s in ctx.statements
                   if re.match(r"\s*CREATE\s+(GLOBAL\s+TEMPORARY\s+)?TABLE\b",
                               s.masked, re.I)]
        if not created:
            return
        if re.search(r"\bCOMMENT\s+ON\s+(TABLE|COLUMN)\b", ctx.masked, re.I):
            return
        for st in created:
            yield self.hit(ctx, offset=st.start_offset, statement=st,
                           message="CREATE TABLE var, COMMENT ON tanimi yok.")
