# -*- coding: utf-8 -*-
"""ORA274 - SQL buffer'in tekrar calistirilmasi (CUR-014/015, LEX-012, CLI-005)."""
import re
from core.model import BaseRule, Severity


class RepeatExecutionRule(BaseRule):
    id = "ORA274"
    name = "Fazladan '/' ile mukerrer calistirma"
    category = "ISTEMCI"
    severity = Severity.FAIL
    description = "Bir ifadeden sonra gelen fazladan '/' onceki komutu TEKRAR calistirir."
    rationale = ("SQL*Plus'ta tek basina '/' bos satir degil, 'son buffer'i yeniden "
                 "calistir' komutudur (CUR-014/015). Bir INSERT'ten sonra ikinci bir "
                 "'/' kaydi iki kez ekler; bir PL/SQL blogu iki kez calisir. Statik "
                 "analiz bu ikinci calismayi saymazsa etki hesabi yanlis olur.")
    remediation = ("Fazladan '/' satirlarini silin. Her ifadeden sonra en fazla bir "
                   "sonlandirici olmalidir.")
    tags = ['client', 'CLI-005', 'LEX-012', 'idempotency', 'LEX-013']

    def check(self, ctx):
        prev_exec = None          # son calistirilabilir ifadenin satiri
        slash_seen_for = None
        for i, line in enumerate(ctx.lines, start=1):
            txt = ctx.masked_lines[i - 1].strip() if i - 1 < len(ctx.masked_lines) else ""
            if txt == "/":
                if prev_exec is None:
                    yield self.hit(ctx, line=i,
                                   message="[LEX-012] Oncesinde ifade olmayan '/' - "
                                           "bos buffer veya beklenmeyen tekrar.")
                elif slash_seen_for == prev_exec:
                    yield self.hit(ctx, line=i,
                                   message="[CUR-014] Fazladan '/': satir %d'deki "
                                           "ifade IKINCI kez calistirilir."
                                           % prev_exec)
                else:
                    slash_seen_for = prev_exec
                continue
            if txt and not txt.startswith("--"):
                if txt.endswith(";") or prev_exec is None:
                    prev_exec = i
                    slash_seen_for = None
