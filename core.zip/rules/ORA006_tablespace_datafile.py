# -*- coding: utf-8 -*-
"""ORA006 - Tablespace / datafile operasyonu."""
import re
from core.model import BaseRule, Severity


class TablespaceOpsRule(BaseRule):
    id = "ORA006"
    name = "Tablespace veya datafile operasyonu"
    category = "YIKICI"
    severity = Severity.FAIL
    description = "Tablespace/datafile olusturma, degistirme veya silme islemi var."
    rationale = ("Depolama katmani degisiklikleri kapasite planlamasi ve yedekleme "
                 "politikasini etkiler; sadece DBA operasyon scriptlerinde olmalidir.")
    remediation = "Storage islemlerini ayri bir DBA scriptine tasiyin."
    tags = ["storage", "ddl"]

    PATTERNS = [
        r"(CREATE|ALTER|DROP)\s+(BIGFILE\s+|SMALLFILE\s+|TEMPORARY\s+|UNDO\s+)*TABLESPACE\b",
        r"\bADD\s+DATAFILE\b",
        r"\bADD\s+TEMPFILE\b",
        r"\bDATAFILE\s+'",
        r"\bAUTOEXTEND\s+(ON|OFF)\b",
    ]

    def check(self, ctx):
        for pat in self.PATTERNS:
            for m in ctx.finditer(pat):
                yield self.hit(ctx, offset=m.start,
                               message="Storage islemi: %s" % " ".join(m.text.split()))
