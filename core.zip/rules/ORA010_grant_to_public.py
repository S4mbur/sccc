# -*- coding: utf-8 -*-
"""ORA010 - PUBLIC'e yetki verilmesi."""
import re
from core.model import BaseRule, Severity


class GrantToPublicRule(BaseRule):
    id = "ORA010"
    name = "PUBLIC rolune yetki verilmis"
    category = "GUVENLIK"
    severity = Severity.FAIL
    description = "GRANT ... TO PUBLIC ifadesi var."
    rationale = ("PUBLIC'e verilen yetki veritabanindaki her kullaniciya acilir. "
                 "Musteri verisine yetkisiz erisim ve denetim bulgusu dogurur.")
    remediation = "Yetkiyi ilgili role veya isimlendirilmis kullaniciya verin."
    tags = ["security", "privilege"]

    def check(self, ctx):
        for m in ctx.finditer(r"\bGRANT\b[^;]{0,400}?\bTO\s+PUBLIC\b", re.I | re.S):
            yield self.hit(ctx, offset=m.start,
                           message="PUBLIC'e yetki: %s" % " ".join(m.text.split())[:120])
        for m in ctx.finditer(r"\bCREATE\s+PUBLIC\s+(SYNONYM|DATABASE\s+LINK)\b"):
            yield self.hit(ctx, offset=m.start, severity=Severity.WARN,
                           message="PUBLIC obje olusturuluyor: %s" % " ".join(m.text.split()))
