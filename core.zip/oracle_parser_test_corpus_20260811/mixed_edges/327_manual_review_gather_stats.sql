-- CASE_ID: TC327
-- EXPECTED: MANUAL_REVIEW
-- TAGS: edge,mixed
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Parser edge case combining multiple deployment concerns.
BEGIN
 DBMS_STATS.GATHER_TABLE_STATS('APP_OWNER', 'TST_ACCOUNT');
END;
/
