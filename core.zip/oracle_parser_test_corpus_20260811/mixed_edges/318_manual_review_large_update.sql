-- CASE_ID: TC318
-- EXPECTED: MANUAL_REVIEW
-- TAGS: edge,mixed
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Parser edge case combining multiple deployment concerns.
UPDATE APP_OWNER.TST_ACCOUNT SET STATUS = 'A' WHERE CUSTOMER_ID IS NOT NULL;
