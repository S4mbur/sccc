-- CASE_ID: TC320
-- EXPECTED: REJECT
-- TAGS: edge,mixed
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Parser edge case combining multiple deployment concerns.
CREATE TABLE APP_OWNER.TST_COMMIT_AFTER_DDL (ID NUMBER);
COMMIT;
