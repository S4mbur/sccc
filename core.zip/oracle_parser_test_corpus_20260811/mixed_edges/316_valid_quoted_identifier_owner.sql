-- CASE_ID: TC316
-- EXPECTED: ACCEPT
-- TAGS: edge,mixed
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Parser edge case combining multiple deployment concerns.
CREATE TABLE APP_OWNER."TST_CASE_SENSITIVE" (ID NUMBER);
