-- CASE_ID: TC326
-- EXPECTED: MANUAL_REVIEW
-- TAGS: edge,mixed
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Parser edge case combining multiple deployment concerns.
ANALYZE TABLE APP_OWNER.TST_ACCOUNT COMPUTE STATISTICS;
