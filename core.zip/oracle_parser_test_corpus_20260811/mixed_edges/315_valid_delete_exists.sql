-- CASE_ID: TC315
-- EXPECTED: ACCEPT
-- TAGS: edge,mixed
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Parser edge case combining multiple deployment concerns.
DELETE FROM APP_OWNER.TST_STAGING_EVENT e
 WHERE EXISTS (
       SELECT 1 FROM APP_OWNER.TST_BATCH b WHERE b.BATCH_ID = e.BATCH_ID AND b.STATUS = 'CANCELLED'
 );
