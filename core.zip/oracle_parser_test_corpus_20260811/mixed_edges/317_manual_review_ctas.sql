-- CASE_ID: TC317
-- EXPECTED: MANUAL_REVIEW
-- TAGS: edge,mixed
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Parser edge case combining multiple deployment concerns.
CREATE TABLE APP_OWNER.TST_COPY AS SELECT * FROM APP_OWNER.TST_ACCOUNT WHERE STATUS = 'A';
