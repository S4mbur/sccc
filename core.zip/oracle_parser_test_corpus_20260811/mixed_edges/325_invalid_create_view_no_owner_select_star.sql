-- CASE_ID: TC325
-- EXPECTED: REJECT
-- TAGS: edge,mixed
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Parser edge case combining multiple deployment concerns.
CREATE OR REPLACE VIEW VW_TST_ALL_CUSTOMERS AS
SELECT * FROM APP_OWNER.CUSTOMER_FULL_PROFILE;
