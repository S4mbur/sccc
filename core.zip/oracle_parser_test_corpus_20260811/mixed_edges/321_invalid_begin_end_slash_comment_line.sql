-- CASE_ID: TC321
-- EXPECTED: REJECT
-- TAGS: edge,mixed
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Parser edge case combining multiple deployment concerns.
BEGIN
 UPDATE APP_OWNER.TST_ACCOUNT SET STATUS='A' WHERE ACCOUNT_ID=1;
END;
-- slash forgotten
