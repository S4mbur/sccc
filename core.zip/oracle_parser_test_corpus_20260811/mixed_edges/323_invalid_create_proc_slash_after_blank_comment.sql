-- CASE_ID: TC323
-- EXPECTED: REJECT
-- TAGS: edge,mixed
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Parser edge case combining multiple deployment concerns.
CREATE OR REPLACE PROCEDURE APP_OWNER.PR_BAD_SLASH_PLACE AS
BEGIN
 NULL;
END;
-- comment
/
