-- CASE_ID: TC319
-- EXPECTED: REJECT
-- TAGS: edge,mixed
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Parser edge case combining multiple deployment concerns.
SELECT COUNT(*) FROM APP_OWNER.TST_LOG;
DELETE FROM APP_OWNER.TST_LOG WHERE CREATED_AT < SYSDATE - 30;
