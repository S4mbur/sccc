-- CASE_ID: TC314
-- EXPECTED: ACCEPT
-- TAGS: edge,mixed
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Parser edge case combining multiple deployment concerns.
UPDATE APP_OWNER.TST_ACCOUNT
   SET STATUS = 'A'
 WHERE ACCOUNT_ID IN (
       SELECT ACCOUNT_ID FROM APP_OWNER.TST_ACCOUNT_QUEUE WHERE QUEUE_ID = 77
 );
