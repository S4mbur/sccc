-- CASE_ID: TC310
-- EXPECTED: REJECT
-- TAGS: ordering,file-name
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Ordered execution filename prefix case.
UPDATE APP_OWNER.TST_ACCOUNT SET STATUS = 'A' WHERE ACCOUNT_ID = 1;
