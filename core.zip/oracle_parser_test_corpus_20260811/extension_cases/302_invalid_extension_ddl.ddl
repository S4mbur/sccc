-- CASE_ID: TC302
-- EXPECTED: REJECT
-- TAGS: extension,file-name
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: File extension rule case.
UPDATE APP_OWNER.TST_ACCOUNT SET STATUS = 'A' WHERE ACCOUNT_ID = 1;
