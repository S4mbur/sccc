-- CASE_ID: TC287
-- EXPECTED: REJECT
-- TAGS: syntax,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Small syntax defect.
DELET FROM APP_OWNER.TST_ACCOUNT WHERE ACCOUNT_ID = 1;
