-- CASE_ID: TC294
-- EXPECTED: REJECT
-- TAGS: syntax,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Small syntax defect.
BEGIN
 NULL;
/
END;
