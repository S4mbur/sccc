-- CASE_ID: TC293
-- EXPECTED: REJECT
-- TAGS: syntax,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Small syntax defect.
BEGIN
 IF 1 = 1 THEN
  NULL;
END;
/
