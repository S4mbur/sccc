-- CASE_ID: TC283
-- EXPECTED: REJECT
-- TAGS: syntax,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Small syntax defect.
CREATE TABLE APP_OWNER.TST_BAD_SYNTAX_01 (ID NUMBER)
