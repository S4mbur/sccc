-- CASE_ID: TC286
-- EXPECTED: REJECT
-- TAGS: syntax,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Small syntax defect.
UPDTE APP_OWNER.TST_ACCOUNT SET STATUS = 'A' WHERE ACCOUNT_ID = 1;
