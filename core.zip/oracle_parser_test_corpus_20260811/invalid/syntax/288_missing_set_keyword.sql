-- CASE_ID: TC288
-- EXPECTED: REJECT
-- TAGS: syntax,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Small syntax defect.
UPDATE APP_OWNER.TST_ACCOUNT STATUS = 'A' WHERE ACCOUNT_ID = 1;
