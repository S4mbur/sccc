-- CASE_ID: TC291
-- EXPECTED: REJECT
-- TAGS: syntax,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Small syntax defect.
DELETE FROM APP_OWNER.TST_ACCOUNT WHERE ACCOUNT_ID = 1));
