-- CASE_ID: TC240
-- EXPECTED: REJECT
-- TAGS: select,output,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Negative SELECT/report-output case.
SELECT ACCOUNT_ID FROM APP_OWNER.TST_ACCOUNT WHERE ACCOUNT_ID = 1
