-- CASE_ID: TC239
-- EXPECTED: REJECT
-- TAGS: select,output,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Negative SELECT/report-output case.
SPOOL account.csv
SELECT * FROM APP_OWNER.TST_ACCOUNT;
SELECT * FROM APP_OWNER.TST_CARD;
SPOOL OFF
