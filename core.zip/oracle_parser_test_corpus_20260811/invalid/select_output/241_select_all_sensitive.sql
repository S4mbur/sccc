-- CASE_ID: TC241
-- EXPECTED: REJECT
-- TAGS: select,output,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Negative SELECT/report-output case.
SELECT * FROM APP_OWNER.CUSTOMER_FULL_PROFILE WHERE CUSTOMER_ID = 1;
