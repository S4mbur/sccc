-- CASE_ID: TC216
-- EXPECTED: REJECT
-- TAGS: comments,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Inline comment should be rejected by the deployment rule.
DELETE FROM APP_OWNER.TST_LOG WHERE LOG_ID = 10; -- inline comment
