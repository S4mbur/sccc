-- CASE_ID: TC219
-- EXPECTED: REJECT
-- TAGS: comments,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Inline comment should be rejected by the deployment rule.
UPDATE APP_OWNER.TST_ACCOUNT SET STATUS = 'A' -- comment
 WHERE ACCOUNT_ID = 10;
