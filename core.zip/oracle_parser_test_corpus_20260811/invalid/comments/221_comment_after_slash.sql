-- CASE_ID: TC221
-- EXPECTED: REJECT
-- TAGS: comments,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Inline comment should be rejected by the deployment rule.
CREATE OR REPLACE PROCEDURE APP_OWNER.PR_TST_BAD_COMMENT AS
BEGIN
 NULL;
END;
/ -- inline slash comment
