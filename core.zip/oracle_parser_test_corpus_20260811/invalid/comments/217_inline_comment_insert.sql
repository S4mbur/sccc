-- CASE_ID: TC217
-- EXPECTED: REJECT
-- TAGS: comments,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Inline comment should be rejected by the deployment rule.
INSERT INTO APP_OWNER.TST_AUDIT_MARKER (MARKER_ID) VALUES (10); -- inline comment
