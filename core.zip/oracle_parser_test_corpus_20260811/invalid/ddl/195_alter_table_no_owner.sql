-- CASE_ID: TC195
-- EXPECTED: REJECT
-- TAGS: ddl,owner,plsql,mixed,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: DDL negative case for owner, slash, or DDL/DML separation.
ALTER TABLE TST_ACCOUNT ADD (DEPLOY_NOTE VARCHAR2(20));
