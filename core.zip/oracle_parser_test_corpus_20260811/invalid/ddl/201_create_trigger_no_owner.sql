-- CASE_ID: TC201
-- EXPECTED: REJECT
-- TAGS: ddl,owner,plsql,mixed,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: DDL negative case for owner, slash, or DDL/DML separation.
CREATE OR REPLACE TRIGGER TRG_TST_ACCOUNT_BIU BEFORE INSERT OR UPDATE ON APP_OWNER.TST_ACCOUNT BEGIN NULL; END; /
