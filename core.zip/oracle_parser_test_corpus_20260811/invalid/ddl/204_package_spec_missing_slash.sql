-- CASE_ID: TC204
-- EXPECTED: REJECT
-- TAGS: ddl,owner,plsql,mixed,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: DDL negative case for owner, slash, or DDL/DML separation.
CREATE OR REPLACE PACKAGE APP_OWNER.PKG_TST_NO_SLASH AS
    PROCEDURE P;
END PKG_TST_NO_SLASH;
