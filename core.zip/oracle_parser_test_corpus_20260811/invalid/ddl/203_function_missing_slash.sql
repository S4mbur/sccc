-- CASE_ID: TC203
-- EXPECTED: REJECT
-- TAGS: ddl,owner,plsql,mixed,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: DDL negative case for owner, slash, or DDL/DML separation.
CREATE OR REPLACE FUNCTION APP_OWNER.FN_TST_NO_SLASH RETURN NUMBER AS
BEGIN
    RETURN 1;
END FN_TST_NO_SLASH;
