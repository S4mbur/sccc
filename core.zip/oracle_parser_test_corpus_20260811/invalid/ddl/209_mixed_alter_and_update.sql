-- CASE_ID: TC209
-- EXPECTED: REJECT
-- TAGS: ddl,owner,plsql,mixed,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: DDL negative case for owner, slash, or DDL/DML separation.
ALTER TABLE APP_OWNER.TST_ACCOUNT ADD (TMP_COL NUMBER);
UPDATE APP_OWNER.TST_ACCOUNT SET TMP_COL = 1 WHERE ACCOUNT_ID = 1;
