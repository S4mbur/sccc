-- CASE_ID: TC208
-- EXPECTED: REJECT
-- TAGS: ddl,owner,plsql,mixed,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: DDL negative case for owner, slash, or DDL/DML separation.
CREATE TABLE APP_OWNER.TST_MIXED_01 (ID NUMBER);
INSERT INTO APP_OWNER.TST_MIXED_01 (ID) VALUES (1);
