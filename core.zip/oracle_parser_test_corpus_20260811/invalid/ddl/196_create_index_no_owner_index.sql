-- CASE_ID: TC196
-- EXPECTED: REJECT
-- TAGS: ddl,owner,plsql,mixed,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: DDL negative case for owner, slash, or DDL/DML separation.
CREATE INDEX IX_TST_ACCOUNT ON APP_OWNER.TST_ACCOUNT (ACCOUNT_ID);
