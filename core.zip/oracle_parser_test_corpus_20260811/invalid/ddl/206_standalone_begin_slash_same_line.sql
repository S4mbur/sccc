-- CASE_ID: TC206
-- EXPECTED: REJECT
-- TAGS: ddl,owner,plsql,mixed,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: DDL negative case for owner, slash, or DDL/DML separation.
BEGIN
    NULL;
END; /
