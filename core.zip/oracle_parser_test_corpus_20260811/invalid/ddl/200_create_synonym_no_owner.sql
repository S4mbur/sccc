-- CASE_ID: TC200
-- EXPECTED: REJECT
-- TAGS: ddl,owner,plsql,mixed,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: DDL negative case for owner, slash, or DDL/DML separation.
CREATE OR REPLACE SYNONYM SYN_TST_ACCOUNT FOR APP_OWNER.TST_ACCOUNT;
