-- CASE_ID: TC202
-- EXPECTED: REJECT
-- TAGS: ddl,owner,plsql,mixed,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: DDL negative case for owner, slash, or DDL/DML separation.
CREATE OR REPLACE PROCEDURE APP_OWNER.PR_TST_NO_SLASH AS
BEGIN
    NULL;
END PR_TST_NO_SLASH;
