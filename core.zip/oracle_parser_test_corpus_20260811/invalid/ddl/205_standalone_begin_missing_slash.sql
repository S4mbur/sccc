-- CASE_ID: TC205
-- EXPECTED: REJECT
-- TAGS: ddl,owner,plsql,mixed,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: DDL negative case for owner, slash, or DDL/DML separation.
BEGIN
    UPDATE APP_OWNER.TST_ACCOUNT SET STATUS = 'A' WHERE ACCOUNT_ID = 1;
END;
