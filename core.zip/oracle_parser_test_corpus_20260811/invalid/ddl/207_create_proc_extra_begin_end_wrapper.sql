-- CASE_ID: TC207
-- EXPECTED: REJECT
-- TAGS: ddl,owner,plsql,mixed,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: DDL negative case for owner, slash, or DDL/DML separation.
BEGIN
    EXECUTE IMMEDIATE 'CREATE OR REPLACE PROCEDURE APP_OWNER.PR_BAD AS BEGIN NULL; END;';
END;
/
