-- CASE_ID: TC199
-- EXPECTED: REJECT
-- TAGS: ddl,owner,plsql,mixed,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: DDL negative case for owner, slash, or DDL/DML separation.
CREATE OR REPLACE VIEW VW_TST_ACCOUNT AS SELECT ACCOUNT_ID FROM APP_OWNER.TST_ACCOUNT;
