-- CASE_ID: TC123
-- EXPECTED: REJECT
-- TAGS: dml,where,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Negative WHERE parsing case.
DELETE FROM APP_OWNER.TST_LOG
  -- operator intended a where below
;
