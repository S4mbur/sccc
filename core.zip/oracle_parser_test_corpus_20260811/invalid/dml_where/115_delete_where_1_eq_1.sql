-- CASE_ID: TC115
-- EXPECTED: REJECT
-- TAGS: dml,where,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Negative WHERE parsing case.
DELETE FROM APP_OWNER.TST_AUDIT_MARKER WHERE 1 = 1;
