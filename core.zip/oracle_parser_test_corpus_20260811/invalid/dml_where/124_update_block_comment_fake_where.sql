-- CASE_ID: TC124
-- EXPECTED: REJECT
-- TAGS: dml,where,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Negative WHERE parsing case.
UPDATE APP_OWNER.TST_CARD SET STATE = 'B' /* where card_id=1 */;
