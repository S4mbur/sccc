-- CASE_ID: TC122
-- EXPECTED: REJECT
-- TAGS: dml,where,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Negative WHERE parsing case.
UPDATE APP_OWNER.TST_ACCOUNT a SET a.STATUS = 'A';
