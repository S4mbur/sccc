-- CASE_ID: TC116
-- EXPECTED: REJECT
-- TAGS: dml,where,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Negative WHERE parsing case.
UPDATE APP_OWNER.TST_ACCOUNT SET STATUS = 'X' WHERE 1=1;
