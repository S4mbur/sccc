-- CASE_ID: TC334
-- EXPECTED: REJECT
-- TAGS: dml,update,where,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Bulk UPDATE without WHERE.
UPDATE CARD_OWNER.TST_ACCOUNT SET RISK_CLASS = 'M';
