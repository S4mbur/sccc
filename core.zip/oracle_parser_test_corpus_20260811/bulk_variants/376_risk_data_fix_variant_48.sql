-- CASE_ID: TC376
-- EXPECTED: REJECT
-- TAGS: dml,delete,comment,where,invalid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Fake WHERE in inline comment.
DELETE FROM RISK_OWNER.TST_RISK_QUEUE; -- WHERE RUN_ID = 48
