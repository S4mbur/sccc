-- CASE_ID: TC162
-- EXPECTED: ACCEPT
-- TAGS: ddl,owner,index,valid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: CREATE INDEX uses owner-qualified index and table names.
CREATE INDEX APP_OWNER.IX_TST_ACC_FLAG_05
    ON APP_OWNER.TST_ACCOUNT_FLAG (ACCOUNT_ID, AML_REVIEW_FLAG);
