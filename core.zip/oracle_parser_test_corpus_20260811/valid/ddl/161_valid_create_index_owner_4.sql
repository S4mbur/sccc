-- CASE_ID: TC161
-- EXPECTED: ACCEPT
-- TAGS: ddl,owner,index,valid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: CREATE INDEX uses owner-qualified index and table names.
CREATE INDEX DWH_OWNER.IX_TST_ACC_FLAG_04
    ON DWH_OWNER.TST_ACCOUNT_FLAG (ACCOUNT_ID, AML_REVIEW_FLAG);
