-- CASE_ID: TC144
-- EXPECTED: ACCEPT
-- TAGS: ddl,owner,alter,valid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: ALTER TABLE references an owner-qualified object.
ALTER TABLE PAY_OWNER.TST_CUSTOMER_LIMIT
  ADD (DEPLOY_NOTE_02 VARCHAR2(100));
