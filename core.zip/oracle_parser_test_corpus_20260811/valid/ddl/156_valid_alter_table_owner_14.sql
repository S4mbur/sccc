-- CASE_ID: TC156
-- EXPECTED: ACCEPT
-- TAGS: ddl,owner,alter,valid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: ALTER TABLE references an owner-qualified object.
ALTER TABLE DWH_OWNER.TST_CUSTOMER_LIMIT
  ADD (DEPLOY_NOTE_14 VARCHAR2(100));
