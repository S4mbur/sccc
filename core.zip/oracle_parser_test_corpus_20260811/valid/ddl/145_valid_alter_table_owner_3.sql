-- CASE_ID: TC145
-- EXPECTED: ACCEPT
-- TAGS: ddl,owner,alter,valid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: ALTER TABLE references an owner-qualified object.
ALTER TABLE RISK_OWNER.TST_CUSTOMER_LIMIT
  ADD (DEPLOY_NOTE_03 VARCHAR2(100));
