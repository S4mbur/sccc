-- CASE_ID: TC235
-- EXPECTED: ACCEPT
-- TAGS: select,output,valid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: One SELECT statement per requested output file.
SELECT ACCOUNT_ID, STATUS, UPDATED_AT
  FROM DWH_OWNER.TST_ACCOUNT
 WHERE ACCOUNT_ID = 3014;
