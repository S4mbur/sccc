-- CASE_ID: TC214
-- EXPECTED: ACCEPT
-- TAGS: comments,valid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Comment is on a separate line or inside PL/SQL create block.
CREATE OR REPLACE PROCEDURE APP_OWNER.PR_TST_COMMENT_OK AS
BEGIN
    -- internal PL/SQL comment is allowed
    NULL;
END PR_TST_COMMENT_OK;
/
