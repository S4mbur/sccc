-- CASE_ID: TC210
-- EXPECTED: ACCEPT
-- TAGS: comments,valid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Comment is on a separate line or inside PL/SQL create block.
-- explain business ticket
UPDATE APP_OWNER.TST_ACCOUNT SET STATUS = 'A' WHERE ACCOUNT_ID = 10;
