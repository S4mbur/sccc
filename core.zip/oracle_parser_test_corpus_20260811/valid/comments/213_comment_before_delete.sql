-- CASE_ID: TC213
-- EXPECTED: ACCEPT
-- TAGS: comments,valid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Comment is on a separate line or inside PL/SQL create block.
-- purge rejected batch only
DELETE FROM APP_OWNER.TST_STAGING_EVENT WHERE BATCH_ID = 7001 AND LOAD_STATUS = 'REJECTED';
