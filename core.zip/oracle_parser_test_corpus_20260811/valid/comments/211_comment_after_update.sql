-- CASE_ID: TC211
-- EXPECTED: ACCEPT
-- TAGS: comments,valid
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Comment is on a separate line or inside PL/SQL create block.
UPDATE APP_OWNER.TST_ACCOUNT SET STATUS = 'A' WHERE ACCOUNT_ID = 10;
-- completed for ticket
