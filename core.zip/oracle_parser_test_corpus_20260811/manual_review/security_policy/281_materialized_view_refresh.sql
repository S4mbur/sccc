-- CASE_ID: TC281
-- EXPECTED: MANUAL_REVIEW
-- TAGS: security,bank-policy,manual-review
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Policy-sensitive operation that many banks would block or require explicit approval.
BEGIN
 DBMS_MVIEW.REFRESH('APP_OWNER.MV_TST_ACCOUNT', 'C');
END;
/
