-- CASE_ID: TC274
-- EXPECTED: MANUAL_REVIEW
-- TAGS: security,bank-policy,manual-review
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Policy-sensitive operation that many banks would block or require explicit approval.
BEGIN
 UPDATE APP_OWNER.TST_ACCOUNT SET STATUS = 'A' WHERE STATUS IS NOT NULL;
END;
/
