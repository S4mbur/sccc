-- CASE_ID: TC271
-- EXPECTED: MANUAL_REVIEW
-- TAGS: security,bank-policy,manual-review
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Policy-sensitive operation that many banks would block or require explicit approval.
SELECT DBMS_CRYPTO.HASH(UTL_RAW.CAST_TO_RAW('secret'), 2) FROM DUAL;
