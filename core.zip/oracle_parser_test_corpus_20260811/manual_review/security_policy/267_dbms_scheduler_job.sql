-- CASE_ID: TC267
-- EXPECTED: MANUAL_REVIEW
-- TAGS: security,bank-policy,manual-review
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Policy-sensitive operation that many banks would block or require explicit approval.
BEGIN
DBMS_SCHEDULER.CREATE_JOB(job_name => 'APP_OWNER.BAD_JOB', job_type => 'PLSQL_BLOCK', job_action => 'BEGIN NULL; END;', enabled => TRUE);
END;
/
