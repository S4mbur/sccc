-- CASE_ID: TC252
-- EXPECTED: MANUAL_REVIEW
-- TAGS: security,bank-policy,manual-review
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Policy-sensitive operation that many banks would block or require explicit approval.
ALTER SYSTEM SET optimizer_features_enable = '19.1.0' SCOPE=BOTH;
