-- CASE_ID: TC269
-- EXPECTED: MANUAL_REVIEW
-- TAGS: security,bank-policy,manual-review
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Policy-sensitive operation that many banks would block or require explicit approval.
BEGIN
 UTL_FILE.FREMOVE('DATA_PUMP_DIR', 'important.log');
END;
/
