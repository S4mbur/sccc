-- CASE_ID: TC263
-- EXPECTED: MANUAL_REVIEW
-- TAGS: security,bank-policy,manual-review
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Policy-sensitive operation that many banks would block or require explicit approval.
ALTER TABLE APP_OWNER.TST_ACCOUNT DROP CONSTRAINT FK_TST_ACCOUNT_CUSTOMER;
