-- CASE_ID: TC270
-- EXPECTED: MANUAL_REVIEW
-- TAGS: security,bank-policy,manual-review
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Policy-sensitive operation that many banks would block or require explicit approval.
BEGIN
 DBMS_OUTPUT.PUT_LINE(UTL_HTTP.REQUEST('http://example.invalid'));
END;
/
