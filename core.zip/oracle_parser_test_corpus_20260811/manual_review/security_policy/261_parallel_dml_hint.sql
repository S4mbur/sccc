-- CASE_ID: TC261
-- EXPECTED: MANUAL_REVIEW
-- TAGS: security,bank-policy,manual-review
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Policy-sensitive operation that many banks would block or require explicit approval.
INSERT /*+ APPEND PARALLEL(8) */ INTO APP_OWNER.TST_AUDIT_MARKER (MARKER_ID) SELECT LEVEL FROM DUAL CONNECT BY LEVEL <= 1000;
