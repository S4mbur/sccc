-- CASE_ID: TC259
-- EXPECTED: MANUAL_REVIEW
-- TAGS: security,bank-policy,manual-review
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Policy-sensitive operation that many banks would block or require explicit approval.
SPOOL C:\temp\customer_extract.csv
SELECT * FROM APP_OWNER.TST_ACCOUNT;
SPOOL OFF
