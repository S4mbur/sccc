-- CASE_ID: TC250
-- EXPECTED: MANUAL_REVIEW
-- TAGS: security,bank-policy,manual-review
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Policy-sensitive operation that many banks would block or require explicit approval.
CREATE PUBLIC SYNONYM TST_ACCOUNT FOR APP_OWNER.TST_ACCOUNT;
