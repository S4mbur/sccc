-- CASE_ID: TC253
-- EXPECTED: MANUAL_REVIEW
-- TAGS: security,bank-policy,manual-review
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Policy-sensitive operation that many banks would block or require explicit approval.
ALTER DATABASE DATAFILE '/u01/oradata/prod01.dbf' RESIZE 40G;
