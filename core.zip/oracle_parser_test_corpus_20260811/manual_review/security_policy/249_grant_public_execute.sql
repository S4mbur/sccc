-- CASE_ID: TC249
-- EXPECTED: MANUAL_REVIEW
-- TAGS: security,bank-policy,manual-review
-- TARGET_DB: COREBANK
-- REQUEST_TITLE: COREBANK synthetic parser validation
-- NOTE: Policy-sensitive operation that many banks would block or require explicit approval.
GRANT EXECUTE ON APP_OWNER.PKG_TST_DEPLOY TO PUBLIC;
