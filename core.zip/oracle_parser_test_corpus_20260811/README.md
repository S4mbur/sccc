# Oracle Parser Test Corpus

Synthetic Oracle deployment parser corpus generated for parser validation.
These scripts use fictitious schemas and tables. Do not run them in production.

Counts:
- Total cases: 383
- ACCEPT: 238
- REJECT: 101
- MANUAL_REVIEW: 44

Important rule themes:
- DML UPDATE/DELETE should include a real WHERE clause.
- DDL and DML should be submitted as separate files.
- DDL object names should include schema owner.
- CREATE PROCEDURE/FUNCTION/PACKAGE/TRIGGER and anonymous BEGIN...END blocks need slash execution terminators.
- Inline comments appended to SQL statements are negative cases.
- Ordered runs should use two-digit filename prefixes.
- SELECT output requests should use one SELECT per file.
- Security-sensitive operations are marked MANUAL_REVIEW.

See manifest.csv for expected results and tags.
