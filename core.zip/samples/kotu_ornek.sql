-- Musteri tablosu duzenleme
SET SERVEROUTPUT ON

DROP TABLE bankapp.musteri_yedek;

CREATE TABLE musteri_temp (
  id      NUMBER,
  ad      VARCHAR2(100),
  bakiye  NUMBER(18,2)
);

ALTER TABLE bankapp.musteri ADD (kimlik_no VARCHAR2(11) NOT NULL);

UPDATE bankapp.hesap SET durum = 'P';

DELETE FROM bankapp.hareket;

INSERT INTO bankapp.log_tablosu VALUES (1, 'A&B testi', SYSDATE);

CREATE INDEX ix_hesap_musteri ON bankapp.hesap(musteri_id) NOLOGGING;

GRANT SELECT ANY TABLE TO PUBLIC;

ALTER USER app_user IDENTIFIED BY Yeni_Sifre123;

SELECT * FROM bankapp.musteri m, bankapp.hesap h;

BEGIN
  FOR r IN (SELECT id FROM bankapp.hesap) LOOP
    UPDATE bankapp.hesap SET guncelleme = TO_DATE('01/01/2026') WHERE id = r.id;
    COMMIT;
  END LOOP;
  EXECUTE IMMEDIATE 'DROP TABLE ' || v_tablo;
END;
/
