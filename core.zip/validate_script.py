#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Oracle SQL Script Dogrulayici (parser).

Kullanim:
    python validate_script.py degisiklik.sql
    python validate_script.py *.sql --config config.yaml --json rapor.json
    python validate_script.py --list-rules

Cikis kodlari:
    0 = PASS   (bulgu yok / sadece INFO)
    1 = WARN   (uyari var)
    2 = FAIL   (engelleyici bulgu var)
    3 = HATA   (dosya okunamadi vb.)
"""
from __future__ import annotations

import argparse
import glob
import io
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from core.config import load_config                      # noqa: E402
from core.context import ScriptContext                   # noqa: E402
from core.registry import discover_rules, run_rules      # noqa: E402
from core.model import Severity                          # noqa: E402
from core import reporter                                # noqa: E402


def read_text(path: str, encoding: str) -> str:
    with io.open(path, "r", encoding=encoding, errors="replace") as f:
        return f.read()


def main(argv=None) -> int:
    p = argparse.ArgumentParser(
        description="Oracle SQL script'lerini kural bazli dogrular (sadece parsing).",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("scripts", nargs="*", help="Dogrulanacak .sql dosyalari")
    p.add_argument("-c", "--config", default=None, help="config.yaml yolu")
    p.add_argument("-j", "--json", default=None, help="JSON rapor dosyasi")
    p.add_argument("-f", "--format", default="console",
                   choices=["console", "json", "both", "quiet"],
                   help="Cikti bicimi (varsayilan: console)")
    p.add_argument("--encoding", default="utf-8", help="Dosya kodlamasi")
    p.add_argument("--list-rules", action="store_true", help="Kurallari listele ve cik")
    p.add_argument("--rule-info", metavar="ID", help="Tek bir kuralin detayini goster")
    p.add_argument("--only", metavar="IDs", help="Sadece bu kurallari calistir (virgullu)")
    p.add_argument("--skip", metavar="IDs", help="Bu kurallari atla (virgullu)")
    p.add_argument("--category", metavar="CATS", help="Sadece bu kategoriler (virgullu)")
    p.add_argument("--min-severity", default="INFO", choices=["INFO", "WARN", "FAIL"],
                   help="Bu seviyenin altindaki bulgulari gizle")
    p.add_argument("--fail-on", default="FAIL", choices=["INFO", "WARN", "FAIL"],
                   help="Hangi seviyeden itibaren exit kodu 2 olsun")
    p.add_argument("--max-per-rule", type=int, default=0,
                   help="Kural basina gosterilecek maksimum bulgu (0 = sinirsiz)")
    p.add_argument("--no-color", action="store_true", help="ANSI renklerini kapat")
    args = p.parse_args(argv)

    default_cfg = os.path.join(HERE, "config.yaml")
    cfg_path = args.config or (default_cfg if os.path.exists(default_cfg) else None)
    try:
        config = load_config(cfg_path)
    except Exception as exc:                                     # noqa: BLE001
        sys.stderr.write("Config okunamadi: %s\n" % exc)
        return reporter.EXIT_ERROR

    rules = discover_rules(config=config)

    if args.only:
        keep = {x.strip().upper() for x in args.only.split(",")}
        for r in rules:
            r.enabled = r.id in keep
    if args.skip:
        drop = {x.strip().upper() for x in args.skip.split(",")}
        for r in rules:
            if r.id in drop:
                r.enabled = False
    if args.category:
        cats = {x.strip().upper() for x in args.category.split(",")}
        for r in rules:
            if r.category.upper() not in cats:
                r.enabled = False

    if args.list_rules:
        print(reporter.render_rule_list(rules))
        return reporter.EXIT_PASS

    if args.rule_info:
        rid = args.rule_info.strip().upper()
        for r in rules:
            if r.id == rid:
                m = r.meta()
                print("%s - %s" % (m["id"], m["name"]))
                print("Kategori   : %s" % m["category"])
                print("Seviye     : %s   (aktif: %s)" % (m["severity"], m["enabled"]))
                print("Kontrol    : %s" % m["description"])
                print("Gerekce    : %s" % m["rationale"])
                print("Cozum      : %s" % m["remediation"])
                print("Parametre  : %s" % (m["params"] or "-"))
                return reporter.EXIT_PASS
        sys.stderr.write("Kural bulunamadi: %s\n" % rid)
        return reporter.EXIT_ERROR

    paths = []
    for pattern in args.scripts:
        hits = glob.glob(pattern)
        paths.extend(hits if hits else [pattern])
    if not paths:
        p.print_help()
        return reporter.EXIT_ERROR

    worst = "PASS"
    for path in paths:
        if not os.path.isfile(path):
            sys.stderr.write("Dosya bulunamadi: %s\n" % path)
            worst = "FAIL"
            continue
        t0 = time.time()
        try:
            text = read_text(path, args.encoding)
            ctx = ScriptContext(path, text, settings=config.get("settings"))
            findings = run_rules(rules, ctx)
        except Exception as exc:                                 # noqa: BLE001
            sys.stderr.write("%s islenirken hata: %s: %s\n"
                             % (path, type(exc).__name__, exc))
            worst = "FAIL"
            continue

        floor = Severity.rank(args.min_severity)
        findings = [f for f in findings if Severity.rank(f.severity) >= floor]

        report = reporter.build_report(rules=rules, ctx=ctx, findings=findings,
                                       duration_ms=(time.time() - t0) * 1000)

        # --fail-on esigini uygula
        top = Severity.max([f.severity for f in findings]) if findings else "INFO"
        if Severity.rank(top) >= Severity.rank(args.fail_on):
            report["verdict"] = "FAIL"
        elif findings and Severity.rank(top) >= Severity.rank("WARN"):
            report["verdict"] = "WARN"
        report["exit_code"] = reporter.exit_code(report["verdict"])

        if args.format in ("console", "both"):
            print(reporter.render_console(
                report, findings, use_color=not args.no_color,
                show_info=Severity.rank(args.min_severity) <= 0,
                max_per_rule=args.max_per_rule))
        if args.format in ("json", "both"):
            import json as _json
            print(_json.dumps(report, ensure_ascii=False, indent=2))
        if args.json:
            out = args.json
            if len(paths) > 1:
                base, ext = os.path.splitext(out)
                out = "%s_%s%s" % (base, os.path.basename(path).replace(".", "_"), ext)
            reporter.write_json(report, out)
            if args.format != "quiet":
                sys.stderr.write("JSON rapor: %s\n" % out)

        if Severity.rank(report["verdict"]) > Severity.rank(worst):
            worst = report["verdict"]

    return reporter.exit_code(worst)


if __name__ == "__main__":
    sys.exit(main())
