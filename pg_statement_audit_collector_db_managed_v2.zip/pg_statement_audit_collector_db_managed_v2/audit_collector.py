#!/usr/bin/env python3
import csv
import io
import json
import logging
import os
import re
import signal
import subprocess
import time
from pathlib import Path

RUNNING = True
APP_DIR = Path(__file__).resolve().parent

def env(name, default=None):
    return os.environ.get(name, default)

def bool_env(name, default=False):
    raw = env(name, "true" if default else "false")
    return str(raw).strip().lower() in ("1", "true", "yes", "on")

def resolve_app_path(value):
    p = Path(value)
    return p if p.is_absolute() else APP_DIR / p

PGDATA = Path(env("PGDATA", "/data/postgres/data"))
PGPORT = str(env("PGPORT", "5420"))
AUDIT_DB = env("AUDIT_DB", "auditdb")
AUDIT_USER = env("AUDIT_USER", "audit_writer")
PSQL_BIN = env("PSQL_BIN", "/usr/bin/psql")

STATE_FILE = resolve_app_path(env("STATE_FILE", "state/state.json"))

SCOPE_REFRESH_SECONDS = int(env("SCOPE_REFRESH_SECONDS", "20"))
IGNORE_REFRESH_SECONDS = int(env("IGNORE_REFRESH_SECONDS", "30"))
POLL_SECONDS = float(env("POLL_SECONDS", "0.50"))
BATCH_SIZE = int(env("BATCH_SIZE", "100"))
FLUSH_SECONDS = float(env("FLUSH_SECONDS", "2"))
START_AT_END = bool_env("START_AT_END", True)
SCOPE_ALLOW_ALL_IF_EMPTY = bool_env("SCOPE_ALLOW_ALL_IF_EMPTY", False)
AUDIT_RELATIONLESS_DDL = bool_env("AUDIT_RELATIONLESS_DDL", True)

logging.basicConfig(
    level=getattr(logging, env("COLLECTOR_LOG_LEVEL", "INFO").upper(), logging.INFO),
    format="%(asctime)s %(levelname)s %(message)s",
)
LOG = logging.getLogger("pg-statement-audit")

IDENT = r'(?:"(?:[^"]|"")*"|[A-Za-z_][A-Za-z0-9_$]*)'
REL = rf'(?:(?P<schema>{IDENT})\s*\.\s*)?(?P<table>{IDENT})'

REL_PATTERNS = [
    re.compile(rf'\bFROM\s+{REL}', re.I),
    re.compile(rf'\bJOIN\s+{REL}', re.I),
    re.compile(rf'\bUPDATE\s+{REL}', re.I),
    re.compile(rf'\bINSERT\s+INTO\s+{REL}', re.I),
    re.compile(rf'\bDELETE\s+FROM\s+{REL}', re.I),
    re.compile(rf'\bMERGE\s+INTO\s+{REL}', re.I),
    re.compile(rf'\bTRUNCATE(?:\s+TABLE)?\s+{REL}', re.I),
    re.compile(rf'\bALTER\s+TABLE(?:\s+IF\s+EXISTS)?\s+{REL}', re.I),
    re.compile(rf'\bDROP\s+TABLE(?:\s+IF\s+EXISTS)?\s+{REL}', re.I),
    re.compile(rf'\bCREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?\s+{REL}', re.I),
    re.compile(rf'\bLOCK\s+TABLE\s+{REL}', re.I),
    re.compile(rf'\bREFERENCES\s+{REL}', re.I),
    re.compile(rf'\bCREATE(?:\s+UNIQUE)?\s+INDEX\b.*?\bON\s+{REL}', re.I | re.S),
    re.compile(rf'\bALTER\s+INDEX(?:\s+IF\s+EXISTS)?\s+{REL}', re.I),
    re.compile(rf'\bDROP\s+INDEX(?:\s+IF\s+EXISTS)?\s+{REL}', re.I),
    re.compile(rf'\bGRANT\b.*?\bON(?:\s+TABLE)?\s+{REL}', re.I | re.S),
    re.compile(rf'\bREVOKE\b.*?\bON(?:\s+TABLE)?\s+{REL}', re.I | re.S),
    re.compile(rf'\bCOMMENT\s+ON\s+TABLE\s+{REL}', re.I),
]

CTE_RE = re.compile(
    rf'(?:\bWITH\b|,)\s*(?P<cte>{IDENT})\s*(?:\([^)]*\))?\s+AS\s*(?:NOT\s+MATERIALIZED\s+|MATERIALIZED\s+)?\(',
    re.I | re.S
)

MSG_SQL_RE = re.compile(r'^(?:statement|execute(?:\s+[^:]+)?):\s*(.*)$', re.I | re.S)

RELATIONLESS_DDL_COMMANDS = {
    "CREATE", "ALTER", "DROP", "GRANT", "REVOKE", "COMMENT", "DO", "CALL"
}

KNOWN_COMMANDS = (
    "SELECT", "INSERT", "UPDATE", "DELETE", "MERGE", "TRUNCATE",
    "CREATE", "ALTER", "DROP", "GRANT", "REVOKE", "COMMENT",
    "COPY", "CALL", "DO", "SHOW", "SET", "RESET"
)

def stop_handler(signum, frame):
    global RUNNING
    RUNNING = False

signal.signal(signal.SIGTERM, stop_handler)
signal.signal(signal.SIGINT, stop_handler)

def ident_value(token):
    if token is None:
        return None
    token = token.strip()
    if token.startswith('"') and token.endswith('"'):
        return token[1:-1].replace('""', '"')
    return token.lower()

def classify(sql):
    stripped = re.sub(
        r'^\s*(?:--[^\n]*(?:\n|$)\s*|/\*.*?\*/\s*)*',
        '',
        sql,
        flags=re.S
    )
    m = re.match(r'([A-Za-z]+)', stripped)
    if m and m.group(1).upper() != "WITH":
        return m.group(1).upper()

    upper = stripped.upper()
    hits = []
    for cmd in KNOWN_COMMANDS:
        x = re.search(rf'\b{cmd}\b', upper)
        if x:
            hits.append((x.start(), cmd))
    return min(hits)[1] if hits else "UNKNOWN"

def extract_sql(entry):
    msg = entry.get("message") or ""
    m = MSG_SQL_RE.match(msg)
    return m.group(1).strip() if m else None

def extract_relations(sql):
    ctes = {ident_value(m.group("cte")) for m in CTE_RE.finditer(sql)}
    relations = set()

    for pattern in REL_PATTERNS:
        for m in pattern.finditer(sql):
            gd = m.groupdict()
            schema = ident_value(gd.get("schema"))
            table = ident_value(gd.get("table"))

            if not table:
                continue
            if schema is None and table in ctes:
                continue

            relations.add((schema, table))

    return relations

def psql_base():
    return [
        PSQL_BIN,
        "-X",
        "-q",
        "-v", "ON_ERROR_STOP=1",
        "-p", PGPORT,
        "-U", AUDIT_USER,
        "-d", AUDIT_DB,
    ]

def psql_csv_query(select_sql):
    cmd = psql_base() + [
        "-c",
        f"COPY ({select_sql}) TO STDOUT WITH (FORMAT csv, NULL '\\N')"
    ]
    result = subprocess.run(
        cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "psql query failed")

    return [
        [None if v == r"\N" else v for v in row]
        for row in csv.reader(io.StringIO(result.stdout))
    ]

def load_scope():
    return {
        (r[0], r[1])
        for r in psql_csv_query("""
            SELECT db_user, database_name
            FROM audit_scope
            WHERE enabled
        """)
    }

def load_ignores():
    schemas = {
        r[0]
        for r in psql_csv_query("""
            SELECT schema_name
            FROM audit_ignore_schema
            WHERE enabled
        """)
    }
    tables = {
        (r[0], r[1], r[2])
        for r in psql_csv_query("""
            SELECT database_name, schema_name, table_name
            FROM audit_ignore_table
            WHERE enabled
        """)
    }
    return schemas, tables

def scope_allows(scope, db_user, database_name):
    if not scope:
        return SCOPE_ALLOW_ALL_IF_EMPTY

    u = db_user or ""
    d = database_name or ""

    return (
        ("*", "*") in scope or
        (u, "*") in scope or
        ("*", d) in scope or
        (u, d) in scope
    )

def relation_is_ignored(database_name, schema, table, ignored_schemas, ignored_tables):
    # Unknown schema => do NOT guess => audit it.
    if schema is None:
        return False

    # STRICT equality only.
    if schema in ignored_schemas:
        return True

    if (database_name, schema, table) in ignored_tables:
        return True

    return False

def current_jsonlog():
    marker = PGDATA / "current_logfiles"
    if not marker.exists():
        raise FileNotFoundError(f"{marker} not found")

    for line in marker.read_text(encoding="utf-8", errors="replace").splitlines():
        dest, _, relpath = line.partition(" ")
        if dest.strip() != "jsonlog":
            continue

        relpath = relpath.strip()
        if not relpath:
            continue

        p = Path(relpath)
        if not p.is_absolute():
            p = PGDATA / p

        if p.is_dir():
            candidates = list(p.glob("*.json")) + list(p.glob("*.jsonlog"))
            if not candidates:
                raise RuntimeError(f"No JSON log file found below {p}")
            p = max(candidates, key=lambda x: x.stat().st_mtime)

        if not p.exists():
            raise FileNotFoundError(f"jsonlog not found: {p}")

        return p

    raise RuntimeError(f"No jsonlog entry found in {marker}")

def load_state():
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}

def save_state(path, inode, offset):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(
        json.dumps({"path": str(path), "inode": inode, "offset": offset}),
        encoding="utf-8"
    )
    os.replace(tmp, STATE_FILE)

def open_follow_file(path, state):
    fh = path.open("r", encoding="utf-8", errors="replace")
    inode = path.stat().st_ino

    if state.get("path") == str(path) and state.get("inode") == inode:
        offset = int(state.get("offset", 0))
        fh.seek(offset)
        LOG.info("resuming %s at offset %s", path, offset)
    elif START_AT_END:
        fh.seek(0, os.SEEK_END)
        LOG.info("starting at end of %s", path)
    else:
        fh.seek(0)
        LOG.info("starting at beginning of %s", path)

    return fh, inode

def int_or_none(v):
    try:
        return int(v) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None

def build_rows(entry, sql, scope, ignored_schemas, ignored_tables):
    db_user = entry.get("user")
    dbname = entry.get("dbname")

    if not scope_allows(scope, db_user, dbname):
        return []

    command = classify(sql)
    relations = extract_relations(sql)

    if relations:
        kept = [
            (schema, table)
            for schema, table in sorted(relations, key=lambda x: ((x[0] or ""), x[1]))
            if not relation_is_ignored(
                dbname, schema, table, ignored_schemas, ignored_tables
            )
        ]

        if not kept:
            return []

        return [
            (
                entry.get("timestamp"),
                dbname,
                db_user,
                entry.get("remote_host"),
                int_or_none(entry.get("remote_port")),
                entry.get("application_name"),
                int_or_none(entry.get("pid")),
                entry.get("session_id"),
                command,
                schema,
                table,
                sql,
            )
            for schema, table in kept
        ]

    if AUDIT_RELATIONLESS_DDL and command in RELATIONLESS_DDL_COMMANDS:
        return [(
            entry.get("timestamp"),
            dbname,
            db_user,
            entry.get("remote_host"),
            int_or_none(entry.get("remote_port")),
            entry.get("application_name"),
            int_or_none(entry.get("pid")),
            entry.get("session_id"),
            command,
            None,
            None,
            sql,
        )]

    return []

def flush_rows(rows):
    if not rows:
        return

    copy_sql = r"""
COPY audit_history
(event_time, database_name, db_user, client_ip, client_port,
 application_name, pid, session_id, command_type,
 schema_name, table_name, statement)
FROM STDIN WITH (FORMAT csv, NULL '\N')
""".strip()

    buf = io.StringIO(newline="")
    writer = csv.writer(buf, lineterminator="\n")

    for row in rows:
        writer.writerow([r"\N" if value is None else value for value in row])

    proc = subprocess.run(
        psql_base() + ["-c", copy_sql],
        input=buf.getvalue(),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )

    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "audit COPY failed")

    rows.clear()

def main():
    LOG.info(
        "collector starting; app_dir=%s PGDATA=%s port=%s db=%s user=%s",
        APP_DIR, PGDATA, PGPORT, AUDIT_DB, AUDIT_USER
    )

    scope = set()
    ignored_schemas = set()
    ignored_tables = set()
    next_scope_refresh = 0.0
    next_ignore_refresh = 0.0
    rows = []
    last_flush = time.monotonic()

    path = current_jsonlog()
    fh, inode = open_follow_file(path, load_state())

    while RUNNING:
        now = time.monotonic()

        if now >= next_scope_refresh:
            try:
                scope = load_scope()
                next_scope_refresh = now + SCOPE_REFRESH_SECONDS
            except Exception as exc:
                LOG.error("scope refresh failed: %s", exc)
                time.sleep(2)
                continue

        if now >= next_ignore_refresh:
            try:
                ignored_schemas, ignored_tables = load_ignores()
                next_ignore_refresh = now + IGNORE_REFRESH_SECONDS
            except Exception as exc:
                LOG.error("ignore refresh failed: %s", exc)
                time.sleep(2)
                continue

        line = fh.readline()

        if line:
            try:
                entry = json.loads(line)
                sql = extract_sql(entry)
                if sql:
                    rows.extend(
                        build_rows(
                            entry, sql, scope,
                            ignored_schemas, ignored_tables
                        )
                    )
            except json.JSONDecodeError:
                LOG.warning("invalid JSON line skipped at %s:%s", path, fh.tell())
            except Exception:
                LOG.exception("processing error")

            save_state(path, inode, fh.tell())

        else:
            try:
                new_path = current_jsonlog()
                new_inode = new_path.stat().st_ino

                if str(new_path) != str(path) or new_inode != inode:
                    fh.close()
                    path = new_path
                    fh, inode = open_follow_file(path, {})
                    LOG.info("switched to rotated jsonlog %s", path)

            except Exception as exc:
                LOG.warning("rotation check failed: %s", exc)

            time.sleep(POLL_SECONDS)

        if rows and (
            len(rows) >= BATCH_SIZE or
            now - last_flush >= FLUSH_SECONDS
        ):
            try:
                flush_rows(rows)
                last_flush = now
            except Exception:
                LOG.exception("audit write failed; rows retained for retry")
                time.sleep(2)

    try:
        if rows:
            flush_rows(rows)
    except Exception:
        LOG.exception("final audit flush failed")

    try:
        fh.close()
    except Exception:
        pass

    LOG.info("collector stopped")

if __name__ == "__main__":
    main()
