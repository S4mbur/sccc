#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
ENV_FILE="$APP_DIR/collector.env"
SERVICE_FILE="/etc/systemd/system/pg-audit-collector.service"

if [[ "$(id -u)" -ne 0 ]]; then
    echo "ERROR: run as root: sudo bash install.sh"
    exit 1
fi

set -a
source "$ENV_FILE"
set +a

: "${PGDATA:=/data/postgres/data}"
: "${PGPORT:=5420}"
: "${AUDIT_DB:=auditdb}"
: "${AUDIT_USER:=audit_writer}"
: "${ADMIN_DB:=postgres}"
: "${ADMIN_DB_USER:=postgres}"
: "${SERVICE_OS_USER:=postgres}"
: "${SERVICE_OS_GROUP:=postgres}"
: "${PSQL_BIN:=/usr/bin/psql}"
: "${PYTHON_BIN:=/usr/bin/python3}"
: "${CREATEDB_BIN:=/usr/bin/createdb}"

echo "Project : $APP_DIR"
echo "PGDATA  : $PGDATA"
echo "Port    : $PGPORT"
echo "Audit DB: $AUDIT_DB"

systemctl stop pg-audit-collector 2>/dev/null || true

install -d -m 0750 -o "$SERVICE_OS_USER" -g "$SERVICE_OS_GROUP" "$APP_DIR/state"

chown root:"$SERVICE_OS_GROUP" \
    "$APP_DIR/collector.env" \
    "$APP_DIR/audit_collector.py" \
    "$APP_DIR/schema.sql"

chmod 0640 "$APP_DIR/collector.env" "$APP_DIR/schema.sql"
chmod 0750 "$APP_DIR/audit_collector.py" "$APP_DIR/install.sh"

admin_psql=(
    sudo -u "$SERVICE_OS_USER"
    "$PSQL_BIN"
    -X
    -v ON_ERROR_STOP=1
    -p "$PGPORT"
    -U "$ADMIN_DB_USER"
)

echo "[1] Checking admin connection..."
"${admin_psql[@]}" -d "$ADMIN_DB" -Atqc "SELECT 1" >/dev/null

echo "[2] Creating audit role if needed..."
role_exists="$("${admin_psql[@]}" -d "$ADMIN_DB" -Atqc \
    "SELECT 1 FROM pg_roles WHERE rolname='$AUDIT_USER';")"

if [[ "$role_exists" != "1" ]]; then
    "${admin_psql[@]}" -d "$ADMIN_DB" -c \
        "CREATE ROLE \"$AUDIT_USER\" LOGIN;"
fi

"${admin_psql[@]}" -d "$ADMIN_DB" -c \
    "ALTER ROLE \"$AUDIT_USER\" SET log_statement='none';"

echo "[3] Creating audit DB if needed..."
db_exists="$("${admin_psql[@]}" -d "$ADMIN_DB" -Atqc \
    "SELECT 1 FROM pg_database WHERE datname='$AUDIT_DB';")"

if [[ "$db_exists" != "1" ]]; then
    sudo -u "$SERVICE_OS_USER" "$CREATEDB_BIN" \
        -p "$PGPORT" \
        -U "$ADMIN_DB_USER" \
        -O "$ADMIN_DB_USER" \
        "$AUDIT_DB"
fi

echo "[4] Creating/upgrading repository..."
"${admin_psql[@]}" -d "$AUDIT_DB" -f "$APP_DIR/schema.sql"

echo "[5] Applying permissions..."
"${admin_psql[@]}" -d "$AUDIT_DB" -c \
    "GRANT CONNECT ON DATABASE \"$AUDIT_DB\" TO \"$AUDIT_USER\";"

"${admin_psql[@]}" -d "$AUDIT_DB" -c \
    "GRANT USAGE ON SCHEMA public TO \"$AUDIT_USER\";"

"${admin_psql[@]}" -d "$AUDIT_DB" -c \
    "GRANT SELECT, INSERT, UPDATE, DELETE
     ON audit_scope, audit_ignore_schema, audit_ignore_table
     TO \"$AUDIT_USER\";"

"${admin_psql[@]}" -d "$AUDIT_DB" -c \
    "GRANT SELECT, INSERT ON audit_history TO \"$AUDIT_USER\";"

"${admin_psql[@]}" -d "$AUDIT_DB" -c \
    "GRANT EXECUTE ON FUNCTION
       audit_scope_set(text,text,boolean),
       audit_scope_delete(text,text),
       audit_ignore_schema_set(text,boolean),
       audit_ignore_schema_delete(text),
       audit_ignore_table_set(text,text,text,boolean),
       audit_ignore_table_delete(text,text,text)
     TO \"$AUDIT_USER\";"

"${admin_psql[@]}" -d "$AUDIT_DB" -c \
    "GRANT USAGE, SELECT ON SEQUENCE audit_history_id_seq TO \"$AUDIT_USER\";" \
    2>/dev/null || true

echo "[6] Testing audit_writer local psql connection..."
sudo -u "$SERVICE_OS_USER" "$PSQL_BIN" \
    -X -q \
    -p "$PGPORT" \
    -U "$AUDIT_USER" \
    -d "$AUDIT_DB" \
    -Atqc "SELECT count(*) FROM audit_scope;" >/dev/null

echo "[7] Checking jsonlog..."
marker="$PGDATA/current_logfiles"

if [[ ! -f "$marker" ]]; then
    echo "ERROR: $marker not found"
    exit 1
fi

if ! grep -q '^jsonlog ' "$marker"; then
    echo "ERROR: no jsonlog entry found in $marker"
    cat "$marker" || true
    exit 1
fi

echo "[8] Installing the only /etc file..."
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=PostgreSQL filtered statement audit collector
After=network.target

[Service]
Type=simple
User=$SERVICE_OS_USER
Group=$SERVICE_OS_GROUP
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/collector.env
ExecStart=$PYTHON_BIN $APP_DIR/audit_collector.py
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

chmod 0644 "$SERVICE_FILE"

systemctl daemon-reload
systemctl reset-failed pg-audit-collector 2>/dev/null || true
systemctl enable pg-audit-collector >/dev/null
systemctl restart pg-audit-collector

sleep 2
systemctl --no-pager --full status pg-audit-collector || true

echo
echo "Installation complete."
echo "All further management is SQL-only inside $AUDIT_DB."
