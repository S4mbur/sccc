CREATE TABLE IF NOT EXISTS audit_scope (
    db_user       text NOT NULL,
    database_name text NOT NULL,
    enabled       boolean NOT NULL DEFAULT true,
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (db_user, database_name),
    CHECK (btrim(db_user) <> ''),
    CHECK (btrim(database_name) <> '')
);

COMMENT ON TABLE audit_scope IS
'DB user + database audit scope. Literal * is supported here only as wildcard.';

CREATE TABLE IF NOT EXISTS audit_ignore_schema (
    schema_name text PRIMARY KEY,
    enabled     boolean NOT NULL DEFAULT true,
    created_at  timestamptz NOT NULL DEFAULT now(),
    updated_at  timestamptz NOT NULL DEFAULT now(),
    CHECK (btrim(schema_name) <> ''),
    CHECK (schema_name <> '*')
);

COMMENT ON TABLE audit_ignore_schema IS
'STRICT exact schema ignore list. No LIKE, prefix, regex or wildcard matching.';

CREATE TABLE IF NOT EXISTS audit_ignore_table (
    database_name text NOT NULL,
    schema_name   text NOT NULL,
    table_name    text NOT NULL,
    enabled       boolean NOT NULL DEFAULT true,
    created_at    timestamptz NOT NULL DEFAULT now(),
    updated_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (database_name, schema_name, table_name),
    CHECK (btrim(database_name) <> ''),
    CHECK (btrim(schema_name) <> ''),
    CHECK (btrim(table_name) <> ''),
    CHECK (database_name <> '*'),
    CHECK (schema_name <> '*'),
    CHECK (table_name <> '*')
);

COMMENT ON TABLE audit_ignore_table IS
'STRICT exact database + schema + table ignore list. No LIKE, prefix, regex or wildcard matching.';

CREATE TABLE IF NOT EXISTS audit_history (
    id               bigserial PRIMARY KEY,
    event_time       timestamptz NOT NULL,
    database_name    text,
    db_user          text,
    client_ip        inet,
    client_port      integer,
    application_name text,
    pid              integer,
    session_id       text,
    command_type     text,
    schema_name      text,
    table_name       text,
    statement        text NOT NULL,
    created_at       timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE audit_history ADD COLUMN IF NOT EXISTS database_name text;
ALTER TABLE audit_history ADD COLUMN IF NOT EXISTS db_user text;
ALTER TABLE audit_history ADD COLUMN IF NOT EXISTS client_ip inet;
ALTER TABLE audit_history ADD COLUMN IF NOT EXISTS client_port integer;
ALTER TABLE audit_history ADD COLUMN IF NOT EXISTS application_name text;
ALTER TABLE audit_history ADD COLUMN IF NOT EXISTS pid integer;
ALTER TABLE audit_history ADD COLUMN IF NOT EXISTS session_id text;
ALTER TABLE audit_history ADD COLUMN IF NOT EXISTS command_type text;
ALTER TABLE audit_history ADD COLUMN IF NOT EXISTS schema_name text;
ALTER TABLE audit_history ADD COLUMN IF NOT EXISTS table_name text;
ALTER TABLE audit_history ADD COLUMN IF NOT EXISTS statement text;
ALTER TABLE audit_history ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

DO $$
DECLARE
    seq regclass;
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns
        WHERE table_schema='public'
          AND table_name='audit_history'
          AND column_name='id'
    ) THEN
        ALTER TABLE audit_history ADD COLUMN id bigint;
    END IF;

    seq := pg_get_serial_sequence('public.audit_history', 'id');

    IF seq IS NULL THEN
        CREATE SEQUENCE IF NOT EXISTS audit_history_id_seq;
        ALTER SEQUENCE audit_history_id_seq OWNED BY audit_history.id;
        ALTER TABLE audit_history
            ALTER COLUMN id SET DEFAULT nextval('audit_history_id_seq');
        seq := 'audit_history_id_seq'::regclass;
    END IF;

    EXECUTE format(
        'UPDATE public.audit_history SET id = nextval(%L) WHERE id IS NULL',
        seq::text
    );

    PERFORM setval(
        seq,
        GREATEST(COALESCE((SELECT max(id) FROM audit_history), 0), 1),
        true
    );
END
$$;

CREATE UNIQUE INDEX IF NOT EXISTS ux_audit_history_id
    ON audit_history(id);

CREATE INDEX IF NOT EXISTS idx_audit_history_event_time
    ON audit_history(event_time DESC);

CREATE INDEX IF NOT EXISTS idx_audit_history_db_user_time
    ON audit_history(database_name, db_user, event_time DESC);

CREATE INDEX IF NOT EXISTS idx_audit_history_relation_time
    ON audit_history(schema_name, table_name, event_time DESC);

-- Explicit exact defaults only.
INSERT INTO audit_ignore_schema(schema_name, enabled)
VALUES
    ('pg_catalog', true),
    ('information_schema', true),
    ('pg_toast', true)
ON CONFLICT (schema_name) DO NOTHING;

CREATE OR REPLACE FUNCTION audit_scope_set(
    p_user text,
    p_database text,
    p_enabled boolean DEFAULT true
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_user IS NULL OR btrim(p_user) = '' THEN
        RAISE EXCEPTION 'user must not be empty';
    END IF;
    IF p_database IS NULL OR btrim(p_database) = '' THEN
        RAISE EXCEPTION 'database must not be empty';
    END IF;

    INSERT INTO audit_scope(db_user, database_name, enabled, updated_at)
    VALUES (p_user, p_database, p_enabled, now())
    ON CONFLICT (db_user, database_name)
    DO UPDATE SET
        enabled = EXCLUDED.enabled,
        updated_at = now();
END
$$;

CREATE OR REPLACE FUNCTION audit_scope_delete(
    p_user text,
    p_database text
)
RETURNS void
LANGUAGE sql
AS $$
    DELETE FROM audit_scope
    WHERE db_user = p_user
      AND database_name = p_database;
$$;

CREATE OR REPLACE FUNCTION audit_ignore_schema_set(
    p_schema text,
    p_enabled boolean DEFAULT true
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_schema IS NULL OR btrim(p_schema) = '' THEN
        RAISE EXCEPTION 'schema must not be empty';
    END IF;
    IF p_schema = '*' THEN
        RAISE EXCEPTION 'wildcard is forbidden in ignore rules';
    END IF;

    INSERT INTO audit_ignore_schema(schema_name, enabled, updated_at)
    VALUES (p_schema, p_enabled, now())
    ON CONFLICT (schema_name)
    DO UPDATE SET
        enabled = EXCLUDED.enabled,
        updated_at = now();
END
$$;

CREATE OR REPLACE FUNCTION audit_ignore_schema_delete(
    p_schema text
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_schema = '*' THEN
        RAISE EXCEPTION 'wildcard is forbidden in ignore rules';
    END IF;
    DELETE FROM audit_ignore_schema
    WHERE schema_name = p_schema;
END
$$;

CREATE OR REPLACE FUNCTION audit_ignore_table_set(
    p_database text,
    p_schema text,
    p_table text,
    p_enabled boolean DEFAULT true
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_database IS NULL OR btrim(p_database) = '' OR
       p_schema IS NULL OR btrim(p_schema) = '' OR
       p_table IS NULL OR btrim(p_table) = '' THEN
        RAISE EXCEPTION 'database, schema and table must not be empty';
    END IF;

    IF p_database = '*' OR p_schema = '*' OR p_table = '*' THEN
        RAISE EXCEPTION 'wildcard is forbidden in ignore rules';
    END IF;

    INSERT INTO audit_ignore_table(
        database_name, schema_name, table_name, enabled, updated_at
    )
    VALUES (
        p_database, p_schema, p_table, p_enabled, now()
    )
    ON CONFLICT (database_name, schema_name, table_name)
    DO UPDATE SET
        enabled = EXCLUDED.enabled,
        updated_at = now();
END
$$;

CREATE OR REPLACE FUNCTION audit_ignore_table_delete(
    p_database text,
    p_schema text,
    p_table text
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_database = '*' OR p_schema = '*' OR p_table = '*' THEN
        RAISE EXCEPTION 'wildcard is forbidden in ignore rules';
    END IF;

    DELETE FROM audit_ignore_table
    WHERE database_name = p_database
      AND schema_name = p_schema
      AND table_name = p_table;
END
$$;
