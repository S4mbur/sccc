POSTGRESQL STATEMENT AUDIT COLLECTOR
DB-MANAGED VERSION
====================================

INSTALL
-------

1. Edit collector.env
2. Run:

    sudo bash install.sh

The application runs directly from the directory where the ZIP was extracted.

Only this is installed under /etc:

    /etc/systemd/system/pg-audit-collector.service

Python has no external library dependency.
Database access is done through local psql subprocess calls.


POST-INSTALL MANAGEMENT
-----------------------

Connect to:

    psql -p 5420 -U audit_writer -d auditdb

or connect as postgres.


AUDIT SCOPE
-----------

Specific user + DB:

    SELECT audit_scope_set('user1','appdb',true);

User in all DBs:

    SELECT audit_scope_set('user1','*',true);

All users in appdb:

    SELECT audit_scope_set('*','appdb',true);

All users / all DBs:

    SELECT audit_scope_set('*','*',true);

Disable:

    SELECT audit_scope_set('user1','appdb',false);

Delete:

    SELECT audit_scope_delete('user1','appdb');

List:

    SELECT *
    FROM audit_scope
    ORDER BY database_name, db_user;


STRICT IGNORE SCHEMAS
---------------------

Default exact rows:

    pg_catalog
    information_schema
    pg_toast

List:

    SELECT *
    FROM audit_ignore_schema
    ORDER BY schema_name;

Add another exact schema:

    SELECT audit_ignore_schema_set('monitoring',true);

Disable:

    SELECT audit_ignore_schema_set('monitoring',false);

Delete:

    SELECT audit_ignore_schema_delete('monitoring');

Direct DML is also allowed to audit_writer:

    INSERT INTO audit_ignore_schema(schema_name)
    VALUES ('some_exact_schema');

There is NO wildcard, LIKE, prefix or regex matching.


STRICT IGNORE TABLES
--------------------

Exact database + schema + table:

    SELECT audit_ignore_table_set(
        'appdb',
        'public',
        'heartbeat',
        true
    );

List:

    SELECT *
    FROM audit_ignore_table
    ORDER BY schema_name, table_name;

Disable:

    SELECT audit_ignore_table_set(
        'appdb',
        'public',
        'heartbeat',
        false
    );

Delete:

    SELECT audit_ignore_table_delete(
        'appdb',
        'public',
        'heartbeat'
    );

Matching is exact database + schema + table. No wildcard is supported here.


FAIL-OPEN RULE
--------------

Explicit:

    SELECT * FROM pg_catalog.pg_class;

=> pg_catalog can be ignored exactly.

Unqualified:

    SELECT * FROM pg_class;

=> collector does NOT guess the schema.
=> it is audited.


AUDIT HISTORY
-------------

    SELECT
        id,
        event_time,
        database_name,
        db_user,
        client_ip,
        application_name,
        command_type,
        schema_name,
        table_name,
        statement
    FROM audit_history
    ORDER BY id DESC
    LIMIT 50;


CONFIG REFRESH
--------------

Scope refresh:

    SCOPE_REFRESH_SECONDS=20

Ignore refresh:

    IGNORE_REFRESH_SECONDS=30

No service restart is required after DB configuration changes.


SERVICE
-------

    systemctl status pg-audit-collector
    journalctl -u pg-audit-collector -f
