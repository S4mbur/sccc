#!/usr/bin/env python3
import importlib.util
from pathlib import Path

p = Path(__file__).resolve().parent / "audit_collector.py"
spec = importlib.util.spec_from_file_location("collector", p)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

schemas = {"pg_catalog", "information_schema", "pg_toast"}
tables = {("appdb", "public", "heartbeat")}

assert m.all_relations_ignored("appdb", "SELECT * FROM pg_catalog.pg_class", schemas, tables)
assert not m.all_relations_ignored("appdb", "SELECT * FROM pg_class", schemas, tables)
assert m.all_relations_ignored("appdb", "SELECT * FROM public.heartbeat", set(), tables)
assert not m.all_relations_ignored("otherdb", "SELECT * FROM public.heartbeat", set(), tables)
assert not m.all_relations_ignored("appdb", "UPDATE ONLY public.salaries SET x=1", schemas, tables)
assert not m.all_relations_ignored("appdb", "SELECT EXTRACT(YEAR FROM now())", schemas, tables)
assert m.all_relations_ignored("appdb", "COPY pg_catalog.pg_class TO STDOUT", schemas, tables)

entry = {
    "timestamp": "2026-10-02 09:00:00+03",
    "user": "user1",
    "dbname": "appdb",
    "remote_host": "[local]",
    "message": "statement: SELECT * FROM public.customer",
    "error_severity": "LOG",
    "session_id": "abc",
    "line_num": 1,
}
store, statement = m.should_store(entry, schemas, tables)
assert store
row = m.clean_row(entry, statement)
assert row[3] == "[local]"
print("self-test OK")
