#!/usr/bin/env python3
import csv
import hashlib
import io
import json
import logging
import os
import re
import signal
import subprocess
import time
from pathlib import Path

RUNNING = True
APP_DIR = Path(__file__).resolve().parent

def env(name, default=None):
    return os.environ.get(name, default)

def bool_env(name, default=False):
    return str(env(name, "true" if default else "false")).strip().lower() in (
        "1", "true", "yes", "on"
    )

def app_path(value):
    p = Path(value)
    return p if p.is_absolute() else APP_DIR / p

PGDATA = Path(env("PGDATA", "/data/postgres/data"))
PGPORT = str(env("PGPORT", "5420"))
AUDIT_DB = env("AUDIT_DB", "auditdb")
AUDIT_USER = env("AUDIT_USER", "audit_writer")
PSQL_BIN = env("PSQL_BIN", "/usr/bin/psql")

POLL_SECONDS = float(env("POLL_SECONDS", "0.25"))
BATCH_SIZE = int(env("BATCH_SIZE", "100"))
FLUSH_SECONDS = float(env("FLUSH_SECONDS", "2"))
IGNORE_REFRESH_SECONDS = int(env("IGNORE_REFRESH_SECONDS", "30"))
HEARTBEAT_SECONDS = int(env("HEARTBEAT_SECONDS", "10"))

START_AT_END = bool_env("START_AT_END", True)
STATE_FILE = app_path(env("STATE_FILE", "state/state.json"))

PGCONNECT_TIMEOUT_SECONDS = int(env("PGCONNECT_TIMEOUT_SECONDS", "5"))
PSQL_TIMEOUT_SECONDS = int(env("PSQL_TIMEOUT_SECONDS", "15"))
STATEMENT_TIMEOUT_MS = int(env("STATEMENT_TIMEOUT_MS", "10000"))
LOCK_TIMEOUT_MS = int(env("LOCK_TIMEOUT_MS", "2000"))

COLLECTOR_NAME = env("COLLECTOR_NAME", "main")

logging.basicConfig(
    level=getattr(logging, env("COLLECTOR_LOG_LEVEL", "INFO").upper(), logging.INFO),
    format="%(asctime)s %(levelname)s %(message)s",
)
LOG = logging.getLogger("pg-statement-audit")

NOISE_RE = re.compile(
    r"^\s*(?:"
    r"SET(?:\s+LOCAL|\s+SESSION)?\b|RESET\b|SHOW\b|"
    r"BEGIN\b|START\s+TRANSACTION\b|COMMIT\b|END\b|ROLLBACK\b|"
    r"SAVEPOINT\b|RELEASE(?:\s+SAVEPOINT)?\b"
    r")",
    re.I | re.S,
)

IDENT = r'(?:"(?:[^"]|"")*"|[A-Za-z_][A-Za-z0-9_$]*)'
REL = rf'(?:(?P<schema>{IDENT})\s*\.\s*)?(?P<table>{IDENT})'

# Used only to PROVE an exact ignore. Any ambiguity means audit.
REL_PATTERNS = [
    re.compile(rf'\bFROM\s+(?:ONLY\s+)?{REL}', re.I),
    re.compile(rf'\bJOIN\s+(?:ONLY\s+)?{REL}', re.I),
    re.compile(rf'\bUPDATE\s+(?:ONLY\s+)?{REL}', re.I),
    re.compile(rf'\bINSERT\s+INTO\s+{REL}', re.I),
    re.compile(rf'\bDELETE\s+FROM\s+(?:ONLY\s+)?{REL}', re.I),
    re.compile(rf'\bMERGE\s+INTO\s+{REL}', re.I),
    re.compile(rf'\bTRUNCATE(?:\s+TABLE)?\s+(?:ONLY\s+)?{REL}', re.I),
    re.compile(rf'\bCOPY\s+{REL}\s+(?:FROM|TO)\b', re.I),
    re.compile(rf'\bALTER\s+TABLE(?:\s+IF\s+EXISTS)?\s+(?:ONLY\s+)?{REL}', re.I),
    re.compile(rf'\bDROP\s+TABLE(?:\s+IF\s+EXISTS)?\s+{REL}', re.I),
    re.compile(rf'\bCREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?\s+{REL}', re.I),
    re.compile(rf'\bREFERENCES\s+{REL}', re.I),
    re.compile(rf'\bCREATE(?:\s+UNIQUE)?\s+INDEX\b.*?\bON\s+(?:ONLY\s+)?{REL}', re.I | re.S),
]

CTE_RE = re.compile(
    rf'(?:\bWITH\b|,)\s*(?P<cte>{IDENT})\s*(?:\([^)]*\))?\s+AS\s*'
    rf'(?:NOT\s+MATERIALIZED\s+|MATERIALIZED\s+)?\(',
    re.I | re.S,
)

FROM_COMMA_RE = re.compile(r'\bFROM\b[^;]*?,', re.I | re.S)
ERROR_SEVERITIES = {"ERROR", "FATAL", "PANIC"}

def stop_handler(signum, frame):
    global RUNNING
    RUNNING = False

signal.signal(signal.SIGTERM, stop_handler)
signal.signal(signal.SIGINT, stop_handler)

def psql_env():
    e = os.environ.copy()
    e["PGCONNECT_TIMEOUT"] = str(PGCONNECT_TIMEOUT_SECONDS)
    e["PGOPTIONS"] = (
        f"-c statement_timeout={STATEMENT_TIMEOUT_MS} "
        f"-c lock_timeout={LOCK_TIMEOUT_MS}"
    )
    return e

def psql_base():
    return [
        PSQL_BIN, "-X", "-q", "-v", "ON_ERROR_STOP=1",
        "-p", PGPORT, "-U", AUDIT_USER, "-d", AUDIT_DB,
    ]

def run_psql(args, input_text=None):
    try:
        return subprocess.run(
            psql_base() + args,
            input=input_text,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=psql_env(),
            timeout=PSQL_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            f"psql timeout after {PSQL_TIMEOUT_SECONDS}s"
        ) from exc

def psql_csv_query(sql):
    proc = run_psql([
        "-c",
        f"COPY ({sql}) TO STDOUT WITH (FORMAT csv, NULL '\\N')"
    ])
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "psql query failed")
    return [
        [None if v == r"\N" else v for v in row]
        for row in csv.reader(io.StringIO(proc.stdout))
    ]

def load_ignores():
    schemas = {
        r[0] for r in psql_csv_query("""
            SELECT schema_name
            FROM audit_ignore_schema
            WHERE enabled
        """)
    }
    tables = {
        (r[0], r[1], r[2]) for r in psql_csv_query("""
            SELECT database_name, schema_name, table_name
            FROM audit_ignore_table
            WHERE enabled
        """)
    }
    return schemas, tables

def ident_value(token):
    if token is None:
        return None
    token = token.strip()
    if token.startswith('"') and token.endswith('"'):
        return token[1:-1].replace('""', '"')
    return token.lower()

def analyze_relations(statement):
    ctes = {ident_value(m.group("cte")) for m in CTE_RE.finditer(statement)}
    relations = set()
    ambiguous = bool(FROM_COMMA_RE.search(statement))

    for pattern in REL_PATTERNS:
        for m in pattern.finditer(statement):
            schema = ident_value(m.groupdict().get("schema"))
            table = ident_value(m.groupdict().get("table"))
            if not table:
                ambiguous = True
                continue
            if schema is None and table in ctes:
                continue
            relations.add((schema, table))
            if schema is None:
                ambiguous = True

    return relations, ambiguous

def all_relations_ignored(dbname, statement, ignored_schemas, ignored_tables):
    relations, ambiguous = analyze_relations(statement)
    if not relations or ambiguous:
        return False

    for schema, table in relations:
        if schema in ignored_schemas:
            continue
        if (dbname, schema, table) in ignored_tables:
            continue
        return False
    return True

def extract_statement(entry):
    if entry.get("statement"):
        return str(entry["statement"])

    message = str(entry.get("message") or "")
    m = re.match(r'^\s*statement:\s*(.*)$', message, re.I | re.S)
    if m:
        return m.group(1).strip()

    m = re.match(r'^\s*execute(?:\s+[^:]+)?:\s*(.*)$', message, re.I | re.S)
    if m:
        return m.group(1).strip()

    return None

def should_store(entry, ignored_schemas, ignored_tables):
    dbname = entry.get("dbname")
    severity = str(entry.get("error_severity") or "").upper()
    statement = extract_statement(entry)

    if severity in ERROR_SEVERITIES:
        if statement and all_relations_ignored(
            dbname, statement, ignored_schemas, ignored_tables
        ):
            return False, statement
        return True, statement

    if not statement:
        return False, None

    if NOISE_RE.match(statement):
        return False, statement

    if all_relations_ignored(
        dbname, statement, ignored_schemas, ignored_tables
    ):
        return False, statement

    return True, statement

def event_key(entry):
    # Technical dedup key. Never stored in audit_history.
    raw = "\x1f".join([
        str(entry.get("session_id") or ""),
        str(entry.get("line_num") or ""),
        str(entry.get("timestamp") or ""),
        str(entry.get("message") or ""),
        str(entry.get("statement") or ""),
        str(entry.get("detail") or ""),
        str(entry.get("state_code") or ""),
    ])
    return hashlib.sha256(raw.encode("utf-8", errors="replace")).hexdigest()

def clean_row(entry, statement):
    severity = entry.get("error_severity")
    message = entry.get("message")

    # Successful statement log message duplicates statement text.
    if str(severity or "").upper() not in ERROR_SEVERITIES:
        message = None

    return (
        event_key(entry),
        entry.get("timestamp"),
        entry.get("user"),
        entry.get("remote_host"),
        entry.get("application_name"),
        severity,
        entry.get("state_code"),
        statement,
        entry.get("detail"),
        message,
    )

def flush_rows(rows):
    if not rows:
        return

    columns = (
        "event_key,event_time,db_user,client_host,application_name,"
        "severity,sqlstate,statement,detail,message"
    )

    buf = io.StringIO(newline="")
    writer = csv.writer(buf, lineterminator="\n")
    for row in rows:
        writer.writerow([r"\N" if v is None else v for v in row])

    script = f"""
BEGIN;
CREATE TEMP TABLE _audit_stage (
    event_key text,
    event_time timestamptz,
    db_user text,
    client_host text,
    application_name text,
    severity text,
    sqlstate text,
    statement text,
    detail text,
    message text
) ON COMMIT DROP;
COPY _audit_stage ({columns}) FROM STDIN WITH (FORMAT csv, NULL '\\N');
{buf.getvalue()}\\.
WITH inserted AS (
    INSERT INTO audit_internal.event_guard(event_key)
    SELECT DISTINCT event_key
    FROM _audit_stage
    ON CONFLICT (event_key) DO NOTHING
    RETURNING event_key
)
INSERT INTO audit_history(
    event_time, db_user, client_host, application_name,
    severity, sqlstate, statement, detail, message
)
SELECT
    s.event_time, s.db_user, s.client_host, s.application_name,
    s.severity, s.sqlstate, s.statement, s.detail, s.message
FROM _audit_stage s
JOIN inserted i USING (event_key);
COMMIT;
"""

    proc = run_psql(["-f", "-"], input_text=script)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "audit batch commit failed")

def list_json_files(directory):
    rows = []
    for p in directory.iterdir():
        if not p.is_file() or p.suffix not in (".json", ".jsonlog"):
            continue
        try:
            st = p.stat()
        except FileNotFoundError:
            continue
        rows.append((st.st_mtime_ns, p.name, p))
    rows.sort(key=lambda x: (x[0], x[1]))
    return [x[2] for x in rows]

def active_jsonlog():
    marker = PGDATA / "current_logfiles"
    if not marker.exists():
        raise FileNotFoundError(f"{marker} not found")

    for line in marker.read_text(encoding="utf-8", errors="replace").splitlines():
        dest, _, relpath = line.partition(" ")
        if dest.strip() != "jsonlog":
            continue
        p = Path(relpath.strip())
        if not p.is_absolute():
            p = PGDATA / p
        if p.is_dir():
            files = list_json_files(p)
            if not files:
                raise RuntimeError(f"No JSON log files under {p}")
            return files[-1]
        return p
    raise RuntimeError(f"No jsonlog entry in {marker}")

def checkpoint(path, offset):
    st = path.stat()
    return {
        "file_path": str(path),
        "offset": int(offset),
        "mtime_ns": int(st.st_mtime_ns),
    }

def load_state():
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None

def save_state(state):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(state), encoding="utf-8")
    os.replace(tmp, STATE_FILE)

def locate_start():
    active = active_jsonlog()
    files = list_json_files(active.parent)
    state = load_state()

    if not state:
        if START_AT_END:
            return active, active.stat().st_size, None
        first = files[0] if files else active
        return first, 0, None

    old = Path(state.get("file_path", ""))
    old_offset = int(state.get("offset", 0))

    if old.exists():
        size = old.stat().st_size
        if old_offset > size:
            return old, 0, (
                f"saved offset {old_offset} > file size {size}; "
                "file truncated, restarting from 0"
            )
        return old, old_offset, None

    old_mtime = int(state.get("mtime_ns", 0))
    candidates = []
    for p in files:
        try:
            if p.stat().st_mtime_ns >= old_mtime:
                candidates.append(p)
        except FileNotFoundError:
            pass

    chosen = candidates[0] if candidates else (files[0] if files else active)
    return chosen, 0, (
        "previous checkpoint file no longer exists; possible audit gap; "
        f"continuing from earliest available file {chosen}"
    )

def next_file(current):
    active = active_jsonlog()
    files = list_json_files(active.parent)
    for i, p in enumerate(files):
        if p == current:
            return files[i + 1] if i + 1 < len(files) else None
    return None

def sql_literal(value):
    if value is None:
        return "NULL"
    return "'" + str(value).replace("'", "''") + "'"

def heartbeat(current_file, current_offset, buffer_size, last_log_event, last_error, flushed=False):
    event_sql = sql_literal(last_log_event)
    file_sql = sql_literal(str(current_file))
    error_sql = sql_literal(last_error[:2000] if last_error else None)
    flush_sql = "clock_timestamp()" if flushed else "NULL"

    sql = f"""
INSERT INTO audit_collector_status(
    collector_name,last_seen,last_successful_flush,last_log_event,
    lag_seconds,buffer_size,current_file,current_offset,last_error,updated_at
)
VALUES(
    {sql_literal(COLLECTOR_NAME)},clock_timestamp(),{flush_sql},
    {event_sql}::timestamptz,
    CASE WHEN {event_sql} IS NULL THEN NULL
         ELSE EXTRACT(EPOCH FROM (clock_timestamp() - {event_sql}::timestamptz)) END,
    {int(buffer_size)},{file_sql},{int(current_offset)},{error_sql},clock_timestamp()
)
ON CONFLICT (collector_name)
DO UPDATE SET
    last_seen=EXCLUDED.last_seen,
    last_successful_flush=COALESCE(EXCLUDED.last_successful_flush,audit_collector_status.last_successful_flush),
    last_log_event=EXCLUDED.last_log_event,
    lag_seconds=EXCLUDED.lag_seconds,
    buffer_size=EXCLUDED.buffer_size,
    current_file=EXCLUDED.current_file,
    current_offset=EXCLUDED.current_offset,
    last_error=EXCLUDED.last_error,
    updated_at=EXCLUDED.updated_at;
"""
    proc = run_psql(["-c", sql])
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "heartbeat failed")

def main():
    LOG.info("starting; app_dir=%s PGDATA=%s port=%s audit_db=%s", APP_DIR, PGDATA, PGPORT, AUDIT_DB)

    ignored_schemas = set()
    ignored_tables = set()
    next_ignore_refresh = 0.0
    next_heartbeat = 0.0
    rows = []
    pending_state = None
    last_flush = time.monotonic()
    last_log_event = None
    last_error = None
    heartbeat_flush = False

    current, offset, warning = locate_start()
    if warning:
        LOG.warning(warning)
        last_error = warning

    fh = current.open("r", encoding="utf-8", errors="replace")
    fh.seek(offset)

    while RUNNING:
        now = time.monotonic()

        if now >= next_ignore_refresh:
            try:
                ignored_schemas, ignored_tables = load_ignores()
                next_ignore_refresh = now + IGNORE_REFRESH_SECONDS
            except Exception as exc:
                last_error = f"ignore refresh: {exc}"
                LOG.error(last_error)
                time.sleep(1)
                continue

        line = fh.readline()

        if line:
            end_offset = fh.tell()
            pending_state = checkpoint(current, end_offset)

            try:
                entry = json.loads(line)
                if entry.get("timestamp"):
                    last_log_event = entry.get("timestamp")

                store, statement = should_store(entry, ignored_schemas, ignored_tables)
                if store:
                    rows.append(clean_row(entry, statement))

            except json.JSONDecodeError as exc:
                last_error = f"invalid json {current}:{end_offset}: {exc}"
                LOG.error(last_error)

            except Exception as exc:
                last_error = f"processing error {current}:{end_offset}: {exc}"
                LOG.exception(last_error)
                pending_state = None
                time.sleep(1)
                continue

            if not rows and pending_state:
                save_state(pending_state)

        else:
            try:
                size = current.stat().st_size
                if fh.tell() > size:
                    last_error = f"log truncated: offset={fh.tell()} size={size}; reopening from 0"
                    LOG.warning(last_error)
                    fh.close()
                    fh = current.open("r", encoding="utf-8", errors="replace")
                    fh.seek(0)
                    pending_state = checkpoint(current, 0)
                    continue
            except FileNotFoundError:
                pass

            if rows:
                try:
                    flush_rows(rows)
                    rows.clear()
                    if pending_state:
                        save_state(pending_state)
                    last_flush = now
                    heartbeat_flush = True
                    last_error = None
                except Exception as exc:
                    last_error = f"flush before rotation: {exc}"
                    LOG.error(last_error)
                    time.sleep(1)
                    continue

            if pending_state:
                save_state(pending_state)

            nxt = next_file(current)
            if nxt is not None and nxt != current:
                fh.close()
                current = nxt
                fh = current.open("r", encoding="utf-8", errors="replace")
                fh.seek(0)
                pending_state = checkpoint(current, 0)
                LOG.info("following next log from beginning: %s", current)
                continue

            time.sleep(POLL_SECONDS)

        if rows and (len(rows) >= BATCH_SIZE or now - last_flush >= FLUSH_SECONDS):
            try:
                flush_rows(rows)
                rows.clear()
                if pending_state:
                    save_state(pending_state)
                last_flush = now
                heartbeat_flush = True
                last_error = None
            except Exception as exc:
                last_error = f"audit flush: {exc}"
                LOG.error(last_error)
                time.sleep(1)

        if now >= next_heartbeat:
            try:
                heartbeat(current, fh.tell(), len(rows), last_log_event, last_error, heartbeat_flush)
                heartbeat_flush = False
                next_heartbeat = now + HEARTBEAT_SECONDS
            except Exception as exc:
                LOG.error("heartbeat failed: %s", exc)
                next_heartbeat = now + 5

    try:
        if rows:
            flush_rows(rows)
            rows.clear()
            if pending_state:
                save_state(pending_state)
    except Exception as exc:
        LOG.error("final flush failed: %s", exc)

    try:
        fh.close()
    except Exception:
        pass

    LOG.info("stopped")

if __name__ == "__main__":
    main()
