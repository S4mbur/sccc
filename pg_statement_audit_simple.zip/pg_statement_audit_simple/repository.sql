-- Run manually while connected to auditdb as postgres/admin.
-- Assumes role audit_writer already exists.

-- Clean table intended for Information Security / reporting.
CREATE TABLE IF NOT EXISTS audit_history (
    event_time       timestamptz NOT NULL,
    db_user          text,
    client_host      text,
    application_name text,
    severity         text,
    sqlstate         text,
    statement        text,
    detail           text,
    message          text,
    created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_history_event_time
    ON audit_history(event_time DESC);

CREATE INDEX IF NOT EXISTS idx_audit_history_user_time
    ON audit_history(db_user, event_time DESC);

-- Strict exact-match ignore configuration.
CREATE TABLE IF NOT EXISTS audit_ignore_schema (
    schema_name text PRIMARY KEY,
    enabled     boolean NOT NULL DEFAULT true,
    created_at  timestamptz NOT NULL DEFAULT now(),
    CHECK (btrim(schema_name) <> ''),
    CHECK (schema_name <> '*')
);

CREATE TABLE IF NOT EXISTS audit_ignore_table (
    database_name text NOT NULL,
    schema_name   text NOT NULL,
    table_name    text NOT NULL,
    enabled       boolean NOT NULL DEFAULT true,
    created_at    timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (database_name, schema_name, table_name),
    CHECK (btrim(database_name) <> ''),
    CHECK (btrim(schema_name) <> ''),
    CHECK (btrim(table_name) <> ''),
    CHECK (database_name <> '*'),
    CHECK (schema_name <> '*'),
    CHECK (table_name <> '*')
);

-- Explicit defaults only. There is no LIKE/prefix/regex behavior.
INSERT INTO audit_ignore_schema(schema_name, enabled)
VALUES
    ('pg_catalog', true),
    ('information_schema', true),
    ('pg_toast', true)
ON CONFLICT (schema_name) DO NOTHING;

-- Technical state kept outside the clean audit table.
CREATE SCHEMA IF NOT EXISTS audit_internal;

CREATE TABLE IF NOT EXISTS audit_internal.event_guard (
    event_key  text PRIMARY KEY,
    first_seen timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_collector_status (
    collector_name        text PRIMARY KEY,
    last_seen             timestamptz,
    last_successful_flush timestamptz,
    last_log_event        timestamptz,
    lag_seconds           numeric,
    buffer_size           integer NOT NULL DEFAULT 0,
    current_file          text,
    current_offset        bigint,
    last_error            text,
    updated_at            timestamptz NOT NULL DEFAULT now()
);

-- Security.
REVOKE CREATE ON SCHEMA public FROM PUBLIC;

REVOKE ALL ON audit_history,
              audit_ignore_schema,
              audit_ignore_table,
              audit_collector_status
FROM PUBLIC;

REVOKE ALL ON SCHEMA audit_internal FROM PUBLIC;
REVOKE ALL ON audit_internal.event_guard FROM PUBLIC;

GRANT USAGE ON SCHEMA public TO audit_writer;
GRANT USAGE ON SCHEMA audit_internal TO audit_writer;

GRANT SELECT, INSERT, UPDATE, DELETE
ON audit_ignore_schema, audit_ignore_table
TO audit_writer;

GRANT INSERT, SELECT
ON audit_history
TO audit_writer;

GRANT SELECT, INSERT, UPDATE
ON audit_collector_status
TO audit_writer;

GRANT SELECT, INSERT
ON audit_internal.event_guard
TO audit_writer;
