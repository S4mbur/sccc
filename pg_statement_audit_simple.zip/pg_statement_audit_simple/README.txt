POSTGRESQL 15 - SIMPLE STATEMENT AUDIT COLLECTOR
================================================

DESIGN
------

PostgreSQL decides which users are audited.

Global:
    log_statement = none

Per user + database:
    ALTER ROLE user1 IN DATABASE appdb SET log_statement = 'all';

Disable:
    ALTER ROLE user1 IN DATABASE appdb RESET log_statement;

Open a NEW DB connection after changing ALTER ROLE ... IN DATABASE.


1. POSTGRESQL LOGGING
---------------------

Recommended global settings:

    ALTER SYSTEM SET log_statement = 'none';
    ALTER SYSTEM SET log_min_error_statement = 'error';
    SELECT pg_reload_conf();

Collector requires:

    logging_collector = on
    log_destination includes jsonlog

If logging_collector is not already on, enabling it requires a PostgreSQL restart.


2. CREATE AUDIT USER / DB MANUALLY
----------------------------------

Example:

    CREATE ROLE audit_writer LOGIN;
    ALTER ROLE audit_writer SET log_statement = 'none';

    CREATE DATABASE auditdb;

    REVOKE CONNECT ON DATABASE auditdb FROM PUBLIC;
    GRANT CONNECT ON DATABASE auditdb TO audit_writer;


3. CREATE REPOSITORY
--------------------

Connect as postgres/admin to auditdb and run:

    psql -p 5420 -d auditdb -f repository.sql


4. CLEAN AUDIT TABLE
--------------------

Information Security only needs:

    audit_history

Columns:

    event_time
    db_user
    client_host
    application_name
    severity
    sqlstate
    statement
    detail
    message
    created_at

Example:

    SELECT
        event_time,
        db_user,
        client_host,
        application_name,
        severity,
        sqlstate,
        statement,
        detail,
        message
    FROM audit_history
    ORDER BY event_time DESC
    LIMIT 100;

There is deliberately NO:

    id
    event_key
    session_id
    line_num
    query_id
    table_name
    schema_name
    database_name

in the clean audit table.


5. TECHNICAL DEDUP IS INTERNAL
------------------------------

Crash/restart duplicate protection still exists.

Technical SHA-256 keys are stored only in:

    audit_internal.event_guard

This keeps audit_history clean while still allowing:

    read log -> DB COMMIT -> checkpoint

without duplicates after a crash between commit and state save.


6. STRICT IGNORE CONFIG
-----------------------

Default exact schema ignores:

    pg_catalog
    information_schema
    pg_toast

List:

    SELECT * FROM audit_ignore_schema;

Add exact schema:

    INSERT INTO audit_ignore_schema(schema_name)
    VALUES ('monitoring');

Disable:

    UPDATE audit_ignore_schema
    SET enabled=false
    WHERE schema_name='monitoring';

Exact database + schema + table ignore:

    INSERT INTO audit_ignore_table(
        database_name,
        schema_name,
        table_name
    )
    VALUES (
        'appdb',
        'public',
        'heartbeat'
    );

There is NO:

    LIKE
    prefix
    regex
    wildcard

Ignore matching is strict equality only.


7. FAIL-OPEN FILTERING
----------------------

Explicit:

    SELECT * FROM pg_catalog.pg_class;

can be ignored exactly.

Unqualified:

    SELECT * FROM pg_class;

is AUDITED.

Collector does not guess search_path.

If parsing is ambiguous, it AUDITS.

COPY is recognized.
UPDATE ONLY / DELETE FROM ONLY are recognized.
Comma-separated FROM constructs are treated as ambiguous and audited.


8. ERRORS
---------

With:

    log_min_error_statement = error

failed statements such as permission denied can be present in JSON logs.

Collector stores:

    severity
    sqlstate
    statement
    detail
    message

For normal successful statement log entries, message duplicates statement, so
message is stored as NULL.

For ERROR/FATAL/PANIC, message is kept.


9. LOCAL SOCKET
---------------

client_host is TEXT.

Therefore values such as:

    [local]

do not cause inet conversion failures.


10. DURABILITY / ROTATION
-------------------------

Durable order:

    read jsonlog
    -> buffer
    -> COMMIT audit rows
    -> save file offset

Offset is never advanced past uncommitted audit rows.

START_AT_END=true is used only when there is no state file.

Rotation behavior:

    finish old file
    -> commit/checkpoint
    -> next available jsonlog from offset 0

If saved offset > current file size, collector treats it as truncation and
restarts that file from offset 0.

If the old checkpoint file has already disappeared, collector reports a possible
audit gap and continues from the earliest available log file.


11. HEARTBEAT
-------------

Technical monitoring table:

    audit_collector_status

Example:

    SELECT
        collector_name,
        last_seen,
        now() - last_seen AS heartbeat_age,
        last_successful_flush,
        last_log_event,
        lag_seconds,
        buffer_size,
        current_file,
        current_offset,
        last_error
    FROM audit_collector_status;

Useful alert conditions:

    heartbeat_age > 30 seconds
    lag_seconds > 30
    buffer_size unexpectedly high
    last_error IS NOT NULL


12. INSTALL SERVICE
-------------------

Edit:

    collector.env

Then:

    sudo bash install.sh

install.sh only:

    1. checks PGDATA/jsonlog/binaries
    2. creates local state directory
    3. writes ONE systemd service file under /etc
    4. starts the service

It intentionally does NOT:

    create user
    create database
    run repository.sql
    alter PostgreSQL parameters

Those are manual and visible.


13. SERVICE
-----------

    systemctl status pg-audit-collector
    journalctl -u pg-audit-collector -f


14. RAW LOG VOLUME
------------------

Filtering happens AFTER PostgreSQL writes jsonlog.

Therefore keep global:

    log_statement = none

and only enable selected pairs:

    ALTER ROLE user1 IN DATABASE appdb SET log_statement='all';

Monitor the PostgreSQL log filesystem separately.
