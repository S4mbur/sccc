#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
ENV_FILE="$APP_DIR/collector.env"
SERVICE_FILE="/etc/systemd/system/pg-audit-collector.service"

if [[ "$(id -u)" -ne 0 ]]; then
    echo "Run as root: sudo bash install.sh"
    exit 1
fi

source "$ENV_FILE"

echo "Project directory : $APP_DIR"
echo "PGDATA            : $PGDATA"
echo "PGPORT            : $PGPORT"
echo "Audit database    : $AUDIT_DB"
echo

echo "[1/4] Checking required files..."
test -f "$PGDATA/current_logfiles"
grep -q '^jsonlog ' "$PGDATA/current_logfiles"
test -x "$PYTHON_BIN"
test -x "$PSQL_BIN"

echo "[2/4] Preparing local state directory..."
install -d -m 0750 -o "$SERVICE_OS_USER" -g "$SERVICE_OS_GROUP" "$APP_DIR/state"
chown root:"$SERVICE_OS_GROUP" "$APP_DIR/collector.env" "$APP_DIR/audit_collector.py"
chmod 0640 "$APP_DIR/collector.env"
chmod 0750 "$APP_DIR/audit_collector.py"

echo "[3/4] Installing systemd service..."
cat > "$SERVICE_FILE" <<UNIT
[Unit]
Description=PostgreSQL statement audit collector
After=network.target

[Service]
Type=simple
User=$SERVICE_OS_USER
Group=$SERVICE_OS_GROUP
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/collector.env
ExecStart=$PYTHON_BIN $APP_DIR/audit_collector.py
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT

chmod 0644 "$SERVICE_FILE"
systemctl daemon-reload
systemctl enable pg-audit-collector >/dev/null

echo "[4/4] Starting collector..."
systemctl restart pg-audit-collector
sleep 2
systemctl --no-pager --full status pg-audit-collector || true

echo
echo "Done. install.sh only installs/starts the service."
echo "Database/user/repository SQL is intentionally manual and visible in README.txt."
