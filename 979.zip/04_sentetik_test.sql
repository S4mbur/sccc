-- =====================================================================
-- 04_sentetik_test.sql
-- Amaç : ORA-00979'u tetikleyen yapının sınırlarını çıkarmak.
--        Aynı dosyayı hem PROD (19.29) hem PREPROD/LAB (19.32) üzerinde
--        çalıştırın ve her varyant için sonucu yan yana yazın.
--        Sadece EXPLAIN PLAN çalışır: veri okunmaz, obje oluşturulmaz.
--
-- Başlangıç noktası Oracle forumunda raporlanan örnek: inline view aynı
-- kolonu iki farklı alias ile dışarı veriyor, dış sorgu birini GROUP BY'a,
-- diğerini SELECT'e koyuyor.
--
-- Bu set bir iskelet. Kendi kalibrasyon setinizdeki (Faz 0) gerçek
-- sorgulardan aynı yapıda varyantlar üretin; local LLM'e "şu sorgunun
-- 20 yapısal varyantını üret, her birinde tek bir şeyi değiştir" diye
-- verebileceğiniz en uygun iş budur.
-- =====================================================================
SET SERVEROUTPUT ON
SET FEEDBACK OFF

-- Anonim blok: veritabanında hiçbir obje oluşturmaz.
DECLARE
  TYPE t_list IS TABLE OF VARCHAR2(4000);
  l_tests t_list := t_list(
    -- V1: forum yapısı — DISTINCT inline view, aynı kolon iki alias, GROUP BY a / SELECT b
    q'[SELECT INITCAP(g.a), g.b, SUM(g.amt)
       FROM (SELECT DISTINCT d.dummy AS a, d.dummy AS b, 1 AS amt FROM dual d) g
       GROUP BY g.a]',
    -- V2: V1'in DISTINCT'siz hali
    q'[SELECT INITCAP(g.a), g.b, SUM(g.amt)
       FROM (SELECT d.dummy AS a, d.dummy AS b, 1 AS amt FROM dual d) g
       GROUP BY g.a]',
    -- V3: kontrol — SELECT ve GROUP BY aynı alias (her iki sürümde de geçmeli)
    q'[SELECT INITCAP(g.a), g.a, SUM(g.amt)
       FROM (SELECT DISTINCT d.dummy AS a, d.dummy AS b, 1 AS amt FROM dual d) g
       GROUP BY g.a]',
    -- V4: inline view yerine WITH
    q'[WITH g AS (SELECT DISTINCT d.dummy AS a, d.dummy AS b, 1 AS amt FROM dual d)
       SELECT INITCAP(g.a), g.b, SUM(g.amt) FROM g GROUP BY g.a]',
    -- V5: fark ORDER BY'da
    q'[SELECT g.a, SUM(g.amt)
       FROM (SELECT DISTINCT d.dummy AS a, d.dummy AS b, 1 AS amt FROM dual d) g
       GROUP BY g.a ORDER BY g.b]',
    -- V6: fark HAVING'de
    q'[SELECT g.a, SUM(g.amt)
       FROM (SELECT DISTINCT d.dummy AS a, d.dummy AS b, 1 AS amt FROM dual d) g
       GROUP BY g.a HAVING MAX(g.b) IS NOT NULL OR g.b IS NOT NULL]',
    -- V7: alias'lardan biri ifade (aynı kolon, farklı ifade)
    q'[SELECT g.a, g.b, SUM(g.amt)
       FROM (SELECT DISTINCT d.dummy AS a, UPPER(d.dummy) AS b, 1 AS amt FROM dual d) g
       GROUP BY g.a]',
    -- V8: iki seviye iç içe view
    q'[SELECT x.a, x.b, SUM(x.amt) FROM (
         SELECT g.a, g.b, g.amt FROM (SELECT DISTINCT d.dummy AS a, d.dummy AS b, 1 AS amt FROM dual d) g
       ) x GROUP BY x.a]'
  );
  PROCEDURE probe(p_no PLS_INTEGER, p_sql VARCHAR2) IS
  BEGIN
    EXECUTE IMMEDIATE 'EXPLAIN PLAN SET STATEMENT_ID = ''SYN' || p_no || ''' FOR ' || p_sql;
    DBMS_OUTPUT.PUT_LINE('V' || p_no || ': OK');
    ROLLBACK;
  EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('V' || p_no || ': ' || SQLERRM);
    ROLLBACK;
  END;
BEGIN
  DBMS_OUTPUT.PUT_LINE('Surum: ' || DBMS_DB_VERSION.VERSION || ' / ' ||
                       SYS_CONTEXT('USERENV','DB_NAME'));
  FOR i IN 1 .. l_tests.COUNT LOOP
    probe(i, l_tests(i));
  END LOOP;
END;
/

-- Beklenen kullanım:
-- * Bazı varyantlar her iki sürümde de hata verebilir (zaten geçersiz SQL).
--   Önemli olan sadece 19.32'de hata veren satırlardır.
-- * DUAL bazı özel optimizasyonlara sahip olduğu için, aynı varyantları
--   kalibrasyon setinizdeki gerçek bir uygulama tablosuyla da kurun
--   (yine sadece EXPLAIN; veri okunmaz).
-- * Sonuç tablosu Faz 3'teki ön eleme kuralını doğrulamak için kullanılır:
--   19.32'de hata veren her varyant, ön eleme kuralına takılmalıdır.
