-- =====================================================================
-- 01_repo_sema.sql
-- Nerede : LAB (19.32) veritabanında, DBA kullanıcısıyla
-- Amaç   : Envanter ve test sonuçlarının tutulacağı REPO979 şeması,
--          test bağlantıları için PROBE979 kullanıcısı ve lab işareti
-- =====================================================================

-- ---------- 1. Kullanıcılar ----------
CREATE USER repo979 IDENTIFIED BY "DegistirBeni_1" DEFAULT TABLESPACE users QUOTA UNLIMITED ON users;
GRANT CREATE SESSION, CREATE TABLE TO repo979;
-- ingest-plscope / ingest-views / prefilter DBA_* görünümlerini okur
GRANT SELECT ANY DICTIONARY TO repo979;

CREATE USER probe979 IDENTIFIED BY "DegistirBeni_2";
GRANT CREATE SESSION TO probe979;

-- Uygulama şemalarına proxy izni (çıktıyı çalıştırın).
-- Proxy ile bağlanan oturum o şemanın KENDİSİ olur: aynı yetkiler,
-- aynı private synonym'ler, aynı isim çözümleme.
SELECT 'ALTER USER "' || username || '" GRANT CONNECT THROUGH probe979;'
FROM   dba_users
WHERE  oracle_maintained = 'N'
AND    username NOT IN ('REPO979', 'PROBE979')
ORDER  BY username;
-- Not: Hedef şemanın CREATE SESSION yetkisi yoksa lab'de verin.

-- ---------- 2. Lab işareti ----------
-- run --mode execute bu tabloyu göremezse çalışmayı reddeder.
-- Böylece execute modu yanlışlıkla ADG/preprod/prod'a yöneltilemez.
CREATE TABLE repo979.lab_marker (marker VARCHAR2(30));
INSERT INTO repo979.lab_marker VALUES ('ORA979_LAB');
COMMIT;
GRANT SELECT ON repo979.lab_marker TO PUBLIC;

-- ---------- 3. Envanter tabloları ----------
ALTER SESSION SET CURRENT_SCHEMA = repo979;

CREATE TABLE sql_inventory (
  inv_id          NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  norm_hash       VARCHAR2(64)  NOT NULL,   -- boşlukları sadeleştirilmiş metnin SHA-256'sı
  parsing_schema  VARCHAR2(128) NOT NULL,
  sql_id          VARCHAR2(13),
  force_match_sig NUMBER,
  stmt_type       VARCHAR2(10),             -- SELECT/INSERT/UPDATE/DELETE/MERGE/OTHER
  sql_text        CLOB          NOT NULL,
  first_seen      DATE DEFAULT SYSDATE,
  last_seen       DATE DEFAULT SYSDATE,
  cand_flag       VARCHAR2(1),              -- ön eleme: Y = çalıştırma adayı
  cand_reason     VARCHAR2(400),
  CONSTRAINT sql_inventory_uk UNIQUE (norm_hash, parsing_schema)
);
CREATE INDEX sql_inventory_fms_ix ON sql_inventory (force_match_sig, parsing_schema);

-- Her SQL nereden geldi (bir SQL'in birden fazla kaynağı olabilir)
CREATE TABLE sql_source_ref (
  inv_id      NUMBER NOT NULL REFERENCES sql_inventory,
  source_type VARCHAR2(20) NOT NULL,  -- CURSOR_CACHE/AWR/PLSCOPE/VIEW/MVIEW/APP_REPO/LLM_DYNAMIC/PREPROD_CATCH
  sql_id      VARCHAR2(13),
  module      VARCHAR2(64),
  action      VARCHAR2(64),
  obj_owner   VARCHAR2(128),
  obj_name    VARCHAR2(400),
  obj_type    VARCHAR2(30),
  line_no     NUMBER,
  executions  NUMBER,
  seen_at     DATE DEFAULT SYSDATE
);
CREATE INDEX sql_source_ref_ix ON sql_source_ref (inv_id);

-- Toplayıcının işlediği SQL_ID'ler (literal varyant sınırı yüzünden
-- envantere girmeyenler de burada tutulur, tekrar tekrar sorgulanmaz)
CREATE TABLE seen_sql_id (
  sql_id     VARCHAR2(13) PRIMARY KEY,
  inv_id     NUMBER,
  first_seen DATE DEFAULT SYSDATE
);

-- Prod'dan yakalanan bind değerleri ve tipleri
CREATE TABLE sql_binds (
  inv_id          NUMBER NOT NULL REFERENCES sql_inventory,
  position        NUMBER NOT NULL,
  bind_name       VARCHAR2(128),
  datatype        NUMBER,
  datatype_string VARCHAR2(30),
  was_captured    VARCHAR2(3),
  value_string    VARCHAR2(4000),
  CONSTRAINT sql_binds_pk PRIMARY KEY (inv_id, position)
);

-- Dışarıdan gelen sorguları uygulamaya bağlamak için V$SESSION örnekleri
CREATE TABLE sql_client_seen (
  sql_id       VARCHAR2(13)  NOT NULL,
  username     VARCHAR2(128),
  machine      VARCHAR2(64),
  program      VARCHAR2(84),
  module       VARCHAR2(64),
  service_name VARCHAR2(64),
  hit_count    NUMBER DEFAULT 1,
  first_seen   DATE DEFAULT SYSDATE,
  last_seen    DATE DEFAULT SYSDATE
);
CREATE UNIQUE INDEX sql_client_seen_uk
  ON sql_client_seen (sql_id, NVL(username,'-'), NVL(machine,'-'), NVL(program,'-'));

CREATE TABLE collector_state (
  name     VARCHAR2(30) PRIMARY KEY,
  last_run DATE
);

-- ---------- 4. Test sonuçları ----------
CREATE TABLE test_result (
  inv_id      NUMBER NOT NULL REFERENCES sql_inventory,
  test_env    VARCHAR2(30) NOT NULL,   -- ADG_1932 / LAB_1932 / PREPROD_1932 / PROD_1929
  test_mode   VARCHAR2(10) NOT NULL,   -- EXPLAIN / EXECUTE
  status      VARCHAR2(10),            -- OK / ERROR / TOOLERR
  ora_code    NUMBER,
  ora_message VARCHAR2(4000),
  elapsed_ms  NUMBER,
  bind_source VARCHAR2(20),            -- NONE / CAPTURED / PARTIAL / NULLS
  tested_at   DATE DEFAULT SYSDATE,
  CONSTRAINT test_result_pk PRIMARY KEY (inv_id, test_env, test_mode)
);
CREATE INDEX test_result_code_ix ON test_result (ora_code, test_env);
