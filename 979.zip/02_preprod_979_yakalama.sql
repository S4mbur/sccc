-- =====================================================================
-- 02_preprod_979_yakalama.sql
-- Nerede : PREPROD (19.32), DBA kullanıcısıyla
-- Amaç   : Preprod'da herhangi bir oturum ORA-00979 aldığında SQL metnini,
--          kimin/hangi uygulamanın çalıştırdığını ve hata yığınını kaydetmek.
--          Faz 0'daki kalibrasyon seti buradan çıkar; testler sürdükçe
--          kendiliğinden büyür.
-- =====================================================================

CREATE TABLE dba_ops.ora979_catch (
  caught_at      TIMESTAMP DEFAULT SYSTIMESTAMP,
  session_user   VARCHAR2(128),
  proxy_user     VARCHAR2(128),
  current_schema VARCHAR2(128),
  os_user        VARCHAR2(128),
  host           VARCHAR2(256),
  program        VARCHAR2(128),
  module         VARCHAR2(64),
  action         VARCHAR2(64),
  service_name   VARCHAR2(64),
  sql_text       CLOB,
  error_stack    VARCHAR2(4000)
);
-- dba_ops yerine kendi yönetim şemanızı kullanın.

CREATE OR REPLACE TRIGGER dba_ops.trg_catch_ora979
AFTER SERVERERROR ON DATABASE
DECLARE
  PRAGMA AUTONOMOUS_TRANSACTION;
  l_parts ora_name_list_t;
  l_n     PLS_INTEGER;
  l_sql   CLOB;
BEGIN
  IF ora_is_servererror(979) THEN
    l_n := ora_sql_txt(l_parts);
    FOR i IN 1 .. NVL(l_n, 0) LOOP
      l_sql := l_sql || l_parts(i);
    END LOOP;

    INSERT INTO dba_ops.ora979_catch
      (session_user, proxy_user, current_schema, os_user, host, program,
       module, action, service_name, sql_text, error_stack)
    VALUES
      (SYS_CONTEXT('USERENV','SESSION_USER'),
       SYS_CONTEXT('USERENV','PROXY_USER'),
       SYS_CONTEXT('USERENV','CURRENT_SCHEMA'),
       SYS_CONTEXT('USERENV','OS_USER'),
       SYS_CONTEXT('USERENV','HOST'),
       SYS_CONTEXT('USERENV','CLIENT_PROGRAM_NAME'),
       SYS_CONTEXT('USERENV','MODULE'),
       SYS_CONTEXT('USERENV','ACTION'),
       SYS_CONTEXT('USERENV','SERVICE_NAME'),
       l_sql,
       SUBSTR(DBMS_UTILITY.FORMAT_ERROR_STACK, 1, 4000));
    COMMIT;
  END IF;
EXCEPTION
  WHEN OTHERS THEN NULL;   -- yakalama mekanizması hiçbir oturumu bozmamalı
END;
/

-- Notlar:
-- * Hata PL/SQL içindeki bir sorgudan geliyorsa ora_sql_txt üst seviye
--   çağrıyı (BEGIN pkg.proc; END;) döndürür. Asıl yer error_stack içindeki
--   ORA-06512 satırlarındadır (paket adı + satır no).
-- * Toplananları envantere almak için:
--     python ora979_tool.py ingest-catch  (PREPROD_* bağlantı değişkenleri ile)
--   ya da tabloyu JSONL'e döküp ingest-file ile alın.

-- Hızlı bakış
SELECT TRUNC(caught_at) gun, session_user, module, COUNT(*) adet
FROM   dba_ops.ora979_catch
GROUP  BY TRUNC(caught_at), session_user, module
ORDER  BY 1 DESC, 4 DESC;
