#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ora979_tool.py - ORA-00979 etki analizi: SQL envanteri toplama ve test.

Gereksinim: Python 3.8+, `pip install oracledb` (thin mod, Instant Client gerekmez)

ALT KOMUTLAR
  collect-cc      Prod cursor cache'teki yeni SQL'leri repoya alır.
                  cron ile 10-15 dakikada bir çalıştırın (4-6 hafta).
  collect-awr     AWR'deki SQL metinlerini bir kez alır (Diagnostics Pack lisansı gerekir).
  ingest-catch    Preprod'daki ORA-00979 yakalama tablosunu alır (02_preprod_979_yakalama.sql).
  ingest-plscope  Lab'deki DBA_STATEMENTS'tan PL/SQL statik SQL'lerini alır.
  ingest-views    View'lardan "SELECT * FROM view", MV'lerden tanım sorgusunu alır.
  ingest-file     JSONL dosyasından SQL alır (uygulama kodu, LLM'in çözdüğü dinamik SQL).
  prefilter       Geniş pattern ile EXECUTE adaylarını işaretler (cand_flag).
  run             EXPLAIN veya EXECUTE testi koşar, sonucu test_result'a yazar.

BAĞLANTI DEĞİŞKENLERİ
  REPO_DSN  REPO_USER  REPO_PWD      lab'deki REPO979 şeması (her komut kullanır)
  PROD_DSN  PROD_USER  PROD_PWD      prod, SELECT_CATALOG_ROLE'lü izleme kullanıcısı
  PREPROD_DSN PREPROD_USER PREPROD_PWD   sadece ingest-catch için
  TARGET_DSN PROBE_USER PROBE_PWD    run komutunun test edeceği ortam (ADG / lab / prod)

ÖRNEKLER
  python ora979_tool.py collect-cc
  python ora979_tool.py ingest-plscope
  python ora979_tool.py ingest-views
  python ora979_tool.py ingest-file --file dinamik_sql.jsonl
  python ora979_tool.py prefilter
  python ora979_tool.py run --env ADG_1932 --mode explain --auth proxy --workers 4 --sleep-ms 20 --limit 200
  python ora979_tool.py run --env ADG_1932 --mode explain --auth proxy --types SELECT
  python ora979_tool.py run --env LAB_1932 --mode execute --auth proxy --only-candidates
  python ora979_tool.py run --env PROD_1929 --mode explain --auth current_schema --failed-in ADG_1932:979

JSONL SATIR FORMATI (ingest-file)
  {"parsing_schema": "APP1", "sql_text": "SELECT ...", "source_type": "APP_REPO",
   "obj_name": "src/main/.../OrderDao.java", "line_no": 120, "module": "order-service"}
"""
import argparse
import datetime as dt
import decimal
import hashlib
import json
import os
import re
import sys
import threading
import time
from collections import defaultdict, namedtuple
from concurrent.futures import ThreadPoolExecutor, as_completed

import oracledb

oracledb.defaults.fetch_lobs = False  # CLOB ve LONG'lar doğrudan str gelsin

DEFAULT_EXCLUDE = {"REPO979", "PROBE979"}
TESTABLE = ("SELECT", "INSERT", "UPDATE", "DELETE", "MERGE")
COMMAND_TYPES = {3: "SELECT", 2: "INSERT", 6: "UPDATE", 7: "DELETE", 189: "MERGE"}

_print_lock = threading.Lock()


def log(msg):
    with _print_lock:
        print(f"[{dt.datetime.now():%H:%M:%S}] {msg}", flush=True)


# ---------------------------------------------------------------------------
# Bağlantı ve metin yardımcıları
# ---------------------------------------------------------------------------
def env(name):
    v = os.environ.get(name)
    if not v:
        sys.exit(f"Ortam değişkeni eksik: {name}")
    return v


def connect(prefix):
    return oracledb.connect(user=env(f"{prefix}_USER"),
                            password=env(f"{prefix}_PWD"),
                            dsn=env(f"{prefix}_DSN"))


_WS = re.compile(r"\s+")
_LEAD = re.compile(r"^\s*(?:/\*.*?\*/\s*|--[^\n]*(?:\n|$)\s*)*", re.S)


def clean_text(text):
    t = (text or "").strip()
    while t.endswith(";") or t.endswith("/"):
        t = t[:-1].rstrip()
    return t


def norm_hash(text):
    # Sadece boşluklar sadeleştirilir; literal'ler korunur (GROUP BY içindeki
    # literal farkı sonucu değiştirebilir). Literal varyant patlaması
    # collect-cc'de force_matching_signature başına sınırla önlenir.
    return hashlib.sha256(_WS.sub(" ", text).strip().encode("utf-8")).hexdigest()


def stmt_type_of(text):
    t = _LEAD.sub("", text).lstrip("( \t\r\n").upper()
    for kw in ("SELECT", "WITH", "INSERT", "UPDATE", "DELETE", "MERGE"):
        if t.startswith(kw):
            return "SELECT" if kw == "WITH" else kw
    return "OTHER"


def chunks(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def in_list(prefix, values):
    """IN (...) için bind isimleri ve sözlüğü üretir."""
    names = [f"{prefix}{i}" for i in range(len(values))]
    return ",".join(":" + n for n in names), dict(zip(names, values))


def maintained_users(cur):
    cur.execute("SELECT username FROM dba_users WHERE oracle_maintained = 'Y'")
    return {r[0] for r in cur.fetchall()}


# ---------------------------------------------------------------------------
# Repo işlemleri
# ---------------------------------------------------------------------------
class Repo:
    def __init__(self):
        self.conn = connect("REPO")
        self.cur = self.conn.cursor()

    def commit(self):
        self.conn.commit()

    def upsert(self, schema, text, sql_id=None, fms=None, stype=None, max_variants=None):
        """Envantere ekler. (inv_id, yeni_mi) döner; varyant sınırına takılırsa (None, False)."""
        text = clean_text(text)
        if not text or not schema:
            return None, False
        h = norm_hash(text)
        stype = stype or stmt_type_of(text)
        c = self.cur
        c.execute("SELECT inv_id FROM sql_inventory WHERE norm_hash = :h AND parsing_schema = :s",
                  h=h, s=schema)
        r = c.fetchone()
        if r:
            c.execute("UPDATE sql_inventory SET last_seen = SYSDATE WHERE inv_id = :i", i=r[0])
            return int(r[0]), False
        if max_variants and fms:
            c.execute("SELECT COUNT(*) FROM sql_inventory "
                      "WHERE force_match_sig = :f AND parsing_schema = :s", f=fms, s=schema)
            if c.fetchone()[0] >= max_variants:
                return None, False
        idv = c.var(oracledb.DB_TYPE_NUMBER)
        c.setinputsizes(t=oracledb.DB_TYPE_CLOB)
        c.execute("""INSERT INTO sql_inventory
                       (norm_hash, parsing_schema, sql_id, force_match_sig, stmt_type, sql_text)
                     VALUES (:h, :s, :q, :f, :st, :t)
                     RETURNING inv_id INTO :id""",
                  h=h, s=schema, q=sql_id, f=fms, st=stype, t=text, id=idv)
        return int(idv.getvalue()[0]), True

    def add_source(self, inv_id, source_type, sql_id=None, module=None, action=None,
                   obj_owner=None, obj_name=None, obj_type=None, line_no=None, executions=None):
        b = dict(i=inv_id, t=source_type, q=sql_id, o=obj_owner, n=obj_name, l=line_no)
        self.cur.execute("""SELECT COUNT(*) FROM sql_source_ref
                            WHERE inv_id = :i AND source_type = :t
                            AND NVL(sql_id,'-') = NVL(:q,'-')
                            AND NVL(obj_owner,'-') = NVL(:o,'-')
                            AND NVL(obj_name,'-') = NVL(:n,'-')
                            AND NVL(line_no,-1) = NVL(:l,-1)""", b)
        if self.cur.fetchone()[0]:
            return
        b.update(m=module, a=action, ot=obj_type, e=executions)
        self.cur.execute("""INSERT INTO sql_source_ref
                              (inv_id, source_type, sql_id, module, action, obj_owner,
                               obj_name, obj_type, line_no, executions)
                            VALUES (:i, :t, :q, :m, :a, :o, :n, :ot, :l, :e)""", b)

    def known_sql_ids(self, ids):
        known = set()
        for part in chunks(ids, 900):
            ph, b = in_list("q", part)
            self.cur.execute(f"SELECT sql_id FROM seen_sql_id WHERE sql_id IN ({ph})", b)
            known.update(r[0] for r in self.cur.fetchall())
        return known

    def mark_seen(self, sql_id, inv_id):
        self.cur.execute("""MERGE INTO seen_sql_id s USING (SELECT :q sql_id FROM dual) x
                            ON (s.sql_id = x.sql_id)
                            WHEN NOT MATCHED THEN INSERT (sql_id, inv_id) VALUES (:q, :i)""",
                         q=sql_id, i=inv_id)

    def has_binds(self, inv_id):
        self.cur.execute("SELECT COUNT(*) FROM sql_binds WHERE inv_id = :i", i=inv_id)
        return self.cur.fetchone()[0] > 0


# ---------------------------------------------------------------------------
# collect-cc : prod cursor cache
# ---------------------------------------------------------------------------
SQL_DETAIL = """
SELECT * FROM (
  SELECT s.sql_id, s.child_number, s.parsing_schema_name, s.force_matching_signature,
         s.command_type, s.module, s.action, s.executions, s.program_line#,
         o.owner, o.object_name, o.object_type, s.sql_fulltext,
         ROW_NUMBER() OVER (PARTITION BY s.sql_id ORDER BY s.child_number) rn
  FROM   v$sql s
  LEFT JOIN dba_objects o ON o.object_id = s.program_id AND s.program_id > 0
  WHERE  s.sql_id IN ({ph})
) WHERE rn = 1"""

BIND_SQL = """
SELECT position, name, datatype, datatype_string, was_captured,
       CASE WHEN was_captured = 'YES' THEN
            CASE WHEN datatype = 12  THEN TO_CHAR(ANYDATA.ACCESSDATE(value_anydata), 'YYYY-MM-DD HH24:MI:SS')
                 WHEN datatype = 180 THEN TO_CHAR(ANYDATA.ACCESSTIMESTAMP(value_anydata), 'YYYY-MM-DD HH24:MI:SS.FF6')
                 ELSE value_string END
       END val
FROM   v$sql_bind_capture
WHERE  sql_id = :q AND child_number = :c
ORDER  BY position"""

SESSION_SQL = """
SELECT DISTINCT sql_id, username, machine, program, module, service_name FROM (
  SELECT sql_id, username, machine, program, module, service_name
  FROM v$session WHERE type = 'USER' AND sql_id IS NOT NULL
  UNION ALL
  SELECT prev_sql_id, username, machine, program, module, service_name
  FROM v$session WHERE type = 'USER' AND prev_sql_id IS NOT NULL)"""

CLIENT_MERGE = """
MERGE INTO sql_client_seen c
USING (SELECT :q sql_id, :u username, :m machine, :p program, :mo module, :sv service_name FROM dual) x
ON (c.sql_id = x.sql_id AND NVL(c.username,'-') = NVL(x.username,'-')
    AND NVL(c.machine,'-') = NVL(x.machine,'-') AND NVL(c.program,'-') = NVL(x.program,'-'))
WHEN MATCHED THEN UPDATE SET c.hit_count = c.hit_count + 1, c.last_seen = SYSDATE
WHEN NOT MATCHED THEN INSERT (sql_id, username, machine, program, module, service_name)
  VALUES (x.sql_id, x.username, x.machine, x.program, x.module, x.service_name)"""


def sample_sessions(pc, repo, samples, interval):
    for k in range(samples):
        pc.execute(SESSION_SQL)
        rows = [dict(q=r[0], u=r[1], m=r[2], p=r[3], mo=r[4], sv=r[5]) for r in pc.fetchall()]
        if rows:
            repo.cur.executemany(CLIENT_MERGE, rows)
        if k < samples - 1:
            time.sleep(interval)


def store_binds(pc, repo, inv_id, sql_id, child):
    pc.execute(BIND_SQL, q=sql_id, c=child)
    rows = [dict(i=inv_id, p=r[0], n=r[1], d=r[2], ds=r[3], w=r[4], v=r[5]) for r in pc.fetchall()]
    if rows:
        repo.cur.executemany("""INSERT INTO sql_binds
                                  (inv_id, position, bind_name, datatype, datatype_string, was_captured, value_string)
                                VALUES (:i, :p, :n, :d, :ds, :w, :v)""", rows)


def cmd_collect_cc(a):
    prod = connect("PROD")
    pc = prod.cursor()
    pc.arraysize = 500
    repo = Repo()
    excl = maintained_users(pc) | DEFAULT_EXCLUDE | {x.upper() for x in a.exclude}

    repo.cur.execute("SELECT last_run FROM collector_state WHERE name = 'CC'")
    r = repo.cur.fetchone()
    since = (r[0] - dt.timedelta(minutes=a.overlap)) if r and r[0] else dt.datetime(1900, 1, 1)
    pc.execute("SELECT SYSDATE FROM dual")
    now = pc.fetchone()[0]

    # V$SQLSTATS kütüphane önbelleği kilitlerine en az dokunan görünüm
    pc.execute("SELECT DISTINCT sql_id FROM v$sqlstats WHERE last_active_time >= :s", s=since)
    active = [x[0] for x in pc.fetchall()]
    known = repo.known_sql_ids(active)
    new_ids = [x for x in active if x not in known]
    log(f"aktif {len(active)} sql_id, yeni {len(new_ids)}")

    added = skipped = 0
    for part in chunks(new_ids, 500):
        ph, b = in_list("q", part)
        pc.execute(SQL_DETAIL.format(ph=ph), b)
        for (sql_id, child, schema, fms, ctype, module, action, execs, line,
             owner, oname, otype, text, _rn) in pc.fetchall():
            stype = COMMAND_TYPES.get(ctype)
            if stype is None or schema in excl or not text:
                repo.mark_seen(sql_id, None)
                skipped += 1
                continue
            inv_id, is_new = repo.upsert(schema, text, sql_id=sql_id, fms=fms or None,
                                         stype=stype, max_variants=a.max_variants)
            repo.mark_seen(sql_id, inv_id)
            if inv_id is None:
                skipped += 1
                continue
            repo.add_source(inv_id, "CURSOR_CACHE", sql_id=sql_id, module=module, action=action,
                            obj_owner=owner, obj_name=oname, obj_type=otype,
                            line_no=line if owner else None, executions=execs)
            if not repo.has_binds(inv_id):
                store_binds(pc, repo, inv_id, sql_id, child)
            added += int(is_new)
        repo.commit()

    sample_sessions(pc, repo, a.session_samples, a.session_interval)
    repo.cur.execute("""MERGE INTO collector_state s USING (SELECT 'CC' name FROM dual) x
                        ON (s.name = x.name)
                        WHEN MATCHED THEN UPDATE SET s.last_run = :n
                        WHEN NOT MATCHED THEN INSERT (name, last_run) VALUES ('CC', :n)""", n=now)
    repo.commit()
    log(f"envantere yeni {added} SQL, atlanan {skipped}")


# ---------------------------------------------------------------------------
# collect-awr
# ---------------------------------------------------------------------------
AWR_SQL = """
SELECT t.sql_id, t.command_type, t.sql_text, s.parsing_schema_name, s.module, s.action, s.fms, s.execs
FROM   dba_hist_sqltext t
JOIN  (SELECT dbid, sql_id, MAX(parsing_schema_name) parsing_schema_name, MAX(module) module,
              MAX(action) action, MAX(force_matching_signature) fms, SUM(executions_delta) execs
       FROM dba_hist_sqlstat GROUP BY dbid, sql_id) s
  ON   s.dbid = t.dbid AND s.sql_id = t.sql_id
WHERE  t.dbid = (SELECT dbid FROM v$database)"""


def cmd_collect_awr(a):
    prod = connect("PROD")
    pc = prod.cursor()
    pc.arraysize = 500
    repo = Repo()
    excl = maintained_users(pc) | DEFAULT_EXCLUDE | {x.upper() for x in a.exclude}
    pc.execute(AWR_SQL)
    n = added = 0
    while True:
        rows = pc.fetchmany()
        if not rows:
            break
        for sql_id, ctype, text, schema, module, action, fms, execs in rows:
            stype = COMMAND_TYPES.get(ctype)
            if stype is None or schema in excl or not text:
                continue
            inv_id, is_new = repo.upsert(schema, text, sql_id=sql_id, fms=fms or None,
                                         stype=stype, max_variants=a.max_variants)
            if inv_id:
                repo.add_source(inv_id, "AWR", sql_id=sql_id, module=module, action=action,
                                executions=execs)
                added += int(is_new)
            n += 1
        repo.commit()
    log(f"AWR: işlenen {n}, envantere yeni {added}")


# ---------------------------------------------------------------------------
# ingest-catch : preprod yakalama tablosu
# ---------------------------------------------------------------------------
def cmd_ingest_catch(a):
    src = connect("PREPROD")
    sc = src.cursor()
    repo = Repo()
    sc.execute(f"SELECT current_schema, session_user, module, sql_text, error_stack "
               f"FROM {a.table} WHERE sql_text IS NOT NULL")
    plsql = added = 0
    for schema, suser, module, text, stack in sc.fetchall():
        if stmt_type_of(text) == "OTHER":
            plsql += 1   # PL/SQL çağrısı: asıl sorgu PL/Scope envanterinden gelir
            continue
        inv_id, is_new = repo.upsert(schema or suser, text)
        if inv_id:
            repo.add_source(inv_id, "PREPROD_CATCH", module=module)
            added += int(is_new)
    repo.commit()
    log(f"preprod yakalama: yeni {added}, PL/SQL çağrısı olarak atlanan {plsql} "
        f"(bunların error_stack'indeki ORA-06512 satırlarına bakın)")


# ---------------------------------------------------------------------------
# ingest-plscope : lab DBA_STATEMENTS
# ---------------------------------------------------------------------------
def cmd_ingest_plscope(a):
    repo = Repo()
    src = repo.conn.cursor()
    src.arraysize = 500
    src.execute("""SELECT owner, object_name, object_type, line, sql_id, type, full_text
                   FROM dba_statements
                   WHERE type IN ('SELECT','INSERT','UPDATE','DELETE','MERGE')
                   AND full_text IS NOT NULL
                   AND owner NOT IN (SELECT username FROM dba_users WHERE oracle_maintained = 'Y')""")
    n = added = 0
    while True:
        rows = src.fetchmany()
        if not rows:
            break
        for owner, oname, otype, line, sql_id, stype, text in rows:
            if owner in DEFAULT_EXCLUDE:
                continue
            # Definer rights birimlerde parsing schema sahibin kendisidir.
            # AUTHID CURRENT_USER birimler için çağıran şemalarla da test etmek
            # isterseniz ingest-file ile ek satır verin.
            inv_id, is_new = repo.upsert(owner, text, sql_id=sql_id, stype=stype)
            if inv_id:
                repo.add_source(inv_id, "PLSCOPE", sql_id=sql_id, obj_owner=owner,
                                obj_name=oname, obj_type=otype, line_no=line)
                added += int(is_new)
            n += 1
        repo.commit()
    log(f"PL/Scope: işlenen {n}, envantere yeni {added}")


# ---------------------------------------------------------------------------
# ingest-views
# ---------------------------------------------------------------------------
def cmd_ingest_views(a):
    repo = Repo()
    src = repo.conn.cursor()
    src.execute("""SELECT owner, view_name FROM dba_views
                   WHERE owner NOT IN (SELECT username FROM dba_users WHERE oracle_maintained = 'Y')""")
    nv = 0
    for owner, name in src.fetchall():
        if owner in DEFAULT_EXCLUDE:
            continue
        inv_id, _ = repo.upsert(owner, f'SELECT * FROM "{owner}"."{name}"', stype="SELECT")
        if inv_id:
            repo.add_source(inv_id, "VIEW", obj_owner=owner, obj_name=name, obj_type="VIEW")
            nv += 1
    repo.commit()
    src.execute("""SELECT owner, mview_name, query FROM dba_mviews
                   WHERE owner NOT IN (SELECT username FROM dba_users WHERE oracle_maintained = 'Y')""")
    nm = 0
    for owner, name, query in src.fetchall():
        if not query:
            continue
        inv_id, _ = repo.upsert(owner, query, stype="SELECT")
        if inv_id:
            repo.add_source(inv_id, "MVIEW", obj_owner=owner, obj_name=name, obj_type="MATERIALIZED VIEW")
            nm += 1
    repo.commit()
    log(f"view {nv}, materialized view {nm}")


# ---------------------------------------------------------------------------
# ingest-file : JSONL
# ---------------------------------------------------------------------------
def cmd_ingest_file(a):
    repo = Repo()
    n = added = bad = 0
    with open(a.file, encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
                schema, text = d["parsing_schema"].upper(), d["sql_text"]
            except (ValueError, KeyError) as e:
                bad += 1
                log(f"satır {lineno} atlandı: {e}")
                continue
            inv_id, is_new = repo.upsert(schema, text)
            if inv_id:
                repo.add_source(inv_id, d.get("source_type", "APP_REPO"),
                                module=d.get("module"), obj_owner=d.get("obj_owner"),
                                obj_name=d.get("obj_name"), obj_type=d.get("obj_type"),
                                line_no=d.get("line_no"))
                added += int(is_new)
            n += 1
    repo.commit()
    log(f"dosya: işlenen {n}, yeni {added}, hatalı {bad}")


# ---------------------------------------------------------------------------
# prefilter : geniş "kaçırmayan" pattern
# ---------------------------------------------------------------------------
AGG_FUNCS = [
    "COUNT", "SUM", "AVG", "MIN", "MAX", "LISTAGG", "STDDEV", "STDDEV_POP", "STDDEV_SAMP",
    "VARIANCE", "VAR_POP", "VAR_SAMP", "MEDIAN", "COLLECT", "XMLAGG", "JSON_ARRAYAGG",
    "JSON_OBJECTAGG", "PERCENTILE_CONT", "PERCENTILE_DISC", "CORR", "COVAR_POP", "COVAR_SAMP",
    "APPROX_COUNT_DISTINCT", "APPROX_COUNT_DISTINCT_DETAIL", "APPROX_MEDIAN", "APPROX_PERCENTILE",
    "ANY_VALUE", "GROUPING", "GROUPING_ID", "GROUP_ID", "RANK", "DENSE_RANK", "CUME_DIST",
    "PERCENT_RANK", "FIRST", "LAST", "STATS_MODE", "REGR_SLOPE", "REGR_INTERCEPT", "REGR_COUNT",
    "REGR_R2", "REGR_AVGX", "REGR_AVGY", "REGR_SXX", "REGR_SYY", "REGR_SXY", "SYS_XMLAGG",
]
_TOK = re.compile(r'"([^"]+)"|([A-Za-z][A-Za-z0-9_$#]*)')


def build_pattern(extra):
    names = sorted(set(AGG_FUNCS) | {x.upper() for x in extra})
    return re.compile(
        r"\bGROUP\s+BY\b|\bDISTINCT\b|\bUNIQUE\b|\bPIVOT\b|\bMODEL\b"
        r"|\bROLLUP\b|\bCUBE\b|\bGROUPING\s+SETS\b"
        r"|\b(?:" + "|".join(re.escape(n) for n in names) + r")\s*\(",
        re.I)


def tokens(text):
    return {q if q else u.upper() for q, u in _TOK.findall(text)}


def cmd_prefilter(a):
    repo = Repo()
    c = repo.conn.cursor()
    c.arraysize = 1000

    c.execute("SELECT DISTINCT object_name FROM dba_procedures WHERE aggregate = 'YES'")
    pattern = build_pattern([r[0] for r in c.fetchall()])

    owner_filter = ("WHERE owner NOT IN (SELECT username FROM dba_users WHERE oracle_maintained = 'Y')"
                    if a.app_views_only else "")
    c.execute(f"SELECT owner, view_name, text FROM dba_views {owner_filter}")
    views = {(o, n): (t or "") for o, n, t in c.fetchall()}
    c.execute("SELECT owner, synonym_name, table_owner, table_name FROM dba_synonyms WHERE db_link IS NULL")
    syn = {(o, n): (to, tn) for o, n, to, tn in c.fetchall()}
    c.execute("""SELECT owner, name, referenced_owner, referenced_name, referenced_type
                 FROM dba_dependencies
                 WHERE type = 'VIEW' AND referenced_type IN ('VIEW','SYNONYM')""")

    def resolve(key):
        for _ in range(10):
            if key in views:
                return key
            if key in syn:
                key = syn[key]
                continue
            return None
        return None

    rev = defaultdict(list)
    for o, n, ro, rn, rt in c.fetchall():
        target = resolve((ro, rn))
        if target:
            rev[target].append((o, n))

    risky = {k for k, t in views.items() if pattern.search(t)}
    queue = list(risky)
    while queue:
        k = queue.pop()
        for dep in rev.get(k, ()):
            if dep not in risky:
                risky.add(dep)
                queue.append(dep)

    risky_names = {n for _, n in risky}
    for (so, sn), _ in syn.items():
        if resolve((so, sn)) in risky:
            risky_names.add(sn)
    log(f"view: toplam {len(views)}, riskli {len(risky)}, riskli isim {len(risky_names)}")

    where = "" if a.all else "WHERE cand_flag IS NULL"
    c.execute(f"SELECT inv_id, stmt_type, sql_text FROM sql_inventory {where}")
    upd = []
    ny = nn = 0
    while True:
        rows = c.fetchmany()
        if not rows:
            break
        for inv_id, stype, text in rows:
            text = text or ""
            m = pattern.search(text)
            if stype == "OTHER":
                flag, reason = "Y", "SINIFLANDIRILAMADI"
            elif m:
                flag, reason = "Y", "PATTERN:" + _WS.sub(" ", m.group(0)).upper()
            else:
                hit = sorted(tokens(text) & risky_names)
                if hit:
                    flag, reason = "Y", ("VIEW:" + ",".join(hit[:5]))[:400]
                else:
                    flag, reason = "N", None
            ny += flag == "Y"
            nn += flag == "N"
            upd.append(dict(f=flag, r=reason, i=inv_id))
        repo.cur.executemany("UPDATE sql_inventory SET cand_flag = :f, cand_reason = :r WHERE inv_id = :i", upd)
        repo.commit()
        upd.clear()
    log(f"aday {ny}, aday değil {nn}")


# ---------------------------------------------------------------------------
# run : EXPLAIN / EXECUTE
# ---------------------------------------------------------------------------
Item = namedtuple("Item", "inv_id schema stype text")


class SafetyError(Exception):
    pass


RESULT_MERGE = """
MERGE INTO test_result r
USING (SELECT :inv_id inv_id, :env test_env, :tmode test_mode FROM dual) x
ON (r.inv_id = x.inv_id AND r.test_env = x.test_env AND r.test_mode = x.test_mode)
WHEN MATCHED THEN UPDATE SET r.status = :st, r.ora_code = :code, r.ora_message = :msg,
     r.elapsed_ms = :ms, r.bind_source = :bs, r.tested_at = SYSDATE
WHEN NOT MATCHED THEN INSERT (inv_id, test_env, test_mode, status, ora_code, ora_message, elapsed_ms, bind_source)
     VALUES (x.inv_id, x.test_env, x.test_mode, :st, :code, :msg, :ms, :bs)"""


def load_items(repo, a):
    mode = a.mode.upper()
    q = ["SELECT i.inv_id, i.parsing_schema, i.stmt_type, i.sql_text FROM sql_inventory i",
         "WHERE i.stmt_type IN ('SELECT','INSERT','UPDATE','DELETE','MERGE')"]
    b = {}
    if a.only_candidates:
        q.append("AND i.cand_flag = 'Y'")
    if a.types:
        ph, tb = in_list("ty", [t.upper() for t in a.types])
        q.append(f"AND i.stmt_type IN ({ph})")
        b.update(tb)
    if a.schemas:
        ph, sb = in_list("s", [s.upper() for s in a.schemas])
        q.append(f"AND i.parsing_schema IN ({ph})")
        b.update(sb)
    if a.failed_in:
        fe, fc = a.failed_in.split(":")
        q.append("AND EXISTS (SELECT 1 FROM test_result f WHERE f.inv_id = i.inv_id "
                 "AND f.test_env = :fe AND f.ora_code = :fc)")
        b.update(fe=fe, fc=int(fc))
    if a.retest_codes:
        ph, cb = in_list("c", [int(x) for x in a.retest_codes])
        q.append("AND EXISTS (SELECT 1 FROM test_result r WHERE r.inv_id = i.inv_id "
                 f"AND r.test_env = :env AND r.test_mode = :tmode AND r.ora_code IN ({ph}))")
        b.update(cb, env=a.env, tmode=mode)
    elif not a.retest:
        q.append("AND NOT EXISTS (SELECT 1 FROM test_result r WHERE r.inv_id = i.inv_id "
                 "AND r.test_env = :env AND r.test_mode = :tmode)")
        b.update(env=a.env, tmode=mode)
    q.append("ORDER BY i.parsing_schema, i.inv_id")
    if a.limit:
        q.append(f"FETCH FIRST {int(a.limit)} ROWS ONLY")
    c = repo.conn.cursor()
    c.arraysize = 1000
    c.execute("\n".join(q), b)
    return [Item(*r) for r in c.fetchall()]


def lab_safety_check(conn):
    c = conn.cursor()
    try:
        c.execute("SELECT marker FROM repo979.lab_marker")
        ok = any(r[0] == "ORA979_LAB" for r in c.fetchall())
    except oracledb.DatabaseError:
        ok = False
    if not ok:
        raise SafetyError("Hedefte REPO979.LAB_MARKER yok: execute modu sadece lab'de çalışır.")
    c.execute("SELECT COUNT(*) FROM all_db_links")
    if c.fetchone()[0]:
        raise SafetyError("Hedef oturum DB link görüyor: execute modu durduruldu.")
    c.execute("SELECT database_role, open_mode FROM v$database")
    role, open_mode = c.fetchone()
    if role != "PRIMARY" or open_mode != "READ WRITE":
        raise SafetyError(f"Hedef lab gibi görünmüyor ({role}/{open_mode}).")


def open_target(a, schema):
    user, pwd, dsn = env("PROBE_USER"), env("PROBE_PWD"), env("TARGET_DSN")
    if a.auth == "proxy":
        conn = oracledb.connect(user=f"{user}[{schema}]", password=pwd, dsn=dsn)
    else:
        conn = oracledb.connect(user=user, password=pwd, dsn=dsn)
        conn.cursor().execute(f'ALTER SESSION SET CURRENT_SCHEMA = "{schema}"')
    conn.call_timeout = a.timeout * 1000
    if a.mode == "execute":
        lab_safety_check(conn)
    return conn


def do_explain(conn, it, a):
    c = conn.cursor()
    into = f" INTO {a.plan_table}" if a.plan_table else ""
    c.prepare(f"EXPLAIN PLAN SET STATEMENT_ID = 'ORA979_{it.inv_id}'{into} FOR {it.text}")
    names = c.bindnames()
    if names:
        # EXPLAIN bind değerine bakmaz; yer tutucular NULL ile doldurulur
        c.execute(None, {n: None for n in names})
        return "NULLS"
    c.execute(None)
    return "NONE"


def _bind_key(name):
    return (name or "").lstrip(":").strip('"').upper()


def convert_bind(dtype, val, captured):
    if captured != "YES" or val is None:
        return None
    try:
        if dtype == 2:
            return decimal.Decimal(val)
        if dtype == 12:
            return dt.datetime.strptime(val, "%Y-%m-%d %H:%M:%S")
        if dtype == 180:
            return dt.datetime.strptime(val, "%Y-%m-%d %H:%M:%S.%f")
        return val
    except (ValueError, decimal.InvalidOperation):
        return None


def do_execute(conn, rc, it, a):
    c = conn.cursor()
    c.prepare(it.text)
    names = c.bindnames()
    if not names:
        c.execute(None)
        src = "NONE"
    else:
        rc.execute("SELECT bind_name, datatype, value_string, was_captured "
                   "FROM sql_binds WHERE inv_id = :i ORDER BY position", i=it.inv_id)
        cap = {}
        for bname, dtype, val, was in rc.fetchall():
            cap.setdefault(_bind_key(bname), convert_bind(dtype, val, was))
        vals = {n: cap.get(_bind_key(n)) for n in names}
        hit = sum(v is not None for v in vals.values())
        c.execute(None, vals)
        src = "CAPTURED" if hit == len(names) else ("PARTIAL" if hit else "NULLS")
    if it.stype == "SELECT":
        c.fetchone()   # lab'de tablolar boş: anında döner
    return src


def run_chunk(a, schema, items, counter):
    repo = connect("REPO")
    rc = repo.cursor()
    mode = a.mode.upper()
    results = []

    def flush():
        if results:
            rc.executemany(RESULT_MERGE, results)
            repo.commit()
            results.clear()

    def record(it, st, code, msg, ms, bs):
        results.append(dict(inv_id=it.inv_id, env=a.env, tmode=mode, st=st, code=code,
                            msg=(msg or "")[:4000] or None, ms=ms, bs=bs))
        if len(results) >= 200:
            flush()

    try:
        conn = open_target(a, schema)
    except SafetyError:
        raise
    except oracledb.Error as e:
        for it in items:
            record(it, "TOOLERR", None, f"BAGLANTI: {e}", None, None)
        flush()
        repo.close()
        log(f"{schema}: bağlantı kurulamadı ({e}); {len(items)} SQL TOOLERR yazıldı")
        return

    try:
        for it in items:
            t0 = time.perf_counter()
            st, code, msg, bs = "OK", None, None, None
            try:
                if a.mode == "explain":
                    bs = do_explain(conn, it, a)
                else:
                    bs = do_execute(conn, rc, it, a)
            except oracledb.DatabaseError as e:
                err = e.args[0]
                full = getattr(err, "full_code", "") or ""
                if full.startswith("ORA-"):
                    st, code = "ERROR", getattr(err, "code", None)
                else:
                    st = "TOOLERR"   # sürücü hatası (ör. DPY-4024 zaman aşımı)
                msg = str(err)
            except Exception as e:  # noqa: BLE001
                st, msg = "TOOLERR", repr(e)
            finally:
                try:
                    conn.rollback()   # EXPLAIN'in plan tablosu satırları ve DML'ler geri alınır
                except oracledb.Error:
                    pass
            record(it, st, code, msg, int((time.perf_counter() - t0) * 1000), bs)

            if not conn.is_healthy():
                try:
                    conn.close()
                except oracledb.Error:
                    pass
                conn = open_target(a, schema)   # başarısız olursa kalanlar bir sonraki koşuda alınır
            with counter["lock"]:
                counter["done"] += 1
                if code == 979:
                    counter["979"] += 1
                if counter["done"] % 500 == 0:
                    log(f"{counter['done']}/{counter['total']} tamamlandı, ORA-00979: {counter['979']}")
            if a.sleep_ms:
                time.sleep(a.sleep_ms / 1000)
    finally:
        flush()
        for x in (conn, repo):
            try:
                x.close()
            except oracledb.Error:
                pass


def cmd_run(a):
    repo = Repo()
    items = load_items(repo, a)
    repo.conn.close()
    if not items:
        log("test edilecek SQL yok")
        return
    by_schema = defaultdict(list)
    for it in items:
        by_schema[it.schema].append(it)
    jobs = [(s, part) for s, lst in by_schema.items() for part in chunks(lst, a.chunk)]
    counter = {"lock": threading.Lock(), "done": 0, "total": len(items), "979": 0}
    log(f"{a.env}/{a.mode}: {len(items)} SQL, {len(by_schema)} şema, {len(jobs)} parça, {a.workers} işçi")

    with ThreadPoolExecutor(max_workers=a.workers) as ex:
        futs = [ex.submit(run_chunk, a, s, part, counter) for s, part in jobs]
        for f in as_completed(futs):
            try:
                f.result()
            except SafetyError as e:
                log(f"GÜVENLİK: {e}")
                for g in futs:
                    g.cancel()
                sys.exit(2)
            except Exception as e:  # noqa: BLE001
                log(f"bir parça yarıda kaldı ({e}); test edilmeyenler sonraki koşuda alınır")
    log(f"bitti: {counter['done']} SQL, ORA-00979: {counter['979']}")


# ---------------------------------------------------------------------------
def main():
    p = argparse.ArgumentParser(description="ORA-00979 envanter ve test aracı")
    sp = p.add_subparsers(dest="cmd", required=True)

    s = sp.add_parser("collect-cc", help="prod cursor cache toplayıcı")
    s.add_argument("--overlap", type=int, default=5, help="önceki koşuyla örtüşme (dk)")
    s.add_argument("--max-variants", type=int, default=3,
                   help="force_matching_signature başına saklanacak literal varyant sayısı")
    s.add_argument("--session-samples", type=int, default=5)
    s.add_argument("--session-interval", type=float, default=3.0)
    s.add_argument("--exclude", nargs="*", default=[])
    s.set_defaults(fn=cmd_collect_cc)

    s = sp.add_parser("collect-awr", help="AWR'den tek seferlik alım")
    s.add_argument("--max-variants", type=int, default=3)
    s.add_argument("--exclude", nargs="*", default=[])
    s.set_defaults(fn=cmd_collect_awr)

    s = sp.add_parser("ingest-catch", help="preprod ORA-00979 yakalama tablosu")
    s.add_argument("--table", default="dba_ops.ora979_catch")
    s.set_defaults(fn=cmd_ingest_catch)

    s = sp.add_parser("ingest-plscope", help="lab DBA_STATEMENTS")
    s.set_defaults(fn=cmd_ingest_plscope)

    s = sp.add_parser("ingest-views", help="view ve MV tanımları")
    s.set_defaults(fn=cmd_ingest_views)

    s = sp.add_parser("ingest-file", help="JSONL dosyası")
    s.add_argument("--file", required=True)
    s.set_defaults(fn=cmd_ingest_file)

    s = sp.add_parser("prefilter", help="EXECUTE adaylarını işaretle")
    s.add_argument("--all", action="store_true", help="daha önce işaretlenenleri de yeniden değerlendir")
    s.add_argument("--app-views-only", action="store_true",
                   help="Oracle'ın kendi view'larını riskli view hesabına katma (önerilmez)")
    s.set_defaults(fn=cmd_prefilter)

    s = sp.add_parser("run", help="EXPLAIN / EXECUTE testi")
    s.add_argument("--env", required=True, help="sonuç etiketi: ADG_1932, LAB_1932, PROD_1929 ...")
    s.add_argument("--mode", choices=["explain", "execute"], required=True)
    s.add_argument("--auth", choices=["proxy", "current_schema"], default="proxy")
    s.add_argument("--workers", type=int, default=4)
    s.add_argument("--chunk", type=int, default=500)
    s.add_argument("--timeout", type=int, default=60, help="SQL başına süre sınırı (sn)")
    s.add_argument("--sleep-ms", type=int, default=0, help="SQL'ler arası bekleme (ADG'yi yormamak için)")
    s.add_argument("--only-candidates", action="store_true", help="sadece cand_flag = Y")
    s.add_argument("--schemas", nargs="*")
    s.add_argument("--types", nargs="*", choices=list(TESTABLE),
                   help="sadece bu SQL tipleri, ör. --types SELECT (ADG'de DML EXPLAIN'i sorun çıkarırsa)")
    s.add_argument("--failed-in", help="ENV:KOD, ör. ADG_1932:979 - sadece orada bu kodla hata verenler")
    s.add_argument("--retest", action="store_true", help="bu ortamda daha önce test edilenleri de koş")
    s.add_argument("--retest-codes", nargs="*", help="sadece bu ORA kodlarıyla hata vermişleri yeniden koş")
    s.add_argument("--limit", type=int)
    s.add_argument("--plan-table", help="EXPLAIN ... INTO <tablo>; uygulama şemasında eski PLAN_TABLE varsa")
    s.set_defaults(fn=cmd_run)

    a = p.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
