-- =====================================================================
-- q979_basit.sql  —  Preprod'da 3 hamlede ORA-00979 avı
--
-- Nerede : SADECE PREPROD (19.32), DBA yetkili bir kullanıcıyla.
-- Ne yapar: Hiçbir obje oluşturmaz, hiçbir sorguyu çalıştırmaz.
--           Sadece EXPLAIN PLAN atar (parse + optimize, veri okunmaz)
--           ve ORA-00979 verenleri ekrana yazar.
-- Yük    : Tek oturum, her blok en fazla 10 dk, her deneme arası kısa bekleme.
--
-- SQL*Plus / SQLcl / SQL Developer'da bloğu seçip çalıştırın.
-- SQL Developer'da sonucu "Dbms Output" panelinde görürsünüz.
-- =====================================================================
SET SERVEROUTPUT ON SIZE UNLIMITED


-- =====================================================================
-- HAMLE 1 (1 dk) — Zaten yaşanmış olanlar
-- 19c, sık tekrarlanan parse hatalarını SQL metniyle alert log'a yazar.
-- =====================================================================
SELECT originating_timestamp, SUBSTR(message_text, 1, 2000) mesaj
FROM   v$diag_alert_ext
WHERE  originating_timestamp > SYSDATE - 30
AND    message_text LIKE '%error=979%'
ORDER  BY originating_timestamp DESC;


-- =====================================================================
-- HAMLE 2 (5-10 dk) — View'lar ve materialized view'lar
-- Her view için "SELECT * FROM view" EXPLAIN edilir. Önce GROUP BY +
-- inline view içerenler, sonra diğer GROUP BY / DISTINCT'liler, en son kalanlar.
-- =====================================================================
DECLARE
  l_end  DATE := SYSDATE + 10/1440;   -- süre sınırı: 10 dk
  l_n    PLS_INTEGER := 0;
  l_hit  PLS_INTEGER := 0;
  l_code NUMBER;

  FUNCTION try_explain(p_schema VARCHAR2, p_sql CLOB) RETURN NUMBER IS
  BEGIN
    EXECUTE IMMEDIATE 'ALTER SESSION SET CURRENT_SCHEMA = "' || p_schema || '"';
    EXECUTE IMMEDIATE 'EXPLAIN PLAN SET STATEMENT_ID = ''Q979'' FOR ' || p_sql;
    ROLLBACK;
    RETURN 0;
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    RETURN -SQLCODE;
  END;
BEGIN
  FOR v IN (SELECT owner, view_name
            FROM   dba_views
            WHERE  owner IN (SELECT username FROM dba_users WHERE oracle_maintained = 'N')
            ORDER  BY CASE
                        WHEN REGEXP_LIKE(text_vc, 'GROUP\s+BY', 'i')
                         AND REGEXP_LIKE(text_vc, '(FROM|JOIN|,)\s*\(\s*(SELECT|WITH)', 'i') THEN 1
                        WHEN REGEXP_LIKE(text_vc, 'GROUP\s+BY', 'i')                     THEN 2
                        WHEN REGEXP_LIKE(text_vc, 'DISTINCT|UNIQUE', 'i')                THEN 3
                        ELSE 4
                      END, owner, view_name) LOOP
    EXIT WHEN SYSDATE > l_end;
    l_code := try_explain(v.owner, 'SELECT * FROM "' || v.owner || '"."' || v.view_name || '"');
    l_n := l_n + 1;
    IF l_code = 979 THEN
      l_hit := l_hit + 1;
      DBMS_OUTPUT.PUT_LINE('ORA-00979  VIEW   ' || v.owner || '.' || v.view_name);
    END IF;
    DBMS_SESSION.SLEEP(0.01);
  END LOOP;

  FOR m IN (SELECT owner, mview_name, query
            FROM   dba_mviews
            WHERE  owner IN (SELECT username FROM dba_users WHERE oracle_maintained = 'N')
            AND    query_len <= 32000) LOOP
    EXIT WHEN SYSDATE > l_end;
    l_code := try_explain(m.owner, m.query);
    l_n := l_n + 1;
    IF l_code = 979 THEN
      l_hit := l_hit + 1;
      DBMS_OUTPUT.PUT_LINE('ORA-00979  MVIEW  ' || m.owner || '.' || m.mview_name);
    END IF;
    DBMS_SESSION.SLEEP(0.01);
  END LOOP;

  EXECUTE IMMEDIATE 'ALTER SESSION SET CURRENT_SCHEMA = "' || SYS_CONTEXT('USERENV','SESSION_USER') || '"';
  DBMS_OUTPUT.PUT_LINE('--- Hamle 2 bitti: denenen ' || l_n || ', ORA-00979 ' || l_hit ||
                       CASE WHEN SYSDATE > l_end THEN ' (süre doldu, kalanlar denenmedi)' END);
END;
/


-- =====================================================================
-- HAMLE 3 (10 dk) — Preprod AWR'deki sorgular
-- Forumdaki yapıya benzeyenler (GROUP BY + inline view / WITH), preprod'da en
-- çok çalışandan başlayarak, en fazla 5000 sorgu.
-- Preprod'un AWR'si 19.32 geçişinden önceki günleri de tutuyorsa en verimli
-- hamle budur. (DBA_HIST_* sorgulamak Diagnostics Pack gerektirir.)
-- =====================================================================
DECLARE
  l_end  DATE := SYSDATE + 10/1440;   -- süre sınırı: 10 dk
  l_n    PLS_INTEGER := 0;
  l_hit  PLS_INTEGER := 0;
  l_code NUMBER;

  -- Bind'li sorgularda sürücü değer isterse (ORA-01008) yer tutucuları NULL'la doldurur.
  PROCEDURE explain_null_binds(p_stmt CLOB) IS
    c  INTEGER := DBMS_SQL.OPEN_CURSOR;
    nm VARCHAR2(200);
    i  PLS_INTEGER := 1;
    d  INTEGER;
  BEGIN
    DBMS_SQL.PARSE(c, p_stmt, DBMS_SQL.NATIVE);
    LOOP
      nm := REGEXP_SUBSTR(p_stmt, ':("[^"]+"|[A-Za-z0-9_$#]+)', 1, i);
      EXIT WHEN nm IS NULL;
      BEGIN
        DBMS_SQL.BIND_VARIABLE(c, nm, CAST(NULL AS VARCHAR2));
      EXCEPTION WHEN OTHERS THEN NULL;
      END;
      i := i + 1;
    END LOOP;
    d := DBMS_SQL.EXECUTE(c);
    DBMS_SQL.CLOSE_CURSOR(c);
  EXCEPTION WHEN OTHERS THEN
    IF DBMS_SQL.IS_OPEN(c) THEN DBMS_SQL.CLOSE_CURSOR(c); END IF;
    RAISE;
  END;

  FUNCTION try_explain(p_schema VARCHAR2, p_sql CLOB) RETURN NUMBER IS
    l_stmt CLOB := 'EXPLAIN PLAN SET STATEMENT_ID = ''Q979'' FOR ' || p_sql;
  BEGIN
    EXECUTE IMMEDIATE 'ALTER SESSION SET CURRENT_SCHEMA = "' || p_schema || '"';
    BEGIN
      EXECUTE IMMEDIATE l_stmt;
    EXCEPTION WHEN OTHERS THEN
      IF SQLCODE = -1008 THEN explain_null_binds(l_stmt); ELSE RAISE; END IF;
    END;
    ROLLBACK;
    RETURN 0;
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    RETURN -SQLCODE;
  END;
BEGIN
  FOR r IN (SELECT * FROM (
              SELECT s.parsing_schema_name sch, t.sql_id, s.execs, t.sql_text
              FROM   dba_hist_sqltext t
              JOIN  (SELECT dbid, sql_id,
                            MAX(parsing_schema_name) parsing_schema_name,
                            SUM(executions_delta)    execs
                     FROM   dba_hist_sqlstat
                     GROUP  BY dbid, sql_id) s
                ON   s.dbid = t.dbid AND s.sql_id = t.sql_id
              WHERE  t.dbid = (SELECT dbid FROM v$database)
              AND    t.command_type IN (2, 3, 6, 7, 189)
              AND    s.parsing_schema_name NOT IN (SELECT username FROM dba_users WHERE oracle_maintained = 'Y')
              AND    REGEXP_LIKE(t.sql_text, 'GROUP\s+BY', 'i')
              AND   (REGEXP_LIKE(t.sql_text, '(FROM|JOIN|,)\s*\(\s*(SELECT|WITH)', 'i')
                     OR REGEXP_LIKE(t.sql_text, 'WITH\s+"?[A-Za-z0-9_$#]+"?\s+AS\s*\(', 'i'))
              ORDER  BY s.execs DESC NULLS LAST)
            WHERE ROWNUM <= 5000) LOOP
    EXIT WHEN SYSDATE > l_end;
    l_code := try_explain(r.sch, r.sql_text);
    l_n := l_n + 1;
    IF l_code = 979 THEN
      l_hit := l_hit + 1;
      DBMS_OUTPUT.PUT_LINE('ORA-00979  ' || r.sql_id || '  ' || r.sch ||
                           '  calisma=' || r.execs || '  ' ||
                           REPLACE(REPLACE(DBMS_LOB.SUBSTR(r.sql_text, 150, 1), CHR(10), ' '), CHR(13), ' '));
    END IF;
    DBMS_SESSION.SLEEP(0.01);
  END LOOP;

  EXECUTE IMMEDIATE 'ALTER SESSION SET CURRENT_SCHEMA = "' || SYS_CONTEXT('USERENV','SESSION_USER') || '"';
  DBMS_OUTPUT.PUT_LINE('--- Hamle 3 bitti: denenen ' || l_n || ', ORA-00979 ' || l_hit ||
                       CASE WHEN SYSDATE > l_end THEN ' (süre doldu, kalanlar denenmedi)' END);
END;
/

-- Bulunan bir sorgunun tam metni için:
-- SELECT sql_text FROM dba_hist_sqltext WHERE sql_id = '<sql_id>';
