-- =====================================================================
-- q979_hizli_rapor.sql  —  İzleme ve sonuçlar
-- Nerede : PREPROD, kurulumu yapan aynı DBA kullanıcısıyla.
-- Test devam ederken başka bir oturumdan istediğiniz zaman çalıştırabilirsiniz.
-- =====================================================================
DEFINE WRK = DBA_OPS


-- R1. İlerleme: önceliğe göre test edilen / bekleyen / ORA-00979
SELECT src, prio,
       COUNT(*)                                                 toplam,
       COUNT(status)                                            test_edilen,
       SUM(CASE WHEN ora_code = 979 THEN 1 ELSE 0 END)          ora979,
       ROUND(100 * SUM(CASE WHEN ora_code = 979 THEN 1 ELSE 0 END)
             / NULLIF(COUNT(status), 0), 1)                     isabet_yuzde,
       ROUND(AVG(elapsed_ms))                                   ort_ms
FROM   &&WRK..q979_cand
GROUP  BY src, prio
ORDER  BY src, prio;


-- R2. BULUNANLAR: prod'da en çok çalışandan aza doğru
SELECT src, parsing_schema, sql_id, module, execs prod_calisma,
       obj_owner, obj_name,
       DBMS_LOB.SUBSTR(sql_text, 300, 1) sql_bas
FROM   &&WRK..q979_cand
WHERE  ora_code = 979
ORDER  BY execs DESC NULLS LAST, src, parsing_schema;


-- R3. Özet: hangi şema / module ne kadar etkileniyor
SELECT parsing_schema, NVL(module, '(view)') module,
       COUNT(*) sorgu_sayisi, SUM(execs) prod_calisma
FROM   &&WRK..q979_cand
WHERE  ora_code = 979
GROUP  BY parsing_schema, NVL(module, '(view)')
ORDER  BY sorgu_sayisi DESC;


-- R4. Diğer hatalar (çoğu preprod ile prod arasındaki obje farkı: gürültü)
--     ORA-942/904/1435 yüksekse ilgili şemalar preprod'da eksik veya farklı demektir.
SELECT ora_code, COUNT(*) adet, SUBSTR(MIN(ora_msg), 1, 120) ornek
FROM   &&WRK..q979_cand
WHERE  status = 'ERROR' AND ora_code <> 979
GROUP  BY ora_code
ORDER  BY adet DESC;


-- R5. (Opsiyonel, Diagnostics Pack) Bulunan AWR sorgularını kaynağa bağla:
--     ASH örneklerinden PL/SQL giriş noktası ve hangi makine/programdan geldiği.
--     Sadece bulunan sorgular için çalışır, ADG'de okur.
SELECT h.sql_id,
       o.owner || '.' || o.object_name   plsql_giris,
       o.object_type,
       h.program, h.machine, h.module,
       COUNT(*)                          ash_ornek
FROM   dba_hist_active_sess_history@adg_ro h
LEFT JOIN dba_objects@adg_ro o ON o.object_id = h.plsql_entry_object_id
WHERE  h.sql_id IN (SELECT sql_id FROM &&WRK..q979_cand WHERE ora_code = 979 AND src = 'AWR')
GROUP  BY h.sql_id, o.owner, o.object_name, o.object_type, h.program, h.machine, h.module
ORDER  BY h.sql_id, ash_ornek DESC;


-- R6. Bulunanları dışa aktarma (uzun vadeli sisteme taşımak için)
--     SQL Developer'da sonucu CSV/JSON olarak kaydedebilirsiniz.
SELECT parsing_schema, sql_id, src, obj_owner, obj_name, module, execs, sql_text
FROM   &&WRK..q979_cand
WHERE  ora_code = 979;


-- =====================================================================
-- TEMİZLİK (sonuçları aldıktan sonra)
-- =====================================================================
-- DROP PROCEDURE &&WRK..q979_run;
-- DROP TABLE &&WRK..q979_cand PURGE;
-- DROP DATABASE LINK adg_ro;
