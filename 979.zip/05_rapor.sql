-- =====================================================================
-- 05_rapor.sql
-- Nerede : LAB, REPO979 şeması ile
-- Amaç   : Test sonuçlarından etkilenen yapıları çıkarmak
-- =====================================================================
ALTER SESSION SET CURRENT_SCHEMA = repo979;

-- R1. Genel durum: ortam x mod x sonuç
SELECT test_env, test_mode, status, ora_code, COUNT(*) adet
FROM   test_result
GROUP  BY test_env, test_mode, status, ora_code
ORDER  BY test_env, test_mode, adet DESC;

-- R2. Envanterin kapsaması: kaynak tipine göre kaç SQL var, kaçı test edildi
SELECT r.source_type,
       COUNT(DISTINCT r.inv_id)                                          sql_sayisi,
       COUNT(DISTINCT CASE WHEN t.inv_id IS NOT NULL THEN r.inv_id END)  test_edilen
FROM   sql_source_ref r
LEFT JOIN test_result t ON t.inv_id = r.inv_id
GROUP  BY r.source_type
ORDER  BY 2 DESC;

-- R3. Bağlam gürültüsü: bunlar ORA-00979 değil, test bağlamı hatası.
--     Yüksek sayılar parsing schema / yetki / synonym / db link eksikliğine işaret eder.
--     Düzeltip ilgili SQL'leri --retest ile tekrar koşun.
SELECT test_env, ora_code, SUBSTR(MIN(ora_message), 1, 120) ornek_mesaj, COUNT(*) adet
FROM   test_result
WHERE  status = 'ERROR'
AND    ora_code IN (942, 904, 1031, 2019, 980, 6550, 16000, 1008, 911, 933)
GROUP  BY test_env, ora_code
ORDER  BY adet DESC;

-- R4. Hedef liste: 19.32'de ORA-00979 veren her SQL ve kaynakları
SELECT t.test_env, t.test_mode, i.inv_id, i.parsing_schema, i.sql_id, i.stmt_type,
       r.source_type, r.obj_owner, r.obj_name, r.obj_type, r.line_no, r.module, r.executions,
       DBMS_LOB.SUBSTR(i.sql_text, 300, 1) sql_bas
FROM   test_result t
JOIN   sql_inventory i ON i.inv_id = t.inv_id
LEFT JOIN sql_source_ref r ON r.inv_id = i.inv_id
WHERE  t.ora_code = 979
AND    t.test_env LIKE '%1932%'
ORDER  BY i.parsing_schema, r.obj_name, r.line_no;

-- R5. 19.29 teyidi gerekenler: ORA-00979 veren ama prod cursor cache'te
--     çalışmış olduğu (executions > 0) kanıtlanmamış SQL'ler.
--     Bunları prod'da EXPLAIN ile teyit edin:
--       python ora979_tool.py run --env PROD_1929 --mode explain --failed-in ADG_1932:979 ...
SELECT DISTINCT i.inv_id, i.parsing_schema
FROM   test_result t
JOIN   sql_inventory i ON i.inv_id = t.inv_id
WHERE  t.ora_code = 979
AND    t.test_env LIKE '%1932%'
AND    NOT EXISTS (SELECT 1 FROM sql_source_ref r
                   WHERE r.inv_id = i.inv_id
                   AND   r.source_type IN ('CURSOR_CACHE','AWR')
                   AND   NVL(r.executions, 0) > 0);

-- R6. Kesinleşmiş regresyonlar: 19.32'de 979, 19.29'da hatasız
--     (prod cursor cache'te çalışmış olanlar otomatik olarak teyitli sayılır)
CREATE OR REPLACE VIEW v_regression_979 AS
SELECT DISTINCT i.inv_id
FROM   test_result t
JOIN   sql_inventory i ON i.inv_id = t.inv_id
WHERE  t.ora_code = 979
AND    t.test_env LIKE '%1932%'
AND   (EXISTS (SELECT 1 FROM sql_source_ref r
               WHERE r.inv_id = i.inv_id
               AND   r.source_type IN ('CURSOR_CACHE','AWR')
               AND   NVL(r.executions, 0) > 0)
       OR EXISTS (SELECT 1 FROM test_result p
                  WHERE p.inv_id = i.inv_id
                  AND   p.test_env = 'PROD_1929'
                  AND   p.status = 'OK'));

-- R7. ETKİLENEN YAPILAR — PL/SQL birimleri (paket/prosedür/trigger + satır)
SELECT r.obj_owner, r.obj_name, r.obj_type,
       COUNT(DISTINCT x.inv_id)                                       sorgu_sayisi,
       LISTAGG(DISTINCT r.line_no, ',') WITHIN GROUP (ORDER BY r.line_no) satirlar
FROM   v_regression_979 x
JOIN   sql_source_ref r ON r.inv_id = x.inv_id
WHERE  r.obj_type IN ('PACKAGE BODY','PACKAGE','PROCEDURE','FUNCTION','TRIGGER','TYPE BODY')
GROUP  BY r.obj_owner, r.obj_name, r.obj_type
ORDER  BY sorgu_sayisi DESC;

-- R8. ETKİLENEN YAPILAR — view ve materialized view'lar
SELECT r.obj_owner, r.obj_name, r.source_type
FROM   v_regression_979 x
JOIN   sql_source_ref r ON r.inv_id = x.inv_id
WHERE  r.source_type IN ('VIEW','MVIEW')
ORDER  BY 1, 2;

-- R9. ETKİLENEN YAPILAR — dışarıdan gelen sorgular, uygulama bazında
--     (PL/SQL'den gelmeyen, cursor cache'te görülen SQL'ler)
SELECT NVL(c.program, '?') program, NVL(c.machine, '?') machine,
       NVL(c.service_name, '?') servis, NVL(c.username, i.parsing_schema) kullanici,
       COUNT(DISTINCT x.inv_id) sorgu_sayisi
FROM   v_regression_979 x
JOIN   sql_inventory i ON i.inv_id = x.inv_id
JOIN   sql_source_ref r ON r.inv_id = x.inv_id AND r.source_type = 'CURSOR_CACHE'
LEFT JOIN sql_client_seen c ON c.sql_id = r.sql_id
WHERE  NOT EXISTS (SELECT 1 FROM sql_source_ref p
                   WHERE p.inv_id = x.inv_id AND p.obj_type IN
                   ('PACKAGE BODY','PACKAGE','PROCEDURE','FUNCTION','TRIGGER','TYPE BODY'))
GROUP  BY c.program, c.machine, c.service_name, NVL(c.username, i.parsing_schema)
ORDER  BY sorgu_sayisi DESC;

-- R10. Kalibrasyon: EXPLAIN ile EXECUTE farklı sonuç verdi mi?
--      Bu sorgu boş dönmüyorsa EXPLAIN tek başına yeterli değildir;
--      EXECUTE katmanı aday kümesinin tamamına genişletilmelidir.
SELECT e.inv_id, e.test_env,
       e.status ex_status, e.ora_code ex_code,
       x.status exe_status, x.ora_code exe_code, x.bind_source
FROM   test_result e
JOIN   test_result x ON x.inv_id = e.inv_id AND x.test_mode = 'EXECUTE'
WHERE  e.test_mode = 'EXPLAIN'
AND   (NVL(e.ora_code, 0) = 979 OR NVL(x.ora_code, 0) = 979)
AND    NVL(e.ora_code, 0) <> NVL(x.ora_code, 0);

-- R11. Ön eleme kuralının doğrulaması: 979 veren ama aday işaretlenmemiş
--      SQL olmamalı. Satır dönüyorsa kural genişletilmeli.
SELECT i.inv_id, i.parsing_schema, i.cand_flag, i.cand_reason
FROM   v_regression_979 x
JOIN   sql_inventory i ON i.inv_id = x.inv_id
WHERE  NVL(i.cand_flag, 'N') <> 'Y';
