-- =====================================================================
-- q979_hizli_kurulum.sql  —  ORA-00979 hızlı tarama (30-60 dk)
--
-- Nerede : SADECE PREPROD (19.32). Prod'da hiçbir şey çalışmaz.
--          Prod'un SQL metinleri ADG'deki AWR kopyasından okunur.
-- Ne yapar: Prod'un en çok çalışan GROUP BY'lı sorgularını ve preprod
--          view'larını preprod'da EXPLAIN PLAN ile test eder.
--          EXPLAIN sorguyu çalıştırmaz, veri okumaz; sadece parse/optimize eder.
-- Yük    : Tek oturum, süre sınırı, her sorgu arasında bekleme.
--
-- Hepsini TEK bir DBA kullanıcısıyla, SQL*Plus / SQLcl / SQL Developer'da
-- sırayla çalıştırın. Aşağıdaki WRK değerini o kullanıcının adı yapın.
-- Lisans notu: DBA_HIST_* sorgulamak Diagnostics Pack gerektirir.
-- =====================================================================
DEFINE WRK = DBA_OPS
SET SERVEROUTPUT ON SIZE UNLIMITED


-- =====================================================================
-- ADIM 0 — Kalibrasyon (2 dk)
-- Preprod'da hata verdiğini bildiğiniz BİR sorguyu alın ve EXPLAIN atın.
-- ORA-00979 geliyorsa yöntem geçerli, devam edin.
-- Gelmiyorsa DURUN: bu hata EXPLAIN aşamasında çıkmıyor demektir.
-- =====================================================================
-- ALTER SESSION SET CURRENT_SCHEMA = <sorgunun_semasi>;
-- EXPLAIN PLAN FOR <bilinen_hatali_sorgu>;
-- ROLLBACK;
-- ALTER SESSION SET CURRENT_SCHEMA = &&WRK;

-- (Bonus, 1 dk) Preprod'da zaten sık tekrarlanmış ORA-00979 parse hataları.
-- 19c, çok tekrarlanan parse hatalarını SQL metniyle alert log'a yazar.
SELECT originating_timestamp, SUBSTR(message_text, 1, 2000) mesaj
FROM   v$diag_alert_ext
WHERE  originating_timestamp > SYSDATE - 30
AND    message_text LIKE '%error=979%'
ORDER  BY originating_timestamp DESC;


-- =====================================================================
-- ADIM 1 — Kurulum (5 dk)
-- =====================================================================

-- 1a. ADG'ye salt okuma DB link'i (prod'da mevcut bir okuma kullanıcısı yeterli;
--     prod'da yeni obje oluşturulmaz).
CREATE DATABASE LINK adg_ro
  CONNECT TO <okuma_kullanicisi> IDENTIFIED BY "<sifre>"
  USING '<ADG_TNS_veya_host:port/servis>';

-- Güvenlik kontrolü: PHYSICAL STANDBY / READ ONLY WITH APPLY görmelisiniz.
-- PRIMARY görürseniz DURUN, link prod'a bakıyor.
SELECT database_role, open_mode FROM v$database@adg_ro;

-- 1b. Çalışma tablosu
CREATE TABLE &&WRK..q979_cand (
  id             NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  src            VARCHAR2(10),      -- AWR / VIEW
  prio           NUMBER,            -- 1 = en olası yapı
  parsing_schema VARCHAR2(128),
  sql_id         VARCHAR2(13),
  fms            NUMBER,
  module         VARCHAR2(64),
  execs          NUMBER,            -- prod'daki çalışma sayısı (AWR)
  obj_owner      VARCHAR2(128),
  obj_name       VARCHAR2(128),
  sql_text       CLOB,
  status         VARCHAR2(10),      -- NULL = test edilmedi / OK / ERROR
  ora_code       NUMBER,
  ora_msg        VARCHAR2(4000),
  elapsed_ms     NUMBER,
  tested_at      DATE
);
CREATE INDEX &&WRK..q979_cand_ix ON &&WRK..q979_cand (status, prio);


-- =====================================================================
-- ADIM 2 — Adayları yükle (5-10 dk)
-- =====================================================================

-- 2a. Prod AWR'deki GROUP BY'lı sorgular (ADG üzerinden okunur)
INSERT INTO &&WRK..q979_cand (src, parsing_schema, sql_id, fms, module, execs, sql_text)
SELECT 'AWR', s.parsing_schema_name, t.sql_id, s.fms, s.module, s.execs, t.sql_text
FROM   dba_hist_sqltext@adg_ro t
JOIN  (SELECT dbid, sql_id,
              MAX(parsing_schema_name)      parsing_schema_name,
              MAX(module)                   module,
              MAX(force_matching_signature) fms,
              SUM(executions_delta)         execs
       FROM   dba_hist_sqlstat@adg_ro
       GROUP  BY dbid, sql_id) s
  ON   s.dbid = t.dbid AND s.sql_id = t.sql_id
WHERE  t.dbid = (SELECT dbid FROM v$database@adg_ro)
AND    t.command_type IN (2, 3, 6, 7, 189)          -- INSERT, SELECT, UPDATE, DELETE, MERGE
AND    s.parsing_schema_name NOT IN (SELECT username FROM dba_users@adg_ro WHERE oracle_maintained = 'Y')
AND    REGEXP_LIKE(t.sql_text, 'GROUP\s+BY', 'i');
COMMIT;

-- 2b. Sadece literal'i farklı kopyaları ele: imza başına en çok çalışan 2 tane kalsın
DELETE FROM &&WRK..q979_cand
WHERE  rowid IN (
  SELECT rid FROM (
    SELECT rowid rid,
           ROW_NUMBER() OVER (PARTITION BY parsing_schema,
                                           CASE WHEN NVL(fms, 0) = 0 THEN sql_id ELSE TO_CHAR(fms) END
                              ORDER BY execs DESC NULLS LAST) rn
    FROM   &&WRK..q979_cand
    WHERE  src = 'AWR')
  WHERE rn > 2);
COMMIT;

-- 2c. Önceliklendir: GROUP BY + inline view / WITH (forumdaki yapı) = 1, diğer GROUP BY = 2
UPDATE &&WRK..q979_cand
SET    prio = CASE
                WHEN REGEXP_LIKE(sql_text, '(FROM|JOIN|,)\s*\(\s*(SELECT|WITH)', 'i')
                  OR REGEXP_LIKE(sql_text, 'WITH\s+"?[A-Za-z0-9_$#]+"?\s+AS\s*\(', 'i') THEN 1
                ELSE 2
              END
WHERE  src = 'AWR';
COMMIT;

-- 2d. Preprod'daki uygulama view'ları: "SELECT * FROM view" olarak test edilir
INSERT INTO &&WRK..q979_cand (src, prio, parsing_schema, obj_owner, obj_name, sql_text)
SELECT 'VIEW',
       CASE
         WHEN REGEXP_LIKE(text_vc, 'GROUP\s+BY', 'i')
          AND (REGEXP_LIKE(text_vc, '(FROM|JOIN|,)\s*\(\s*(SELECT|WITH)', 'i')
               OR REGEXP_LIKE(text_vc, 'WITH\s+"?[A-Za-z0-9_$#]+"?\s+AS\s*\(', 'i')) THEN 1
         WHEN REGEXP_LIKE(text_vc, 'GROUP\s+BY', 'i')       THEN 2
         WHEN REGEXP_LIKE(text_vc, 'DISTINCT|UNIQUE', 'i')  THEN 3
         ELSE 4
       END,
       owner, owner, view_name,
       'SELECT * FROM "' || owner || '"."' || view_name || '"'
FROM   dba_views
WHERE  owner IN (SELECT username FROM dba_users WHERE oracle_maintained = 'N')
AND    owner <> '&&WRK';
COMMIT;

-- 2e. Kaç aday var? (süreyi buna göre ayarlayın)
SELECT src, prio, COUNT(*) adet, SUM(execs) prod_calisma
FROM   &&WRK..q979_cand
GROUP  BY src, prio
ORDER  BY src, prio;


-- =====================================================================
-- ADIM 3 — Test prosedürü
-- AUTHID CURRENT_USER: DBA rolünüzün yetkileriyle çalışır, böylece her
-- şemanın sorgusu EXPLAIN edilebilir.
-- =====================================================================
CREATE OR REPLACE PROCEDURE &&WRK..q979_run (
  p_minutes  IN NUMBER      DEFAULT 30,    -- süre sınırı (dk), dolunca kendiliğinden durur
  p_sleep    IN NUMBER      DEFAULT 0.02,  -- her EXPLAIN arası bekleme (sn)
  p_max_prio IN PLS_INTEGER DEFAULT 3,     -- 4 = DISTINCT/GROUP BY içermeyen view'lar da
  p_workers  IN PLS_INTEGER DEFAULT 1,     -- paralel oturum sayısı (her oturum farklı p_worker ile)
  p_worker   IN PLS_INTEGER DEFAULT 0
) AUTHID CURRENT_USER IS
  l_end  DATE := SYSDATE + p_minutes / 1440;
  l_t0   NUMBER;
  l_code NUMBER;
  l_msg  VARCHAR2(4000);
  l_n    PLS_INTEGER := 0;
  l_hit  PLS_INTEGER := 0;

  -- Sonuç yazımı ayrı işlemde: EXPLAIN sonrası ROLLBACK onu geri almasın
  PROCEDURE save(p_id NUMBER, p_code NUMBER, p_msg VARCHAR2, p_ms NUMBER) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    UPDATE &&WRK..q979_cand
    SET    status = CASE WHEN p_code IS NULL THEN 'OK' ELSE 'ERROR' END,
           ora_code = p_code, ora_msg = p_msg, elapsed_ms = p_ms, tested_at = SYSDATE
    WHERE  id = p_id;
    COMMIT;
  END;

  -- Sürücü bind değeri isterse (ORA-01008) yer tutucuları NULL ile doldurup tekrar dener.
  -- EXPLAIN bind değerine zaten bakmaz.
  PROCEDURE explain_null_binds(p_stmt CLOB) IS
    c  INTEGER := DBMS_SQL.OPEN_CURSOR;
    nm VARCHAR2(200);
    i  PLS_INTEGER := 1;
    d  INTEGER;
  BEGIN
    DBMS_SQL.PARSE(c, p_stmt, DBMS_SQL.NATIVE);
    LOOP
      nm := REGEXP_SUBSTR(p_stmt, ':("[^"]+"|[A-Za-z0-9_$#]+)', 1, i);
      EXIT WHEN nm IS NULL;
      BEGIN
        DBMS_SQL.BIND_VARIABLE(c, nm, CAST(NULL AS VARCHAR2));
      EXCEPTION WHEN OTHERS THEN NULL;   -- literal içindeki ':' gibi sahte eşleşmeler
      END;
      i := i + 1;
    END LOOP;
    d := DBMS_SQL.EXECUTE(c);
    DBMS_SQL.CLOSE_CURSOR(c);
  EXCEPTION WHEN OTHERS THEN
    IF DBMS_SQL.IS_OPEN(c) THEN DBMS_SQL.CLOSE_CURSOR(c); END IF;
    RAISE;
  END;

BEGIN
  FOR r IN (SELECT id, parsing_schema, sql_text
            FROM   &&WRK..q979_cand
            WHERE  status IS NULL
            AND    prio <= p_max_prio
            AND    MOD(id, p_workers) = p_worker
            ORDER  BY prio, execs DESC NULLS LAST, id) LOOP
    EXIT WHEN SYSDATE > l_end;
    l_t0 := DBMS_UTILITY.GET_TIME;
    l_code := NULL;
    l_msg := NULL;
    BEGIN
      EXECUTE IMMEDIATE 'ALTER SESSION SET CURRENT_SCHEMA = "' || r.parsing_schema || '"';
      BEGIN
        EXECUTE IMMEDIATE 'EXPLAIN PLAN SET STATEMENT_ID = ''Q979'' FOR ' || r.sql_text;
      EXCEPTION WHEN OTHERS THEN
        IF SQLCODE = -1008 THEN
          explain_null_binds('EXPLAIN PLAN SET STATEMENT_ID = ''Q979'' FOR ' || r.sql_text);
        ELSE
          RAISE;
        END IF;
      END;
    EXCEPTION WHEN OTHERS THEN
      l_code := -SQLCODE;
      l_msg  := SUBSTR(SQLERRM, 1, 4000);
    END;
    ROLLBACK;   -- plan tablosu satırlarını temizler
    save(r.id, l_code, l_msg, (DBMS_UTILITY.GET_TIME - l_t0) * 10);
    l_n := l_n + 1;
    IF l_code = 979 THEN l_hit := l_hit + 1; END IF;
    IF p_sleep > 0 THEN DBMS_SESSION.SLEEP(p_sleep); END IF;
  END LOOP;
  EXECUTE IMMEDIATE 'ALTER SESSION SET CURRENT_SCHEMA = "' || SYS_CONTEXT('USERENV','SESSION_USER') || '"';
  DBMS_OUTPUT.PUT_LINE('Test edilen: ' || l_n || ', ORA-00979: ' || l_hit);
END;
/


-- =====================================================================
-- ADIM 3 — Çalıştır (30 dk)
-- Kapanmayacak bir oturumda çalıştırın. Yarıda kalırsa aynı komutu tekrar
-- verin; test edilmemiş olanlardan devam eder.
-- İlerlemeyi başka bir oturumda q979_hizli_rapor.sql ile izleyin.
-- =====================================================================
EXEC &&WRK..q979_run(p_minutes => 30, p_sleep => 0.02);

-- Daha hızlı isterseniz iki ayrı oturumda:
--   oturum 1: EXEC &&WRK..q979_run(p_minutes => 30, p_workers => 2, p_worker => 0);
--   oturum 2: EXEC &&WRK..q979_run(p_minutes => 30, p_workers => 2, p_worker => 1);
