-- =====================================================================
-- 03_lab_hazirlik.sql
-- Amaç : Prod'un VERİSİZ ama istatistikli bir kopyasını 19.32 lab'de kurmak.
--        Tablolar boş olduğu için sorgular değiştirilmeden, maliyetsiz
--        çalıştırılabilir; istatistikler prod'dan geldiği için optimizer
--        prod'daki gibi karar verir (ORA-00979'u tetikleyen dönüşümler dahil).
--
-- Lab gereksinimi: preprod ile AYNI RU ve AYNI one-off seti (19.32),
--                  prod ile aynı karakter seti.
-- =====================================================================


-- #####################################################################
-- BÖLÜM A — ADG üzerinde çalıştırılacak DDL üreticiler (spool alın)
-- #####################################################################

-- A1. Tablespace'ler (lab'de db_create_file_dest ayarlı olmalı)
SELECT 'CREATE BIGFILE TABLESPACE "' || tablespace_name ||
       '" DATAFILE SIZE 100M AUTOEXTEND ON NEXT 100M;'
FROM   dba_tablespaces
WHERE  contents = 'PERMANENT'
AND    tablespace_name NOT IN ('SYSTEM','SYSAUX','USERS');

SELECT 'CREATE BIGFILE TEMPORARY TABLESPACE "' || tablespace_name ||
       '" TEMPFILE SIZE 100M AUTOEXTEND ON NEXT 100M;'
FROM   dba_tablespaces
WHERE  contents = 'TEMPORARY'
AND    tablespace_name <> 'TEMP';

-- A2. Roller (şema modu export rolleri getirmez)
SELECT 'CREATE ROLE "' || role || '";'
FROM   dba_roles
WHERE  oracle_maintained = 'N';

-- A3. Uygulama context'leri (VPD politikaları kullanıyorsa gerekli)
SELECT 'CREATE OR REPLACE CONTEXT ' || namespace || ' USING "' || schema || '"."' || package || '";'
FROM   dba_context
WHERE  schema IN (SELECT username FROM dba_users WHERE oracle_maintained = 'N');

-- A4. Public synonym'ler (şema modu getirmez; import SONRASI çalıştırın)
SELECT 'CREATE OR REPLACE PUBLIC SYNONYM "' || synonym_name || '" FOR "' ||
       table_owner || '"."' || table_name || '";'
FROM   dba_synonyms
WHERE  owner = 'PUBLIC'
AND    db_link IS NULL
AND    table_owner IN (SELECT username FROM dba_users WHERE oracle_maintained = 'N');

-- A5. Uygulama şema listesi (expdp SCHEMAS= için)
SELECT LISTAGG(username, ',') WITHIN GROUP (ORDER BY username)
FROM   dba_users
WHERE  oracle_maintained = 'N';


-- #####################################################################
-- BÖLÜM B — PROD (primary) üzerinde: optimizer'ı etkileyen parametreler
-- Bu sorgu sadece okuma yapar. Çıkan değerleri lab'de AYNEN set edin.
-- Prod'da halihazırda set edilmiş gizli parametre varsa onlar da listelenir;
-- lab'e taşımak yeni parametre ellemek değil, prod'u birebir yansıtmaktır.
-- #####################################################################
SELECT name, value
FROM   v$parameter
WHERE  isdefault = 'FALSE'
AND   (name LIKE 'optimizer%'
       OR name LIKE '\_%' ESCAPE '\'
       OR name IN ('cursor_sharing','db_file_multiblock_read_count',
                   'query_rewrite_enabled','query_rewrite_integrity',
                   'star_transformation_enabled','statistics_level',
                   'nls_sort','nls_comp','nls_date_format','nls_language',
                   'nls_territory','compatible','parallel_degree_policy'))
ORDER  BY name;


-- #####################################################################
-- BÖLÜM C — Lab'de import (işletim sistemi kabuğunda)
-- #####################################################################
-- C1. Lab'de ADG'ye bakan geçici DB link (import sonrası SİLİNECEK):
--   CREATE DATABASE LINK adg_link CONNECT TO <dp_kullanici> IDENTIFIED BY <sifre> USING '<ADG_TNS>';
--   Not: Kaynak read-only olabilir; kaynak kullanıcının default temporary
--   tablespace'i locally managed olmalıdır.
--
-- C2. Bölüm A'daki tablespace / rol / context DDL'lerini lab'de çalıştırın.
--
-- C3. Metadata export (veri yok, istatistikler varsayılan olarak dahil):
--   expdp system NETWORK_LINK=adg_link SCHEMAS=<A5 listesi> CONTENT=METADATA_ONLY \
--         DIRECTORY=dp_dir DUMPFILE=prodmeta_%U.dmp LOGFILE=prodmeta_exp.log PARALLEL=4
--
-- C4. Import (DB link ve job'lar hariç, segment oluşturulmadan):
--   impdp system DIRECTORY=dp_dir DUMPFILE=prodmeta_%U.dmp LOGFILE=prodmeta_imp.log \
--         EXCLUDE=DB_LINK EXCLUDE=PROCOBJ EXCLUDE=JOB \
--         TRANSFORM=SEGMENT_CREATION:N PARALLEL=4
--
-- C5. Bölüm A4 (public synonym) çıktısını çalıştırın.
-- C6. DROP DATABASE LINK adg_link;


-- #####################################################################
-- BÖLÜM D — Lab'de import sonrası güvenlik ve sabitleme (DBA ile)
-- #####################################################################

-- D1. Hiçbir job çalışmasın
ALTER SYSTEM SET job_queue_processes = 0 SCOPE = BOTH;

-- D2. Otomatik istatistik ve tuning görevleri kapalı
BEGIN
  DBMS_AUTO_TASK_ADMIN.DISABLE('auto optimizer stats collection', NULL, NULL);
  DBMS_AUTO_TASK_ADMIN.DISABLE('sql tuning advisor', NULL, NULL);
END;
/

-- D3. Prod istatistikleri kilitlensin (boş tabloya yeniden toplanmasın)
BEGIN
  FOR s IN (SELECT username FROM dba_users
            WHERE oracle_maintained = 'N'
            AND   username NOT IN ('REPO979','PROBE979')) LOOP
    DBMS_STATS.LOCK_SCHEMA_STATS(s.username);
  END LOOP;
END;
/

-- D4. Kontroller: hepsi 0 dönmeli
SELECT COUNT(*) db_link_sayisi FROM dba_db_links;
SELECT COUNT(*) aktif_job      FROM dba_scheduler_jobs
WHERE  enabled = 'TRUE' AND owner NOT IN (SELECT username FROM dba_users WHERE oracle_maintained = 'Y');
-- Dizinler ve network ACL'leri: lab dışına çıkış olmadığını gözle kontrol edin
SELECT directory_name, directory_path FROM dba_directories ORDER BY 1;
SELECT host, lower_port, upper_port, acl FROM dba_network_acls;

-- D5. Bölüm B'deki parametreleri ALTER SYSTEM ile lab'e uygulayın.

-- D6. Kalan geçersiz objeler (DB link'e bağlı olanlar beklenen gürültüdür)
@?/rdbms/admin/utlrp.sql
SELECT owner, object_type, COUNT(*)
FROM   dba_objects
WHERE  status = 'INVALID'
AND    owner IN (SELECT username FROM dba_users WHERE oracle_maintained = 'N')
GROUP  BY owner, object_type
ORDER  BY 3 DESC;


-- #####################################################################
-- BÖLÜM E — PL/Scope ile PL/SQL içindeki tüm statik SQL'leri çıkarmak
-- #####################################################################

-- E1. Bütün uygulama kodunu PL/Scope açık şekilde yeniden derle
ALTER SYSTEM SET plsql_scope_settings = 'STATEMENTS:ALL' SCOPE = BOTH;

BEGIN
  FOR s IN (SELECT username FROM dba_users
            WHERE oracle_maintained = 'N'
            AND   username NOT IN ('REPO979','PROBE979')) LOOP
    DBMS_UTILITY.COMPILE_SCHEMA(schema         => s.username,
                                compile_all    => TRUE,
                                reuse_settings => FALSE);
  END LOOP;
END;
/

-- E2. Kontrol: derlenen birimlerin hepsinde STATEMENTS:ALL görünmeli
SELECT plsql_scope_settings, COUNT(*)
FROM   dba_plsql_object_settings
WHERE  owner IN (SELECT username FROM dba_users WHERE oracle_maintained = 'N')
GROUP  BY plsql_scope_settings;

-- E3. Kaç statik SQL çıktı
SELECT type, COUNT(*)
FROM   dba_statements
WHERE  owner IN (SELECT username FROM dba_users WHERE oracle_maintained = 'N')
GROUP  BY type
ORDER  BY 2 DESC;
-- Envantere alma: python ora979_tool.py ingest-plscope


-- #####################################################################
-- BÖLÜM F — Dinamik SQL kuran PL/SQL birimleri (LLM ile çözülecek liste)
-- Statik SQL olmayan, metni çalışma anında birleştirilen sorgular
-- PL/Scope'ta tam metin olarak görünmez. Bu birimlerin kaynak kodu
-- local LLM'e verilir, olası SQL şablonları JSONL olarak üretilir.
-- #####################################################################
SELECT s.owner, s.name, s.type,
       COUNT(*)                                                     dinamik_nokta,
       MAX(CASE WHEN REGEXP_LIKE(s.text, 'GROUP\s+BY|DISTINCT|UNIQUE|PIVOT', 'i') THEN 'Y' END) gruplama_izi
FROM   dba_source s
WHERE  s.owner IN (SELECT username FROM dba_users WHERE oracle_maintained = 'N')
AND    REGEXP_LIKE(s.text, 'EXECUTE\s+IMMEDIATE|DBMS_SQL\s*\.\s*PARSE|OPEN\s+\w+\s+FOR\s+[^S\s]', 'i')
GROUP  BY s.owner, s.name, s.type
ORDER  BY 4 DESC;
-- Not: "gruplama_izi" boş olsa bile dinamik SQL'in parçaları başka satırda
-- veya başka bir birimde olabilir; listeyi elemek için değil önceliklendirmek
-- için kullanın.
